"""Turn the identifier from fixture-green into evidence, or kill it.

`identify.py` is currently scored only against synthetic fixtures written by
the same person who wrote the scorer. That is the condition under which a
scorer looks better than it is. This module runs it against real recorded
sessions and reports whether it holds up.

**The protocol is enforced here in code, not asked for in a document.** Margin
measures the scorer's *confidence*, not its *correctness* — a confidently
wrong pick and a confidently right one look identical. So the only thing that
turns a run into evidence is a human saying which response really carried the
data, **before** seeing what the scorer chose. Three rules make that
mechanical:

1. ``score`` refuses to run on an unlabelled session.
2. ``label`` refuses to overwrite an existing label.
3. ``label`` lists candidates in **capture order with no scores shown** — if it
   ranked them, the ordering would leak the scorer's answer to the labeller and
   there would be no ground truth left.

Usage::

    falsifier record https://app.example.com/things --label "things list"
    falsifier label  app.example.com-things-list
    falsifier score  app.example.com-things-list
    falsifier report
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import statistics
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from . import login, recorder, vault
from .browser import session_for
from .identify import RecordedResponse, RecordedSession, identify_data_response
from .paths import home, write_private

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def runs_dir() -> Path:
    d = home() / "falsifier"
    d.mkdir(parents=True, exist_ok=True)
    # Recordings hold real page content from an authenticated session. Match
    # the 0700 that paths.home() already enforces on the store root.
    os.chmod(d, 0o700)
    return d


def slugify(host: str, task_label: str) -> str:
    joined = f"{host}-{task_label}".casefold()
    return _SLUG_RE.sub("-", joined).strip("-")[:80] or "run"


def run_dir(run_id: str) -> Path:
    return runs_dir() / run_id


class ProtocolError(RuntimeError):
    """An action that would have destroyed the run's evidential value."""


# --------------------------------------------------------------------------
# Storage
# --------------------------------------------------------------------------


def save_session(session: RecordedSession, run_id: str) -> Path:
    """Persist a recording. Refuses to clobber a run that is already labelled."""
    d = run_dir(run_id)
    if (d / "truth.json").exists():
        raise ProtocolError(
            f"{run_id} is already labelled — re-recording it would let the "
            "recording be changed after the ground truth was fixed. Delete the "
            "run explicitly if that is really what you want."
        )
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o700)
    payload = {
        "host": session.host,
        "task_label": session.task_label,
        "page_url": session.page_url,
        "rendered_text": session.rendered_text,
        "dropped": session.dropped,
        "responses": [asdict(r) for r in session.responses],
    }
    # write_private, not write_text: a recording is authenticated page content
    # and captured request bodies. It must never be world-readable, and the
    # atomic 0600 create leaves no window where it is.
    write_private(d / "session.json", json.dumps(payload, indent=2))
    return d / "session.json"


def load_session(run_id: str) -> RecordedSession:
    path = run_dir(run_id) / "session.json"
    if not path.exists():
        raise ProtocolError(f"no recording for {run_id} — run `falsifier record` first")
    raw = json.loads(path.read_text(encoding="utf-8"))
    return RecordedSession(
        host=str(raw.get("host", "")),
        task_label=str(raw.get("task_label", "")),
        page_url=str(raw.get("page_url", "")),
        rendered_text=str(raw.get("rendered_text", "")),
        dropped=int(raw.get("dropped", 0) or 0),
        responses=[RecordedResponse(**r) for r in raw.get("responses", [])],
    )


@dataclass(frozen=True)
class Truth:
    """What a human said, before seeing the scorer's opinion."""

    run_id: str
    #: seq of the response that really carried the data, or None for
    #: "no single response did" — which is a legitimate and important answer.
    true_seq: int | None
    note: str = ""


def save_truth(truth: Truth) -> Path:
    path = run_dir(truth.run_id) / "truth.json"
    if path.exists():
        raise ProtocolError(
            f"{truth.run_id} is already labelled and labels are immutable. "
            "Re-labelling after seeing a score is how a falsifier stops being one."
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    write_private(path, json.dumps(asdict(truth), indent=2))
    return path


def load_truth(run_id: str) -> Truth | None:
    path = run_dir(run_id) / "truth.json"
    if not path.exists():
        return None
    raw = json.loads(path.read_text(encoding="utf-8"))
    seq = raw.get("true_seq")
    return Truth(
        run_id=str(raw.get("run_id", run_id)),
        true_seq=None if seq is None else int(seq),
        note=str(raw.get("note", "")),
    )


# --------------------------------------------------------------------------
# Labelling — deliberately shows no scores and no ranking
# --------------------------------------------------------------------------


def labelling_view(session: RecordedSession) -> list[dict[str, Any]]:
    """Candidates in CAPTURE ORDER, with no score and no rank.

    Ranking here would hand the labeller the scorer's answer and there would be
    no independent ground truth left. Order is ``seq`` and nothing else.
    """
    view: list[dict[str, Any]] = []
    for r in sorted(session.responses, key=lambda x: x.seq):
        body = r.resp_body or ""
        view.append(
            {
                "seq": r.seq,
                "method": r.method,
                "status": r.status,
                "url": r.url[:160],
                "content_type": (r.resp_content_type or "").split(";")[0],
                "bytes": len(body),
                "body_captured": r.body_captured,
                "body_skip_reason": r.body_skip_reason,
                "preview": body[:400].replace("\n", " ") if body else "",
            }
        )
    return view


# --------------------------------------------------------------------------
# Scoring — only after a label exists
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class RunResult:
    run_id: str
    host: str
    task_label: str
    #: None when the labeller said no single response carried the data.
    true_seq: int | None
    picked_seq: int | None
    correct: bool
    margin: float
    top_score: float
    candidates_scored: int
    dropped: int
    #: True when the recording was partial, so its numbers are not comparable.
    partial: bool


def score_run(run_id: str) -> RunResult:
    """Score one labelled run. Raises if it has not been labelled yet."""
    session = load_session(run_id)
    truth = load_truth(run_id)
    if truth is None:
        raise ProtocolError(
            f"{run_id} has no ground truth. Run `falsifier label {run_id}` first — "
            "scoring before labelling means the label can be influenced by the "
            "score, and the run stops being evidence."
        )
    ranking = identify_data_response(session)
    best = ranking.best
    picked = best.response.seq if best is not None else None
    return RunResult(
        run_id=run_id,
        host=session.host,
        task_label=session.task_label,
        true_seq=truth.true_seq,
        picked_seq=picked,
        correct=(picked == truth.true_seq),
        margin=ranking.margin,
        top_score=best.score if best is not None else 0.0,
        candidates_scored=len(ranking.ranked),
        dropped=session.dropped,
        partial=session.dropped > 0,
    )


def all_run_ids() -> list[str]:
    return sorted(p.name for p in runs_dir().iterdir() if (p / "session.json").exists())


@dataclass(frozen=True)
class Report:
    results: list[RunResult]
    unlabelled: list[str]

    @property
    def scored(self) -> list[RunResult]:
        return self.results

    @property
    def correct_count(self) -> int:
        return sum(1 for r in self.results if r.correct)

    @property
    def margins(self) -> list[float]:
        return sorted(r.margin for r in self.results)

    def thin_margins(self, threshold: float = 0.10) -> list[RunResult]:
        """The tail that decides the verdict.

        A good mean with three near-zero margins means auto-selection cannot be
        trusted exactly where it matters, and an average would hide that.
        """
        return [r for r in self.results if r.margin < threshold]


def build_report() -> Report:
    results: list[RunResult] = []
    unlabelled: list[str] = []
    for run_id in all_run_ids():
        if load_truth(run_id) is None:
            unlabelled.append(run_id)
            continue
        results.append(score_run(run_id))
    return Report(results=results, unlabelled=unlabelled)


def format_report(report: Report) -> str:
    """Human-readable summary. Reports the DISTRIBUTION, never just a mean."""
    lines: list[str] = []
    lines.append("FALSIFIER — failure mode #1: does the identifier generalize?")
    lines.append("")
    if report.unlabelled:
        lines.append(f"UNLABELLED (not scored, label these first): {len(report.unlabelled)}")
        for run_id in report.unlabelled:
            lines.append(f"  · {run_id}")
        lines.append("")
    if not report.results:
        lines.append("No labelled runs yet. Nothing has been measured.")
        return "\n".join(lines)

    lines.append(f"{'run':<38} {'true':>5} {'pick':>5} {'ok':>3} {'margin':>7}  flags")
    for r in sorted(report.results, key=lambda x: x.margin):
        flags = "PARTIAL" if r.partial else ""
        lines.append(
            f"{r.run_id[:38]:<38} {str(r.true_seq):>5} {str(r.picked_seq):>5} "
            f"{'Y' if r.correct else 'N':>3} {r.margin:>7.3f}  {flags}"
        )
    lines.append("")
    n = len(report.results)
    lines.append(f"top-1 correct: {report.correct_count}/{n}")
    lines.append(f"margins (every value, ascending): "
                 f"{', '.join(f'{m:.3f}' for m in report.margins)}")
    if n >= 2:
        lines.append(f"median margin: {statistics.median(report.margins):.3f}")
    thin = report.thin_margins()
    lines.append(f"thin margins (<0.10): {len(thin)}  <- THIS IS THE FINDING")
    for r in thin:
        lines.append(f"  · {r.run_id} margin={r.margin:.3f} correct={r.correct}")
    lines.append("")
    lines.append(
        "Reminder: margin is CONFIDENCE, not correctness. A confident wrong pick "
        "and a confident right one look identical — only the labels separate them."
    )
    return "\n".join(lines)


# --------------------------------------------------------------------------
# Recording a real site
# --------------------------------------------------------------------------


async def record(
    url: str, task_label: str, *, visible: bool = False
) -> tuple[str, RecordedSession]:
    """Sign in, load the page, and keep everything the browser saw.

    The recorder wraps ``login.fetch`` rather than replacing it, so the run
    exercises the same login path a user gets — a recording made by a
    special-case code path would not be evidence about the real one.
    """
    host = vault.normalize_host(url)
    session = await session_for(host, headless=not visible)
    async with recorder.recording(session, host=host, task_label=task_label) as sink:
        result = await login.fetch(url, visible=visible)
        if not result.ok:
            raise ProtocolError(
                f"fetch failed ({result.reason}): {result.message}. "
                "Nothing was recorded worth labelling."
            )
    if not sink:
        raise ProtocolError("the recorder returned nothing — is the daemon alive?")
    return slugify(host, task_label), sink[0]


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------


def _cmd_record(args: argparse.Namespace) -> int:
    run_id, session = asyncio.run(record(args.url, args.label, visible=args.visible))
    save_session(session, run_id)
    print(f"recorded {run_id}: {len(session.responses)} responses", end="")
    print(f", {session.dropped} dropped (PARTIAL)" if session.dropped else "")
    print(f"next: falsifier label {run_id}")
    return 0


def _cmd_label(args: argparse.Namespace) -> int:
    session = load_session(args.run_id)
    if load_truth(args.run_id) is not None:
        print(f"{args.run_id} is already labelled — labels are immutable.")
        return 1
    print(f"host={session.host}  task={session.task_label}  url={session.page_url}")
    print(f"\n--- what was on screen (first 600 chars) ---\n{session.rendered_text[:600]}\n")
    print("--- responses, in CAPTURE ORDER (no scores shown, by design) ---")
    for row in labelling_view(session):
        skip = f"  [skipped: {row['body_skip_reason']}]" if not row["body_captured"] else ""
        print(f"\n[{row['seq']}] {row['method']} {row['status']} {row['content_type']} "
              f"{row['bytes']}B{skip}\n    {row['url']}\n    {row['preview'][:200]}")
    print("\nWhich seq actually carried the data on screen? "
          "(number, or 'none' if no single response did)")
    answer = input("> ").strip().casefold()
    note = input("note (optional) > ").strip()
    true_seq = None if answer in {"none", "", "n"} else int(answer)
    save_truth(Truth(run_id=args.run_id, true_seq=true_seq, note=note))
    print(f"labelled. next: falsifier score {args.run_id}")
    return 0


def _cmd_score(args: argparse.Namespace) -> int:
    r = score_run(args.run_id)
    print(f"{r.run_id}: true={r.true_seq} picked={r.picked_seq} "
          f"correct={'YES' if r.correct else 'NO'} margin={r.margin:.3f}"
          f"{'  [PARTIAL RECORDING]' if r.partial else ''}")
    return 0


def _cmd_report(args: argparse.Namespace) -> int:
    print(format_report(build_report()))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="falsifier",
        description="Test whether the data-response identifier generalizes to real sites.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_rec = sub.add_parser("record", help="sign in, load a page, keep every response")
    p_rec.add_argument("url")
    p_rec.add_argument("--label", required=True, help="what task this page represents")
    p_rec.add_argument("--visible", action="store_true", help="show the browser window")
    p_rec.set_defaults(func=_cmd_record)

    p_lab = sub.add_parser("label", help="record ground truth BEFORE scoring")
    p_lab.add_argument("run_id")
    p_lab.set_defaults(func=_cmd_label)

    p_sc = sub.add_parser("score", help="score one labelled run")
    p_sc.add_argument("run_id")
    p_sc.set_defaults(func=_cmd_score)

    p_rep = sub.add_parser("report", help="margin distribution across all labelled runs")
    p_rep.set_defaults(func=_cmd_report)

    args = parser.parse_args(argv)
    try:
        result: int = args.func(args)
        return result
    except ProtocolError as exc:
        print(f"refused: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
