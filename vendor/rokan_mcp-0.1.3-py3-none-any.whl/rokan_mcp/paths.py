"""Filesystem layout for the local Rokan install.

Everything Rokan stores lives under one directory the user owns. Nothing is
uploaded anywhere: credentials, browser profiles and the usage counter are all
local files. ``ROKAN_MCP_HOME`` relocates the whole tree (used by the tests).
"""

from __future__ import annotations

import contextlib
import os
import tempfile
from pathlib import Path


def home() -> Path:
    """Root of the local Rokan store, created on first access with 0700."""
    raw = os.environ.get("ROKAN_MCP_HOME")
    root = Path(raw).expanduser() if raw else Path.home() / ".rokan"
    root.mkdir(parents=True, exist_ok=True)
    # 0700: the vault and the master key live here.
    os.chmod(root, 0o700)
    return root


def vault_file() -> Path:
    return home() / "vault.json"


def master_key_file() -> Path:
    return home() / "master.key"


def license_file() -> Path:
    return home() / "license"


def usage_file() -> Path:
    return home() / "usage.json"


def profile_dir(profile_key: str) -> Path:
    """Chromium profile for one site. Cookies here are what make a repeat
    fetch skip the login entirely."""
    d = home() / "profiles" / profile_key
    d.mkdir(parents=True, exist_ok=True)
    return d


def write_private(path: Path, data: str) -> None:
    """Write a file only the current user can read, without ever leaving the
    secret readable in a window between create and chmod.

    The temporary name is UNIQUE and created exclusively. It used to be
    `<path>.tmp` — fixed, guessable, opened without `O_EXCL` or
    `O_NOFOLLOW` — so a symlink planted at that name before the first write
    was followed, and `os.replace` then made the real file the link.
    Reproduced end to end: `usage.json` became a symlink into a directory
    of someone else's choosing, and this function is the single write path
    for the vault master key, the vault itself, the licence and the
    falsifier's recordings.

    It also fsyncs. `os.replace` makes the rename atomic and says nothing
    about the data being on disk; a crash in between leaves a zero-length
    `master.key`, which is exactly the "the stored logins are
    unrecoverable" case the vault warns about.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        dir=str(path.parent), prefix=path.name + ".", suffix=".tmp"
    )
    tmp = Path(tmp_name)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
    except Exception:
        # `fdopen` takes ownership of the descriptor, so it is closed by the
        # `with` — but `fchmod` runs BEFORE that, and a failure there used to
        # leak it. The temp name is unique now, so a leftover accumulates
        # rather than being overwritten next time: it holds master-key or
        # vault bytes and must go.
        with contextlib.suppress(OSError):
            os.close(fd)
        tmp.unlink(missing_ok=True)
        raise
    try:
        os.replace(tmp, path)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise
    os.chmod(path, 0o600)
    # The rename itself, so the file exists under its real name after a
    # power loss rather than only in the page cache.
    with contextlib.suppress(OSError):
        dir_fd = os.open(str(path.parent), os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
