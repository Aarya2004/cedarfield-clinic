"""The MCP server: what an agent actually calls.

There is deliberately no tool here that accepts a password. Saving a login is a
CLI action the human performs, so a credential never appears in a prompt, a
transcript, or a model provider's logs — not even once, at setup. The agent
gets told which command to ask for instead.
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from collections.abc import Awaitable, Callable
from typing import Any

from . import license, login, vault

logger = logging.getLogger("rokan_mcp")

SERVER_NAME = "rokan"
SERVER_VERSION = "0.1.0"

TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "name": "rokan_fetch",
        "description": (
            "Fetch a web page that sits behind a login and return its text. Rokan signs "
            "in with the credentials the user stored locally, including a six-digit "
            "authenticator code when the site asks for one, then returns the page. The "
            "signed-in session is reused, so fetching the same site again is fast and "
            "does not log in a second time.\n\n"
            "Use this whenever a URL returns a sign-in page, a 401/403, or an empty "
            "shell instead of content. If it fails, the result carries a 'reason' and a "
            "'next_step' saying exactly what to do — follow that rather than retrying "
            "the same call.\n\n"
            "Rokan never solves bot checks and never creates accounts; it reports both "
            "honestly instead."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "Full URL of the page to fetch, including https://",
                    "minLength": 4,
                },
                "visible": {
                    "type": "boolean",
                    "description": (
                        "Open a real browser window instead of running headless. Use "
                        "this when a previous call reported captcha_blocked so the user "
                        "can clear the challenge by hand."
                    ),
                    "default": False,
                },
            },
            "required": ["url"],
            "additionalProperties": False,
        },
    },
    {
        "name": "rokan_list_logins",
        "description": (
            "List the sites the user has stored a login for, with the username and "
            "whether a two-factor secret is saved. Never returns passwords. Call this "
            "before rokan_fetch if you are unsure whether a site is set up."
        ),
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "rokan_add_login",
        "description": (
            "Get the exact command the user must run to store a login for a site. "
            "Passwords are entered by the human in their own terminal and are never "
            "sent through this conversation, so call this and relay the command — do "
            "not ask the user to paste a password to you."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "site": {
                    "type": "string",
                    "description": "Hostname or URL of the site needing a login",
                    "minLength": 3,
                }
            },
            "required": ["site"],
            "additionalProperties": False,
        },
    },
    {
        "name": "rokan_status",
        "description": (
            "Report the current plan, how many successful fetches have been used this "
            "month, and how many remain."
        ),
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
]


async def _tool_fetch(args: dict[str, Any]) -> dict[str, Any]:
    url = str(args.get("url", "")).strip()
    if not url:
        return {"ok": False, "reason": "bad_request", "message": "url is required"}

    quota = license.check_quota()
    if not quota.allowed:
        return {
            "ok": False,
            "reason": "quota_exhausted",
            "message": quota.message,
            "next_step": f"Ask the user to upgrade at {license.BUY_URL}.",
            "plan": quota.plan,
            "used_this_month": quota.used,
        }

    result = await login.fetch(url, visible=bool(args.get("visible", False)))
    payload = result.to_dict()
    if result.ok:
        used = license.record_success()
        payload["plan"] = quota.plan
        payload["fetches_remaining_this_month"] = max(0, quota.limit - used)
    return payload


def _tool_list_logins() -> dict[str, Any]:
    sites = vault.list_sites()
    return {
        "ok": True,
        "count": len(sites),
        "sites": sites,
        "note": (
            "Passwords are never returned. To add one, use rokan_add_login."
            if sites
            else "No logins stored yet. Use rokan_add_login to get the setup command."
        ),
    }


def _tool_add_login(args: dict[str, Any]) -> dict[str, Any]:
    raw = str(args.get("site", "")).strip()
    try:
        host = vault.normalize_host(raw)
    except ValueError as exc:
        return {"ok": False, "reason": "bad_request", "message": str(exc)}
    return {
        "ok": True,
        "host": host,
        "command": f"rokan save-login {host}",
        "instructions": (
            f"Ask the user to run `rokan save-login {host}` in their terminal. It "
            "prompts for the username and password without echoing them, and asks "
            "for the authenticator setup key if the site uses two-factor. The "
            "credential is encrypted on their machine and is never sent through this "
            "conversation. Once they confirm, retry rokan_fetch."
        ),
    }


def _tool_status() -> dict[str, Any]:
    lic = license.load_license()
    quota = license.check_quota()
    return {
        "ok": True,
        "plan": lic.plan,
        "licensed_to": lic.email or None,
        "license_valid": lic.valid,
        "license_problem": lic.problem or None,
        "expires": lic.expires or None,
        "used_this_month": quota.used,
        "monthly_limit": quota.limit,
        "remaining": quota.remaining,
        "sites_configured": len(vault.list_sites()),
        "upgrade_url": license.BUY_URL,
    }


async def dispatch(name: str, args: dict[str, Any]) -> dict[str, Any]:
    if name == "rokan_fetch":
        return await _tool_fetch(args)
    if name == "rokan_list_logins":
        return _tool_list_logins()
    if name == "rokan_add_login":
        return _tool_add_login(args)
    if name == "rokan_status":
        return _tool_status()
    return {"ok": False, "reason": "unknown_tool", "message": f"no such tool: {name}"}


async def _run_tool(name: str, args: dict[str, Any]) -> str:
    """Dispatch and serialise. A crashing tool must not kill the session."""
    try:
        result = await dispatch(name, args)
    except Exception as exc:
        logger.exception("rokan_mcp tool %s failed", name)
        result = {
            "ok": False,
            "reason": "internal_error",
            "message": f"{type(exc).__name__}: {exc}",
        }
    return json.dumps(result, default=str, indent=2)


# Typed entry points. SDK 2.x builds each tool's schema from these signatures;
# SDK 1.x uses TOOL_SCHEMAS above. The two must describe the same arguments,
# which test_tool_signatures_match_the_declared_schemas checks.
async def rokan_fetch(url: str, visible: bool = False) -> str:
    return await _run_tool("rokan_fetch", {"url": url, "visible": visible})


async def rokan_list_logins() -> str:
    return await _run_tool("rokan_list_logins", {})


async def rokan_add_login(site: str) -> str:
    return await _run_tool("rokan_add_login", {"site": site})


async def rokan_status() -> str:
    return await _run_tool("rokan_status", {})


# Annotated explicitly: the values have heterogeneous signatures, and mypy's
# join for that is `builtins.function`, which satisfies neither `add_tool`
# nor `inspect.signature` at the call sites.
TOOL_FUNCTIONS: dict[str, Callable[..., Awaitable[str]]] = {
    "rokan_fetch": rokan_fetch,
    "rokan_list_logins": rokan_list_logins,
    "rokan_add_login": rokan_add_login,
    "rokan_status": rokan_status,
}


def sdk_major() -> int:
    """Which major version of the MCP SDK is installed.

    2.x removed the `@server.list_tools()` decorators from the low-level Server
    and replaced them with MCPServer. Both are supported here rather than
    pinning the package to an old SDK, because whichever version a client
    happens to resolve has to work.
    """
    try:
        from mcp.server.mcpserver import MCPServer  # noqa: F401
    except ImportError:
        return 1
    return 2


def build_server() -> Any:
    """Build the server against whichever SDK generation is installed."""
    if sdk_major() >= 2:
        from mcp.server.mcpserver import MCPServer

        server = MCPServer(name=SERVER_NAME, version=SERVER_VERSION)
        for schema in TOOL_SCHEMAS:
            server.add_tool(
                TOOL_FUNCTIONS[schema["name"]],
                name=schema["name"],
                description=schema["description"],
                structured_output=False,
            )
        return server

    from mcp.server import Server
    from mcp.types import TextContent, Tool

    legacy: Any = Server(SERVER_NAME, version=SERVER_VERSION)

    # The ignore is needed under this package's strict config and unused under
    # the repo root's non-strict config; `unused-ignore` in the list covers both.
    @legacy.list_tools()  # type: ignore[untyped-decorator, unused-ignore]
    async def _list_tools() -> list[Tool]:
        return [Tool(**schema) for schema in TOOL_SCHEMAS]

    @legacy.call_tool()  # type: ignore[untyped-decorator, unused-ignore]
    async def _call_tool(name: str, arguments: dict[str, Any] | None) -> list[TextContent]:
        return [TextContent(type="text", text=await _run_tool(name, arguments or {}))]

    return legacy


async def serve() -> None:
    """Run the stdio server.

    Browsers are deliberately left running when this exits. MCP clients restart
    their servers often, and killing the browser each time would throw away the
    signed-in sessions that make repeat fetches fast. Idle browsers shut
    themselves down after ten minutes; `rokan close` ends them immediately.
    """
    server = build_server()
    if sdk_major() >= 2:
        await server.run_stdio_async()
        return

    from mcp.server.stdio import stdio_server

    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        stream=sys.stderr,  # stdout is the MCP transport
    )
    try:
        asyncio.run(serve())
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
