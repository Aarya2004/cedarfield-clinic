"""Which hosts we have actually signed into — the fact `authenticated`
could not supply.

`FetchResult.authenticated` is set on every successful fetch: it means
"a usable page came back", not "this page sat behind a session". Two real
runs on 2026-08-24 proved the difference expensive — supabase.com served
a marketing testimonial as "my current plan" with `authenticated=True`,
and githubstatus.com, where no account exists at all, reported the same.

An account-scoped question ("MY plan", "MY usage") needs the other fact:
did a session for this host ever get established? That is
`login_performed` on this run, or a sign-in recorded on an earlier one —
session reuse legitimately reports `login_performed=False`, so the run
that signs in must leave the evidence behind for the runs that do not.

**Hosts and timestamps only.** No credential, no cookie, no token. The
file answers exactly one question and is worth nothing to a thief.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from . import paths, vault


def sessions_file() -> Path:
    return paths.home() / "sessions.json"


def _load() -> dict[str, str]:
    """The record, or an empty one. FAILS CLOSED on anything unreadable:
    a file we cannot parse must not be able to vouch for a host."""
    path = sessions_file()
    if not path.exists():
        return {}
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(loaded, dict):
        return {}
    return {str(k): str(v) for k, v in loaded.items()}


def record_sign_in(host: str) -> None:
    """Remember that a login for this host actually succeeded.

    Normalised through the vault's own rule, so a record written from a
    full URL is found by a later bare-host lookup — a record that
    disagreed with the vault's keying would silently never match.
    """
    key = vault.normalize_host(host)
    if not key:
        return
    known = _load()
    known[key] = datetime.now(UTC).isoformat()
    paths.write_private(sessions_file(), json.dumps(known, indent=2))


def signed_in(host: str) -> bool:
    """Has a session for this host ever been established on this machine?"""
    key = vault.normalize_host(host)
    return bool(key) and key in _load()
