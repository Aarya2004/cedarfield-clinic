"""Licensing, verified offline.

A licence is an ed25519-signed token. The client checks the signature against a
public key compiled into this file and never contacts a server, so using Rokan
does not tell us which sites you visit or how often. The usage counter is a
local file for your own visibility and for enforcing the tier you bought.

Only *successful* fetches count. A fetch that hit a bot check, or found no
stored credential, is not billable — you pay for pages you actually got.
"""

from __future__ import annotations

import base64
import json
import os
from dataclasses import dataclass
from datetime import UTC, date, datetime
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .paths import license_file, usage_file, write_private

ISSUER_PUBLIC_KEY = bytes.fromhex(
    "8e55c92eeb0fa077fac28fe4ff7818a23dcdd62b4bd1d3e658d7bfab88341287"
)

FREE_MONTHLY_FETCHES = 25
PLAN_QUOTAS = {"free": FREE_MONTHLY_FETCHES, "pro": 2_000, "team": 10_000}

BUY_URL = "https://rokan.computer/buy"


@dataclass(frozen=True, slots=True)
class License:
    plan: str
    email: str
    quota: int
    expires: str
    valid: bool
    problem: str = ""

    @property
    def is_paid(self) -> bool:
        return self.valid and self.plan != "free"


def _b64d(raw: str) -> bytes:
    return base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4))


def _b64e(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def encode_token(payload: dict[str, Any], signature: bytes) -> str:
    body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"rokan-{_b64e(body)}.{_b64e(signature)}"


def signed_bytes(payload: dict[str, Any]) -> bytes:
    """Exactly the bytes the issuer signs — kept in one place so the minting
    CLI and the verifier can never disagree about canonical form."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def verify_token(token: str) -> License:
    free = License(plan="free", email="", quota=FREE_MONTHLY_FETCHES, expires="", valid=True)
    token = (token or "").strip()
    if not token:
        return free
    if not token.startswith("rokan-") or "." not in token:
        return License("free", "", FREE_MONTHLY_FETCHES, "", False, "the licence key is malformed")

    body_b64, _, sig_b64 = token[len("rokan-") :].partition(".")
    try:
        body = _b64d(body_b64)
        signature = _b64d(sig_b64)
        payload = json.loads(body.decode("utf-8"))
    except (ValueError, json.JSONDecodeError):
        return License("free", "", FREE_MONTHLY_FETCHES, "", False, "the licence key is corrupt")

    try:
        Ed25519PublicKey.from_public_bytes(ISSUER_PUBLIC_KEY).verify(signature, body)
    except InvalidSignature:
        return License(
            "free", "", FREE_MONTHLY_FETCHES, "", False, "the licence signature is not valid"
        )

    plan = str(payload.get("plan", "free"))
    expires = str(payload.get("expires", ""))
    if expires:
        try:
            if date.fromisoformat(expires) < datetime.now(UTC).date():
                return License(
                    plan,
                    str(payload.get("email", "")),
                    0,
                    expires,
                    False,
                    f"the licence expired on {expires}",
                )
        except ValueError:
            return License(
                "free", "", FREE_MONTHLY_FETCHES, "", False, "the expiry date is unreadable"
            )

    return License(
        plan=plan,
        email=str(payload.get("email", "")),
        quota=int(payload.get("quota", PLAN_QUOTAS.get(plan, FREE_MONTHLY_FETCHES))),
        expires=expires,
        valid=True,
    )


def load_license() -> License:
    token = os.environ.get("ROKAN_LICENSE_KEY", "").strip()
    if not token:
        path = license_file()
        if path.exists():
            token = path.read_text(encoding="utf-8").strip()
    return verify_token(token)


def install_license(token: str) -> License:
    parsed = verify_token(token)
    if not parsed.valid:
        raise ValueError(parsed.problem or "that licence key is not valid")
    write_private(license_file(), token.strip())
    return parsed


def _period() -> str:
    return datetime.now(UTC).strftime("%Y-%m")


def _read_usage() -> dict[str, Any]:
    path = usage_file()
    if not path.exists():
        return {"period": _period(), "count": 0}
    # Every failure, not the two that were imagined. A counter file is a
    # convenience; a person who cannot fetch because their usage counter is
    # a JSON list has been locked out by bookkeeping. `[]` raised
    # AttributeError on `.get` and a non-numeric count raised ValueError on
    # `int()`, and both escaped all the way out of the fetch — while the
    # test claiming "a corrupt counter does not lock the user out" only ever
    # tried a truncated string.
    fresh = {"period": _period(), "count": 0}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or str(data.get("period")) != _period():
            return fresh
        return {"period": _period(), "count": int(data.get("count", 0))}
    except Exception:  # noqa: BLE001 — an unreadable counter starts over
        return fresh


def usage_this_month() -> int:
    return int(_read_usage()["count"])


def record_success() -> int:
    data = _read_usage()
    data["count"] = int(data["count"]) + 1
    write_private(usage_file(), json.dumps(data))
    return int(data["count"])


@dataclass(frozen=True, slots=True)
class Quota:
    allowed: bool
    plan: str
    used: int
    limit: int
    message: str = ""

    @property
    def remaining(self) -> int:
        return max(0, self.limit - self.used)


def check_quota() -> Quota:
    lic = load_license()
    used = usage_this_month()
    if not lic.valid:
        return Quota(
            allowed=False,
            plan=lic.plan,
            used=used,
            limit=0,
            message=f"{lic.problem}. Renew at {BUY_URL} or unset ROKAN_LICENSE_KEY to "
            f"fall back to the free tier ({FREE_MONTHLY_FETCHES} fetches a month).",
        )
    if used >= lic.quota:
        tier = "free tier" if not lic.is_paid else f"{lic.plan} plan"
        return Quota(
            allowed=False,
            plan=lic.plan,
            used=used,
            limit=lic.quota,
            message=f"the {tier} allows {lic.quota} successful fetches a month and "
            f"{used} have been used. Upgrade at {BUY_URL}.",
        )
    return Quota(allowed=True, plan=lic.plan, used=used, limit=lic.quota)
