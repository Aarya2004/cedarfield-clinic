"""Thin client for the vendored browser daemon.

The daemon is a separate process that owns one Chromium profile and speaks
newline-delimited JSON over a Unix socket. Keeping it out-of-process is what
lets a browser survive between tool calls: the second fetch of a site reuses
the cookies from the first and skips the login entirely.

One daemon per site profile. The daemon reaps itself after ten idle minutes.
"""

from __future__ import annotations

import asyncio
import contextlib
import hashlib
import json
import os
import re
import socket
import sys
import weakref
from pathlib import Path
from typing import Any

from .paths import home, profile_dir

DAEMON_SCRIPT = Path(__file__).resolve().parent / "_daemon.py"

_SPAWN_TIMEOUT_S = 25.0
_SOCKET_APPEAR_TIMEOUT_S = 5.0
_COMMAND_TIMEOUT_S = 45.0
_READ_LIMIT = 32 * 1024 * 1024  # snapshots and screenshots arrive on one line
_SAFE_KEY_RE = re.compile(r"[^A-Za-z0-9_-]")

_sessions: dict[str, BrowserSession] = {}
#: Keyed by loop, and weak so a finished loop does not keep its lock alive.
_locks: weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, asyncio.Lock] = (
    weakref.WeakKeyDictionary()
)


class BrowserError(RuntimeError):
    """The browser could not be started or driven."""


def profile_key_for(host: str) -> str:
    """Filesystem- and socket-safe key for a host.

    A hash suffix keeps the key unique after the character scrub, and keeps the
    Unix socket path well under the 104-byte ``sun_path`` limit on macOS.
    """
    scrubbed = _SAFE_KEY_RE.sub("-", host)[:40].strip("-") or "site"
    digest = hashlib.sha256(host.encode("utf-8")).hexdigest()[:8]
    return f"{scrubbed}-{digest}"


def _socket_path(profile_key: str) -> str:
    # /tmp rather than $TMPDIR: macOS per-user temp dirs are long enough to
    # blow the sun_path limit on their own.
    #
    # The store's location is folded in so that two installs pointing at
    # different homes never adopt each other's browser — which would hand one
    # store's cookies to the other.
    scope = hashlib.sha256(str(home()).encode("utf-8")).hexdigest()[:6]
    return f"/tmp/rokan-mcp-{scope}-{profile_key}.sock"


class BrowserSession:
    """One Chromium profile, driven over the daemon socket."""

    def __init__(self, profile_key: str, *, headless: bool = True) -> None:
        self.profile_key = profile_key
        self.headless = headless
        self.socket_path = _socket_path(profile_key)
        self._process: asyncio.subprocess.Process | None = None
        self._adopted = False
        self._lock = asyncio.Lock()
        #: The loop that created our subprocess transport. That transport can
        #: only be awaited from its own loop, and this registry deliberately
        #: outlives loops, so a session that crosses one is re-homed (see
        #: `rehome`) rather than awaited.
        self._loop: asyncio.AbstractEventLoop | None = None
        #: Tasks that read the daemon's stdout and stderr and throw them
        #: away. Nothing reads those pipes after the READY line, and a pipe
        #: nobody reads fills at 64 KiB — at which point the daemon's own
        #: write blocks and its event loop stops serving commands, while this
        #: process happily waits for a reply that will never come.
        self._drains: list[asyncio.Task[None]] = []

    @property
    def alive(self) -> bool:
        if self._adopted:
            return True
        return self._process is not None and self._process.returncode is None

    def _owned_here(self) -> bool:
        """Is this loop the one that created our subprocess transport?

        Commands do not care — each opens its own socket connection — but
        anything that awaits the transport does, because awaiting it from
        another loop raises "attached to a different loop" from deep inside
        asyncio.
        """
        if self._process is None or self._loop is None:
            return True
        try:
            return self._loop is asyncio.get_running_loop()
        except RuntimeError:
            return False

    def rehome(self) -> None:
        """Keep using a daemon this loop did not start.

        A session that outlives its loop is still a perfectly good daemon: it
        is another process, reached over a socket that every command opens
        fresh. What must not happen is this loop awaiting the old loop's
        subprocess transport — so the handle is released and the session
        becomes what it now honestly is, one we attached to.

        Killing it instead would be worse than untidy. Chromium flushes its
        cookie jar on a clean shutdown, so a signalled daemon can cost the
        user their signed-in session, and the next run finds a login wall
        where its compiled endpoint used to be. Measured, on the second call
        of a three-call test.
        """
        if self._process is not None:
            self._process = None
            self._adopted = True
        # The drain tasks belong to the departed loop as well; cancelling
        # them from here would raise. Dropping the references is enough —
        # the loop that owned them is finished, and so are they.
        self._drains = []
        self._loop = None
        # The command lock is an asyncio primitive too, and it binds to the
        # first loop that CONTENDS it. Uncontended it survives the move
        # unnoticed, which is why this was invisible: the first two
        # concurrent sends from a new loop raise "bound to a different event
        # loop" out of `send`, as a bare RuntimeError rather than a
        # BrowserError. Nothing in the agent runs concurrent sends today; one
        # `gather` in the scheduler would have made it live.
        self._lock = asyncio.Lock()

    async def _adopt_running_daemon(self) -> bool:
        """Attach to a daemon another process already started.

        This is what makes a signed-in session survive between separate `rokan`
        invocations: the browser stays warm in its own process, holding the
        cookies, and the next command talks to it rather than launching a
        second Chromium over the same profile directory — which would fight
        the first for the profile lock and lose the session.
        """
        if not os.path.exists(self.socket_path):
            return False
        pong = await self._raw_command("ping", {}, timeout=5.0)
        if not pong.get("ok"):
            # A stale socket from a daemon that died. Clear it and start fresh.
            with contextlib.suppress(FileNotFoundError):
                os.unlink(self.socket_path)
            return False
        if bool(pong.get("effective_headless", True)) != self.headless:
            # Headless-ness is fixed when Chromium launches, so a running
            # daemon in the wrong mode has to go. This is the path taken when a
            # bot check forces a retry with a visible window.
            await self._raw_command("close", {}, timeout=3.0)
            for _ in range(20):
                if not os.path.exists(self.socket_path):
                    break
                await asyncio.sleep(0.1)
            with contextlib.suppress(FileNotFoundError):
                os.unlink(self.socket_path)
            return False
        self._adopted = True
        return True

    async def start(self) -> None:
        if self.alive:
            return
        if not DAEMON_SCRIPT.exists():
            raise BrowserError(
                f"browser daemon missing at {DAEMON_SCRIPT} — the install is incomplete"
            )
        if await self._adopt_running_daemon():
            self._loop = asyncio.get_running_loop()
            return

        env = dict(os.environ)
        env["ROKAN_BROWSER_HEADLESS"] = "true" if self.headless else "false"
        env.setdefault("PYTHONUNBUFFERED", "1")

        try:
            process = await asyncio.create_subprocess_exec(
                sys.executable,
                str(DAEMON_SCRIPT),
                "--mission-id",
                self.profile_key,
                "--socket-path",
                self.socket_path,
                "--user-data-dir",
                str(profile_dir(self.profile_key)),
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
        except OSError as exc:
            raise BrowserError(f"could not start the browser daemon: {exc}") from exc
        self._process = process
        self._loop = asyncio.get_running_loop()

        try:
            await self._await_ready(process)
            await self._await_socket()
            self._drains = [
                asyncio.create_task(_swallow(pipe))
                for pipe in (process.stdout, process.stderr)
                if pipe is not None
            ]
        except BaseException:
            # BaseException, not Exception, because CancelledError is the one
            # that matters here. A caller that times out mid-start — the
            # compiled fast path does exactly this — would otherwise leave a
            # daemon and its Chromium running with nothing holding a
            # reference to them, once per attempt.
            await self.close()
            raise

    async def _await_ready(self, process: asyncio.subprocess.Process) -> None:
        assert process.stdout is not None
        try:
            line = await asyncio.wait_for(process.stdout.readline(), timeout=_SPAWN_TIMEOUT_S)
        except TimeoutError as exc:
            raise BrowserError(
                "the browser daemon did not report ready within "
                f"{_SPAWN_TIMEOUT_S:.0f}s"
            ) from exc
        if not line:
            detail = await self._drain_stderr(process)
            raise BrowserError(f"the browser daemon exited during startup{detail}")
        if not line.decode("utf-8", "replace").startswith("READY"):
            raise BrowserError(
                f"unexpected daemon greeting: {line.decode('utf-8', 'replace').strip()!r}"
            )

    async def _await_socket(self) -> None:
        deadline = asyncio.get_running_loop().time() + _SOCKET_APPEAR_TIMEOUT_S
        while asyncio.get_running_loop().time() < deadline:
            if os.path.exists(self.socket_path):
                return
            await asyncio.sleep(0.05)
        raise BrowserError(f"the browser daemon never created its socket at {self.socket_path}")

    @staticmethod
    async def _drain_stderr(process: asyncio.subprocess.Process) -> str:
        if process.stderr is None:
            return ""
        try:
            raw = await asyncio.wait_for(process.stderr.read(4096), timeout=2.0)
        except (TimeoutError, OSError):
            return ""
        text = raw.decode("utf-8", "replace").strip()
        if not text:
            return ""
        if "playwright" in text.lower():
            # Name the running interpreter: a uvx/pipx user's shell `python`
            # has no playwright module, so a bare `python -m ...` hint fails
            # for exactly the install mode the README leads with.
            return (
                ". Chromium is not installed — run: "
                f"{sys.executable} -m playwright install chromium"
            )
        return f": {text.splitlines()[-1][:200]}"

    async def _raw_command(
        self, cmd: str, args: dict[str, Any] | None = None, *, timeout: float = _COMMAND_TIMEOUT_S
    ) -> dict[str, Any]:
        """One request/response over the socket. No locking, no auto-start."""
        payload = json.dumps({"id": cmd, "cmd": cmd, "args": args or {}}) + "\n"
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_unix_connection(self.socket_path, limit=_READ_LIMIT),
                timeout=10.0,
            )
        except (OSError, TimeoutError) as exc:
            return {"ok": False, "error": "daemon_unreachable", "detail": str(exc)}

        try:
            writer.write(payload.encode("utf-8"))
            await writer.drain()
            line = await asyncio.wait_for(reader.readline(), timeout=timeout)
        except TimeoutError:
            return {"ok": False, "error": "timeout", "detail": f"{cmd} exceeded {timeout:.0f}s"}
        except OSError as exc:
            return {"ok": False, "error": "daemon_crashed", "detail": str(exc)}
        finally:
            writer.close()
            with contextlib.suppress(OSError):
                await writer.wait_closed()

        if not line:
            return {"ok": False, "error": "daemon_crashed", "detail": "empty response"}
        try:
            decoded: dict[str, Any] = json.loads(line.decode("utf-8", "replace"))
        except json.JSONDecodeError as exc:
            return {"ok": False, "error": "bad_response", "detail": str(exc)}
        return decoded

    async def send(
        self, cmd: str, args: dict[str, Any] | None = None, *, timeout: float = _COMMAND_TIMEOUT_S
    ) -> dict[str, Any]:
        """Send one command. Always returns a dict; never raises for a command
        the daemon merely refused — those come back as ``{"ok": False, ...}``."""
        async with self._lock:
            if not self.alive:
                await self.start()
            result = await self._raw_command(cmd, args, timeout=timeout)
            if result.get("error") == "daemon_unreachable" and self._adopted:
                # The daemon we attached to went away between the ping and now
                # (idle timeout, or the user closed the window). Start our own
                # and try once more rather than failing the fetch.
                self._adopted = False
                await self.start()
                result = await self._raw_command(cmd, args, timeout=timeout)
            return result

    async def close(self) -> None:
        """Shut the browser down and flush its profile to disk.

        Also closes a daemon this process merely attached to — the point of
        `close` is that the browser is gone afterwards, regardless of who
        started it.
        """
        # Asked BEFORE the handle is released: `_owned_here` answers "is this
        # loop the one that created our transport", and its first line is
        # "no transport, so yes". Reading it after the line below therefore
        # always said yes, and the guard the comment describes did not exist.
        owned = self._owned_here()
        for drain in self._drains:
            drain.cancel()
        self._drains = []
        process, self._process = self._process, None
        was_adopted, self._adopted = self._adopted, False
        if process is None and not was_adopted:
            return
        acknowledged = bool((await self._raw_command("close", {}, timeout=5.0)).get("ok"))

        if process is not None and process.returncode is None and owned:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=3.0)
            except TimeoutError:
                process.kill()
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(process.wait(), timeout=1.0)
            acknowledged = True
        # Unlink once the daemon is GONE — not merely once it said yes.
        #
        # Both halves of that matter and the first version had only one.
        # Unlinking a socket whose daemon is still alive makes that daemon
        # unreachable while its Chromium keeps the profile lock, so every
        # later session launches a rival that loses the lock. But LEAVING a
        # socket whose daemon has died is not free either: the next session
        # finds the file, tries to adopt it, and pays a connect timeout —
        # measured, on the live-site probe, as 6/6 sites becoming 3/6 and the
        # step taking eight times as long.
        #
        # So: ask. A socket nothing answers on is a leftover.
        for _ in range(10):
            if acknowledged and not _socket_answers(self.socket_path):
                break
            if not os.path.exists(self.socket_path):
                return
            if not _socket_answers(self.socket_path):
                break
            await asyncio.sleep(0.1)
        if not _socket_answers(self.socket_path):
            with contextlib.suppress(FileNotFoundError):
                os.unlink(self.socket_path)


async def _swallow(pipe: asyncio.StreamReader) -> None:
    """Read a pipe to EOF and discard it, so the writer never blocks."""
    with contextlib.suppress(Exception):
        while await pipe.read(8192):
            pass


def _registry_lock() -> asyncio.Lock:
    """One lock per event loop.

    A single module-level `asyncio.Lock` binds to the first loop that awaits
    it and then raises from every other one. This registry deliberately
    outlives loops, so its lock cannot.
    """
    loop = asyncio.get_running_loop()
    lock = _locks.get(loop)
    if lock is None:
        lock = asyncio.Lock()
        _locks[loop] = lock
    return lock


def _watch_wished() -> bool:
    """Whether ``ROKAN_BROWSER_WATCH=1`` should put a window on screen.

    A deliberate MIRROR of the daemon's ``_effective_headless`` (env switch,
    display guard, CI guard) — mirrored rather than imported because the
    daemon file must stay self-contained for the wheel's copy-check; a test
    holds the two in agreement.

    Why the client needs its own copy at all: the client tells the daemon
    what it wants twice — ``ROKAN_BROWSER_HEADLESS`` in the spawn env, and
    ``self.headless`` against the pong's ``effective_headless`` when
    adopting. Both come from the caller's ``headless`` argument, so with
    every product call site passing the default, the daemon's own WATCH
    handling was unreachable: the env force said "true" and won. That broke
    the documented bot-check handoff for ``rokan-do`` — the user was told
    to re-run under WATCH, and the window never came.
    """
    watch = os.environ.get("ROKAN_BROWSER_WATCH", "").strip().lower() in (
        "1",
        "true",
        "yes",
    )
    if not watch:
        return False
    # The daemon would force headless anyway on these hosts; wishing headed
    # here would only make adoption close and relaunch a good daemon on
    # every single run.
    if sys.platform.startswith("linux") and not (
        os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")
    ):
        return False
    return os.environ.get("CI", "").strip().lower() not in ("true", "1")


async def session_for(host: str, *, headless: bool | None = None) -> BrowserSession:
    """Get (or start) the session that owns this host's cookies.

    ``headless=None`` means the product default: headless, unless the user
    deliberately put a window on screen with ``ROKAN_BROWSER_WATCH=1`` (and
    a display exists to show it). An explicit ``True``/``False`` wins — the
    MCP surface's ``visible=true`` keeps meaning exactly what it says.
    """
    if headless is None:
        headless = not _watch_wished()
    # Keyed by SOCKET PATH, not by profile key.
    #
    # `_socket_path` folds the store's location in, specifically so "two
    # installs pointing at different homes never adopt each other's browser
    # — which would hand one store's cookies to the other". The registry
    # ignored that and keyed on the host alone, so the second store to ask
    # for a host got the first store's live session, its Chromium, and its
    # login cookies.
    #
    # Measured consequence, and it reached a published number: the eval
    # harness rotates ROKAN_MCP_HOME per task to make every run cold, and
    # from task two onward every task reused task one's browser. The login
    # step ran once across thirty tasks rather than thirty times.
    key = _socket_path(profile_key_for(host))
    async with _registry_lock():
        existing = _sessions.get(key)
        if existing is not None:
            if not existing._owned_here():
                # Started by a loop that has since finished. Still a good
                # daemon — every command opens its own socket — so keep it
                # and stop pretending we own its transport.
                existing.rehome()
            if existing.alive and existing.headless == headless:
                return existing
            await existing.close()
            _sessions.pop(key, None)
        created = BrowserSession(profile_key_for(host), headless=headless)
        await created.start()
        _sessions[key] = created
        return created


async def close_all() -> None:
    async with _registry_lock():
        for sess in list(_sessions.values()):
            if not sess._owned_here():
                sess.rehome()
            await sess.close()
        _sessions.clear()


async def _close_socket(path: str) -> bool:
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_unix_connection(path, limit=_READ_LIMIT), timeout=3.0
        )
    except (OSError, TimeoutError):
        return False
    try:
        writer.write(b'{"id":"close","cmd":"close","args":{}}\n')
        await writer.drain()
        await asyncio.wait_for(reader.readline(), timeout=5.0)
        return True
    except (OSError, TimeoutError):
        return False
    finally:
        writer.close()
        with contextlib.suppress(OSError):
            await writer.wait_closed()


async def close_orphans() -> int:
    """Shut down every Rokan browser on this machine, including ones started by
    another process. Returns how many were closed."""
    await close_all()
    closed = 0
    for sock in sorted(Path("/tmp").glob("rokan-mcp-*.sock")):
        if await _close_socket(str(sock)):
            closed += 1
            with contextlib.suppress(FileNotFoundError):
                os.unlink(sock)
        elif not _socket_answers(str(sock)):
            # Nothing is listening: a leftover file from a daemon that died.
            # Safe to remove, and removing it is what lets the next session
            # start cleanly instead of trying to adopt a corpse.
            with contextlib.suppress(FileNotFoundError):
                os.unlink(sock)
    return closed


def _socket_answers(path: str) -> bool:
    """Is anything listening on this socket right now?

    Used to tell a stale file from a hung daemon. Unlinking the second kind
    strands a live Chromium holding the profile lock, with nothing left that
    can reach it.
    """
    probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        probe.settimeout(1.0)
        probe.connect(path)
        return True
    except OSError:
        return False
    finally:
        probe.close()
