"""``python -m rokan_mcp`` starts the MCP server, matching the console script."""

from __future__ import annotations

from .server import main

if __name__ == "__main__":
    raise SystemExit(main())
