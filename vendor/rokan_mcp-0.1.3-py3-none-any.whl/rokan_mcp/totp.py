"""RFC 6238 TOTP, computed locally.

The point of computing it here rather than asking the model for it: the seed
never enters a prompt and never crosses the network. The six-digit code is
generated microseconds before it is typed into the page.
"""

from __future__ import annotations

import base64
import hmac
import struct
from hashlib import sha1, sha256, sha512

_ALGOS = {"SHA1": sha1, "SHA256": sha256, "SHA512": sha512}
_B32_ALPHABET = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567")


def normalize_secret(raw: str) -> bytes | None:
    """Decode a base32 TOTP setup key as shown by an authenticator page.

    Returns None rather than raising, and rejects any character outside the
    base32 alphabet instead of letting a mis-copied label silently decode to
    garbage that would produce plausible-looking wrong codes forever.
    """
    if not raw:
        return None
    cleaned = "".join(raw.split()).replace("-", "").replace("_", "").upper().rstrip("=")
    if not cleaned or any(ch not in _B32_ALPHABET for ch in cleaned):
        return None
    padded = cleaned + "=" * (-len(cleaned) % 8)
    try:
        seed = base64.b32decode(padded, casefold=False)
    except Exception:
        return None
    # Shorter than 80 bits is not a real TOTP seed; refuse it at capture time
    # rather than generating codes that will never be accepted.
    return seed if len(seed) >= 10 else None


def generate_code(
    secret: bytes,
    unix_time: int,
    *,
    step_seconds: int = 30,
    digits: int = 6,
    algorithm: str = "SHA1",
) -> str:
    if step_seconds <= 0:
        raise ValueError("step_seconds must be positive")
    if not 6 <= digits <= 10:
        raise ValueError("digits must be between 6 and 10")
    digest = _ALGOS.get(algorithm.upper())
    if digest is None:
        raise ValueError(f"unsupported algorithm: {algorithm}")

    counter = max(0, unix_time) // step_seconds
    mac = hmac.new(secret, struct.pack(">Q", counter), digest).digest()
    offset = mac[-1] & 0x0F
    truncated = struct.unpack(">I", mac[offset : offset + 4])[0] & 0x7FFFFFFF
    return str(truncated % (10**digits)).zfill(digits)
