"""Local encrypted credential store.

Two layers of Fernet, mirroring the design used server-side in the main Rokan
repo:

* each secret is encrypted on its own, so one can be rotated without touching
  the others;
* the whole ``{host: entry}`` map is then encrypted again, so a stolen vault
  file does not even reveal *which* sites the user has accounts on. Host names
  in plaintext would be a list of where to go phishing.

Keys are derived per purpose with HKDF from a master key held in a 0600 file,
so compromising the key used for passwords does not yield the one used for TOTP
seeds.
"""

from __future__ import annotations

import base64
import json
import secrets
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from urllib.parse import urlsplit

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from .paths import master_key_file, vault_file, write_private

VAULT_VERSION = 1
_HKDF_SALT = b"rokan-mcp-local-vault-v1"
_INFO_OUTER = b"rokan-mcp-vault-outer-v1"
_INFO_PASSWORD = b"rokan-mcp-vault-password-v1"
_INFO_TOTP = b"rokan-mcp-vault-totp-v1"


class VaultError(RuntimeError):
    """Raised when the vault cannot be read or written."""


@dataclass(frozen=True, slots=True)
class Credential:
    host: str
    username: str
    password: str
    totp_seed: bytes | None
    created_at: str
    updated_at: str

    @property
    def has_totp(self) -> bool:
        return self.totp_seed is not None


def normalize_host(raw: str) -> str:
    """Reduce a URL or hostname to the vault key.

    Deliberately strict: lowercase registrable host, no scheme, no port, no
    path, ``www.`` dropped. Paths must not survive, because the map is indexed
    by exact string and ``example.com/admin`` would otherwise shadow a
    different service.
    """
    value = (raw or "").strip().lower()
    if not value:
        raise ValueError("host is required")
    if "//" not in value:
        value = "//" + value
    host = urlsplit(value).hostname or ""
    if not host:
        raise ValueError(f"could not read a hostname from {raw!r}")
    if host.startswith("www."):
        host = host[4:]
    if not host or "." not in host:
        raise ValueError(f"{raw!r} does not look like a hostname")
    return host


def _apex(host: str) -> str:
    """Last two labels. Naive on purpose — no public-suffix list.

    Two callers, and the second makes this a SECURITY primitive (2026-08-25):
    `find_sibling` suggests a stored host when an exact lookup misses; and
    `rokan_do.policy._has_authority` treats ANY stored login under the same
    apex as authority over a host — so a login on acme.example guards
    checkout.acme.example. Naive apex means a login on myblog.github.io
    also guards evil.github.io: that OVER-guards (a refusal, never a write),
    which is the safe direction. Do not narrow this without re-reading the
    policy tests.
    """
    parts = host.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


def _load_master_key() -> bytes:
    """Load the master key from its 0600 file, minting one on first use.

    There is deliberately no environment-variable path. An env var is readable
    from ``/proc/<pid>/environ``, is inherited by every child process — the
    browser daemon and Chromium itself — and survives into crash dumps, error
    reporters and ``docker inspect``. The keyfile is strictly better and is the
    only documented mechanism.
    """
    path = master_key_file()
    if path.exists():
        try:
            key = bytes.fromhex(path.read_text(encoding="utf-8").strip())
        except ValueError as exc:
            raise VaultError(
                f"{path} is corrupt (expected hex). Move it aside and re-add your logins."
            ) from exc
        if len(key) < 32:
            raise VaultError(f"{path} holds a key shorter than 32 bytes")
        return key

    key = secrets.token_bytes(32)
    write_private(path, key.hex())
    return key


def _fernet(info: bytes) -> Fernet:
    raw = HKDF(
        algorithm=hashes.SHA256(), length=32, salt=_HKDF_SALT, info=info
    ).derive(_load_master_key())
    return Fernet(base64.urlsafe_b64encode(raw))


def _read_map() -> dict[str, dict[str, Any]]:
    path = vault_file()
    if not path.exists():
        return {}
    try:
        envelope = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise VaultError(f"{path} is not readable JSON") from exc

    version = envelope.get("version")
    if version != VAULT_VERSION:
        raise VaultError(
            f"{path} has vault version {version!r}, this build understands {VAULT_VERSION}"
        )
    try:
        plain = _fernet(_INFO_OUTER).decrypt(str(envelope["outer"]).encode("ascii"))
    except (InvalidToken, KeyError, UnicodeEncodeError) as exc:
        raise VaultError(
            f"{path} could not be decrypted with the current master key. "
            "If you replaced ~/.rokan/master.key, the stored logins are unrecoverable."
        ) from exc
    decoded: dict[str, dict[str, Any]] = json.loads(plain.decode("utf-8"))
    return decoded


def _write_map(entries: dict[str, dict[str, Any]]) -> None:
    blob = json.dumps(entries, sort_keys=True, separators=(",", ":")).encode("utf-8")
    envelope = {
        "version": VAULT_VERSION,
        "outer": _fernet(_INFO_OUTER).encrypt(blob).decode("ascii"),
    }
    write_private(vault_file(), json.dumps(envelope, indent=2))


def save(
    site: str, username: str, password: str, totp_secret: str | None = None
) -> tuple[str, bool]:
    """Store (or replace) the login for one host.

    Returns ``(host, totp_stored)``. A TOTP secret that will not decode is a
    hard error rather than a silent drop — a login that needs a second factor
    and has a broken seed fails at the worst possible moment otherwise.
    """
    host = normalize_host(site)
    if not username:
        raise ValueError("username is required")
    if not password:
        raise ValueError("password is required")

    seed: bytes | None = None
    if totp_secret:
        from .totp import normalize_secret

        seed = normalize_secret(totp_secret)
        if seed is None:
            raise ValueError(
                "that TOTP secret is not valid base32 — copy the 'setup key' or "
                "'manual entry' string the site shows next to the QR code"
            )

    now = datetime.now(UTC).isoformat()
    entries = _read_map()
    existing = entries.get(host)
    entries[host] = {
        "username": username,
        "password": _fernet(_INFO_PASSWORD).encrypt(password.encode("utf-8")).decode("ascii"),
        "totp": (
            _fernet(_INFO_TOTP).encrypt(seed).decode("ascii") if seed is not None else None
        ),
        "created_at": (existing or {}).get("created_at", now),
        "updated_at": now,
    }
    _write_map(entries)
    return host, seed is not None


def get(site: str) -> Credential | None:
    host = normalize_host(site)
    entry = _read_map().get(host)
    if entry is None:
        return None
    totp_ct = entry.get("totp")
    try:
        password = (
            _fernet(_INFO_PASSWORD)
            .decrypt(str(entry["password"]).encode("ascii"))
            .decode("utf-8")
        )
        seed = (
            _fernet(_INFO_TOTP).decrypt(str(totp_ct).encode("ascii"))
            if totp_ct
            else None
        )
    except (InvalidToken, KeyError, UnicodeError) as exc:
        # A single entry that will not decrypt, in a file that DID.
        #
        # The outer envelope already raises `VaultError` for this; the inner
        # fields raised `cryptography.fernet.InvalidToken` straight through
        # the caller instead. `login.py` catches `VaultError` around this
        # call and nothing else, so an entry edited or truncated on disk
        # crashed the whole run with a library traceback rather than saying
        # which login is unreadable.
        #
        # Found by testing that a password ciphertext moved into the totp
        # slot is rejected. It is — this is what rejection looked like.
        raise VaultError(
            f"the stored login for {host} could not be decrypted — it was "
            "edited or written by a different master key. Run: rokan "
            f"save-login {host}"
        ) from exc
    return Credential(
        host=host,
        username=str(entry["username"]),
        password=password,
        totp_seed=seed,
        created_at=str(entry.get("created_at", "")),
        updated_at=str(entry.get("updated_at", "")),
    )


def find_sibling(site: str) -> str | None:
    """Host stored under the same apex, when the exact host has no entry.

    Real services split login across subdomains (``app.x.com`` versus
    ``next-app.x.com``) and the wrong one rejects perfectly valid credentials
    with "incorrect password". Naming the stored host lets the caller say so
    instead of reporting a bad password.
    """
    host = normalize_host(site)
    apex = _apex(host)
    for candidate in _read_map():
        if candidate != host and _apex(candidate) == apex:
            return candidate
    return None


def delete(site: str) -> bool:
    host = normalize_host(site)
    entries = _read_map()
    if host not in entries:
        return False
    del entries[host]
    _write_map(entries)
    return True


def list_sites() -> list[dict[str, Any]]:
    """Every stored login, without decrypting a single secret."""
    out: list[dict[str, Any]] = []
    for host, entry in sorted(_read_map().items()):
        out.append(
            {
                "host": host,
                "username": str(entry.get("username", "")),
                "has_totp": entry.get("totp") is not None,
                "updated_at": str(entry.get("updated_at", "")),
            }
        )
    return out
