"""Pick the one recorded response that carried the data the user was looking at.

This is the whole bet of the learned-replay feature. A single page load fires
dozens of requests — telemetry, feature flags, avatars, session pings — and
exactly one of them (usually) holds the rows the user actually read. If that
response can be found *without any per-site rules*, the feature is a product.
If it needs hand-tuning per site, it is a consultancy and we should not build
it. See ``plans/learned-response-replay-design.md`` §6 for the falsifier.

The signal: **weighted leaf-value overlap**. Parse each JSON response, pull out
its leaf values, weight each by how distinctive it is, and measure what
fraction of that weight appears verbatim in the page's rendered text. The
response whose values densely populate the screen IS the data the user saw.
A telemetry beacon shares nothing with the screen; the table endpoint shares
almost everything.

No site-specific knowledge appears anywhere in this module, by design.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from typing import Any

#: Leaves shorter than this are too common to be evidence — "1", "on", "id"
#: appear on every page by chance, and counting them would let a tiny config
#: blob outscore the real table.
_MIN_INTERESTING_LEN = 4

#: Above this length a value is essentially unique; more characters do not make
#: it more convincing, so the distinctiveness curve flattens here.
_SATURATION_LEN = 24

#: Values that are pure structure rather than content. Matching these against
#: the page proves nothing.
_STOP_VALUES = frozenset(
    {
        "true",
        "false",
        "null",
        "none",
        "nil",
        "yes",
        "no",
        "ok",
        "id",
        "name",
        "type",
        "url",
        "http",
        "https",
        "get",
        "post",
        "asc",
        "desc",
        "utc",
        "gmt",
    }
)

#: Content types that can plausibly carry a data payload, and the prior we give
#: each. Anything unlisted scores zero and is dropped before scoring.
_CTYPE_PRIORS: tuple[tuple[str, float], ...] = (
    ("application/json", 1.0),
    ("application/graphql", 1.0),
    ("application/x-ndjson", 0.95),
    ("text/json", 1.0),
    ("+json", 1.0),
    ("text/plain", 0.35),
    ("text/html", 0.15),
)

#: Resource types worth recording at all. A data payload never arrives as a
#: stylesheet.
_DATA_RESOURCE_TYPES = frozenset({"xhr", "fetch", "document", "other", ""})

_WS_RE = re.compile(r"\s+")
#: A run of hex/base64-ish characters with no vowels reads as a machine token
#: (etag, request id, trace id). Distinctive, but never shown to the user, so
#: counting it in the denominator would unfairly punish real data responses.
_OPAQUE_RE = re.compile(r"^[A-Fa-f0-9]{16,}$|^[A-Za-z0-9_-]{22,}$")


@dataclass(frozen=True)
class RecordedResponse:
    """One response observed during a recorded session.

    The trailing fields carry no weight in scoring. They exist so a
    recording stays an *ordered sequence of operations observed under a
    known page* rather than an undifferentiated pile with one winner. A
    mission that cannot name the operation it is about to perform cannot
    be paused and redirected between steps, and retrofitting that into a
    format that never captured ordering is far more expensive than
    writing two fields down now.
    """

    url: str
    method: str
    status: int
    resource_type: str
    resp_content_type: str
    resp_body: str
    req_headers: dict[str, str] = field(default_factory=dict)
    req_body: str | None = None
    truncated: bool = False
    #: Milliseconds since the recording started. Used only to break ties.
    t_start: float = 0.0
    #: Monotonic capture order within the session. Survives equal timestamps.
    seq: int = 0
    #: The page the user was on when this response arrived — task context.
    page_url: str = ""
    #: False when the recorder deliberately skipped the body. The reason is
    #: always stated, so the recorder's one filter stays inspectable.
    body_captured: bool = True
    body_skip_reason: str = ""


@dataclass(frozen=True)
class RecordedSession:
    """Everything observed while the user performed one real task."""

    host: str
    task_label: str
    page_url: str
    rendered_text: str
    responses: list[RecordedResponse]
    #: Responses seen after the recorder's buffer filled. Non-zero means this
    #: session is PARTIAL — a truncated recording must never be scored as if
    #: it were the whole task.
    dropped: int = 0


@dataclass(frozen=True)
class Candidate:
    """A response, scored against what the page displayed."""

    response: RecordedResponse
    score: float
    overlap: float
    matched_weight: float
    #: How many *distinct* leaf values this response put on the screen.
    matched_count: int
    total_weight: float
    ctype_prior: float
    structure_bonus: float


@dataclass(frozen=True)
class Ranking:
    """Scored candidates, best first, plus the confidence in the top pick."""

    ranked: list[Candidate]
    #: score[0] - score[1]. Thin margins mean two responses look equally like
    #: the data, which is exactly when auto-selection should not be trusted.
    margin: float

    @property
    def best(self) -> Candidate | None:
        return self.ranked[0] if self.ranked else None


def normalize_text(text: str) -> str:
    """Collapse whitespace and case-fold, so page text can be searched cheaply.

    Rendered text wraps and indents in ways the JSON never does, so a verbatim
    comparison against raw ``innerText`` would miss almost everything.
    """
    return _WS_RE.sub(" ", text).casefold()


def _walk_leaves(node: Any, out: list[str], depth: int = 0) -> None:
    if depth > 12:  # pathological nesting; the data is never down there
        return
    if isinstance(node, dict):
        for value in node.values():
            _walk_leaves(value, out, depth + 1)
    elif isinstance(node, list):
        for value in node:
            _walk_leaves(value, out, depth + 1)
    elif isinstance(node, bool) or node is None:
        return  # booleans and nulls carry no identifying content
    elif isinstance(node, (int, float)):
        # Render floats the way a page would, not the way repr() would.
        if isinstance(node, float) and node.is_integer():
            out.append(str(int(node)))
        else:
            out.append(str(node))
    elif isinstance(node, str):
        out.append(node)


def extract_leaf_values(body: str) -> list[str]:
    """Every scalar leaf in a JSON body, de-duplicated, order preserved.

    Returns an empty list for anything that is not parseable JSON — callers
    treat that as "no evidence" rather than an error, because plenty of
    recorded responses are HTML or binary.
    """
    try:
        parsed = json.loads(body)
    except (ValueError, TypeError):
        return []
    leaves: list[str] = []
    _walk_leaves(parsed, leaves)
    seen: set[str] = set()
    unique: list[str] = []
    for leaf in leaves:
        stripped = leaf.strip()
        if not stripped or stripped in seen:
            continue
        seen.add(stripped)
        unique.append(stripped)
    return unique


def value_distinctiveness(value: str) -> float:
    """How much it means that this value showed up on the page.

    ``"1"`` appearing on screen is a coincidence. A 30-character product title
    appearing on screen is proof. Opaque machine tokens score zero: they are
    unique but never displayed, so counting them would penalise the very
    responses we are trying to find.
    """
    stripped = value.strip()
    if not stripped:
        return 0.0
    folded = stripped.casefold()
    if folded in _STOP_VALUES:
        return 0.0
    if len(stripped) < _MIN_INTERESTING_LEN:
        return 0.0
    if _OPAQUE_RE.match(stripped):
        return 0.0
    # Logarithmic so a 200-character blob is not worth ten titles.
    span = min(len(stripped), _SATURATION_LEN) - _MIN_INTERESTING_LEN
    scale = _SATURATION_LEN - _MIN_INTERESTING_LEN
    return 0.25 + 0.75 * (math.log1p(span) / math.log1p(scale))


def content_type_prior(content_type: str) -> float:
    """Prior likelihood that a body of this media type carries the data."""
    lowered = (content_type or "").split(";")[0].strip().casefold()
    if not lowered:
        return 0.0
    for needle, prior in _CTYPE_PRIORS:
        if needle in lowered:
            return prior
    return 0.0


def value_overlap(values: list[str], normalized_text: str) -> tuple[float, float, int]:
    """Weighted ``(matched, total, matched_count)`` against the page text.

    All three are returned because the ratio alone is actively misleading. A
    breadcrumb response holding one field that echoes the page heading matches
    100% of its own values and would outrank the table it sits above. The
    absolute mass and the count of *distinct* values matched are what separate
    "this response explains the screen" from "this response happens to agree
    with one line of it".
    """
    matched = 0.0
    total = 0.0
    matched_count = 0
    for value in values:
        weight = value_distinctiveness(value)
        if weight <= 0.0:
            continue
        total += weight
        if normalize_text(value) in normalized_text:
            matched += weight
            matched_count += 1
    return matched, total, matched_count


def _structure_bonus(body: str, parsed_leaves: int) -> float:
    """Reward bodies shaped like a result set rather than a status blob.

    An array of objects with many leaves is what a list view is made of; a
    ``{"ok": true}`` is not.
    """
    try:
        parsed = json.loads(body)
    except (ValueError, TypeError):
        return 0.0
    bonus = 0.0
    if isinstance(parsed, list) and len(parsed) > 1:
        bonus += 0.10
    elif isinstance(parsed, dict):
        for value in parsed.values():
            if isinstance(value, list) and len(value) > 1:
                bonus += 0.10
                break
    if parsed_leaves >= 12:
        bonus += 0.05
    return bonus


def score_candidate(response: RecordedResponse, normalized_text: str) -> Candidate | None:
    """Score one response, or ``None`` if it cannot be data at all."""
    if response.status >= 400 or response.method.upper() not in {"GET", "POST"}:
        return None
    if response.resource_type.casefold() not in _DATA_RESOURCE_TYPES:
        return None
    prior = content_type_prior(response.resp_content_type)
    if prior <= 0.0:
        return None
    values = extract_leaf_values(response.resp_body)
    if not values:
        return None
    matched, total, matched_count = value_overlap(values, normalized_text)
    if total <= 0.0:
        return None
    overlap = matched / total
    bonus = _structure_bonus(response.resp_body, len(values))
    # Three views of the same evidence, because any one of them alone is
    # gameable by a real page's noise:
    #   overlap  — is this response *about* the screen, or unrelated?
    #   mass     — how much distinctive content does it account for?
    #   coverage — how many separate on-screen facts does it explain?
    # Coverage is what stops a one-field blob echoing the heading from
    # outranking the table underneath it.
    mass = matched / (matched + 6.0)
    coverage = matched_count / (matched_count + 3.0)
    score = prior * (0.45 * overlap + 0.25 * mass + 0.30 * coverage) + bonus
    return Candidate(
        response=response,
        score=score,
        overlap=overlap,
        matched_weight=matched,
        matched_count=matched_count,
        total_weight=total,
        ctype_prior=prior,
        structure_bonus=bonus,
    )


def identify_data_response(session: RecordedSession) -> Ranking:
    """Rank the session's responses by how well they explain the screen."""
    normalized = normalize_text(session.rendered_text)
    scored = [
        candidate
        for candidate in (score_candidate(r, normalized) for r in session.responses)
        if candidate is not None
    ]
    # Later responses win ties: the data fetch usually follows the bootstrap.
    scored.sort(key=lambda c: (c.score, c.response.t_start), reverse=True)
    margin = scored[0].score - scored[1].score if len(scored) >= 2 else (
        scored[0].score if scored else 0.0
    )
    return Ranking(ranked=scored, margin=margin)
