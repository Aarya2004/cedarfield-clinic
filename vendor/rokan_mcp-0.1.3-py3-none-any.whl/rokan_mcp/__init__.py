"""Rokan — authenticated fetch for AI agents.

Give it a URL behind a login. It signs in with credentials stored encrypted on
your own machine, clears a six-digit authenticator code if the site asks for
one, and hands back the page.

It never solves bot checks, never creates accounts, and never puts a password
in a prompt.
"""

from __future__ import annotations

__version__ = "0.1.2"
__all__ = ["__version__"]
