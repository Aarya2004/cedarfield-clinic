"""Record one real session so the identifier can be scored against it.

The Playwright page lives inside the daemon process, not here, so the
recording itself happens there (``record_start`` / ``record_stop``) and this
module is the thin client that drives it and returns a typed session.

Deliberately indiscriminate. The recorder captures every response it sees;
``identify.score_candidate`` is what decides which ones could be data. Keeping
the two apart is what lets the identifier be *tested* — if the recorder also
filtered to plausible-looking candidates, the same assumptions would be applied
twice and a bad scorer would still look good.
"""

from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator
from typing import Any

from .identify import RecordedResponse, RecordedSession


class RecordingError(RuntimeError):
    """The daemon refused to start or finish a recording."""


def _to_response(raw: dict[str, Any]) -> RecordedResponse:
    """Convert one daemon wire dict into a typed response.

    Tolerant by construction: a recording that loses one malformed entry is
    worth far more than one that raises halfway through.
    """
    return RecordedResponse(
        url=str(raw.get("url", "")),
        method=str(raw.get("method", "")),
        status=int(raw.get("status", 0) or 0),
        resource_type=str(raw.get("resource_type", "")),
        resp_content_type=str(raw.get("resp_content_type", "")),
        resp_body=str(raw.get("resp_body", "") or ""),
        req_headers=dict(raw.get("req_headers", {}) or {}),
        req_body=raw.get("req_body"),
        truncated=bool(raw.get("truncated", False)),
        t_start=float(raw.get("t_start", 0.0) or 0.0),
        seq=int(raw.get("seq", 0) or 0),
        page_url=str(raw.get("page_url", "") or ""),
        body_captured=bool(raw.get("body_captured", True)),
        body_skip_reason=str(raw.get("body_skip_reason", "") or ""),
    )


async def start(session: Any) -> None:
    """Begin recording. Clears anything buffered from a previous run."""
    result = await session.send("record_start", {})
    if not result.get("ok"):
        raise RecordingError(str(result.get("error", "record_start failed")))


async def stop(session: Any, *, host: str, task_label: str) -> RecordedSession:
    """Stop recording and return the session, page text included.

    The page text comes back from the same daemon call as the responses so
    that both describe the same instant. Fetching it separately would let the
    page navigate in between, and the identifier's whole signal is the overlap
    between the two.
    """
    result = await session.send("record_stop", {})
    if not result.get("ok"):
        raise RecordingError(str(result.get("error", "record_stop failed")))

    raw_responses = result.get("responses", []) or []
    responses: list[RecordedResponse] = []
    for raw in raw_responses:
        if isinstance(raw, dict):
            with contextlib.suppress(TypeError, ValueError):
                responses.append(_to_response(raw))
    responses.sort(key=lambda r: r.seq)

    return RecordedSession(
        host=host,
        task_label=task_label,
        page_url=str(result.get("page_url", "") or ""),
        rendered_text=str(result.get("rendered_text", "") or ""),
        responses=responses,
        dropped=int(result.get("dropped", 0) or 0),
    )


@contextlib.asynccontextmanager
async def recording(
    session: Any, *, host: str, task_label: str
) -> AsyncIterator[list[RecordedSession]]:
    """Record whatever happens inside the block.

    Yields a one-slot list that holds the session once the block exits::

        async with recorder.recording(sess, host=h, task_label="bookings") as out:
            await login.fetch(url)
        session = out[0]

    The recording is stopped even if the body raises, because a browser left
    recording forever would quietly accumulate every response of every later
    command into a buffer nobody drains.
    """
    await start(session)
    sink: list[RecordedSession] = []
    try:
        yield sink
    finally:
        # A recording is an OBSERVATION of the run, never part of it, so
        # nothing it does may end a task. `RecordingError` and `OSError`
        # were suppressed; an oversized `record_stop` reply raises
        # `ValueError` from the socket reader instead, and that ended a
        # task on zara.com that had done nothing wrong (2026-08-27).
        with contextlib.suppress(Exception):
            sink.append(await stop(session, host=host, task_label=task_label))
