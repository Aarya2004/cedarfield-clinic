"""Reading a login page without asking a model.

Login forms are one of the most stereotyped things on the web: a username box,
a password box, a submit button, and sometimes a six-digit code. Recognising
them with rules rather than a language model makes a fetch take seconds
instead of a minute, cost nothing per call, and — the part that matters most —
behave the same way twice.

Everything here is a pure function over the daemon's snapshot payload, so the
whole classifier is testable without a browser.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit

# --- what a field is called -------------------------------------------------

_USERNAME_HINT = re.compile(
    r"(e-?mail|user\s?name|user[\s_-]?id|\blogin\b|\baccount\b|phone|mobile)", re.I
)
# "code" alone is far too common (promo code, zip code, country code), so the
# generic word only counts when nothing on the negative list is nearby.
_TOTP_HINT = re.compile(
    r"(one[\s-]?time|\botp\b|\b2fa\b|two[\s-]?factor|authenticat|passcode"
    r"|security\s+code|verification\s+code|verify\s+code|\bmfa\b|\btotp\b"
    r"|auth(?:entication)?\s+code|\bcode\b)",
    re.I,
)
_NOT_TOTP = re.compile(
    r"(promo|coupon|discount|referral|invite|gift|zip|postal|post\s?code"
    r"|country|area\s+code|currency|barcode|\bqr\b|language|region)",
    re.I,
)
_CONFIRM_PASSWORD = re.compile(
    r"(confirm|repeat|re-?enter|re-?type|\bagain\b|verify\s+password|new\s+password)", re.I
)

# --- what a button does -----------------------------------------------------

_SUBMIT_POSITIVE = re.compile(
    r"^\s*(sign\s?in|log\s?in|login|signin|continue|next|submit|verify"
    r"|confirm|authenticate|send\s+code|proceed)\b",
    re.I,
)
# Checked first and wins outright. "Continue with Google" must never be read as
# "Continue", and clicking "Sign up" on a login page would create an account —
# which Rokan must never do by accident.
_SUBMIT_NEGATIVE = re.compile(
    r"(sign\s?up|signup|register|create\s+(an\s+)?account|forgot|reset|cancel"
    r"|\bback\b|with\s+(google|github|apple|microsoft|facebook|okta|slack|x\b"
    r"|twitter|linkedin|gitlab|discord|saml|sso)"
    r"|use\s+(google|github|apple|microsoft|sso|passkey|single\s+sign)"
    r"|passkey|magic\s+link|email\s+me|single\s+sign|\bsso\b|show\s+password"
    r"|remember|privacy|terms|cookie|help|support|contact)",
    re.I,
)

_LOGIN_URL = re.compile(
    r"(^|/)(login|log-in|signin|sign-in|sign_in|auth|authenticate|authorize"
    r"|sessions?/new|users/sign_in|account/login|challenge|mfa|2fa|verify)(/|$|\?|#)",
    re.I,
)
_LOGIN_COPY = re.compile(
    r"\b(sign in|log in|login|welcome back|continue to your account"
    r"|enter your password|session expired|you (must|need to) (be )?(sign|log))\b",
    re.I,
)
# Bot walls that are a whole page rather than a widget. The daemon detects the
# embedded kind (a reCAPTCHA or Turnstile frame inside a form), but an
# interstitial — Cloudflare's "Performing security verification" — has no
# widget to find: it is a near-empty page with a line of prose. Measured on
# gitlab.com/users/sign_in, which without this reads as an ordinary page with
# no login form, so a fetch would hand the block page back as if it were the
# content the caller asked for. That is the worst failure this product has.
_BOT_WALL = re.compile(
    r"(performing\s+security\s+verification|checking\s+(if\s+)?your\s+browser"
    r"|verify(ing)?\s+(that\s+)?you\s+are\s+(a\s+)?human|are\s+you\s+a\s+robot"
    r"|enable\s+javascript\s+and\s+cookies|ddos\s+protection\s+by"
    r"|just\s+a\s+moment|please\s+stand\s+by|unusual\s+traffic"
    r"|attention\s+required|ray\s+id|access\s+denied|request\s+blocked"
    # Phrasings this missed, measured on real walls (2026-08-27).
    # pngtree.com serves "Human verification / We apologize for the
    # confusion, but we can't quite tell if you're a person or a script /
    # I am human" — a bot wall in every respect, which fell through to the
    # second-factor branch and was reported to the user as
    # "no login stored for pngtree.com".
    r"|human\s+verification|i\s+am\s+human|(?:person|human)\s+or\s+a\s+script"
    r"|i'?m\s+not\s+a\s+robot|verify\s+you'?re\s+human"
    r"|complete\s+the\s+security\s+check|additional\s+verification\s+required)",
    re.I,
)
# A block page is nearly empty. A real page that merely mentions these phrases
# has navigation, links and content, so the element count separates them.
_BOT_WALL_MAX_ELEMENTS = 8

#: Most interactive elements a page can have and still plausibly BE a
#: sign-in page rather than merely mention one.
#:
#: MEASURED, 2026-08-23, through the real daemon:
#:
#:     github.com/login              15 fields   a real wall
#:     news.ycombinator.com/login     7
#:     gitlab.com/users/sign_in       2
#:     ---
#:     postgresql.org/support/…      30 fields   content
#:     pypi.org/project/pytest      126
#:     stackoverflow.com/questions  187
#:     developer.mozilla.org/…      250
#:     w3schools.com/tags/…         251
#:
#: Forty sits far from both clusters. It exists because the two-step-form
#: branch below fired on w3schools — a public documentation page with a
#: newsletter input and the words "Sign in" in its nav — and Rokan then
#: refused to read a public page because no login was stored for it. That
#: shape is most of the commercial web: an email field plus a sign-in link.
_LOGIN_PAGE_MAX_FIELDS = 40

_ERROR_COPY = re.compile(
    r"(incorrect|invalid|wrong|does\s?n[o']?t match|could\s?n[o']?t (find|sign|log)"
    r"|unable to (log|sign)|try again|too many (attempts|requests)|not recognized"
    r"|is required|expired|locked|disabled|denied|unauthor|forbidden|failed)",
    re.I,
)

_TEXT_INPUT_TYPES = frozenset({"", "text", "email", "tel", "number", "search", "url"})
_BUTTON_TYPES = frozenset({"submit", "button"})


@dataclass(frozen=True, slots=True)
class Field:
    """One interactive element from a snapshot."""

    ref: str
    role: str
    label: str
    placeholder: str
    input_type: str
    dom_id: str
    disabled: bool
    filled: bool

    @property
    def haystack(self) -> str:
        return f"{self.label} {self.placeholder} {self.dom_id}".strip().lower()


@dataclass(frozen=True, slots=True)
class PageState:
    """What the page in front of us is, and which elements to act on."""

    kind: str  # authenticated | login | totp | signup | captcha | unknown
    username: Field | None = None
    password: Field | None = None
    totp: Field | None = None
    submit: Field | None = None
    error_text: str | None = None
    detail: str = ""


def parse_fields(ref_map: dict[str, Any]) -> list[Field]:
    fields: list[Field] = []
    for ref, raw in (ref_map or {}).items():
        if not isinstance(raw, dict):
            continue
        fields.append(
            Field(
                ref=str(ref),
                role=str(raw.get("role", "") or ""),
                label=str(raw.get("label", "") or ""),
                placeholder=str(raw.get("placeholder", "") or ""),
                input_type=str(raw.get("input_type", "") or "").lower(),
                dom_id=str(raw.get("dom_id", "") or ""),
                disabled=bool(raw.get("disabled")),
                filled=bool(raw.get("filled")),
            )
        )
    return fields


def _is_text_input(field: Field) -> bool:
    return field.role in {"input", "textbox", "combobox"} and field.input_type in _TEXT_INPUT_TYPES


def _is_button(field: Field) -> bool:
    return field.role in {"button", "link"} or field.input_type in _BUTTON_TYPES


def find_password(fields: list[Field]) -> Field | None:
    candidates = [f for f in fields if f.input_type == "password" and not f.disabled]
    if not candidates:
        return None
    # On a form with a confirmation box the first one is the real password.
    primary = [f for f in candidates if not _CONFIRM_PASSWORD.search(f.haystack)]
    return (primary or candidates)[0]


def find_confirm_password(fields: list[Field]) -> Field | None:
    for f in fields:
        if f.input_type == "password" and _CONFIRM_PASSWORD.search(f.haystack):
            return f
    return None


def find_username(fields: list[Field]) -> Field | None:
    texts = [f for f in fields if _is_text_input(f) and not f.disabled]
    if not texts:
        return None
    for f in texts:  # an explicit type=email is the strongest signal there is
        if f.input_type == "email":
            return f
    named = [f for f in texts if _USERNAME_HINT.search(f.haystack)]
    if named:
        return named[0]
    # A lone text box sitting next to a password box is the username, whatever
    # the site chose to label it.
    return texts[0] if len(texts) == 1 else None


def find_totp(fields: list[Field]) -> Field | None:
    for f in fields:
        if f.input_type == "password" or f.disabled or not _is_text_input(f):
            continue
        hay = f.haystack
        if _TOTP_HINT.search(hay) and not _NOT_TOTP.search(hay):
            return f
    return None


def find_submit(fields: list[Field]) -> Field | None:
    buttons = [f for f in fields if _is_button(f) and not f.disabled]
    usable = [f for f in buttons if not _SUBMIT_NEGATIVE.search(f.haystack)]
    for f in usable:
        if _SUBMIT_POSITIVE.search(f.label.strip()):
            return f
    for f in usable:
        if f.input_type == "submit":
            return f
    # A single unambiguous control is worth trying; several are not, because
    # picking the wrong one on a login page can mean registering an account.
    # Links are excluded here: on a half-rendered page the only remaining
    # candidate is often a nav link, and resend.com/login was measured picking
    # "Home" that way. A real submit is a button or an input[type=submit].
    if len(usable) == 1 and (usable[0].role == "button" or usable[0].input_type == "submit"):
        return usable[0]
    return None


def extract_error(texts: list[str] | None) -> str | None:
    for raw in texts or []:
        text = str(raw).strip()
        if 3 <= len(text) <= 300 and _ERROR_COPY.search(text):
            return text
    return None


def looks_like_login_url(url: str) -> bool:
    parts = urlsplit(url or "")
    return bool(_LOGIN_URL.search(parts.path or "")) or bool(_LOGIN_URL.search(parts.query or ""))


def page_mentions_login(texts: list[str] | None) -> bool:
    return any(_LOGIN_COPY.search(str(t)) for t in (texts or []))


def classify(snapshot: dict[str, Any]) -> PageState:
    """Decide what the current page is and what to act on next."""
    captcha = snapshot.get("captcha")
    if isinstance(captcha, dict) and captcha.get("present"):
        return PageState(
            kind="captcha",
            detail=str(captcha.get("kind") or "bot check"),
        )

    fields = parse_fields(snapshot.get("ref_map") or {})
    texts = [str(t) for t in (snapshot.get("page_text") or [])]
    url = str(snapshot.get("url") or "")

    password = find_password(fields)
    username = find_username(fields)
    totp = find_totp(fields)
    submit = find_submit(fields)
    error = extract_error(texts)

    # A guess about what one text input IS must not out-rank what the page
    # SAYS. pngtree's wall carries a single box labelled "Fill in the
    # verification code", which `find_username` claims — so a page reading
    # "Human verification / we can't quite tell if you're a person or a
    # script / I am human" was excluded from this branch by the very field
    # that proves it is a wall (2026-08-27). A password field still
    # excludes it: that is a sign-in, whatever else is written on it.
    if (
        password is None
        and len(fields) <= _BOT_WALL_MAX_ELEMENTS
        and _BOT_WALL.search(" ".join([*texts, str(snapshot.get("title") or "")]))
    ):
        return PageState(kind="captcha", detail="bot wall")

    # Registering an account is never something a fetch should do on its own.
    if password is not None:
        signup_button = any(
            _is_button(f)
            and re.search(r"(sign\s?up|register|create\s+(an\s+)?account)", f.haystack, re.I)
            and _SUBMIT_POSITIVE.search(f.label.strip()) is None
            for f in fields
        )
        if find_confirm_password(fields) is not None or (
            signup_button and not _LOGIN_COPY.search(" ".join(texts))
        ):
            return PageState(
                kind="signup",
                username=username,
                password=password,
                submit=submit,
                error_text=error,
                detail="this page creates a new account",
            )

    # A password field makes this a login page only if the page IS one. The
    # same measurement that justifies `_LOGIN_PAGE_MAX_FIELDS` for the
    # two-step branch applies here and was simply never applied: real login
    # pages are small, and half the commercial web is a large content page
    # carrying a sign-in MODAL, password field and all.
    #
    # Measured on pngtree.com (2026-08-27): asked to browse a public
    # gallery and note the file formats of the first ten assets, Rokan
    # refused with "no login stored for pngtree.com" — for a page anyone
    # can read without an account.
    #
    # The trade, stated plainly and unchanged from the branch below: a
    # genuine sign-in page at a URL that does not look like one AND
    # carrying 40+ interactive elements now falls through, and the
    # sign-in page is returned as content. `login.fetch`'s resettle guard
    # still catches it whenever the URL is login-shaped, and an
    # account-scoped question is refused before it gets here.
    if password is not None and (
        looks_like_login_url(url) or len(fields) <= _LOGIN_PAGE_MAX_FIELDS
    ):
        return PageState(
            kind="login",
            username=username,
            password=password,
            totp=totp,
            submit=submit,
            error_text=error,
            detail="password form",
        )

    if totp is not None:
        return PageState(
            kind="totp", totp=totp, submit=submit, error_text=error, detail="second factor"
        )

    # First half of a two-step form: the username is asked for on its own page,
    # the password arrives after "Next". Only read it that way when the page or
    # the URL actually says this is a sign-in.
    #
    # MENTIONING a sign-in is not being one. "Sign in" in the nav plus any
    # text input matched a documentation page with 251 fields, and the fetch
    # then abstained asking for a credential to read something public. So
    # when the URL does not say login, the page must also be small enough to
    # be a login page — see `_LOGIN_PAGE_MAX_FIELDS` for the measurements.
    #
    # The trade, stated plainly: a genuine two-step sign-in page at a URL
    # that does not look like one AND carrying 40+ interactive elements now
    # falls through to "authenticated" and returns the sign-in page as the
    # answer. That is the failure this branch was written to prevent. It is
    # the rarer of the two by a wide margin — and the resettle guard in
    # `login.fetch` still catches it whenever the URL is login-shaped.
    if username is not None and (
        looks_like_login_url(url)
        or (page_mentions_login(texts) and len(fields) <= _LOGIN_PAGE_MAX_FIELDS)
    ):
        return PageState(
            kind="login",
            username=username,
            submit=submit,
            error_text=error,
            detail="username step of a two-step form",
        )

    if looks_like_login_url(url) and (username is not None or page_mentions_login(texts)):
        return PageState(kind="unknown", error_text=error, detail="login page with no usable form")

    return PageState(kind="authenticated", detail="no login wall in the way")
