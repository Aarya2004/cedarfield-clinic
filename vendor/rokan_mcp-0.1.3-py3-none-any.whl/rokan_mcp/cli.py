"""The `rokan` command.

Credentials are entered here and nowhere else. The terminal is the only place a
password is typed, so it never reaches a model, a transcript, or a log.
"""

from __future__ import annotations

import argparse
import asyncio
import getpass
import json
import os
import sys
from pathlib import Path
from typing import Any

from . import license, login, vault

INSTALL_LINE = "claude mcp add rokan -- uvx rokan-mcp"


def _out(msg: str = "") -> None:
    print(msg, file=sys.stdout)


def _err(msg: str) -> None:
    print(msg, file=sys.stderr)


def cmd_save_login(args: argparse.Namespace) -> int:
    try:
        host = vault.normalize_host(args.site)
    except ValueError as exc:
        _err(f"error: {exc}")
        return 2

    _out(f"Storing a login for {host}.")
    _out("Nothing typed here is sent anywhere — it is encrypted on this machine.")
    _out()

    username = (args.username or input("Username or email: ")).strip()
    if not username:
        _err("error: a username is required")
        return 2

    password = os.environ.get("ROKAN_SAVE_PASSWORD") or getpass.getpass("Password (hidden): ")
    if not password:
        _err("error: a password is required")
        return 2

    totp_secret: str | None = args.totp
    if totp_secret is None and not args.no_totp:
        _out()
        _out("If this site asks for a six-digit code, paste the authenticator setup key")
        _out("(the 'manual entry' or 'setup key' string shown next to the QR code).")
        totp_secret = getpass.getpass("TOTP setup key (hidden, blank to skip): ").strip() or None

    try:
        stored_host, has_totp = vault.save(host, username, password, totp_secret)
    except (ValueError, vault.VaultError) as exc:
        _err(f"error: {exc}")
        return 2

    _out()
    _out(f"Saved {username} for {stored_host}" + (" with two-factor." if has_totp else "."))
    _out(f"Try it:  rokan fetch https://{stored_host}")
    return 0


def cmd_list(_args: argparse.Namespace) -> int:
    sites = vault.list_sites()
    if not sites:
        _out("No logins stored. Add one with:  rokan save-login <site>")
        return 0
    width = max(len(str(s["host"])) for s in sites)
    for site in sites:
        flag = "  2FA" if site["has_totp"] else ""
        _out(f"{str(site['host']):<{width}}  {site['username']}{flag}")
    return 0


def cmd_delete(args: argparse.Namespace) -> int:
    try:
        removed = vault.delete(args.site)
    except (ValueError, vault.VaultError) as exc:
        _err(f"error: {exc}")
        return 2
    if removed:
        _out(f"Removed the login for {vault.normalize_host(args.site)}.")
        return 0
    _out(f"No login was stored for {args.site}.")
    return 1


def cmd_fetch(args: argparse.Namespace) -> int:
    quota = license.check_quota()
    if not quota.allowed:
        _err(f"error: {quota.message}")
        return 3

    result = asyncio.run(login.fetch(args.url, visible=args.visible))
    used = license.record_success() if result.ok else quota.used

    if args.json:
        _out(json.dumps(result.to_dict(), indent=2, default=str))
        return 0 if result.ok else 1

    if not result.ok:
        _err(f"failed: {result.reason}")
        _err(result.message)
        if result.next_step:
            _err("")
            _err(result.next_step)
        return 1

    _out(result.title)
    _out(f"{result.url}   ({result.elapsed_ms} ms, {result.steps} step(s))")
    if result.actions:
        _out(f"Did: {', '.join(result.actions)}")
    _out(f"Fetches left this month: {max(0, quota.limit - used)}")
    _out("-" * 72)
    _out(result.text[: args.max_chars])
    return 0


def cmd_close(_args: argparse.Namespace) -> int:
    from . import browser

    count = asyncio.run(browser.close_orphans())
    _out(f"Closed {count} browser session(s).")
    return 0


def cmd_status(_args: argparse.Namespace) -> int:
    lic = license.load_license()
    quota = license.check_quota()
    _out(f"Plan:      {lic.plan}" + (f"  ({lic.email})" if lic.email else ""))
    if not lic.valid:
        _out(f"Licence:   INVALID — {lic.problem}")
    elif lic.expires:
        _out(f"Expires:   {lic.expires}")
    _out(f"This month: {quota.used} of {quota.limit} successful fetches used")
    _out(f"Sites:     {len(vault.list_sites())} configured")
    if not lic.is_paid:
        _out()
        _out(f"Upgrade for more: {license.BUY_URL}")
    return 0


def cmd_activate(args: argparse.Namespace) -> int:
    try:
        lic = license.install_license(args.key)
    except ValueError as exc:
        _err(f"error: {exc}")
        return 2
    _out(f"Activated the {lic.plan} plan for {lic.email}.")
    until = f", until {lic.expires}." if lic.expires else "."
    _out(f"{lic.quota} successful fetches a month{until}")
    return 0


def cmd_install(_args: argparse.Namespace) -> int:
    _out("Add Rokan to Claude Code:")
    _out()
    _out(f"    {INSTALL_LINE}")
    _out()
    _out("Or add this to any MCP client's config:")
    _out()
    _out(
        json.dumps(
            {"mcpServers": {"rokan": {"command": "uvx", "args": ["rokan-mcp"]}}},
            indent=2,
        )
    )
    _out()
    _out("Then store a login:   rokan save-login <site>")
    return 0


def cmd_issue(args: argparse.Namespace) -> int:
    """Mint a licence key. Requires the issuer private key — not shipped to users."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    raw = os.environ.get("ROKAN_ISSUER_KEY", "").strip()
    if not raw:
        key_path = Path.home() / ".rokan-issuer.key"
        if not key_path.exists():
            _err("error: no issuer key (set ROKAN_ISSUER_KEY or place ~/.rokan-issuer.key)")
            return 2
        raw = key_path.read_text(encoding="utf-8").strip()

    payload: dict[str, Any] = {
        "email": args.email,
        "plan": args.plan,
        "quota": args.quota or license.PLAN_QUOTAS.get(args.plan, 2_000),
        "expires": args.expires,
    }
    signer = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(raw))
    token = license.encode_token(payload, signer.sign(license.signed_bytes(payload)))

    check = license.verify_token(token)
    if not check.valid:
        _err(f"error: minted a key that does not verify ({check.problem})")
        return 1

    _out(token)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rokan-fetch",
        description="Authenticated fetch for AI agents.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("save-login", help="store a login for a site (prompts, never echoes)")
    p.add_argument("site")
    p.add_argument("--username", help="skip the username prompt")
    p.add_argument("--totp", help="TOTP setup key (prefer the interactive prompt)")
    p.add_argument("--no-totp", action="store_true", help="skip the two-factor prompt")
    p.set_defaults(func=cmd_save_login)

    p = sub.add_parser("list", help="list stored logins (never shows passwords)")
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("delete", help="remove a stored login")
    p.add_argument("site")
    p.set_defaults(func=cmd_delete)

    p = sub.add_parser("fetch", help="fetch a page behind a login")
    p.add_argument("url")
    p.add_argument("--visible", action="store_true", help="show the browser window")
    p.add_argument("--json", action="store_true", help="emit the raw result")
    p.add_argument("--max-chars", type=int, default=4000)
    p.set_defaults(func=cmd_fetch)

    p = sub.add_parser("status", help="show plan and usage")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("close", help="shut down any browsers Rokan left running")
    p.set_defaults(func=cmd_close)

    p = sub.add_parser("activate", help="install a licence key")
    p.add_argument("key")
    p.set_defaults(func=cmd_activate)

    p = sub.add_parser("install", help="print the MCP install command")
    p.set_defaults(func=cmd_install)

    p = sub.add_parser("issue", help=argparse.SUPPRESS)
    p.add_argument("--email", required=True)
    p.add_argument("--plan", default="pro", choices=sorted(license.PLAN_QUOTAS))
    p.add_argument("--quota", type=int)
    p.add_argument("--expires", required=True, help="YYYY-MM-DD")
    p.set_defaults(func=cmd_issue)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result: int = args.func(args)
    except KeyboardInterrupt:
        print("\n  stopped.", file=sys.stderr)
        return 130
    except vault.VaultError as exc:
        # `save-login` and `delete` caught this; `list`, `status` and `fetch`
        # did not — so the one carefully written sentence for a replaced
        # master key ("the stored logins are unrecoverable") was the last
        # line of a forty-line stack dump.
        print(f"\n  ✕ {exc}", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001 — the last line before the user
        print(f"\n  ✕ {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    return result


if __name__ == "__main__":
    raise SystemExit(main())
