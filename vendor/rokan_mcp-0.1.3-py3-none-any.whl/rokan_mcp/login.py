"""Get through the login wall, then hand back the page.

The rules this follows are deliberate and not tunable:

* **One password attempt per fetch.** If the first submission is rejected we
  stop and report what the site said. Retrying is how accounts get locked.
* **Never submit a registration form.** If the page turns out to create an
  account, we stop without touching it.
* **Never solve a bot check.** We detect it, keep the browser alive so a human
  can clear it, and say so plainly.
"""

from __future__ import annotations

import asyncio
import contextlib
import sys
import time
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlsplit

from . import forms, vault, sessions
from .browser import BrowserError, session_for
from .totp import generate_code

MAX_STEPS = 6
_TEXT_LIMIT = 30_000

# Every way a fetch can fail, and what the caller should do about it. The
# guidance is written for an agent to act on without asking a human first,
# except where a human genuinely is the only way forward.
NEXT_STEPS: dict[str, str] = {
    "no_credential": (
        "No login is stored for this site. Call rokan_save_login with the username and "
        "password (and the TOTP setup key if the site asks for a six-digit code), then "
        "retry this fetch."
    ),
    "captcha_blocked": (
        "A bot check is in the way. Rokan does not solve these by design. Call "
        "rokan_fetch again with visible=true, ask the user to clear the challenge in "
        "the window that opens, then fetch once more — the signed-in session is kept."
    ),
    "credential_may_be_exposed": (
        "The page navigated to another site WHILE the password was being "
        "typed, so some of it may have reached that site. Rokan cannot "
        "recall keystrokes. Change this password on the service now, then "
        "update the stored one with rokan_save_login."
    ),
    "credential_origin_refused": (
        "The sign-in form is not on the site the stored login belongs to — a "
        "redirect moved the page to another origin, so Rokan typed nothing. "
        "Open the URL yourself and confirm where it leads before retrying."
    ),
    "login_rejected": (
        "The site rejected the stored credentials. Rokan stops after one attempt rather "
        "than risk locking the account. Ask the user to confirm the username and "
        "password, then update them with rokan_save_login."
    ),
    "signup_page": (
        "That URL is a registration form, not a login. Rokan will not create accounts. "
        "Point it at the sign-in URL instead."
    ),
    "totp_required_no_seed": (
        "The site is asking for a six-digit code and no TOTP secret is stored. Ask the "
        "user for the authenticator setup key and save it with rokan_save_login."
    ),
    "email_code_required": (
        "The site emailed a one-time code rather than using an authenticator app. "
        "Rokan cannot read the user's email in this version — ask the user for the code."
    ),
    "submit_not_found": (
        "The login fields were found but no submit button was. Retry with visible=true "
        "to see the page, or report the URL so the form can be supported."
    ),
    "login_form_not_found": (
        "This looks like a login page but no username or password field was found — it "
        "may be a single-sign-on or passkey flow, which this version does not drive."
    ),
    "navigation_failed": "The page did not load. Check the URL and the network connection.",
    "invalid_url": (
        "That is not a URL Rokan can key a login to. Pass a full URL with a "
        "registrable hostname, e.g. https://app.yourtool.com/settings — bare "
        "names like 'localhost' are not supported."
    ),
    # sys.executable rather than bare `python`: under uvx/pipx the user's shell
    # python has no playwright module, but the interpreter running this server
    # always does — the hint must be pasteable in every install mode.
    "browser_unavailable": (
        f"Chromium could not be started. Run: {sys.executable} -m playwright install chromium"
    ),
    "too_many_steps": (
        "The login did not settle after several steps. Retry with visible=true to watch "
        "what the page is doing."
    ),
}


@dataclass(slots=True)
class FetchResult:
    ok: bool
    url: str = ""
    title: str = ""
    text: str = ""
    authenticated: bool = False
    login_performed: bool = False
    #: Did a session for this host ever actually get established — this run
    #: or a recorded earlier one?
    #:
    #: `authenticated` is set on EVERY successful fetch, so it means "a
    #: usable page came back", not "this page sat behind a session".
    #: Measured 2026-08-24: supabase.com's public homepage and
    #: githubstatus.com (no account at all) both reported
    #: `authenticated=True`. An account-scoped question needs THIS fact.
    session_backed: bool = False
    steps: int = 0
    elapsed_ms: int = 0
    reason: str | None = None
    message: str = ""
    next_step: str | None = None
    actions: list[str] = field(default_factory=list)
    #: True when the page was longer than `_TEXT_LIMIT` and what came back
    #: is the first part of it.
    #:
    #: Silence here is a lie by omission, and it produced one: curl's manual
    #: page is 263,000 characters, the answer to "how many redirects does
    #: curl follow" sits at 114,000, and the caller was handed 30,000 with
    #: no indication there was more. The failure then read "expected
    #: '--max-redirs' on the page" — which sounds like the site does not say
    #: it, when the truth is that we stopped reading before we got there.
    truncated: bool = False

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "ok": self.ok,
            "url": self.url,
            "authenticated": self.authenticated,
            "login_performed": self.login_performed,
            "session_backed": self.session_backed,
            "steps": self.steps,
            "elapsed_ms": self.elapsed_ms,
            "actions": self.actions,
        }
        if self.ok:
            payload["title"] = self.title
            payload["text"] = self.text
            payload["truncated"] = self.truncated
        else:
            payload["reason"] = self.reason
            payload["message"] = self.message
            payload["next_step"] = self.next_step
        return payload


def _fail(reason: str, message: str, **kw: Any) -> FetchResult:
    return FetchResult(
        ok=False,
        reason=reason,
        message=message,
        next_step=NEXT_STEPS.get(reason),
        **kw,
    )


def _fingerprint(snapshot: dict[str, Any]) -> str:
    refs = snapshot.get("ref_map") or {}
    labels = sorted(f"{k}:{v.get('label', '')}" for k, v in refs.items() if isinstance(v, dict))
    return f"{snapshot.get('url', '')}|{'|'.join(labels)}"


def _same_page(a: str, b: str) -> bool:
    pa, pb = urlsplit(a), urlsplit(b)
    return (pa.netloc, pa.path.rstrip("/")) == (pb.netloc, pb.path.rstrip("/"))


async def _snapshot(
    session: Any, url: str | None = None, *, reload: bool = False
) -> dict[str, Any]:
    args: dict[str, Any] = {"url": url} if url else {}
    if reload and url:
        args["reload"] = True
    result: dict[str, Any] = await session.send("snapshot", args)
    return result


async def fetch(
    url: str,
    *,
    visible: bool = False,
    timeout_s: float = 120.0,
    reload: bool = False,
) -> FetchResult:
    """Return the content at ``url``, signing in first if the site demands it.

    ``reload`` forces a real re-fetch of the first page. Without it, a caller
    that asks for the same url twice is handed the copy already open in the
    tab — correct for an agent working a page, and silently fatal for anything
    checking one url on a schedule.
    """
    started = time.monotonic()

    try:
        host = vault.normalize_host(url)
    except ValueError as exc:
        # Not a navigation problem: nothing was ever dialled. Saying "check
        # the network" here sends the caller to debug the wrong thing.
        return _fail("invalid_url", str(exc))
    if not url.lower().startswith(("http://", "https://")):
        url = "https://" + url.lstrip("/")

    try:
        session = await session_for(host, headless=not visible)
    except BrowserError as exc:
        return _fail("browser_unavailable", str(exc))

    try:
        return await asyncio.wait_for(
            _drive(session, url, host, started, reload=reload), timeout=timeout_s
        )
    except TimeoutError:
        return _fail(
            "too_many_steps",
            f"gave up after {timeout_s:.0f}s",
            elapsed_ms=int((time.monotonic() - started) * 1000),
        )


def _origin_of(page_url: str) -> str:
    """The page's host for a MESSAGE — never raising.

    `normalize_host` raises on an empty or non-http url, and the refusal
    message called it on exactly the urls that had just failed the check.
    So the guard declined correctly and then crashed building the sentence
    that says so.
    """
    try:
        return vault.normalize_host(page_url) or "nowhere"
    except ValueError:
        # NOT the url itself: it is attacker-controlled and this string is
        # model-facing prose. The full url is already carried in `url=`.
        return "an origin Rokan could not name"


def _same_site(page_url: str, host: str) -> bool:
    """Is this page on the site the credential belongs to?

    A sign-in form is a place to type a password, and the only thing that
    makes it safe is being on the right site. Nothing checked. `fetch`
    derives the vault host once, from the URL the user asked for, and every
    `page.goto` after that follows redirects — so an open redirect, a
    hijacked CDN, an injected script or a third-party IdP could move the
    page to another origin and the stored password was typed into whatever
    form was there. Reproduced: asked for app.example.com, filled at
    evil-idp.example.net, `ok=True`.

    The asymmetry made it plain. `session_fetch` refuses a host mismatch
    twice for a request that carries only cookies; the one path that carries
    the plaintext password had no check at all.

    A subdomain is the same site — accounts.example.com signs you in to
    example.com — and "example.com.attacker.net" is not, because it does not
    END with ".example.com".
    """
    if not host:
        return False
    try:
        here = vault.normalize_host(page_url)
    except ValueError:
        # An empty url, about:blank, a data: page, anything unparseable.
        # `normalize_host` RAISES on these rather than returning "", so the
        # check crashed out of the login state machine instead of declining
        # — and a crash escapes the Result contract entirely, which is worse
        # than the refusal it was supposed to produce. An origin we cannot
        # name is not the credential's origin.
        return False
    if not here:
        return False
    return here == host or here.endswith("." + host)


#: What a page's kind means once credentials have been accepted. Module
#: scope, NOT function scope: it lived inside the `not _same_page` branch
#: and a later reader used it unconditionally, so every same-page run
#: raised UnboundLocalError — a crash shipped to the branch and caught by
#: review, not by 265 green tests, because every test navigated away.
_AFTER_LOGIN_REFUSALS = {
    "login": "login_rejected",
    # NOT `totp_required_no_seed` — a seed may well be stored, and that
    # reason's guidance sends the user to find an authenticator setup key
    # they already saved. Reaching a code prompt on the page we asked for,
    # after the password was accepted, means the sign-in did not complete.
    "totp": "login_rejected",
    "captcha": "captcha_blocked",
    "signup": "signup_page",
}


async def _drive(
    session: Any, url: str, host: str, started: float, *, reload: bool = False
) -> FetchResult:
    actions: list[str] = []
    login_performed = False
    password_submitted = False
    totp_submitted = False
    credential: vault.Credential | None = None
    last_fingerprint = ""

    snapshot = await _snapshot(session, url, reload=reload)
    if not snapshot.get("ok"):
        # Chromium missing is not a navigation problem, and saying so would
        # send a first-run user to debug their network instead of running
        # one install command.
        if snapshot.get("error") == "chromium_missing":
            return _fail(
                "browser_unavailable",
                "chromium is not installed",
                elapsed_ms=int((time.monotonic() - started) * 1000),
            )
        return _fail(
            "navigation_failed",
            f"could not load {url}: {snapshot.get('error', 'unknown error')}",
            elapsed_ms=int((time.monotonic() - started) * 1000),
        )

    steps = 0
    resettled = False
    for steps in range(1, MAX_STEPS + 1):
        state = forms.classify(snapshot)

        # Sitting on a sign-in URL with no sign-in form on it is a
        # contradiction, and on a client-rendered page it usually means the
        # snapshot landed before the form mounted. Measured on railway.com and
        # resend.com. Look once more before believing it — concluding
        # "authenticated" here would return the login page as the answer.
        if (
            not resettled
            and state.kind in {"authenticated", "unknown"}
            and forms.looks_like_login_url(str(snapshot.get("url", "")))
        ):
            resettled = True
            await asyncio.sleep(1.5)
            resnapped = await _snapshot(session)
            if resnapped.get("ok"):
                snapshot = resnapped
                state = forms.classify(snapshot)

        if state.kind == "captcha":
            return _fail(
                "captcha_blocked",
                f"a {state.detail} challenge is in the way at "
                f"{snapshot.get('url', url)}",
                url=str(snapshot.get("url", url)),
                login_performed=login_performed,
                steps=steps,
                actions=actions,
                elapsed_ms=int((time.monotonic() - started) * 1000),
            )

        if state.kind == "signup":
            return _fail(
                "signup_page",
                f"{snapshot.get('url', url)} is a registration form; Rokan does not "
                "create accounts",
                url=str(snapshot.get("url", url)),
                steps=steps,
                actions=actions,
                elapsed_ms=int((time.monotonic() - started) * 1000),
            )

        if state.kind == "authenticated":
            break

        if state.kind == "unknown":
            return _fail(
                "login_form_not_found",
                state.error_text or f"no usable login form at {snapshot.get('url', url)}",
                url=str(snapshot.get("url", url)),
                steps=steps,
                actions=actions,
                elapsed_ms=int((time.monotonic() - started) * 1000),
            )

        # From here the page is a login or a second-factor challenge.
        if credential is None:
            try:
                credential = vault.get(host)
            except vault.VaultError as exc:
                # A stored-credential problem, not an internal error. It used
                # to escape `fetch` entirely — `BrowserError` and
                # `TimeoutError` were caught and this was not — and reached
                # the MCP client as `internal_error` with no reason and no
                # next step.
                return _fail(
                    "no_credential",
                    str(exc),
                    url=str(snapshot.get("url", url)),
                    steps=steps,
                    actions=actions,
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                )
            if credential is None:
                sibling = vault.find_sibling(host)
                extra = (
                    f" A login is stored for {sibling}, which is a different host on the "
                    f"same service — credentials saved there will be rejected by {host}."
                    if sibling
                    else ""
                )
                return _fail(
                    "no_credential",
                    f"no login stored for {host}.{extra}",
                    url=str(snapshot.get("url", url)),
                    steps=steps,
                    actions=actions,
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                )

        fingerprint = _fingerprint(snapshot)
        stuck = fingerprint == last_fingerprint
        last_fingerprint = fingerprint

        if state.kind == "totp" or (state.totp is not None and password_submitted):
            if totp_submitted or stuck:
                return _fail(
                    "login_rejected",
                    state.error_text or "the six-digit code was not accepted",
                    url=str(snapshot.get("url", url)),
                    login_performed=login_performed,
                    steps=steps,
                    actions=actions,
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                )
            if credential.totp_seed is None:
                reason = (
                    "email_code_required"
                    if "email" in (state.totp.haystack if state.totp else "")
                    else "totp_required_no_seed"
                )
                return _fail(
                    reason,
                    f"{host} is asking for a one-time code and none can be generated",
                    url=str(snapshot.get("url", url)),
                    login_performed=login_performed,
                    steps=steps,
                    actions=actions,
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                )
            assert state.totp is not None
            code = generate_code(credential.totp_seed, int(time.time()))
            # A one-time code is a credential too.
            totp_here = str(snapshot.get("url", url))
            if not _same_site(totp_here, host):
                return _fail(
                    "credential_origin_refused",
                    f"the code form is on {_origin_of(totp_here)}, "
                    f"not {host} — nothing was typed",
                    url=totp_here,
                    login_performed=login_performed,
                    steps=steps,
                    actions=actions,
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                )
            filled = await session.send(
                "fill_ref",
                {
                    "ref": state.totp.ref,
                    "value": code,
                    "expect_host": host,
                    "stored_credential": True,
                },
            )
            if not filled.get("ok"):
                return _fail(
                    "login_form_not_found",
                    f"could not type the code: {filled.get('error', 'unknown')}",
                    url=str(snapshot.get("url", url)),
                    steps=steps,
                    actions=actions,
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                )
            actions.append("entered one-time code")
            totp_submitted = True
            submit_result = await _submit(session, state, actions, host)
            if submit_result is not None:
                submit_result.steps = steps
                submit_result.actions = actions
                submit_result.elapsed_ms = int((time.monotonic() - started) * 1000)
                return submit_result
            snapshot = await _snapshot(session)
            continue

        # A login form. One password attempt, no more.
        if password_submitted:
            return _fail(
                "login_rejected",
                state.error_text
                or f"{host} returned to the sign-in page after the credentials were sent",
                url=str(snapshot.get("url", url)),
                login_performed=login_performed,
                steps=steps,
                actions=actions,
                elapsed_ms=int((time.monotonic() - started) * 1000),
            )

        # Checked HERE, immediately before anything is typed, and again on
        # every pass of the loop — step two of a two-step form can move
        # origin after step one was fine.
        here = str(snapshot.get("url", url))
        if not _same_site(here, host):
            return _fail(
                "credential_origin_refused",
                f"the sign-in form is on {_origin_of(here)}, not "
                f"{host} — nothing was typed",
                url=here,
                login_performed=login_performed,
                steps=steps,
                actions=actions,
                elapsed_ms=int((time.monotonic() - started) * 1000),
            )

        if state.username is not None and not state.username.filled:
            filled = await session.send(
                "fill_ref",
                {
                    "ref": state.username.ref,
                    "value": credential.username,
                    # Stated so the daemon can refuse beside the typing. The
                    # check below is on a SNAPSHOT, and the page can move in
                    # the two round trips between them.
                    "expect_host": host,
                    "stored_credential": True,
                },
            )
            if not filled.get("ok"):
                if filled.get("error") == "fill_origin_moved_mid_write":
                    # The keystrokes are already gone. Say so, in the words a
                    # person needs: not "a check failed" but "change your
                    # password". Detection without disclosure would be worse
                    # than not detecting it, because it would look handled.
                    return _fail(
                        "credential_may_be_exposed",
                        "the page moved to another site WHILE the password "
                        "was being typed, so some of it may have reached "
                        "that site — change this password now",
                        url=str(snapshot.get("url", url)),
                        login_performed=True,
                        steps=steps,
                        actions=actions,
                        elapsed_ms=int((time.monotonic() - started) * 1000),
                    )
                if filled.get("error") == "fill_origin_refused":
                    return _fail(
                        "credential_origin_refused",
                        f"the page moved while signing in ({filled.get('detail', '')})"
                        " — nothing was typed",
                        url=str(snapshot.get("url", url)),
                        login_performed=login_performed,
                        steps=steps,
                        actions=actions,
                        elapsed_ms=int((time.monotonic() - started) * 1000),
                    )
                return _fail(
                    "login_form_not_found",
                    f"could not type the username: {filled.get('error', 'unknown')}",
                    url=str(snapshot.get("url", url)),
                    steps=steps,
                    actions=actions,
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                )
            actions.append("entered username")

        if state.password is not None:
            filled = await session.send(
                "fill_ref",
                {
                    "ref": state.password.ref,
                    "value": credential.password,
                    "expect_host": host,
                    "stored_credential": True,
                },
            )
            if not filled.get("ok"):
                if filled.get("error") == "fill_origin_moved_mid_write":
                    # The keystrokes are already gone. Say so, in the words a
                    # person needs: not "a check failed" but "change your
                    # password". Detection without disclosure would be worse
                    # than not detecting it, because it would look handled.
                    return _fail(
                        "credential_may_be_exposed",
                        "the page moved to another site WHILE the password "
                        "was being typed, so some of it may have reached "
                        "that site — change this password now",
                        url=str(snapshot.get("url", url)),
                        login_performed=True,
                        steps=steps,
                        actions=actions,
                        elapsed_ms=int((time.monotonic() - started) * 1000),
                    )
                if filled.get("error") == "fill_origin_refused":
                    return _fail(
                        "credential_origin_refused",
                        f"the page moved while signing in ({filled.get('detail', '')})"
                        " — nothing was typed",
                        url=str(snapshot.get("url", url)),
                        login_performed=login_performed,
                        steps=steps,
                        actions=actions,
                        elapsed_ms=int((time.monotonic() - started) * 1000),
                    )
                return _fail(
                    "login_form_not_found",
                    f"could not type the password: {filled.get('error', 'unknown')}",
                    url=str(snapshot.get("url", url)),
                    steps=steps,
                    actions=actions,
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                )
            actions.append("entered password")
            password_submitted = True
            login_performed = True

        submit_result = await _submit(session, state, actions, host)
        if submit_result is not None:
            submit_result.steps = steps
            submit_result.actions = actions
            submit_result.elapsed_ms = int((time.monotonic() - started) * 1000)
            return submit_result
        snapshot = await _snapshot(session)
    else:
        return _fail(
            "too_many_steps",
            f"the sign-in did not settle after {MAX_STEPS} steps",
            url=str(snapshot.get("url", url)),
            login_performed=login_performed,
            steps=MAX_STEPS,
            actions=actions,
            elapsed_ms=int((time.monotonic() - started) * 1000),
        )

    # Signed in (or never challenged). Go back to what was actually asked for.
    landed = str(snapshot.get("url", url))
    if not _same_page(landed, url):
        snapshot = await _snapshot(session, url)
        if not snapshot.get("ok"):
            return _fail(
                "navigation_failed",
                f"signed in, but {url} would not load: {snapshot.get('error', 'unknown')}",
                login_performed=login_performed,
                steps=steps,
                actions=actions,
                elapsed_ms=int((time.monotonic() - started) * 1000),
            )
        final_state = forms.classify(snapshot)
        # Every kind that is not the page we asked for, not just the two that
        # look like sign-in.
        #
        # This branch is the COMMON case — it runs whenever the login landed
        # somewhere other than the requested URL — and it rejected only
        # `login` and `totp`. A bot wall, a signup form or an unrecognised
        # page fell straight through to `get_text` and came back as ok=True
        # with `authenticated=True`. Measured: "Checking your browser... Ray
        # ID: 8f2c" handed to the model as the content of the page.
        #
        # The in-loop path has always checked captcha first and refused.
        # `forms.py` calls returning a wall as content "the worst failure
        # this product has"; this is the path where it was still possible.
        refusal = _AFTER_LOGIN_REFUSALS.get(final_state.kind)
        if refusal is None and final_state.kind != "authenticated":
            refusal = "login_form_not_found"
        if refusal is not None:
            return _fail(
                refusal,
                final_state.error_text
                or f"{url} showed a {final_state.kind} page after the "
                "credentials were accepted",
                url=str(snapshot.get("url", url)),
                login_performed=login_performed,
                steps=steps,
                actions=actions,
                elapsed_ms=int((time.monotonic() - started) * 1000),
            )

    # A SIGN-IN PAGE IS NEVER CONTENT.
    #
    # Found on Arav's restored Supabase project, 2026-08-24: the snapshot
    # beat the render, so `classify` saw no form and no copy and said
    # "authenticated", the loop broke out, and this function returned the
    # SIGN-IN PAGE's text with `authenticated=True` and zero actions
    # attempted. Every individual step behaved as designed; the result was
    # a signed-out page offered as the user's own.
    #
    # This gate does not depend on the classifier being right — which is
    # the point, because the classifier is the part already hardened
    # twice. If the run ends on a login URL having performed no login,
    # that is a refusal. Re-classified once here so the refusal names what
    # is actually in the way (Supabase's sign-in carries an hCaptcha)
    # rather than reporting a generic failure.
    final_url = str(snapshot.get("url", url))
    # `ref_map` is the daemon's key (`_daemon.py:1926`), and `forms.py`
    # reads the same one. The first version of this line checked
    # "elements", which the daemon never emits — so `unrendered` was
    # always True and the narrowing did nothing. The pytest run caught it
    # only because `tests/conftest.py` puts `src/` ahead of the installed
    # package: every standalone probe I ran was importing the INSTALLED
    # copy and passing for the wrong reason.
    unrendered = not (snapshot.get("ref_map") or snapshot.get("page_text"))
    if not login_performed and forms.looks_like_login_url(final_url) and unrendered:
        # NARROWED to the measured root cause. The first version refused on
        # the URL alone, and review measured the collateral: a signed-in
        # `supabase.com/dashboard/project/…/auth/users`, `/docs/guides/auth`
        # and every OAuth `/auth/callback` match `_LOGIN_URL` too, so warm
        # sessions on ordinary pages became refusals. The true positive is
        # distinguished by the SNAPSHOT BEING EMPTY — that is the race this
        # exists for, and a rendered page with elements is not it.
        #
        # The re-classify is gone: the only way out of the drive loop is
        # kind == "authenticated", so it could only ever return that, the
        # lookup always missed, and the "names the hCaptcha" claim was
        # false. The refusal names the class it can honestly name.
        #
        # The URL is NOT interpolated: a magic-link `?token=` or an OAuth
        # `?code=` matches this path, and this string is model-facing prose.
        # `_origin_of` exists for exactly this reason; the full URL travels
        # in `url=`.
        return _fail(
            "login_form_not_found",
            f"{_origin_of(final_url)} returned a sign-in page that had not "
            "finished loading, and no sign-in was performed",
            url=final_url,
            login_performed=False,
            steps=steps,
            actions=actions,
            elapsed_ms=int((time.monotonic() - started) * 1000),
        )

    body = await session.send("get_text")
    text = str(body.get("text", "")) if body.get("ok") else ""
    if not text:
        text = "\n".join(str(t) for t in (snapshot.get("page_text") or []))

    # A login that just succeeded is the evidence later runs need: session
    # REUSE legitimately reports `login_performed=False`, so the run that
    # signs in must leave the record behind for the runs that do not.
    if login_performed:
        with contextlib.suppress(OSError):
            sessions.record_sign_in(host or url)
    return FetchResult(
        ok=True,
        url=str(snapshot.get("url", url)),
        title=str(snapshot.get("title", "")),
        text=text[:_TEXT_LIMIT],
        truncated=len(text) > _TEXT_LIMIT,
        authenticated=True,
        session_backed=login_performed or sessions.signed_in(host or url),
        login_performed=login_performed,
        steps=steps,
        elapsed_ms=int((time.monotonic() - started) * 1000),
        actions=actions,
    )


async def _submit(
    session: Any,
    state: forms.PageState,
    actions: list[str],
    host: str = "",
) -> FetchResult | None:
    """Click the form's submit control. Returns a failure, or None to continue.

    The host is stated so the daemon can refuse if the page has moved. This
    click is what SENDS what was just typed — the daemon's guard for it was
    written and then left unarmed, because no caller passed a host, and this
    is the one caller that could.
    """
    if state.submit is None:
        return _fail(
            "submit_not_found",
            "the login fields were filled but no submit button could be identified",
        )
    clicked = await session.send(
        "click_ref", {"ref": state.submit.ref, "expect_host": host}
    )
    if clicked.get("error") == "click_origin_refused":
        return _fail(
            "credential_origin_refused",
            "the page moved before the form could be submitted",
        )
    if not clicked.get("ok"):
        return _fail(
            "submit_not_found",
            f"could not click {state.submit.label!r}: {clicked.get('error', 'unknown')}",
        )
    actions.append(f"clicked {state.submit.label!r}")
    return None
