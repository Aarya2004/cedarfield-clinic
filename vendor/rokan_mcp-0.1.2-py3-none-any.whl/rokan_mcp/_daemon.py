"""Per-mission long-running browser daemon entry point.

Spawned by :mod:`apps.api.rokan_browser.daemon_client` via
``asyncio.create_subprocess_exec``. Holds ONE Playwright browser +
persistent context open for the lifetime of a mission so multiple
Brain tool calls (``browser_snapshot``, ``browser_click_ref``,
``computer_use_action``) share DOM state, cookies, localStorage.
Tracks EVERY page (tab) in the context — new tabs opened by clicks are
auto-followed when they belong to the mission (opener chains to a
tracked page / same registrable domain / known OAuth host), so a
``target=_blank`` signup flow no longer strands the agent on a stale
tab (the "opens a tab then restarts" failure).

Wire protocol — newline-delimited JSON over a Unix-domain socket at
``/tmp/rokan-browser-<sanitized-mission_id>.sock``:

    request  := {"id": "<corr-id>", "cmd": "<name>", "args": {...}}\\n
    response := {"id": "<corr-id>", "ok": bool, ...}\\n

Lifecycle:
    * Daemon is started lazily by ``daemon_client.send_command`` when
      the first command for a mission_id arrives.
    * Hard 10-min idle timeout — Brain missions rarely run longer.
    * Mission-end cleanup hook in ``brain_integration._kill_browser_daemon``
      sends ``{"cmd": "close"}`` then deletes the socket.
    * On any unhandled exception the daemon writes
      ``/tmp/rokan-browser-<mid>.crash`` with the traceback, then exits
      so the next call falls back to spawning a fresh subprocess via the
      existing path in ``tools_browser_refs``.

Trust boundary: this script accepts the ``user_data_dir`` from the parent
on stdin once at startup. It never reads paths from socket commands —
that way a Brain command cannot pivot the daemon to a different profile
mid-mission. ``mission_id`` is sanitised by the parent ([A-Za-z0-9_-]).

This file is intentionally self-contained (uses only stdlib +
playwright). Keep it small — it's executed in a fresh interpreter and is
the trust boundary between the FastAPI process and Playwright.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import importlib.util
import json
import logging
import os
import re
import shlex
import signal
import subprocess
import sys
import time
import traceback
from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.parse import quote, quote_plus, urlparse

# --------------------------------------------------------------------------
# Tunables (must stay in sync with daemon_client.py)
# --------------------------------------------------------------------------

#: Hard idle timeout — daemon exits if no command arrives within this.
IDLE_TIMEOUT_S: float = 600.0  # 10 minutes
#: Per-command navigation/wait budget inside the daemon.
NAV_TIMEOUT_MS: int = 15_000
#: Max bytes per inbound JSON line — anything bigger is rejected before
#: parse so a misbehaving client cannot blow memory.
MAX_COMMAND_BYTES: int = 64 * 1024
#: Snapshot label truncation (matches tools_browser_refs).
MAX_LABEL_CHARS: int = 80
#: Allowed mission_id charset — same as daemon_client's sanitiser.
_MID_RE = re.compile(r"^[A-Za-z0-9_-]{1,128}$")

#: Demo overlay (saffron step pill, apps/api/rokan_browser/page_overlay.py).
#: Opt-in via env so prod/headless runs never pay for cosmetics.
_OVERLAY_ENV = "ROKAN_BROWSER_OVERLAY"
_OVERLAY_TOTAL_ENV = "ROKAN_BROWSER_OVERLAY_TOTAL"
#: Commands that advance the visible step counter (viewer-meaningful
#: actions only — reads like snapshot/get_text re-assert, never count).
_OVERLAY_STEP_CMDS: frozenset[str] = frozenset(
    {"navigate", "click_ref", "click_xy", "fill_ref", "set_files", "type"}
)

logger = logging.getLogger("rokan_browser_daemon")


def _load_overlay_js(mission_id: str) -> str | None:
    """Demo-gated saffron-pill overlay JS, or None when disabled.

    Loads ``page_overlay.py`` by file path (this script stays free of
    ``apps.api`` package imports). Purely cosmetic: ANY failure logs and
    returns None — the overlay must never break a mission.
    """
    if os.environ.get(_OVERLAY_ENV, "").strip().lower() not in {"1", "true", "yes"}:
        return None
    path = (
        Path(__file__).resolve().parent.parent
        / "apps" / "api" / "rokan_browser" / "page_overlay.py"
    )
    try:
        spec = importlib.util.spec_from_file_location("_rokan_page_overlay", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"cannot load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules.setdefault("_rokan_page_overlay", module)
        spec.loader.exec_module(module)
        try:
            total = int(os.environ.get(_OVERLAY_TOTAL_ENV, "25"))
        except ValueError:
            total = 25
        return str(module.rokan_overlay_script(mission_id, total_steps_hint=total))
    except Exception:  # noqa: BLE001 — cosmetic, never fatal
        logger.warning("overlay load failed (non-fatal)", exc_info=True)
        return None


# --------------------------------------------------------------------------
# DOM snapshot script (daemon-grade).
#
# DIVERGENCE NOTE: this is deliberately RICHER than the legacy
# ``tools_browser_refs._RUNNER_SOURCE`` extraction — that one stays the
# minimal degraded fallback for when the daemon is down. Do NOT couple
# them. Daemon extras (W6): viewport-first ordering, bbox child-dedup,
# occlusion filter, below-fold accounting, aria state, filled markers.
# --------------------------------------------------------------------------

_HEADING_JS = r"""
  // The nearest heading ABOVE a node — what a person uses to tell one
  // "Databases" from another. Walks up, and at each ancestor scans back
  // through previous siblings for a heading or a short block of text.
  //
  // Shared by the snapshot and the repeat-group scan because they must
  // agree: a plan that reads "Databases under Research" off one and
  // resolves it against the other only works if both name the section
  // the same way.
  //
  // `cache` memoises the whole path walked. That is sound HERE and only
  // here: the walk from an ancestor repeats exactly the sibling scan the
  // walk from the start node already did and found nothing in, so every
  // node on the path shares the answer. It matters because innerText
  // forces layout, and without it a page of a hundred candidates pays
  // that cost a hundred times over the same ancestors.
  function headingAbove(start, cache) {
    const path = [];
    let head = '';
    for (let node = start; node; node = node.parentElement) {
      if (cache.has(node)) { head = cache.get(node); break; }
      path.push(node);
      let found = '';
      for (let sib = node.previousElementSibling; sib; sib = sib.previousElementSibling) {
        const text = (sib.innerText || '').trim().split('\n')[0].trim();
        if (!text) continue;
        const tag = sib.tagName;
        if (/^H[1-6]$/.test(tag) || sib.getAttribute('role') === 'heading') {
          found = text.slice(0, 120);
          break;
        }
        // A short block of text can be a styled header — many sites
        // mark sections with a div rather than an h2. A block that
        // CONTAINS a control is not one: it is the row before this one.
        // Without this, a list of same-labelled buttons gives each one
        // the previous row's text as its "section", which distinguishes
        // them by accident and names them wrongly.
        if (text.length <= 80
            && /^(?:DIV|P|SPAN|SECTION|HEADER|LEGEND|CAPTION)$/.test(tag)
            && !sib.querySelector('a,button,input,select,textarea')) {
          found = text.slice(0, 120);
          break;
        }
      }
      if (found) { head = found; break; }
    }
    for (const node of path) cache.set(node, head);
    return head;
  }
"""


_SNAPSHOT_JS = r"""
() => {
""" + _HEADING_JS + r"""
  const vw = window.innerWidth, vh = window.innerHeight;
  function visible(el) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const s = window.getComputedStyle(el);
    if (s.visibility === 'hidden' || s.display === 'none') return false;
    return true;
  }
  function label(el) {
    const aria = el.getAttribute('aria-label');
    if (aria) return aria.trim();
    // IDs are scoped per shadow root — a shadow input's <label for=...> and
    // aria-labelledby target live in the SAME root, never in document.
    const scope = el.getRootNode();
    const lblby = el.getAttribute('aria-labelledby');
    if (lblby && scope.getElementById) {
      const r = scope.getElementById(lblby);
      if (r) return (r.innerText||'').trim();
    }
    if (el.id && scope.querySelector) {
      const lab = scope.querySelector('label[for="' + CSS.escape(el.id) + '"]');
      if (lab) return (lab.innerText||'').trim();
    }
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      return (el.getAttribute('placeholder') || el.getAttribute('name')
              || el.getAttribute('type') || 'text');
    }
    const t = (el.innerText || el.textContent || '').trim();
    return t;
  }
  function roleOf(el) {
    const r = el.getAttribute('role');
    if (r) return r;
    const tag = el.tagName.toLowerCase();
    if (tag === 'a') return 'link';
    if (tag === 'button') return 'button';
    if (tag === 'select') return 'select';
    if (tag === 'textarea') return 'input';
    if (tag === 'input') return 'input';
    return tag;
  }
  // A selector built from the element's OWN durable attributes, so it
  // survives a React/SPA re-render that wipes our injected
  // data-rokan-ref (the measured Plunk-login wall, 2026-06-10). Order =
  // most-stable-and-unique first. Empty string = no durable handle (fall
  // back to the injected ref only).
  function stableSelectorFor(el) {
    const tag = el.tagName ? el.tagName.toLowerCase() : '';
    // name= is the form-field anchor React preserves across re-renders.
    const nm = el.getAttribute && el.getAttribute('name');
    if (nm) return tag + '[name="' + CSS.escape(nm) + '"]';
    // type + placeholder pins a specific input even with no name.
    const ty = el.getAttribute && el.getAttribute('type');
    const ph = el.getAttribute && el.getAttribute('placeholder');
    if (tag === 'input' && ty && ph) {
      return 'input[type="' + CSS.escape(ty) + '"][placeholder="'
        + CSS.escape(ph) + '"]';
    }
    if (ph) return tag + '[placeholder="' + CSS.escape(ph) + '"]';
    // aria-label is stable on icon buttons / custom controls.
    const al = el.getAttribute && el.getAttribute('aria-label');
    if (al) return tag + '[aria-label="' + CSS.escape(al) + '"]';
    const ty2 = (tag === 'button' || tag === 'input') ? ty : '';
    if (ty2 === 'submit') return tag + '[type="submit"]';
    return '';
  }
  function selectorFor(el) {
    if (el.id) return '#' + CSS.escape(el.id);
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && parts.length < 6) {
      let part = cur.tagName.toLowerCase();
      const parent = cur.parentElement;
      if (parent) {
        const sibs = Array.from(parent.children).filter(c => c.tagName === cur.tagName);
        const idx = sibs.indexOf(cur) + 1;
        part += ':nth-of-type(' + idx + ')';
      }
      parts.unshift(part);
      if (cur.id) {
        parts[0] = cur.tagName.toLowerCase() + '#' + CSS.escape(cur.id);
        break;
      }
      cur = cur.parentElement;
    }
    return parts.join(' > ');
  }
  // browser-use-style: capture ALL interactive/clickable elements, not just
  // native tags — SPAs render <div>/<span> with role/onclick as buttons, and
  // those are otherwise invisible to the agent (→ it can't click → wanders).
  const SEL = 'a,button,input,select,textarea,summary,'
    + '[role=button],[role=link],[role=checkbox],[role=radio],[role=tab],'
    + '[role=menuitem],[role=switch],[role=textbox],[role=combobox],'
    + '[onclick],[contenteditable=true],[tabindex]:not([tabindex="-1"])';
  const TYPING = new Set(['INPUT', 'SELECT', 'TEXTAREA']);

  // Pass 1 — collect visible candidates with bboxes, descending through
  // OPEN shadow roots (modern web-component forms — Stripe Elements,
  // custom <x-input> design systems — live inside shadow DOM and are
  // INVISIBLE to a top-document querySelectorAll, so the agent can't see
  // or click them). Closed roots are intentionally hidden by the page;
  // we don't pierce those. The roots list is built ONCE and reused by the
  // salient-text scan below — a validation error rendered inside a shadow
  // form is exactly the text the agent must see.
  const roots = [document];
  for (let i = 0; i < roots.length; i++) {
    for (const el of roots[i].querySelectorAll('*')) {
      if (el.shadowRoot) roots.push(el.shadowRoot);
    }
  }
  function eachRoot(sel, cb) {
    for (const root of roots) {
      for (const el of root.querySelectorAll(sel)) cb(el);
    }
  }
  // Stale data-rokan-ref attributes from a prior snapshot are cleared
  // first so a re-used ref can never resolve to an old element.
  eachRoot('[data-rokan-ref]', el => el.removeAttribute('data-rokan-ref'));
  const cands = [];
  eachRoot(SEL, el => {
    // Hidden <input type=file> are the NORM (sites hide the input and
    // style a sibling button that forwards the click) — exempt them
    // from the visibility filter or uploads are unreachable.
    // set_input_files works on hidden inputs.
    const isFileInput = el.tagName === 'INPUT'
      && (el.getAttribute('type') || '').toLowerCase() === 'file';
    const vis = visible(el);
    if (!vis && !isFileInput) return;
    const r = el.getBoundingClientRect();
    cands.push({
      el: el,
      rect: r,
      inView: r.bottom > 0 && r.top < vh && r.right > 0 && r.left < vw,
      hidden: isFileInput && !vis,
    });
  });

  // Pass 2 — bbox child-dedup: suppress a candidate >=99% contained in a
  // tracked interactive ANCESTOR (kills the "clicked the icon-span, not
  // the button" wrong-click). Kept regardless: typing targets, elements
  // with their own onclick, and native controls whose role differs from
  // the ancestor's (an "Add to cart" <button> inside a card <a> is a
  // real, distinct action).
  const candSet = new Set(cands.map(c => c.el));
  function swallowedByAncestor(c) {
    const el = c.el;
    if (TYPING.has(el.tagName) || el.isContentEditable) return false;
    if (el.getAttribute('onclick')) return false;
    let anc = el.parentElement;
    while (anc) {
      if (candSet.has(anc)) {
        const tag = el.tagName;
        const ancRole = roleOf(anc);
        if (tag === 'A' && el.getAttribute('href') && ancRole !== 'link') return false;
        if (tag === 'BUTTON' && ancRole !== 'button') return false;
        const a = anc.getBoundingClientRect();
        const r = c.rect;
        const area = Math.max(1, r.width * r.height);
        const ix = Math.max(0, Math.min(r.right, a.right) - Math.max(r.left, a.left));
        const iy = Math.max(0, Math.min(r.bottom, a.bottom) - Math.max(r.top, a.top));
        return (ix * iy) / area >= 0.99;
      }
      anc = anc.parentElement;
    }
    return false;
  }
  const deduped = cands.filter(c => !swallowedByAncestor(c));

  // Pass 3 — occlusion: when a large fixed overlay/modal plausibly
  // exists (cheap precheck over top-level nodes only), drop in-viewport
  // non-typing candidates whose center hits a FOREIGN element — those
  // are behind the modal and a click would miss. Typing targets are
  // never dropped (custom-styled checkboxes/inputs legitimately sit
  // under their styled label).
  let overlayLikely = false;
  for (const el of document.querySelectorAll('body > *, dialog, [class*=modal i], [class*=overlay i]')) {
    const s = window.getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden') continue;
    if (s.position !== 'fixed' && s.position !== 'sticky' && el.tagName !== 'DIALOG') continue;
    const r = el.getBoundingClientRect();
    if (r.width * r.height >= vw * vh * 0.3) { overlayLikely = true; break; }
  }
  function occluded(c) {
    const r = c.rect;
    const cx = Math.min(vw - 1, Math.max(0, r.left + r.width / 2));
    const cy = Math.min(vh - 1, Math.max(0, r.top + r.height / 2));
    const hit = document.elementFromPoint(cx, cy);
    if (!hit) return false;
    if (hit === c.el || c.el.contains(hit) || hit.contains(c.el)) return false;
    if (hit.tagName === 'LABEL' && hit.htmlFor && hit.htmlFor === c.el.id) return false;
    return true;
  }
  const kept = deduped.filter(c => {
    if (!overlayLikely) return true;
    if (!c.inView) return true;
    if (TYPING.has(c.el.tagName)) return true;
    // elementFromPoint over shadow content returns the shadow HOST, not
    // the inner element, so occlusion can't be judged reliably — never
    // drop a shadow-DOM element on a false "occluded" reading.
    if (c.el.getRootNode() !== document) return true;
    return !occluded(c);
  });

  // Pass 4 — order: in-viewport first (stable doc order within each
  // group), below-fold after; apply the 250 cap AFTER ordering so it
  // drops the least-actionable tail, not the page's bottom half.
  const inView = kept.filter(c => c.inView);
  const belowFold = kept.filter(c => !c.inView);
  const ordered = inView.concat(belowFold).slice(0, 250);
  const dropped = kept.length - ordered.length;

  const out = [];
  let id = 0;
  for (const c of ordered) {
    const el = c.el;
    id += 1;
    // The robust click selector: tag the element with a unique
    // data-rokan-ref and address it by that attribute. A bare attribute
    // selector (no combinators) is the one form Playwright resolves
    // straight THROUGH open shadow boundaries — the old positional
    // `div:nth-of-type(2) > input` path could neither cross a shadow
    // root nor survive sibling churn. dom_id/in_shadow are diagnostics.
    let rkSelector;
    try {
      el.setAttribute('data-rokan-ref', String(id));
      rkSelector = '[data-rokan-ref="' + id + '"]';
    } catch (e) {
      rkSelector = selectorFor(el);  // SVG/exotic node — fall back
    }
    const item = {
      id: id,
      role: roleOf(el),
      label: label(el),
      href: el.getAttribute('href') || '',
      placeholder: el.getAttribute('placeholder') || '',
      input_type: (el.getAttribute('type') || '').toLowerCase(),
      disabled: !!(el.disabled || el.getAttribute('aria-disabled') === 'true'),
      selector: rkSelector,
      stable_selector: stableSelectorFor(el),
      dom_id: el.id || '',
      in_shadow: el.getRootNode() !== document,
      below_fold: !c.inView,
    };
    if (c.hidden) item.hidden = true;
    // "filled" only for text-entry targets — checkboxes/radios/buttons
    // have a default value="on" that would false-flag them.
    const NON_TEXT = new Set(['checkbox', 'radio', 'submit', 'button', 'reset', 'image', 'file']);
    item.filled = !!(
      ((el.tagName === 'INPUT' && !NON_TEXT.has(item.input_type))
        || el.tagName === 'TEXTAREA') && el.value
    );
    if (el.tagName === 'INPUT' && (item.input_type === 'checkbox' || item.input_type === 'radio')) {
      item.checked = !!el.checked;
    }
    // Native <select>: surface the choosable options — clicking one opens
    // an OS-rendered dropdown no agent can drive, so the agent must pick
    // by option label via fill (select_option under the hood).
    if (el.tagName === 'SELECT') {
      const opts = [];
      for (let oi = 0; oi < el.options.length && opts.length < 12; oi++) {
        const o = el.options[oi];
        const t = ((o.label || o.text || o.value || '') + '').trim();
        if (t) opts.push(t.slice(0, 40));
      }
      item.options = opts;
      item.options_total = el.options.length;
      const so = el.selectedIndex >= 0 ? el.options[el.selectedIndex] : null;
      item.selected = so
        ? ((so.label || so.text || so.value || '') + '').trim().slice(0, 40)
        : '';
    }
    const ARIA = [['aria-expanded', 'expanded'], ['aria-selected', 'selected'],
                  ['aria-checked', 'checked'], ['aria-current', 'current']];
    for (const pair of ARIA) {
      const v = el.getAttribute(pair[0]);
      if (v !== null) item[pair[1]] = v !== 'false';
    }
    out.push(item);
  }
  // A section for the elements that NEED one: those whose label the page
  // uses more than once. "Databases" matching four things is a refusal
  // and a refusal ends the task (measured on apa.org, 2026-08-27) —
  // while a unique label needs no section and computing one for it would
  // buy nothing and cost a layout.
  const labelCount = new Map();
  for (const it of out) {
    const k = (it.label || '').trim().toLowerCase();
    if (k) labelCount.set(k, (labelCount.get(k) || 0) + 1);
  }
  const headCache = new Map();
  for (let i = 0; i < out.length; i++) {
    const k = (out[i].label || '').trim().toLowerCase();
    if (!k || (labelCount.get(k) || 0) < 2) continue;
    const sect = headingAbove(ordered[i].el, headCache);
    if (sect && sect.trim().toLowerCase() !== k) out[i].section = sect;
  }
  // Salient PAGE TEXT — so the agent SEES what a human sees (esp. inline
  // errors/validation like "email already associated"), not just buttons.
  // Without this the agent is blind to WHY a submit failed and re-submits
  // robotically until it pays for a slow vision call. Headings give
  // context; alert/error regions + red-colored text catch validation.
  const texts = [];
  const seen = new Set();
  function pushText(t, cap) {
    t = (t || '').trim().replace(/\s+/g, ' ');
    if (t.length < 2 || seen.has(t)) return;
    if (t.length > (cap || 200)) {
      // Prose over the cap is boilerplate (nav/footer wrappers) — drop.
      // Code-ish callers pass a bigger cap and get TRUNCATED instead:
      // the measured wall (Plunk onboarding, 2026-06-10) was a 208+ char
      // cURL snippet carrying the API base URL + auth header that this
      // drop made invisible — the Brain guessed a legacy host and burned
      // 8 calls re-deriving the contract from the docs site.
      if (!cap) return;
      t = t.slice(0, cap) + '…';
      if (seen.has(t)) return;
    }
    seen.add(t); texts.push(t);
  }
  eachRoot('h1,h2,h3', el => { if (visible(el)) pushText(el.innerText); });
  const ERR_SEL = '[role=alert],[aria-live],[class*=error],[class*=Error],'
    + '[class*=alert],[class*=Alert],[class*=warning],[class*=success],[class*=invalid]';
  eachRoot(ERR_SEL, el => { if (visible(el)) pushText(el.innerText || el.textContent); });
  // High-signal copy targets: API keys, codes, tokens, CLI commands almost
  // always render in mono containers. The agent MUST be able to read these
  // (e.g. the api_key on a post-signup confirm page) without a vision call —
  // missing this is why a text-only snapshot looked "blind" to the key.
  eachRoot('pre,code,kbd,samp', el => { if (visible(el)) pushText(el.innerText || el.textContent, 500); });
  // Body prose with a direct text node — statuses, confirmations, instructions,
  // validation. Bounded by the 40-item cap + dedup so we surface what the page
  // SAYS without dumping nav/footer wrapper boilerplate.
  for (const root of roots) {
    if (texts.length >= 40) break;
    const scan = root.querySelectorAll('p,li,dd,dt,td,span,div,small,label');
    for (let i = 0; i < scan.length && texts.length < 40; i++) {
      const el = scan[i];
      if (!visible(el)) continue;
      const direct = Array.from(el.childNodes).some(
        n => n.nodeType === 3 && n.textContent.trim()
      );
      if (direct) pushText(el.innerText);
    }
  }
  return { elements: out, texts: texts, dropped: dropped };
}
"""


def _truncate(s: Any, n: int) -> str:
    if s is None:
        return ""
    text = str(s)
    if len(text) > n:
        return text[: n - 1] + "…"
    return text


# --------------------------------------------------------------------------
# Cheap DOM fingerprint — W5 action feedback (NOT a full snapshot)
# --------------------------------------------------------------------------

# Same interactive-element selector as _SNAPSHOT_JS, but only counts +
# concatenates short labels. One evaluate ≈ 1-3ms; used before/after
# click/fill/type so the agent learns whether its action changed anything
# (url_changed / dom_changed / new_tab) without paying for a snapshot.
_FINGERPRINT_JS = r"""
() => {
  const SEL = 'a,button,input,select,textarea,summary,'
    + '[role=button],[role=link],[role=checkbox],[role=radio],[role=tab],'
    + '[role=menuitem],[role=switch],[role=textbox],[role=combobox],'
    + '[onclick],[contenteditable=true],[tabindex]:not([tabindex="-1"])';
  let n = 0;
  const parts = [];
  function fp(root) {
    for (const el of root.querySelectorAll(SEL)) {
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      n += 1;
      // STATE, not just the label. A checkbox or radio toggle changes
      // neither its text, nor the element count, nor the body's
      // textContent — so a correct click on browser-use's own consent
      // checkbox was reported back as "changed nothing on the page" and
      // the plan was abandoned mid-form (measured 2026-08-27).
      const state = el.type === 'checkbox' || el.type === 'radio'
        ? (el.checked ? '1' : '0')
        : (el.getAttribute('aria-checked') || el.getAttribute('aria-expanded')
           || el.getAttribute('aria-selected') || '');
      parts.push(el.tagName + '|' + ((el.innerText || el.value || '') + '').slice(0, 40) + '|' + state);
    }
    for (const el of root.querySelectorAll('*')) {
      if (el.shadowRoot) fp(el.shadowRoot);
    }
  }
  fp(document);
  parts.sort();
  // Page-text hash (djb2): interactive elements alone MISS content-only
  // mutations — the measured wall (Plunk settings, 2026-06-10) was a
  // reveal-secret-key click that swapped a masked •••• text node for the
  // sk_ key: zero interactive elements changed, so dom_changed read
  // false and the Brain was told its click "likely missed".
  let th = 5381;
  const txt = (document.body && document.body.textContent) || '';
  for (let i = 0; i < txt.length; i++) {
    th = ((th << 5) + th + txt.charCodeAt(i)) | 0;
  }
  return { count: n, sig: parts.join('\n'), text_h: th };
}
"""


# A LIST on a page is a set of siblings that share a shape — table rows,
# result cards, nav items. Reading one as "the lines after the heading,
# until a blank line" works only on pages that happen to put blanks
# between their blocks. Measured 2026-08-27: on news.ycombinator.com the
# blank-line rule returns ZERO lines for the front page (there is no gap
# after the header), and on crates.io it returns 39 — the owners list
# plus the categories, the keywords and the footer that follow it.
#
# So the page is asked where its repeats are. Each group here is one set
# of same-shaped visible siblings, flattened to the text lines it covers.
# The reader uses a group as a FENCE — the block stops at the first line
# that is not inside it — and never as the source of the lines, which
# stay the page's own text so the verifier can still find every one of
# them. Main frame only for now; a list split across iframes is rare and
# would need the frame's own text to line up with the fence.
_COLLECTIONS_JS = r"""
() => {
""" + _HEADING_JS + r"""
  const MAX_GROUPS = 60, MAX_UNITS = 200, MAX_CELLS = 12, MIN_UNITS = 3;
  const MAX_LINE = 300;
  // A TOTAL budget, not only a per-group one. The per-group caps multiply:
  // 60 x 200 x 12 x 300 is 43 MB, and the reply travels on ONE line of a
  // unix socket whose reader stops at 32 MB (browser._READ_LIMIT). Over
  // that the client raises "Separator is not found, and chunk exceed the
  // limit" and the whole run dies — measured on zara.com, 2026-08-27, as
  // an uncaught exception, and on bbcgoodfood.com as `browser_unavailable`,
  // because `executor._act` reports every transport fault that way.
  //
  // 256 KB is two orders of magnitude under the socket limit and far more
  // than the planner's context can hold, so the cap costs nothing real.
  const MAX_CHARS = 256 * 1024;
  let spent = 0;
  // A WORK deadline, not only an output cap. Every cap here bounds what is
  // RETURNED; none bounds what is done. `querySelectorAll('*')` runs to
  // completion on a page with no qualifying groups, and `innerText` is
  // read up to MAX_GROUPS x MAX_UNITS times, each one a forced reflow.
  //
  // The Python side gives up at 3s and returns nothing — but cancelling
  // that await does not stop this: the renderer stays busy while the
  // daemon still holds its state lock, so every later command on the host
  // queues behind a page that is still working.
  const DEADLINE = performance.now() + 2000;
  function shape(el) {
    const cls = (el.getAttribute('class') || '').trim().split(/\s+/)
      .filter(Boolean).sort().join('.');
    return el.tagName + '|' + cls + '|' + (el.getAttribute('role') || '');
  }
  function vis(el) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const s = window.getComputedStyle(el);
    return s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0';
  }
  const out = [];
  const headCache = new Map();
  for (const p of document.querySelectorAll('*')) {
    if (out.length >= MAX_GROUPS || spent >= MAX_CHARS) break;
    if (performance.now() > DEADLINE) break;
    const kids = Array.from(p.children);
    if (kids.length < MIN_UNITS) continue;
    const byShape = new Map();
    for (const k of kids) {
      const s = shape(k);
      if (!byShape.has(s)) byShape.set(s, []);
      byShape.get(s).push(k);
    }
    for (const [, siblings] of byShape) {
      if (siblings.length < MIN_UNITS) continue;
      if (spent >= MAX_CHARS || performance.now() > DEADLINE) break;
      const units = [];
      for (const u of siblings) {
        if (units.length >= MAX_UNITS || spent >= MAX_CHARS) break;
        if (!vis(u)) continue;
        const cells = [];
        for (const raw of (u.innerText || '').split('\n')) {
          const t = raw.trim();
          if (t && cells.length < MAX_CELLS) {
            const cell = t.slice(0, MAX_LINE);
            cells.push(cell);
            spent += cell.length;
          }
        }
        if (cells.length) units.push(cells);
      }
      if (units.length >= MIN_UNITS) {
        // What a PERSON would use to tell one list from another. A page
        // carries several repeats — stackexchange shows its communities
        // and its hot questions — and by rows alone they are
        // indistinguishable, so a plan asking for "the top 5 communities"
        // has nothing to choose by and picks whichever is bigger
        // (measured 2026-08-27).
        const head = headingAbove(p, headCache);
        out.push({ units: units, heading: head });
      }
    }
  }
  return out;
}
"""



#: Cap on child frames considered per snapshot/fingerprint — an
#: ad-stuffed page can carry dozens of trackers; the forms we care
#: about live in the first few real frames.
_MAX_SNAPSHOT_FRAMES = 8


async def _fingerprint(page: Any) -> tuple[int, str] | None:
    """``(element_count, sha1(sorted labels)[:12])`` — None if unreadable.

    Child frames are summed in (bounded): a click inside an iframe that
    only mutates iframe DOM must not read back as dom_changed=False — a
    false "nothing happened" makes the Brain re-click and double-submit.
    """
    try:
        raw = await page.evaluate(_FINGERPRINT_JS)
        count = int(raw.get("count", 0))
        sigs = [str(raw.get("sig", "")), str(raw.get("text_h", ""))]
        try:
            children = [f for f in page.frames if f is not page.main_frame]
        except Exception:  # noqa: BLE001 — fake pages have no frames attr
            children = []
        for fr in children[:_MAX_SNAPSHOT_FRAMES]:
            try:
                fraw = await fr.evaluate(_FINGERPRINT_JS)
                count += int(fraw.get("count", 0))
                sigs.append(str(fraw.get("sig", "")))
                sigs.append(str(fraw.get("text_h", "")))
            except Exception:  # noqa: BLE001 — frame died mid-probe
                continue
        sig = hashlib.sha1(
            "\n".join(sigs).encode("utf-8", "replace")
        ).hexdigest()[:12]
        return count, sig
    except Exception:  # noqa: BLE001 — feedback is best-effort, never fatal
        return None


async def _candidate_frames(page: Any) -> list[tuple[Any, str]]:
    """Visible child frames worth snapshotting, as ``(frame, label)``.

    Playwright evaluates per-frame, which reaches same-origin AND
    cross-origin (OOPIF) content alike — login forms, payment fields,
    consent widgets. Tracking pixels / hidden frames (no box, < 3px) are
    skipped; capped so an ad-stuffed page can't stall the snapshot.
    """
    out: list[tuple[Any, str]] = []
    try:
        frames = [f for f in page.frames if f is not page.main_frame]
    except Exception:  # noqa: BLE001 — fake pages have no frames attr
        return out
    for fr in frames:
        try:
            if fr.is_detached():
                continue
            fe = await fr.frame_element()
            box = await fe.bounding_box()
            if not box or box["width"] < 3 or box["height"] < 3:
                continue
            label = (
                await fe.get_attribute("title")
                or await fe.get_attribute("name")
                or ""
            )
        except Exception:  # noqa: BLE001 — mid-navigation / detached frame
            continue
        out.append((fr, str(label)))
        if len(out) >= _MAX_SNAPSHOT_FRAMES:
            break
    return out


#: Bot-gate widget hosts/markers (Gap 6). Detection ONLY — Rokan never
#: solves a challenge; the Brain pauses and hands the solve link to the
#: human, then resumes (ask_user → captcha_human_gate).
_CAPTCHA_FRAME_MARKERS = (
    "recaptcha",
    "hcaptcha",
    "turnstile",
    "challenges.cloudflare",
    "arkoselabs",
    "funcaptcha",
    "geetest",
    "perimeterx",
    "datadome",
)
_CAPTCHA_TEXT_MARKERS = (
    "not a robot",
    "verify you are human",
    "security check",
    "unusual traffic",
    "are you human",
)


def _captcha_kind(haystack: str) -> str:
    if "recaptcha" in haystack:
        return "recaptcha"
    if "hcaptcha" in haystack:
        return "hcaptcha"
    if "turnstile" in haystack or "cloudflare" in haystack:
        return "turnstile"
    for marker in _CAPTCHA_FRAME_MARKERS:
        if marker in haystack:
            return marker
    return "generic"


def _detect_captcha(
    ref_map: dict[str, dict[str, Any]],
    frame_labels: list[str],
    texts: list[Any],
) -> dict[str, Any] | None:
    """Structural bot-gate detection over the snapshot we already have —
    widget iframes by host/title, checkbox labels, challenge prose. Zero
    extra page roundtrips."""
    for ref, m in ref_map.items():
        ftag = (m.get("frame") or "").lower()
        if ftag and any(k in ftag for k in _CAPTCHA_FRAME_MARKERS):
            return {
                "present": True,
                "kind": _captcha_kind(ftag),
                "evidence": f"widget iframe {m.get('frame')!r} ({ref})",
            }
        lbl = (m.get("label") or "").lower()
        if lbl and any(t in lbl for t in _CAPTCHA_TEXT_MARKERS):
            return {
                "present": True,
                "kind": "generic",
                "evidence": f"element {m.get('label')!r} ({ref})",
            }
    for fl in frame_labels:
        low = (fl or "").lower()
        if low and any(k in low for k in _CAPTCHA_FRAME_MARKERS):
            return {
                "present": True,
                "kind": _captcha_kind(low),
                "evidence": f"iframe {fl!r}",
            }
    for t in texts:
        low = str(t).lower()
        if any(marker in low for marker in _CAPTCHA_TEXT_MARKERS):
            return {
                "present": True,
                "kind": "generic",
                "evidence": f"page text {str(t)[:60]!r}",
            }
    return None


def _ref_context(page: Any, snap: PageSnap, ref: str) -> Any | None:
    """The locator context a ref resolves in: its iframe Frame if it was
    snapshotted inside one (and that frame is still alive), the page for
    main-frame refs, None if the frame detached (caller returns a
    re-snapshot hint — clicking a guessed context is never OK)."""
    target = snap.ref_frames.get(ref)
    if target is None:
        return page
    try:
        if target.is_detached():
            return None
    except Exception:  # noqa: BLE001 — unknown frame state = treat as gone
        return None
    return target


async def _live_count(ctx: Any, selector: str) -> int:
    """``locator(selector).count()`` — number of live matches, no
    actionability wait. -1 if the probe itself errored (treat as unknown,
    never block a legitimate action)."""
    if not selector:
        return 0
    try:
        return int(await ctx.locator(selector).count())
    except Exception:  # noqa: BLE001 — count() failed; unknown
        return -1


def _ref_gone_result(page: Any, snap: PageSnap) -> dict[str, Any]:
    """The honest ref_not_found payload when BOTH selectors count zero.

    Distinguish the two true causes — the Brain reacts differently:
      * the page NAVIGATED since the snapshot (the measured Plunk
        /auth/login wall, 2026-06-10: a live session client-redirects
        the login page to the dashboard, so the form the snapshot saw
        no longer exists anywhere) → say where we are NOW;
      * same URL, so the framework re-rendered the node away → the old
        re-snapshot hint."""
    now = (page.url or "").split("#", 1)[0].rstrip("/")
    was = (snap.prev_url or "").split("#", 1)[0].rstrip("/")
    if was and now != was:
        return {
            "ok": False,
            "error": "ref_not_found",
            "detail": (
                f"the page NAVIGATED after your snapshot — you are now on "
                f"{page.url} (snapshot was {snap.prev_url}). That element "
                "no longer exists. browser_snapshot THIS page and act on "
                "what is actually here."
            ),
        }
    return {
        "ok": False,
        "error": "ref_not_found",
        "detail": (
            "that ref is gone from the page (it likely re-rendered) "
            "— take browser_snapshot again and use a fresh ref"
        ),
    }


#: What is actually at an element's centre. Playwright's actionability
#: check already WAITS for the element to be hit-testable — that wait
#: timing out is what `click_failed` is — but it does not say what was in
#: the way, so the error named an exception type and nothing about the
#: page. Half the commercial web puts a consent or region wall over the
#: content (zara.com's "SELECT YOUR LOCATION", newegg's "Change Country"),
#: and a wall that renders after the fetch is invisible to every text we
#: hold. It is not invisible to the point the click aimed at.
_COVERED_BY_JS = r"""
(el) => {
  const r = el.getBoundingClientRect();
  if (!r.width || !r.height) return '';
  const x = r.left + r.width / 2, y = r.top + r.height / 2;
  if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) return '';
  // elementFromPoint over shadow content returns the HOST, not the inner
  // node, so a shadow element can never be judged covered — the same rule
  // the snapshot's occlusion pass follows, for the same reason.
  if (el.getRootNode() !== document) return '';
  const top = document.elementFromPoint(x, y);
  if (!top || top === el || el.contains(top) || top.contains(el)) return '';
  // Name the thing a person would name: its own visible words, else what
  // it calls itself. Walk up while the words are empty — the topmost node
  // at a point is often a bare styling layer inside the real overlay.
  for (let node = top; node && node !== document.body; node = node.parentElement) {
    const text = ((node.innerText || '') + '').trim().replace(/\s+/g, ' ');
    if (text) return text.slice(0, 80);
    const aria = node.getAttribute && node.getAttribute('aria-label');
    if (aria) return (aria + '').trim().slice(0, 80);
  }
  return '';
}
"""


async def _what_covers(ctx: Any, selector: str) -> str:
    """The words on whatever sits over this element, or "" — for any
    reason at all. Best-effort: a diagnosis that raises would replace a
    click failure with a worse one."""
    # An explicit, short timeout. Without one this inherits
    # `set_default_timeout(NAV_TIMEOUT_MS)` = 15s, and the commonest reason
    # a click fails is that the element is no longer there — exactly when
    # the locator will wait the whole budget. That wait happens inside
    # `_dispatch`, which holds the daemon's state lock, so every other
    # command on the host queues behind the diagnosis of one failure. A
    # diagnosis worth a second is not worth fifteen.
    try:
        return str(
            await ctx.locator(selector).first.evaluate(_COVERED_BY_JS, timeout=1_000)
            or ""
        )
    except Exception:  # noqa: BLE001 — a diagnosis never fails a louder way
        return ""


async def _resolve_ref_selector(
    ctx: Any, entry: dict[str, Any]
) -> tuple[str | None, bool]:
    """Pick the selector to act on for a ref, recovering from re-render.

    The measured real-site wall (Plunk's Next.js, 2026-06-10): a
    continuous React re-render wipes the injected ``data-rokan-ref``
    attribute, so the primary selector resolves to ZERO live elements —
    and re-snapshotting just loses the race again. Recovery: fall back to
    the element's OWN durable ``stable_selector`` (``[name=…]`` /
    ``input[type][placeholder]`` / ``[aria-label=…]``), captured at the
    SAME snapshot, which survives the re-render.

    Returns ``(selector_to_use, recovered)``:
      * primary resolves (or the probe is unsure) → use it, recovered=False
      * primary dead but stable_selector resolves → use stable, recovered=True
      * neither resolves → (None, False): the ref is genuinely gone."""
    primary = str(entry.get("selector") or "")
    n = await _live_count(ctx, primary)
    if n != 0:  # >0 = present; -1 = probe unsure → don't pre-empt
        return primary, False
    stable = str(entry.get("stable_selector") or "")
    if stable and await _live_count(ctx, stable) > 0:
        return stable, True
    return None, False


# --------------------------------------------------------------------------
# New-tab auto-follow policy helpers
# --------------------------------------------------------------------------

#: Auth providers whose popups we follow even when the opener chain is
#: broken (some OAuth flows re-parent their windows).
_OAUTH_HOSTS = frozenset(
    {
        "accounts.google.com",
        "github.com",
        "appleid.apple.com",
        "login.microsoftonline.com",
        "login.live.com",
        "www.facebook.com",
        "facebook.com",
    }
)
_OAUTH_SUFFIXES = (".auth0.com", ".okta.com")


def _host_of(url: str) -> str:
    try:
        return (urlparse(url).hostname or "").lower()
    except Exception:  # noqa: BLE001
        return ""


def _registrable(host: str) -> str:
    """Approximate registrable domain (last two labels). A heuristic for
    the auto-follow rule only — the opener chain is the primary signal,
    so co.uk-style false negatives just mean "track, don't switch".
    """
    parts = host.rsplit(".", 2)
    return ".".join(parts[-2:]) if len(parts) >= 2 else host




def _effective_headless() -> bool:
    """The headless decision (3A) — env wish + the local safety guard.

    **The default is HEADLESS. The user must never see a browser window.**

    An earlier build of this function defaulted to headed-and-hidden, on the
    theory that headless leaks ``Google SwiftShader`` as its WebGL renderer.
    Measured 2026-08-20, that theory was wrong twice over:

    * ``--window-position=-10000,-10000`` is silently ignored by macOS. The
      flag appears in argv and the window still lands at ``(0, 33)``, fully
      visible on the user's desktop. "Headed-hidden" does not exist here.
    * SwiftShader is a property of the *bundled* ``chrome-headless-shell``
      binary, not of headless mode. Real Chrome headless reports
      ``ANGLE (Apple, ANGLE Metal Renderer: Apple M4 Pro)`` and a genuine
      five-entry ``PluginArray`` — byte-identical to headed on every measured
      surface except the UA string, which ``_headless_user_agent`` corrects.

    So invisibility and a clean fingerprint are not in tension: real Chrome,
    headless, is both.

    ``ROKAN_BROWSER_WATCH=1`` puts a window on screen deliberately — for demos
    and for handing a bot challenge to a human. The guard forces headless
    regardless of any wish on CI or a display-less Linux host (Chromium would
    crash "Missing X server") — never trust the parent. Spawn-time only:
    changing it mid-session would relaunch the browser and wipe DOM/tab state
    (see ``set_headless``).
    """
    wish = os.environ.get("ROKAN_BROWSER_HEADLESS", "").strip().lower()
    if wish in ("false", "0", "no"):
        headed = True
    elif wish in ("true", "1", "yes"):
        headed = False
    else:
        headed = _WATCH_BROWSER
    no_display = sys.platform.startswith("linux") and not (
        os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")
    )
    ci = os.environ.get("CI", "").strip().lower() in ("true", "1")
    return (not headed) or no_display or ci


# --------------------------------------------------------------------------
# Daemon state — one instance per process
# --------------------------------------------------------------------------


class PageSnap:
    """Per-page (per-tab) snapshot bookkeeping.

    ``ref_map`` is that tab's most-recent snapshot's @eN -> selector
    lookup so ``click_ref`` resolves without a re-snapshot; ``prev_url``
    + ``prev_labels`` feed the *[ref] NEW-element diff marker. One
    instance per tracked page — switching tabs never mixes ref
    namespaces (the old single-page scalars did exactly that the moment
    a second tab appeared).

    ``ref_frames`` maps a ref to the live Playwright Frame it was
    snapshotted in (iframe elements only — main-frame refs are absent).
    Internal: NEVER serialized over the wire; cleared in lockstep with
    ``ref_map`` so a stale ref can't click into a gone frame.
    """

    __slots__ = ("ref_map", "ref_frames", "prev_url", "prev_labels")

    def __init__(self) -> None:
        self.ref_map: dict[str, dict[str, Any]] = {}
        self.ref_frames: dict[str, Any] = {}
        self.prev_url: str = ""
        self.prev_labels: set[str] = set()


# --------------------------------------------------------------------------
# Session recorder (learned-replay, day 1)
# --------------------------------------------------------------------------

#: Hard ceiling on recorded responses. Generous on purpose — the recorder is
#: deliberately indiscriminate, and a truncated recording is reported via
#: ``dropped`` rather than passed off as complete.
RECORD_MAX_RESPONSES = 400
RECORD_MAX_BODY_BYTES = 512 * 1024

#: Media types whose bytes are worth reading. Everything else is recorded as
#: metadata with a stated reason, never dropped silently.
_RECORD_TEXTUAL_HINTS = (
    "json",
    "javascript",
    "text/",
    "xml",
    "graphql",
    "x-ndjson",
    "x-www-form-urlencoded",
)

#: Request headers never written down. The replayer executes inside the live
#: page, so the browser reattaches these itself; a stored copy would be a
#: credential at rest for no benefit.
_RECORD_HEADER_DENYLIST = frozenset(
    {"cookie", "authorization", "proxy-authorization", "set-cookie"}
)

#: Below this length a "secret" is too generic to scrub safely — a 3-character
#: value would shred unrelated bodies. Real passwords and TOTP codes are longer.
_SCRUB_MIN_LEN = 4


#: Opt-in for demos, debugging and human handoff: put a real window ON screen.
#: Off by default — in normal use the browser is headless and the user never
#: sees it. This is the ONLY switch that makes a window appear.
_WATCH_BROWSER = os.environ.get("ROKAN_BROWSER_WATCH", "").strip().lower() in (
    "1",
    "true",
    "yes",
)


def _needs_sandbox_disabled() -> bool:
    """True only where Chromium's sandbox genuinely cannot start.

    ``--no-sandbox`` turns off Chromium's process sandbox outright. That is a
    real downgrade in a browser holding the user's authenticated sessions, and
    it is only actually required as root or inside an unprivileged container —
    never on a developer's machine. Detect those cases rather than always
    passing it.
    """
    if os.environ.get("ROKAN_BROWSER_NO_SANDBOX", "").strip().lower() in (
        "1",
        "true",
        "yes",
    ):
        return True
    try:
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            return True
    except Exception:  # noqa: BLE001 — platform without geteuid
        pass
    # Docker/Podman leave these markers; Chromium's sandbox needs privileges
    # containers usually drop.
    return Path("/.dockerenv").exists() or Path("/run/.containerenv").exists()


def _launch_args() -> list[str]:
    """Chromium flags for the mission browser.

    Site isolation stays ON. It was previously disabled so ``click_xy`` could
    reach cross-origin iframe content, but that is a downgrade in a browser
    holding the user's sessions, and the V0 surface never calls ``click_xy`` —
    it sends only click_ref, fill_ref, get_text, snapshot, record_start and
    record_stop. Cross-origin frames are reached through CDP auto-attach.

    There is deliberately no ``--window-position``. It was here to push a
    headed window off-screen, but macOS ignores the flag outright (measured
    2026-08-20: window at ``(0, 33)`` with the flag in argv). It bought
    nothing but the appearance of hiding. Invisibility comes from headless.
    """
    args = [
        "--disable-blink-features=AutomationControlled",
        # WebMCP (Tier 0): the page's own declared tools are only exposed to
        # the CDP WebMCP domain when this feature is on. Read-only consumption
        # of a site's structured tools; no behaviour change for the DOM path.
        "--enable-features=WebMCP",
    ]
    if _needs_sandbox_disabled():
        args.append("--no-sandbox")
    # Operator-supplied flags, appended last so they can override ours.
    # Shell-split, so a quoted value survives: ROKAN_BROWSER_EXTRA_ARGS=
    # '--remote-debugging-port=9222 --user-data-dir="/tmp/a b"'. Empty or
    # unset adds nothing.
    extra = os.environ.get("ROKAN_BROWSER_EXTRA_ARGS", "").strip()
    if extra:
        args.extend(shlex.split(extra))
    return args


#: Where Chrome lives, per platform. Only ever executed with ``--version`` —
#: Playwright's ``channel="chrome"`` does the actual launching.
_CHROME_BINARIES = (
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
    "/opt/google/chrome/chrome",
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
)


@lru_cache(maxsize=1)
def _chrome_major_version() -> str | None:
    """Major version of the installed Chrome, or None if it cannot be read."""
    for path in _CHROME_BINARIES:
        if not Path(path).exists():
            continue
        try:
            out = subprocess.run(  # noqa: S603 — fixed path, fixed argv
                [path, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            ).stdout
        except Exception:  # noqa: BLE001 — a version probe must never be fatal
            continue
        match = re.search(r"\b(\d+)\.\d+\.\d+\.\d+\b", out)
        if match:
            return match.group(1)
    return None


def _headless_user_agent() -> str | None:
    """The UA a *headed* Chrome of this exact version sends, or None.

    Headless Chrome differs from headed in exactly one observable way
    (measured 2026-08-20 against a local header-echo server): the UA string
    says ``HeadlessChrome``. ``Sec-CH-UA``, ``navigator.userAgentData``, the
    WebGL renderer and ``navigator.plugins`` were byte-identical. So correct
    that one string and change nothing else.

    Passing it as the ``--user-agent`` launch flag — rather than Playwright's
    ``user_agent=`` or a CDP ``Emulation.setUserAgentOverride`` — is a
    measured choice, not a stylistic one. The flag leaves ``Sec-CH-UA`` intact
    and applies to every page in the context; the per-page CDP override leaked
    ``HeadlessChrome`` on the second page opened.

    The version is read from the installed binary and never hardcoded. A
    hardcoded UA is how this daemon once shipped ``Chrome/131`` seventeen
    releases late. Returns None when Chrome is absent, in which case no UA
    flag is passed at all: claiming Chrome's version while actually running
    bundled Chromium would be a worse mismatch than the headless tell itself.
    """
    major = _chrome_major_version()
    if not major:
        return None
    # Chrome froze the platform token and the minor/build/patch fields at
    # version 110 ("UA reduction"), so the whole string follows from the major
    # version. Verified byte-for-byte against live headed Chrome 151.
    if sys.platform == "darwin":
        platform_token = "Macintosh; Intel Mac OS X 10_15_7"
    elif sys.platform.startswith("win"):
        platform_token = "Windows NT 10.0; Win64; x64"
    else:
        platform_token = "X11; Linux x86_64"
    return (
        f"Mozilla/5.0 ({platform_token}) AppleWebKit/537.36 "
        f"(KHTML, like Gecko) Chrome/{major}.0.0.0 Safari/537.36"
    )


def _scrub_secrets(text: str | None, secrets: set[str]) -> str | None:
    """Remove every value the daemon typed from a captured request body.

    Request *headers* have had a denylist since the recorder was written; bodies
    did not, so a login POST reached disk as ``username=…&password=…`` in
    plaintext. This closes that gap at the only layer that can know the answer:
    the daemon typed the value, so the daemon knows the exact string.

    Form posts percent-encode, and JSON bodies backslash-escape, so the raw
    value alone is not enough — each secret is scrubbed in every encoding it
    could plausibly appear in. Never raises: a scrub that fails must not break
    a recording, but it also must not return an unscrubbed body, so the failure
    path drops the body entirely.
    """
    if not text or not secrets:
        return text
    try:
        out = text
        for secret in secrets:
            if len(secret) < _SCRUB_MIN_LEN:
                continue
            for form in (
                secret,
                quote(secret, safe=""),
                quote_plus(secret),
                json.dumps(secret)[1:-1],  # JSON escaping, without the quotes
            ):
                if form:
                    out = out.replace(form, "[REDACTED]")
        return out
    except Exception:  # noqa: BLE001 — never let redaction break a recording
        return "[REDACTED — scrub failed]"


async def _read_body(response: Any, content_type: str) -> tuple[str, bool, str, bool]:
    """Return ``(body, captured, skip_reason, truncated)`` for one response.

    Never raises: a body that cannot be read is a recorded fact, not an
    error. Bodies are skipped only for non-textual media types and only
    with the reason attached, so the recorder's one filter stays visible
    to whoever reads the recording.
    """
    lowered = (content_type or "").casefold()
    if not lowered:
        return "", False, "no content-type", False
    if not any(hint in lowered for hint in _RECORD_TEXTUAL_HINTS):
        return "", False, f"non-textual media type ({lowered.split(';')[0]})", False
    try:
        raw = await response.text()
    except Exception as exc:  # noqa: BLE001 — body already consumed, redirect, abort
        return "", False, f"unreadable ({type(exc).__name__})", False
    text = str(raw or "")
    if len(text) > RECORD_MAX_BODY_BYTES:
        return text[:RECORD_MAX_BODY_BYTES], True, "", True
    return text, True, "", False


class DaemonState:
    """All mutable per-daemon state lives here.

    Multi-tab spine (2026-06-10, W1): there is deliberately NO
    ``self.page`` — every handler resolves :meth:`active_page` so an
    un-migrated code path fails loud (``AttributeError``) instead of
    silently acting on a stale tab. ``pages`` holds ``(tab_id, Page)``
    in creation order (newest last); per-tab snapshot state lives in
    ``page_state[tab_id]``.

    Concurrency contract: commands run under ``self.lock``. Playwright
    events (``context.on("page")``, ``page.on("close")``) fire OFF that
    lock, so event handlers only do append-only mutations (list append,
    fresh dict key, scalar set, set.add) — the destructive cleanup
    happens in :meth:`sweep_closed`, called under the lock at the top
    of ``_dispatch``.
    """

    def __init__(self, mission_id: str, user_data_dir: str) -> None:
        self.mission_id = mission_id
        self.user_data_dir = user_data_dir
        self.last_activity = time.monotonic()
        self.pw: Any = None
        self.ctx: Any = None
        #: (tab_id, Page) in creation order, newest last.
        self.pages: list[tuple[int, Any]] = []
        self.page_state: dict[int, PageSnap] = {}
        self.active_tab_id: int | None = None
        self._tab_seq: int = 0
        #: Tombstones set by ``page.on("close")`` (off-lock); swept under
        #: the lock by :meth:`sweep_closed`.
        self._closed_tab_ids: set[int] = set()
        #: Out-of-band page events (JS dialogs, file choosers, downloads)
        #: appended OFF the lock by Playwright event handlers; drained
        #: under the lock by :meth:`drain_events` and attached to the
        #: next command's response so the Brain SEES what happened.
        self.page_events: list[dict[str, Any]] = []
        self.shutdown_event: asyncio.Event = asyncio.Event()
        # The lock serialises browser commands within the daemon so two
        # in-flight clients cannot collide on the active page.
        self.lock: asyncio.Lock = asyncio.Lock()
        #: Demo overlay (env-gated): the injected JS, or None when off,
        #: and the action counter shown in the saffron step pill.
        self.overlay_js: str | None = None
        self.overlay_step: int = 0
        #: Session recorder (off unless record_start ran). Responses are
        #: appended OFF the lock by page.on("response") and drained under
        #: the lock by record_stop.
        self.recording: bool = False
        self.recorded: list[dict[str, Any]] = []
        self.record_t0: float = 0.0
        self._record_seq: int = 0
        #: Count of responses seen after the buffer filled, so a truncated
        #: recording can never be mistaken for a complete one.
        self.record_dropped: int = 0
        #: Every value this daemon has typed into a field (fill_ref). The
        #: recorder scrubs these out of captured request bodies, so a login
        #: POST never reaches disk with the password in it. Secrets reach the
        #: browser exactly one way — fill_ref — so the component that typed
        #: them is the one that knows what to redact. Never logged, never
        #: returned by any command.
        self._typed_secrets: set[str] = set()

    def touch(self) -> None:
        self.last_activity = time.monotonic()

    # ---- tab registry ----------------------------------------------------

    def attach_page(self, page: Any, *, activate: bool) -> int:
        """Track a page; idempotent. Append-only + scalar set, so it is
        safe from OFF-lock event handlers too. Returns the tab_id."""
        for tid, tracked in self.pages:
            if tracked is page:
                return tid
        self._tab_seq += 1
        tab_id = self._tab_seq
        self.pages.append((tab_id, page))
        self.page_state[tab_id] = PageSnap()
        try:
            page.on(
                "close",
                lambda *_a, _tid=tab_id: self._closed_tab_ids.add(_tid),
            )
            # JS dialogs: with NO listener Playwright auto-DISMISSES every
            # dialog — a dismissed beforeunload CANCELS the navigation, so
            # the agent clicks "leave", nothing happens, and it is
            # stranded on the page it tried to exit. Registering the
            # handler makes the policy ours (see _on_dialog).
            page.on("dialog", self._on_dialog)
            # File chooser: registering a listener makes Playwright
            # INTERCEPT the chooser — the native OS picker (which would
            # block a headed session, and which no agent can dismiss)
            # never opens. We record the event instead (see
            # _on_file_chooser).
            page.on("filechooser", self._on_file_chooser)
            # Download: record + cancel so a download click neither hangs
            # nor silently writes files we have no tool to read yet.
            page.on("download", self._on_download)
            # Session recorder. Registered always, inert unless recording:
            # attaching it lazily at record_start would miss the responses
            # of a page that was already open, which are usually the ones
            # that matter.
            page.on("response", self._on_response)
        except Exception:  # noqa: BLE001 — fakes/odd pages may lack .on
            pass
        if activate or self.active_tab_id is None:
            self.active_tab_id = tab_id
        return tab_id

    # ---- out-of-band page events (dialogs / choosers / downloads) ---------

    async def _on_dialog(self, dialog: Any) -> None:
        """``page.on("dialog")`` — runs OFF the lock; append-only.

        Policy: accept alert/confirm/beforeunload — the dialog interrupts
        an action the agent ALREADY chose, so the agent-friendly answer
        is "proceed" (an auto-dismissed confirm/beforeunload silently
        cancels the action → the wandering/hang class). Dismiss prompt —
        never type a guessed value into a page. Every dialog is recorded
        so the Brain sees what the page asked.
        """
        dtype = str(getattr(dialog, "type", "") or "")
        message = str(getattr(dialog, "message", "") or "")[:200]
        action = "dismissed" if dtype == "prompt" else "accepted"
        try:
            if dtype == "prompt":
                await dialog.dismiss()
            else:
                await dialog.accept()
        except Exception:  # noqa: BLE001 — dialog may already be gone
            pass
        self.page_events.append(
            {
                "kind": "js_dialog",
                "dialog_type": dtype,
                "message": message,
                "action": action,
            }
        )

    async def _on_file_chooser(self, chooser: Any) -> None:
        """``page.on("filechooser")`` — OFF the lock; append-only.

        The listener's existence suppresses the native OS picker; we
        record that the page asked for a file so the Brain stops pushing
        that control instead of waiting on a dialog that never resolves.
        """
        multiple = getattr(chooser, "is_multiple", False)
        if callable(multiple):  # property in playwright-python; method in fakes
            multiple = multiple()
        self.page_events.append(
            {"kind": "file_chooser", "multiple": bool(multiple)}
        )

    async def _on_download(self, download: Any) -> None:
        """``page.on("download")`` — OFF the lock; append-only.

        Cancel immediately: there is no Brain tool that reads a local
        file yet, so completing the download would only burn disk. The
        recorded event tells the Brain the click started a download (and
        its filename) — usually the signal to find the same data via an
        API or on-page text instead.
        """
        filename = str(getattr(download, "suggested_filename", "") or "")[:120]
        try:
            await download.cancel()
        except Exception:  # noqa: BLE001 — cancel is best-effort
            pass
        self.page_events.append(
            {"kind": "download", "filename": filename, "action": "cancelled"}
        )

    async def _on_response(self, response: Any) -> None:
        """``page.on("response")`` — OFF the lock; append-only. Never raises.

        Records EVERY response while recording is on, deliberately. The
        scorer that picks the data-bearing response applies its own
        content-type and status filters, and those filters are the thing
        under test — if this handler pre-filtered to plausible-looking
        candidates too, the same assumptions would be applied twice and
        the falsifier could not fail honestly.

        Bodies are the one exception, and the exception is recorded
        rather than silent: fetching the bytes of a video or a font costs
        real time and buys nothing, so a body is read only for text-ish
        media types. Every skipped body carries the reason, so a reader
        can always see what was passed over and why.

        ``seq`` and ``page_url`` are captured so a recording stays an
        ordered sequence of operations observed under a known page,
        rather than an undifferentiated pile. A mission that cannot say
        which operation comes next cannot be steered between steps.
        """
        if not self.recording:
            return
        try:
            if len(self.recorded) >= RECORD_MAX_RESPONSES:
                self.record_dropped += 1
                return
            self._record_seq += 1
            seq = self._record_seq
            request = getattr(response, "request", None)
            headers = {}
            try:
                headers = dict(getattr(response, "headers", {}) or {})
            except Exception:  # noqa: BLE001 — odd pages may not expose them
                headers = {}
            ctype = str(headers.get("content-type", ""))
            body, captured, skip_reason, truncated = await _read_body(response, ctype)
            page_url = ""
            try:
                frame = getattr(response, "frame", None)
                page = getattr(frame, "page", None) if frame is not None else None
                page_url = str(getattr(page, "url", "") or "")
            except Exception:  # noqa: BLE001 — detached frame
                page_url = ""
            req_headers: dict[str, str] = {}
            req_body: str | None = None
            method = ""
            resource_type = ""
            if request is not None:
                method = str(getattr(request, "method", "") or "")
                resource_type = str(getattr(request, "resource_type", "") or "")
                try:
                    req_headers = {
                        k: v
                        for k, v in dict(getattr(request, "headers", {}) or {}).items()
                        # Never persist the session itself. The replayer runs
                        # inside the live page, which reattaches cookies on
                        # its own, so a stored copy is pure liability.
                        if k.lower() not in _RECORD_HEADER_DENYLIST
                    }
                except Exception:  # noqa: BLE001
                    req_headers = {}
                try:
                    req_body = getattr(request, "post_data", None)
                except Exception:  # noqa: BLE001
                    req_body = None
            self.recorded.append(
                {
                    "seq": seq,
                    "t_start": round((time.monotonic() - self.record_t0) * 1000.0, 1),
                    "url": str(getattr(response, "url", "") or "")[:2000],
                    "method": method,
                    "status": int(getattr(response, "status", 0) or 0),
                    "resource_type": resource_type,
                    "resp_content_type": ctype,
                    "resp_body": body,
                    "body_captured": captured,
                    "body_skip_reason": skip_reason,
                    "truncated": truncated,
                    "req_headers": req_headers,
                    # Scrub before truncating: a secret straddling the cut
                    # would otherwise survive as a fragment.
                    "req_body": (
                        (_scrub_secrets(req_body, self._typed_secrets) or "")[
                            :RECORD_MAX_BODY_BYTES
                        ]
                        if req_body
                        else None
                    ),
                    "page_url": page_url[:2000],
                }
            )
        except Exception:  # noqa: BLE001 — a recorder must never break a page
            logger.debug("response recorder skipped one", exc_info=True)

    def drain_events(self) -> list[dict[str, Any]]:
        """Pop all pending out-of-band events. MUST run under the lock.

        Pops one-at-a-time (GIL-atomic) so an OFF-lock append racing this
        drain is never lost — it lands in the next drain instead.
        """
        events: list[dict[str, Any]] = []
        while self.page_events:
            events.append(self.page_events.pop(0))
        return events

    def sweep_closed(self) -> None:
        """Drop tombstoned/closed tabs. MUST run under the lock."""
        dead = set(self._closed_tab_ids)
        for tid, page in self.pages:
            try:
                if page.is_closed():
                    dead.add(tid)
            except Exception:  # noqa: BLE001 — unreadable page = dead
                dead.add(tid)
        if not dead:
            return
        self.pages = [(t, p) for t, p in self.pages if t not in dead]
        for tid in dead:
            self.page_state.pop(tid, None)
            self._closed_tab_ids.discard(tid)
        if self.active_tab_id in dead:
            self.active_tab_id = self.pages[-1][0] if self.pages else None

    def active_page(self) -> Any | None:
        """The page commands act on: the pinned active tab, else the
        newest tracked tab (repairs ``active_tab_id`` when stale)."""
        if self.active_tab_id is not None:
            for tid, page in self.pages:
                if tid == self.active_tab_id:
                    return page
        if self.pages:
            self.active_tab_id = self.pages[-1][0]
            return self.pages[-1][1]
        return None

    async def require_page(self) -> tuple[Any, PageSnap]:
        """ensure_browser + resolve the active page and its PageSnap."""
        await self.ensure_browser()
        page = self.active_page()
        if page is None:
            raise RuntimeError("no_open_page")
        assert self.active_tab_id is not None  # set by active_page()
        snap = self.page_state.get(self.active_tab_id)
        if snap is None:  # defensive — attach_page always creates one
            snap = PageSnap()
            self.page_state[self.active_tab_id] = snap
        return page, snap

    async def reconcile_pages(self) -> list[int]:
        """Track any context page we haven't seen yet (belt + braces vs
        event-delivery ordering); apply the auto-follow rule to each.
        Call under the lock. Returns newly-tracked tab_ids."""
        if self.ctx is None:
            return []
        try:
            ctx_pages = list(self.ctx.pages)
        except Exception:  # noqa: BLE001
            return []
        new_ids: list[int] = []
        for p in ctx_pages:
            if any(tracked is p for _, tracked in self.pages):
                continue
            prev_active = self.active_page()
            tid = self.attach_page(p, activate=False)
            new_ids.append(tid)
            if await self._should_follow(p, prev_active):
                self.active_tab_id = tid
        return new_ids

    async def _on_new_page(self, page: Any) -> None:
        """``context.on("page")`` handler — runs OFF the command lock,
        so: append-only registration + a single scalar set. Auto-follow
        only when the tab plausibly belongs to the mission; ad/tracker
        popups stay tracked-but-not-followed."""
        prev_active = self.active_page()
        tab_id = self.attach_page(page, activate=False)
        try:
            page.set_default_timeout(NAV_TIMEOUT_MS)
        except Exception:  # noqa: BLE001
            pass
        if await self._should_follow(page, prev_active):
            self.active_tab_id = tab_id

    async def _should_follow(self, page: Any, prev_active: Any) -> bool:
        """Follow iff: opener chains to a tracked page, OR same
        registrable domain as the active page, OR a known OAuth host."""
        try:
            opener = await page.opener()
        except Exception:  # noqa: BLE001
            opener = None
        if opener is not None and any(
            tracked is opener for _, tracked in self.pages
        ):
            return True
        host = _host_of(page.url or "")
        if not host:
            # The "page" event often fires before the URL is known.
            try:
                await page.wait_for_load_state(
                    "domcontentloaded", timeout=3_000
                )
            except Exception:  # noqa: BLE001
                pass
            host = _host_of(page.url or "")
        if not host:
            return False
        if host in _OAUTH_HOSTS or host.endswith(_OAUTH_SUFFIXES):
            return True
        active_host = _host_of(
            (prev_active.url if prev_active is not None else "") or ""
        )
        return bool(active_host) and _registrable(host) == _registrable(
            active_host
        )

    # ---- browser lifecycle -------------------------------------------------

    async def ensure_browser(self) -> None:
        """Lazily start Playwright + open the persistent context.

        Idempotent — a no-op while at least one tracked page is alive.
        """
        self.sweep_closed()
        if self.ctx is not None and self.active_page() is not None:
            return
        if self.ctx is not None:
            # Context alive but every tab closed — open a fresh one.
            page = await self.ctx.new_page()
            page.set_default_timeout(NAV_TIMEOUT_MS)
            self.attach_page(page, activate=True)
            return
        try:
            from playwright.async_api import async_playwright
        except Exception as exc:
            raise RuntimeError(
                f"playwright_unavailable:{type(exc).__name__}"
            ) from exc

        Path(self.user_data_dir).mkdir(parents=True, exist_ok=True)

        if self.pw is None:
            self.pw = await async_playwright().start()

        # Browser posture (2026-08-20). The previous approach — bundled
        # Chromium, a spoofed user-agent and a hand-written stealth script —
        # was net-NEGATIVE. `navigator.plugins => [1,2,3,4,5]` returned an
        # integer array where a real browser returns a PluginArray, and the
        # webdriver getter's toString() was `() => undefined`; both are named
        # signatures detectors look for. A spoofed UA is worse still, because
        # Playwright's `user_agent=` does not update the Sec-CH-UA client
        # hints, so the two disagree — and inconsistency between signals is
        # the dominant detection method.
        #
        # Real Chrome supplies chrome.runtime, real plugins, matching client
        # hints and a genuine TLS fingerprint natively, at a layer no patch
        # reproduces. So: no UA override, no injected stealth, and be a real
        # browser instead of impersonating one.
        launch_kwargs: dict[str, Any] = {
            "user_data_dir": self.user_data_dir,
            "headless": _effective_headless(),
            "viewport": {"width": 1366, "height": 768},
            "locale": "en-US",
            "timezone_id": "America/New_York",
            "args": _launch_args(),
            # Playwright disables Chromium's sandbox by DEFAULT — measured:
            # our own process carried --no-sandbox even though _launch_args
            # never added it. Only an explicit True turns it back on, so the
            # conditional above is meaningless without this line.
            "chromium_sandbox": not _needs_sandbox_disabled(),
        }
        try:
            # The UA correction rides only on the real-Chrome attempt: on the
            # bundled-Chromium fallback it would claim a version that binary
            # does not have, and Sec-CH-UA would contradict it.
            chrome_args = list(launch_kwargs["args"])
            if _effective_headless():
                spoofed = _headless_user_agent()
                if spoofed:
                    chrome_args.append(f"--user-agent={spoofed}")
            self.ctx = await self.pw.chromium.launch_persistent_context(
                channel="chrome", **{**launch_kwargs, "args": chrome_args}
            )
        except Exception as exc:  # noqa: BLE001 — Chrome may not be installed
            # Never a hard dependency: the install story cannot require a
            # second browser. Bundled Chromium is the documented fallback.
            logger.info(
                "real Chrome unavailable (%s); falling back to bundled Chromium",
                type(exc).__name__,
            )
            self.ctx = await self.pw.chromium.launch_persistent_context(**launch_kwargs)
        # Demo overlay (env-gated): saffron step pill on every page so a
        # viewer can SEE Rokan working. Cosmetic — failure disables it.
        self.overlay_js = _load_overlay_js(self.mission_id)
        if self.overlay_js is not None:
            try:
                await self.ctx.add_init_script(self.overlay_js)
                logger.info("rokan demo overlay enabled")
            except Exception:  # noqa: BLE001
                logger.warning("overlay init script failed (non-fatal)")
                self.overlay_js = None
        # Track every tab the context opens from now on (W1).
        self.ctx.on("page", self._on_new_page)
        pages = list(self.ctx.pages)
        first = pages[0] if pages else await self.ctx.new_page()
        first.set_default_timeout(NAV_TIMEOUT_MS)
        self.attach_page(first, activate=True)
        for extra in pages[1:]:  # restored-session tabs, if any
            self.attach_page(extra, activate=False)

    async def shutdown(self) -> None:
        """Close the browser cleanly. Never raises."""
        self.shutdown_event.set()
        if self.ctx is not None:
            try:
                # ``close()`` flushes storage_state to user_data_dir.
                await self.ctx.close()
            except Exception:
                logger.exception("ctx.close failed")
            self.ctx = None
        if self.pw is not None:
            try:
                await self.pw.stop()
            except Exception:
                logger.exception("pw.stop failed")
            self.pw = None
        self.pages.clear()
        self.page_state.clear()
        self.active_tab_id = None
        self._closed_tab_ids.clear()


# --------------------------------------------------------------------------
# Command dispatcher
# --------------------------------------------------------------------------


async def _cmd_navigate(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    url = str(args.get("url") or "").strip()
    if not url:
        return {"ok": False, "error": "missing_url"}
    if not url.lower().startswith(("http://", "https://")):
        return {"ok": False, "error": "bad_url_scheme"}
    page, snap = await state.require_page()
    # Opt-in re-fetch. The idempotent shortcut below is right for an agent
    # working a page and WRONG for anything that re-visits one URL on a
    # schedule: a watcher would be handed the first-ever copy forever and
    # report "no change" while the page changed underneath it. Measured
    # 2026-08-20 — three navigations to a ticking page produced one fetch and
    # three identical reads.
    #
    # Default stays unchanged so the navigate→reload→refill bug stays fixed.
    force_reload = bool(args.get("reload"))
    # Idempotent: do NOT reload a page we're already on. Reloading an SPA
    # wipes filled fields / open modals → the navigate→reload→refill loop
    # (the #1 cause of the "it typed the email then the page reloaded" bug).
    # Return the current page so the brain snapshots + acts IN PLACE.
    cur = (page.url or "").split("#", 1)[0].rstrip("/")
    same_page = bool(cur) and cur == url.split("#", 1)[0].rstrip("/")
    if same_page and not force_reload:
        try:
            title = await page.title()
        except Exception:  # noqa: BLE001
            title = ""
        return {
            "ok": True,
            "final_url": page.url,
            "title": title or "",
            "already_here": True,
        }
    try:
        # E1 (2026-06-10): domcontentloaded only — the old unconditional
        # 6s networkidle settle dominated navigation latency. SPA
        # hydration is handled where it matters: the snapshot's
        # empty-extraction retry loop settles networkidle on demand.
        if same_page and force_reload:
            # reload() revalidates; goto() to the URL we are already on is
            # served straight from the HTTP cache.
            await page.reload(wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS)
        else:
            await page.goto(url, wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS)
    except Exception as exc:
        return {
            "ok": False,
            "error": "navigation_failed",
            "detail": type(exc).__name__,
        }
    # Real navigation invalidates this tab's refs — make that honest
    # (ref_not_found) instead of silently clicking the wrong element.
    snap.ref_map = {}
    snap.ref_frames = {}
    # Late client-side redirect — same race as the W5 click settle. The
    # measured wall (Plunk /auth/login with a live session, 2026-06-10):
    # goto reports the login page, then the SPA bounces to the dashboard
    # hundreds of ms later. Without this settle the Brain was told it
    # was on a login form that no longer existed and its fills died
    # ref_not_found.
    landed = page.url
    await _settle_after_click(page, landed)
    try:
        title = await page.title()
    except Exception:
        title = ""
    result: dict[str, Any] = {
        "ok": True,
        "final_url": page.url,
        "title": title or "",
    }
    if same_page and force_reload:
        result["reloaded"] = True
    if (page.url or "").split("#", 1)[0].rstrip("/") != url.split("#", 1)[0].rstrip(
        "/"
    ):
        result["redirected_from"] = url
    return result


async def _cmd_snapshot(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    url = str(args.get("url") or "").strip()
    page, snap = await state.require_page()
    if url:
        if not url.lower().startswith(("http://", "https://")):
            return {"ok": False, "error": "bad_url_scheme"}
        # Idempotent (same fix as navigate): only goto if it's a DIFFERENT
        # page. browser_snapshot(url=current_page) must NOT reload — a full
        # reload wipes filled fields/modals (THE page-refresh obsession).
        # If we're already there, just snapshot the live page in place.
        #
        # `reload` opts out, for callers that re-visit ONE url on a schedule
        # and would otherwise be handed the first copy forever. This path
        # matters more than navigate's: login.fetch() reaches a page through
        # snapshot, so a watcher built on it silently never re-fetched.
        force_reload = bool(args.get("reload"))
        cur = (page.url or "").split("#", 1)[0].rstrip("/")
        same_page = cur == url.split("#", 1)[0].rstrip("/")
        if not same_page or force_reload:
            try:
                if same_page and force_reload:
                    # goto() to the url we are already on is served from the
                    # HTTP cache; reload() revalidates.
                    await page.reload(
                        wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS
                    )
                else:
                    await page.goto(
                        url, wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS
                    )
            except Exception as exc:
                return {
                    "ok": False,
                    "error": "navigation_failed",
                    "detail": type(exc).__name__,
                }
    # E1 (2026-06-10): no unconditional networkidle — extraction runs
    # immediately; only a page with NO interactive ELEMENTS (SPA still
    # hydrating behind a "Loading…" skeleton) pays for a capped settle +
    # retry. KEYING ON ELEMENTS, NOT TEXT, is load-bearing: Plunk (and
    # many SPAs) render a "Loading…" text node FIRST, so an
    # `elements OR texts` break stopped retrying before the form
    # appeared → the Brain never saw the email field and wandered
    # (measured 2026-06-10 on app.useplunk.com). We retry until we get
    # something CLICKABLE, up to 4 attempts (~3s total).
    raw: Any = None
    elements: list[Any] = []
    texts: list[Any] = []
    dropped = 0
    for attempt in range(4):
        try:
            raw = await page.evaluate(_SNAPSHOT_JS)
        except Exception as exc:
            return {
                "ok": False,
                "error": "snapshot_failed",
                "detail": type(exc).__name__,
            }
        # New JS returns {elements, texts, dropped}; tolerate the old
        # bare-list shape (older script / test stubs) so nothing breaks.
        if isinstance(raw, dict):
            elements = raw.get("elements") or []
            texts = raw.get("texts") or []
            dropped = int(raw.get("dropped") or 0)
        else:
            elements = raw or []
            texts = []
        # Stop as soon as the page is ACTIONABLE. On the final attempt
        # accept whatever we have (a genuinely text-only page — e.g. a
        # bare "Verified!" confirmation — must still return its text).
        if elements or (attempt == 3 and texts):
            break
        try:
            if attempt < 2:
                await page.wait_for_load_state("networkidle", timeout=2_000)
            else:
                await page.wait_for_timeout(700)
        except Exception:  # noqa: BLE001 — retry wait is best-effort
            pass

    # Iframes (same-origin AND cross-origin): run the SAME snapshot JS
    # inside each visible child frame — login forms, payment fields and
    # consent widgets live there and are invisible to the main-frame
    # evaluate. Playwright evaluates per-frame (OOPIF included), so both
    # origins work. Frame elements get globally renumbered Brain-facing
    # refs; their selectors stay frame-LOCAL and click/fill route through
    # the live Frame recorded in snap.ref_frames.
    frame_sections: list[tuple[Any, str, list[Any], list[Any]]] = []
    for fr, flabel in await _candidate_frames(page):
        try:
            fraw = await fr.evaluate(_SNAPSHOT_JS)
        except Exception:  # noqa: BLE001 — frame navigated/died mid-snap
            continue
        if not isinstance(fraw, dict):
            continue
        f_elements = fraw.get("elements") or []
        f_texts = fraw.get("texts") or []
        if not f_elements and not f_texts:
            continue
        try:
            f_url = str(fr.url or "")
        except Exception:  # noqa: BLE001
            f_url = ""
        frame_sections.append(
            (fr, flabel or f_url or "iframe", f_elements, f_texts)
        )

    rendered: list[str] = []
    ref_map: dict[str, dict[str, Any]] = {}
    ref_frames: dict[str, Any] = {}
    cur_url = page.url or ""
    # Mark elements that appeared since the last snapshot (same page only —
    # on a fresh page everything is trivially "new", which is noise).
    same_page = bool(snap.prev_url) and cur_url == snap.prev_url
    cur_keys: set[str] = set()
    any_new = False
    eid_n = 0
    sections: list[tuple[Any, str, list[Any]]] = [(None, "", elements)]
    sections.extend((fr, fl, els) for fr, fl, els, _ts in frame_sections)
    for fr, flabel, sec_elements in sections:
        if fr is not None and sec_elements:
            rendered.append(f"  -- inside iframe {_truncate(flabel, 70)!r} --")
        for item in sec_elements:
            eid_n += 1
            eid = "@e" + str(eid_n)
            label = _truncate(item.get("label", ""), MAX_LABEL_CHARS)
            role = item.get("role", "") or ""
            href = item.get("href", "") or ""
            ph = item.get("placeholder", "") or ""
            itype = item.get("input_type", "") or ""
            # Key must NOT include the selector: data-rokan-ref ids are
            # positional, so one inserted element would shift every id
            # and star the whole page as NEW. frame + dom_id/href/
            # placeholder/type are identity signals that survive
            # re-snapshots of the same page.
            key = "|".join(
                (
                    flabel,
                    role,
                    label,
                    item.get("dom_id", "") or "",
                    href,
                    ph,
                    itype,
                )
            )
            cur_keys.add(key)
            is_new = same_page and key not in snap.prev_labels
            any_new = any_new or is_new
            suffix = ""
            if role == "link" and href:
                suffix = f"  href={href}"
            elif role == "input" and ph:
                suffix = f"  placeholder={ph!r}"
            elif role == "input" and itype:
                suffix = f"  type={itype}"
            if item.get("filled"):
                suffix += "  (already filled)"
            if item.get("disabled"):
                suffix += "  (DISABLED — fill required fields first)"
            for aria_flag in ("expanded", "selected", "checked", "current"):
                val = item.get(aria_flag)
                if val is not None:
                    suffix += f"  [{aria_flag}={'yes' if val else 'no'}]"
            if role == "select" and item.get("options") is not None:
                opts = [
                    _truncate(o, 30) for o in (item.get("options") or [])
                ][:12]
                total = int(item.get("options_total") or len(opts))
                more = f" (+{total - len(opts)} more)" if total > len(opts) else ""
                sel = _truncate(item.get("selected") or "", 30)
                suffix += (
                    f"  options={opts!r}{more}  selected={sel!r}"
                    "  — set with browser_fill_ref(value=<option label>)"
                )
            if item.get("hidden"):
                suffix += "  (hidden file input — attach files via set_files)"
            elif item.get("below_fold"):
                suffix += "  (below fold — still clickable by ref)"
            section = str(item.get("section") or "")[:60]
            if section:
                # Only ever present on a label the page repeats, which is
                # exactly when the planner has to be able to say WHICH
                # one — and it can only say it if it can see it.
                suffix += f"  under {section!r}"
            mark = "*" if is_new else " "
            rendered.append(f"  {mark}[{eid}] {role:8s} {label!r}{suffix}")
            ref_map[eid] = {
                "selector": item.get("selector", "") or "",
                "stable_selector": item.get("stable_selector", "") or "",
                "role": role,
                "label": label,
                "input_type": itype,
                "frame": "" if fr is None else flabel,
                "in_shadow": bool(item.get("in_shadow")),
                # Carried for programmatic (non-LLM) consumers that classify a
                # form from the ref_map alone — a deterministic login driver
                # needs the placeholder/id to tell a TOTP box from a search box,
                # and `filled`/`disabled` to know whether a step already ran.
                # The rendered text the Brain reads is unchanged.
                "placeholder": ph,
                "dom_id": str(item.get("dom_id", "") or ""),
                # A real link has somewhere to go. The write policy waives
                # its guard for navigation only when this is non-empty — a
                # page can call anything role=link; it cannot fake an href
                # into a click that stays on the page.
                "href": str(item.get("href", "") or ""),
                "disabled": bool(item.get("disabled")),
                "filled": bool(item.get("filled")),
                # Empty unless the page uses this label more than once.
                "section": str(item.get("section") or "")[:60],
            }
            if role == "select" and item.get("options") is not None:
                ref_map[eid]["options"] = [
                    str(o) for o in (item.get("options") or [])
                ][:12]
            if fr is not None:
                ref_frames[eid] = fr
    if any_new:
        rendered.insert(
            0,
            "  (* = NEW since your last action — likely what you just "
            "triggered; usually where to act next)",
        )
    if dropped:
        rendered.append(
            f"  (+{dropped} more interactive elements were cut at the "
            "250-element cap — least-visible ones dropped first)"
        )

    # Frame texts ride along after main-page texts, same global cap —
    # an error message rendered inside a payment iframe is still the
    # reason the submit failed.
    for _fr, _fl, _els, f_texts in frame_sections:
        for t in f_texts:
            if len(texts) >= 40:
                break
            texts.append(t)

    snap.ref_map = ref_map
    snap.ref_frames = ref_frames
    snap.prev_url = cur_url
    snap.prev_labels = cur_keys

    # Gap 6 — STRUCTURED bot-gate detection (engine signal, not LLM
    # inference from "nothing changed"). Detection only: solving routes
    # to the human via ask_user → captcha_human_gate.
    captcha = _detect_captcha(
        ref_map, [fl for _f, fl, _e, _t in frame_sections], texts
    )
    if captcha:
        rendered.insert(
            0,
            f"  ⚠ CAPTCHA/bot-gate detected: {captcha['kind']} — "
            f"{captcha['evidence']}. NEVER try to solve it. If it blocks "
            "progress, ask_user for a human solve and report "
            "reason='captcha_human_gate'.",
        )

    try:
        title = await page.title()
    except Exception:
        title = ""

    result = {
        "ok": True,
        "url": page.url,
        "title": title or "",
        "rendered": rendered,
        "ref_map": ref_map,
        # 520 = the JS code-snippet cap (500) + ellipsis margin; prose
        # items arrive already ≤200 from pushText, so this only spares
        # API snippets from a second cut.
        "page_text": [_truncate(t, 520) for t in texts][:40],
        "tabs_open": len(state.pages),
    }
    if captcha:
        result["captcha"] = captcha
    return result


async def _cmd_click_ref(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    raw_ref = str(args.get("ref") or "").strip()
    if not raw_ref:
        return {"ok": False, "error": "missing_ref"}
    ref = raw_ref if raw_ref.startswith("@") else "@" + raw_ref
    page, snap = await state.require_page()

    entry = snap.ref_map.get(ref)
    if not entry or not entry.get("selector"):
        return {"ok": False, "error": "ref_not_found"}
    selector = str(entry["selector"])
    # Native <select> (Gap 4): clicking one opens an OS-rendered dropdown
    # that exists outside the page — neither headless nor headed agents
    # can see or drive it, and the click would just hang/no-op. Redirect
    # honestly instead of pretending the click worked.
    if str(entry.get("role") or "") == "select":
        return {
            "ok": False,
            "error": "select_use_fill_ref",
            "detail": (
                "that's a native <select> dropdown — use browser_fill_ref"
                "(ref, value=<option label>) to choose an option. Options: "
                f"{entry.get('options') or 'see snapshot'}"
            ),
        }
    ctx = _ref_context(page, snap, ref)
    if ctx is None:
        return {
            "ok": False,
            "error": "frame_detached",
            "detail": "that iframe is gone — take browser_snapshot again",
        }
    # The click that SUBMITS a form is what sends whatever was just typed,
    # so it takes the same origin check as the typing — on the context the
    # click targets, not the parent page. Optional, because most clicks are
    # nobody's secret; `login._submit` always states it.
    expected = str(args.get("expect_host") or "").strip().lower()
    if not _origin_matches(ctx, expected):
        return {
            "ok": False,
            "error": "click_origin_refused",
            "detail": "the document is not on the expected site",
        }
    resolved, recovered = await _resolve_ref_selector(ctx, entry)
    if resolved is None:
        return _ref_gone_result(page, snap)
    selector = resolved
    text_to_type = args.get("text_to_type")

    # W5 action feedback: cheap count+hash fingerprint before/after (the
    # ~1-3ms evaluate, NOT a full snapshot) so the Brain learns whether
    # its click actually changed anything.
    pre_url = page.url or ""
    pre_fp = await _fingerprint(page)
    known_tabs = {tid for tid, _ in state.pages}
    try:
        locator = ctx.locator(selector).first
        await locator.scroll_into_view_if_needed(timeout=3_000)
        await locator.click(timeout=5_000)
    except Exception as exc:
        # `click_failed` does NOT mean the click never happened, and a
        # caller that assumes it does will double-submit. Playwright's
        # click ends by WAITING for any navigation it initiated, inside
        # this same 5s budget (its own docs: "Wait for initiated
        # navigations to either succeed or fail, unless noWaitAfter"), so
        # a submit whose server takes six seconds throws TimeoutError
        # AFTER the form was sent. An element the click re-rendered throws
        # "detached" after the fact for the same reason.
        #
        # So measure it rather than assume it: the fingerprint and URL
        # taken before the click, compared now. Read FIRST, before the
        # occlusion probe, so this describes the click and not the
        # diagnosis. Unreadable stays None — never False.
        post_fp = await _fingerprint(page)
        try:
            post_url = page.url or ""
        except Exception:  # noqa: BLE001 — reporting must not raise
            post_url = pre_url
        page_changed: bool | None = None
        if pre_fp is not None and post_fp is not None:
            page_changed = bool(
                pre_fp != post_fp
                or post_url.split("#", 1)[0] != pre_url.split("#", 1)[0]
            )
        covering = await _what_covers(ctx, selector)
        reply: dict[str, Any] = {
            "ok": False,
            "error": "click_failed",
            "detail": type(exc).__name__,
            "page_changed": page_changed,
            # Carried on the FAILURE too. Reporting ref health only when
            # the action succeeded measures "refs that survived long
            # enough to work", which is the one population guaranteed to
            # look healthy — and a page mid-re-render both kills refs AND
            # leaves elements unclickable, so the excluded cases are
            # exactly the interesting ones.
            "ref_recovered": recovered,
        }
        if covering:
            reply["covered_by"] = covering
            reply["detail"] = f"{type(exc).__name__} — covered by {covering!r}"
        return reply
    if text_to_type:
        try:
            await page.keyboard.type(str(text_to_type), delay=10)
        except Exception as exc:
            return {
                "ok": False,
                "error": "type_failed",
                "detail": type(exc).__name__,
                "ref_recovered": recovered,
            }
    await _settle_after_click(page, pre_url)
    return await _post_action_report(
        state,
        snap,
        pre_url=pre_url,
        pre_fp=pre_fp,
        known_tabs=known_tabs,
        ref_recovered=recovered,
    )


#: One-roundtrip option matcher for native <select> — exact label/value
#: first, then unique case-insensitive substring (LLMs pass "United
#: States" for "United States of America"). Returns the option VALUE to
#: select, or null + the visible option list for an honest error.
_SELECT_MATCH_JS = r"""
(el, needle) => {
  const n = ((needle || '') + '').trim().toLowerCase();
  const all = [];
  let exact = null;
  const fuzzy = [];
  for (const o of el.options) {
    const label = ((o.label || o.text || '') + '').trim();
    const val = (o.value + '').trim();
    all.push(label || val);
    const ll = label.toLowerCase(), lv = val.toLowerCase();
    if (ll === n || lv === n) {
      if (exact === null) exact = o.value;
    } else if (n && (ll.includes(n) || lv.includes(n))) {
      fuzzy.push(o.value);
    }
  }
  if (exact !== null) return { value: exact, all: all, ambiguous: false };
  if (fuzzy.length === 1) return { value: fuzzy[0], all: all, ambiguous: false };
  return { value: null, all: all, ambiguous: fuzzy.length > 1 };
}
"""


async def _fill_select(
    page: Any, ctx: Any, selector: str, value: str
) -> dict[str, Any]:
    """Set a native <select> by option label/value. ``select_option``
    drives the element directly — the OS-rendered dropdown (which no
    agent, headless or headed, can see or click) never opens — and fires
    real change events so framework listeners run."""
    pre_fp = await _fingerprint(page)
    locator = ctx.locator(selector).first
    try:
        m = await locator.evaluate(_SELECT_MATCH_JS, value)
    except Exception as exc:
        return {
            "ok": False,
            "error": "select_failed",
            "detail": type(exc).__name__,
        }
    matched = (m or {}).get("value") if isinstance(m, dict) else None
    if matched is None:
        options = (m or {}).get("all") if isinstance(m, dict) else None
        ambiguous = bool((m or {}).get("ambiguous")) if isinstance(m, dict) else False
        return {
            "ok": False,
            "error": "ambiguous_option" if ambiguous else "option_not_found",
            "detail": (
                f"no {'unique ' if ambiguous else ''}option matching "
                f"{value!r}. Pass one of the visible option labels: "
                f"{options!r}"
            ),
        }
    try:
        await locator.select_option(value=str(matched), timeout=3_000)
    except Exception as exc:
        return {
            "ok": False,
            "error": "select_failed",
            "detail": type(exc).__name__,
        }
    post_fp = await _fingerprint(page)
    dom_changed: bool | None = None
    if pre_fp is not None and post_fp is not None:
        dom_changed = pre_fp != post_fp
    return {"ok": True, "selected": str(matched), "dom_changed": dom_changed}


async def _settle_after_click(page: Any, pre_url: str) -> None:
    """Give an async / SPA navigation a bounded chance to fire AND settle
    BEFORE the W5 fingerprint reads ``url_changed``.

    Two measured walls drive the shape:

    1. Plunk "Create Project" (2026-06-10): a submit button POSTs to an
       API and CLIENT-redirects on success — the URL changes hundreds of
       ms AFTER the click. ``domcontentloaded`` does NOT fire on a
       client-side route change (history.pushState), so reading
       ``url_changed`` immediately reported "nothing happened"; the Brain
       concluded its click missed, retried, and escalated to ``click_xy``.
    2. Plunk signup, HEADED (2026-06-11, diag_daemon_signup_flap.py): the
       redirect to ``/auth/verify-email`` fires ~2s after the click —
       past the old 1.5s first-change cap — so the click reported
       ``url_changed=False`` while the page navigated underneath the
       Brain's next snapshot, and headed runs can hop more than once
       (signup → verify) before coming to rest.

    So: wait for a real document load, then wait for a FIRST URL change
    (3s cap — headed redirects measured ~2s), and once a navigation has
    begun, keep polling until the URL has been STABLE for 700ms (5s cap)
    so multi-hop redirect chains are reported at their final stop. A
    click that genuinely stays in place pays the first-change cap once
    and never enters the stability wait. Best-effort — never raises."""
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=3_000)
    except Exception:  # noqa: BLE001 — settle is best-effort
        pass
    base = pre_url.split("#", 1)[0]
    try:
        await page.wait_for_url(
            lambda u: u.split("#", 1)[0] != base, timeout=3_000
        )
    except Exception:  # noqa: BLE001 — no nav within budget = in-place
        return
    # A navigation began — wait for the URL to come to REST. First-change
    # alone is not enough: headed multi-hop chains flap refs between
    # snapshots if the report fires mid-chain.
    deadline = time.monotonic() + 5.0
    try:
        last = (page.url or "").split("#", 1)[0]
    except Exception:  # noqa: BLE001 — settle is best-effort
        return
    quiet_since = time.monotonic()
    while time.monotonic() < deadline:
        await asyncio.sleep(0.1)
        try:
            cur = (page.url or "").split("#", 1)[0]
        except Exception:  # noqa: BLE001 — settle is best-effort
            return
        if cur != last:
            last = cur
            quiet_since = time.monotonic()
        elif time.monotonic() - quiet_since >= 0.7:
            return


async def _post_action_report(
    state: DaemonState,
    snap: PageSnap,
    *,
    pre_url: str,
    pre_fp: tuple[int, str] | None,
    known_tabs: set[int],
    ref_recovered: bool | None = None,
) -> dict[str, Any]:
    """Shared W5 feedback assembly after a click-like action.

    Reconciles new tabs inline (W1 — deterministic, not event-ordering-
    dependent), drops the acting tab's stale ref-map, and reports
    url_changed / dom_changed / new_tab against the now-active page.
    """
    await state.reconcile_pages()
    state.sweep_closed()
    new_tab = any(tid not in known_tabs for tid, _ in state.pages)

    # The action likely mutated the DOM — drop the stale ref-map. Brain
    # must re-snapshot before clicking again.
    snap.ref_map = {}
    snap.ref_frames = {}

    active = state.active_page()
    post_url = (active.url if active is not None else "") or ""
    post_fp = await _fingerprint(active) if active is not None else None
    url_changed = post_url.split("#", 1)[0] != pre_url.split("#", 1)[0]
    dom_changed: bool | None = None
    if pre_fp is not None and post_fp is not None:
        dom_changed = pre_fp != post_fp
    try:
        title = (await active.title()) if active is not None else ""
    except Exception:
        title = ""
    report: dict[str, Any] = {
        "ok": True,
        "post_url": post_url,
        "active_url": post_url,
        "title": title or "",
        "url_changed": url_changed,
        "dom_changed": dom_changed,
        "new_tab": new_tab,
    }
    # Ref health — computed by `_resolve_ref_selector` since the Plunk
    # re-render wall and discarded ever since. True means the injected
    # `data-rokan-ref` was dead on arrival and the element's OWN durable
    # selector recovered it; the rate of that is the number that decides
    # whether a structural fingerprint is worth building. ABSENT for
    # actions that address no ref (click_xy, type) — "not measured" must
    # never read as "fine", the same rule `w5` follows with None.
    if ref_recovered is not None:
        report["ref_recovered"] = bool(ref_recovered)
    return report


async def _cmd_click_xy(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """Coordinate click (3B, W9) — trusted input via ``page.mouse``, which
    goes through the compositor and therefore lands inside CROSS-ORIGIN
    IFRAMES (OAuth / Stripe / captcha widgets) that the DOM-snapshot ref
    path cannot see. High-risk fallback: the caller must echo the
    viewport its coordinates were derived in; a mismatch rejects rather
    than clicking a guessed pixel.
    """
    try:
        x = float(args.get("x"))  # type: ignore[arg-type]
        y = float(args.get("y"))  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return {"ok": False, "error": "bad_coordinates"}
    page, snap = await state.require_page()
    cur_vp = page.viewport_size or {}
    vp = args.get("viewport") or {}
    try:
        vp_w = int(vp.get("width"))  # type: ignore[arg-type]
        vp_h = int(vp.get("height"))  # type: ignore[arg-type]
        vp_ok = vp_w == int(cur_vp.get("width") or 0) and vp_h == int(
            cur_vp.get("height") or 0
        )
    except (TypeError, ValueError):
        vp_ok = False
    if not vp_ok:
        return {
            "ok": False,
            "error": "viewport_mismatch",
            "detail": (
                "pass the viewport your coordinates were derived in; "
                f"the live viewport is {cur_vp}"
            ),
            "viewport": cur_vp,
        }
    if not (0 <= x < float(cur_vp["width"]) and 0 <= y < float(cur_vp["height"])):
        return {"ok": False, "error": "out_of_viewport", "viewport": cur_vp}

    pre_url = page.url or ""
    pre_fp = await _fingerprint(page)
    known_tabs = {tid for tid, _ in state.pages}
    try:
        await page.mouse.click(x, y)
    except Exception as exc:
        return {
            "ok": False,
            "error": "click_failed",
            "detail": type(exc).__name__,
        }
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=3_000)
    except Exception:
        pass
    return await _post_action_report(
        state, snap, pre_url=pre_url, pre_fp=pre_fp, known_tabs=known_tabs
    )


def _origin_matches(context: Any, expected: str) -> bool:
    """Is the document that will receive these keystrokes the expected one?

    THE CONTEXT, not the page. Four rounds of review moved this check
    closer to the write and it was still one indirection away: the guard
    read `page.url` while the fill targets `_ref_context(...)`, which is
    the iframe Frame when the ref was snapshotted inside one. Snapshotting
    deliberately walks cross-origin frames, so a password field could live
    in a third-party IdP or payment iframe and both layers — daemon and
    client — measured the parent. Reproduced: guard passed for
    app.example.com while the keystrokes went to a frame at
    evil-idp.example.net.

    `hostname`, not `netloc`: userinfo like `https://evil.com@good.com/`
    parses with hostname "good.com", which is correct, and netloc would
    have carried the decoration.
    """
    if not expected:
        return True
    try:
        here = (urlparse(getattr(context, "url", "") or "").hostname or "").lower()
    except ValueError:
        return False
    here = here.removeprefix("www.")
    want = expected.strip().lower().removeprefix("www.")
    if not here or not want:
        return False
    return here == want or here.endswith("." + want)


async def _cmd_fill_ref(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    raw_ref = str(args.get("ref") or "").strip()
    value = args.get("value")
    if not raw_ref:
        return {"ok": False, "error": "missing_ref"}
    if value is None:
        return {"ok": False, "error": "missing_value"}
    # Remember what we are about to type so the recorder can scrub it out of
    # any request body. Recorded on ATTEMPT, not on success: a fill that fails
    # its readback may still have put characters in the field, and a later
    # submit would carry them. Over-redacting is safe; under-redacting leaks.
    if len(str(value)) >= _SCRUB_MIN_LEN:
        state._typed_secrets.add(str(value))
    ref = raw_ref if raw_ref.startswith("@") else "@" + raw_ref
    page, snap = await state.require_page()

    expected = str(args.get("expect_host") or "").strip().lower()
    entry = snap.ref_map.get(ref)
    if not entry or not entry.get("selector"):
        return {"ok": False, "error": "ref_not_found"}
    selector = str(entry["selector"])
    ctx = _ref_context(page, snap, ref)
    if ctx is None:
        return {
            "ok": False,
            "error": "frame_detached",
            "detail": "that iframe is gone — take browser_snapshot again",
        }
    # Fail-closed for a STORED credential, and only for that.
    #
    # The first version required a host for any password-typed field, which
    # broke two real callers at once: the Brain's `browser_fill_ref` (which
    # never passed one) and, worse, signup — where the password being typed
    # is one Rokan just generated and no stored host exists yet. A guard
    # that stops the product signing anyone up is not a safe default.
    #
    # The narrow rule is the right one: a credential being REPLAYED from a
    # store is the thing a moved page can steal, and the caller replaying it
    # always knows which host it belongs to.
    if args.get("stored_credential") and not expected:
        return {
            "ok": False,
            "error": "expect_host_required",
            "detail": "replaying a stored credential must state its host",
        }
    if not _origin_matches(ctx, expected):
        return {
            "ok": False,
            "error": "fill_origin_refused",
            "detail": "the field is not in a document on the expected site",
        }
    # Native <select> (Gap 4): route to select_option — fill()/keystrokes
    # cannot set a select, and a click would open the undrivable
    # OS-rendered dropdown.
    if str(entry.get("role") or "") == "select":
        return await _fill_select(page, ctx, selector, str(value))
    resolved, recovered = await _resolve_ref_selector(ctx, entry)
    if resolved is None:
        return _ref_gone_result(page, snap)
    selector = resolved
    pre_fp = await _fingerprint(page)
    # E2 (2026-06-10): fast path = locator.fill() for plain text-ish
    # inputs, with MANDATORY value readback — fill() is ~20x faster than
    # per-char keystrokes. React/Vue controlled inputs ignore fill() (it
    # sets .value without the keydown/input events the framework listens
    # for — Resend's signup is exactly this), so an empty/mismatched
    # readback falls back to the proven click→clear→type keystroke path.
    # password + unknown types go STRAIGHT to keystrokes (a password
    # readback would put the secret through one more code path for no
    # win, and validated fields want real key events).
    fast_types = {"text", "email", "search", "url", "tel", "number", ""}
    input_type = str(entry.get("input_type") or "").lower()
    # Checked again HERE, on the last line before anything is typed.
    #
    # Between the check above and this point sit a selector resolution, a
    # multi-frame fingerprint, and — below — a `locator.click` that AUTO-WAITS,
    # which is precisely what lets a navigation arriving in that window make
    # the element resolve. A check two awaits early is a check about a
    # document that may no longer be there.
    if not _origin_matches(ctx, expected):
        return {
            "ok": False,
            "error": "fill_origin_refused",
            "detail": "the document moved before anything was typed",
        }
    try:
        locator = ctx.locator(selector).first
        await locator.scroll_into_view_if_needed(timeout=3_000)
        filled_fast = False
        if input_type in fast_types:
            try:
                await locator.fill(str(value), timeout=3_000)
                readback = await locator.input_value(timeout=1_000)
                filled_fast = readback == str(value)
            except Exception:  # noqa: BLE001 — fall back to keystrokes
                filled_fast = False
        if not filled_fast:
            await locator.click(timeout=5_000)
            try:
                await locator.fill("", timeout=3_000)  # clear prior value
            except Exception:  # noqa: BLE001 — clearing is best-effort
                pass
            await page.keyboard.type(str(value), delay=25)
    except Exception as exc:
        return {
            "ok": False,
            "error": "fill_origin_refused"
            if "origin" in str(exc).lower()
            else "fill_failed",
            "detail": type(exc).__name__,
        }

    # AFTER the write, on the same context, before anything is reported.
    #
    # A pre-check cannot be made atomic with a keystroke — Playwright types
    # into whatever is focused, and `locator.click` auto-waits, which is
    # precisely what lets a navigation land inside the window. Four review
    # rounds moved this check closer to the write and each time it was still
    # one indirection away, so the honest move is to stop pretending the
    # window can be closed and to DETECT it instead.
    #
    # If the document moved while a stored credential was going in, the
    # keystrokes cannot be recalled. What can be done is refuse to report
    # success and say plainly that the secret may have gone somewhere else,
    # so the person can rotate it. Silent is the part that is unacceptable;
    # a bounded, disclosed risk is survivable.
    if not _origin_matches(ctx, expected):
        return {
            "ok": False,
            "error": "fill_origin_moved_mid_write",
            "detail": (
                "the page moved while this was being typed — treat the value "
                "as exposed and change it"
            ),
        }
    # W5: dom_changed after a fill catches instant validation errors
    # (an error label appearing IS a DOM change beyond the typed value).
    post_fp = await _fingerprint(page)
    dom_changed: bool | None = None
    if pre_fp is not None and post_fp is not None:
        dom_changed = pre_fp != post_fp
    return {"ok": True, "dom_changed": dom_changed, "ref_recovered": recovered}


async def _cmd_set_files(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """Attach file(s) to an <input type=file> by ref (Gap 5).

    The filechooser listener already suppresses the native OS picker (no
    hang); this verb is how an upload actually COMPLETES —
    ``set_input_files`` works directly on the input, hidden or not.
    Files are confined to ``ROKAN_BROWSER_UPLOAD_DIR``: relative names
    only, resolved + prefix-checked, so the agent can never reach the
    wider filesystem. Fail closed when the dir isn't configured.
    """
    raw_ref = str(args.get("ref") or "").strip()
    if not raw_ref:
        return {"ok": False, "error": "missing_ref"}
    ref = raw_ref if raw_ref.startswith("@") else "@" + raw_ref
    raw_paths = args.get("paths")
    if isinstance(raw_paths, str):
        raw_paths = [raw_paths]
    if not isinstance(raw_paths, list) or not raw_paths:
        return {"ok": False, "error": "missing_paths"}
    if len(raw_paths) > 5:
        return {"ok": False, "error": "too_many_files", "detail": "max 5"}
    upload_root = os.environ.get("ROKAN_BROWSER_UPLOAD_DIR", "").strip()
    if not upload_root:
        return {
            "ok": False,
            "error": "uploads_disabled",
            "detail": "ROKAN_BROWSER_UPLOAD_DIR is not configured",
        }
    root = Path(upload_root).resolve()
    paths: list[str] = []
    total_bytes = 0
    for rp in raw_paths:
        p = (root / str(rp)).resolve()
        if p == root or not p.is_relative_to(root):
            return {
                "ok": False,
                "error": "path_outside_upload_dir",
                "detail": str(rp)[:80],
            }
        if not p.is_file():
            return {
                "ok": False,
                "error": "file_not_found",
                "detail": str(rp)[:80],
            }
        total_bytes += p.stat().st_size
        paths.append(str(p))
    if total_bytes > 25 * 1024 * 1024:
        return {"ok": False, "error": "files_too_large", "detail": "max 25MB total"}
    page, snap = await state.require_page()
    entry = snap.ref_map.get(ref)
    if not entry or not entry.get("selector"):
        return {"ok": False, "error": "ref_not_found"}
    if str(entry.get("input_type") or "").lower() != "file":
        return {
            "ok": False,
            "error": "not_a_file_input",
            "detail": (
                f"ref {ref} is {entry.get('role') or '?'}"
                f"/{entry.get('input_type') or 'text'} — set_files only "
                "works on <input type=file>"
            ),
        }
    ctx = _ref_context(page, snap, ref)
    if ctx is None:
        return {
            "ok": False,
            "error": "frame_detached",
            "detail": "that iframe is gone — take browser_snapshot again",
        }
    pre_fp = await _fingerprint(page)
    try:
        locator = ctx.locator(str(entry["selector"])).first
        await locator.set_input_files(paths, timeout=5_000)
    except Exception as exc:
        return {
            "ok": False,
            "error": "set_files_failed",
            "detail": type(exc).__name__,
        }
    post_fp = await _fingerprint(page)
    dom_changed: bool | None = None
    if pre_fp is not None and post_fp is not None:
        dom_changed = pre_fp != post_fp
    return {
        "ok": True,
        "attached": [Path(p).name for p in paths],
        "dom_changed": dom_changed,
    }


async def _cmd_type(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    text = args.get("text")
    if not isinstance(text, str) or not text:
        return {"ok": False, "error": "missing_text"}
    # Same rule as fill_ref: anything typed into the page is a candidate
    # secret and must be scrubbable out of a captured request body.
    if len(text) >= _SCRUB_MIN_LEN:
        state._typed_secrets.add(text)
    page, snap = await state.require_page()
    pre_url = page.url or ""
    pre_fp = await _fingerprint(page)
    known_tabs = {tid for tid, _ in state.pages}
    try:
        await page.keyboard.type(text, delay=10)
    except Exception as exc:
        return {
            "ok": False,
            "error": "type_failed",
            "detail": type(exc).__name__,
        }
    if "\n" in text or "\r" in text:
        # A newline is Enter, and Enter submits whatever is focused — a
        # navigation as surely as a click. Settle and report the full W5
        # (url_changed / new_tab too), exactly as click_ref does; the
        # one-field report used to hide a search that had just run
        # (2026-08-25, the 30-task general set).
        await _settle_after_click(page, pre_url)
        return await _post_action_report(
            state, snap, pre_url=pre_url, pre_fp=pre_fp, known_tabs=known_tabs
        )
    post_fp = await _fingerprint(page)
    dom_changed: bool | None = None
    if pre_fp is not None and post_fp is not None:
        dom_changed = pre_fp != post_fp
    return {"ok": True, "dom_changed": dom_changed}


async def _cmd_screenshot(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    import base64

    page, _snap = await state.require_page()
    try:
        png = await page.screenshot(type="png", full_page=False)
    except Exception as exc:
        return {
            "ok": False,
            "error": "screenshot_failed",
            "detail": type(exc).__name__,
        }
    return {
        "ok": True,
        "png_b64": base64.standard_b64encode(png).decode("ascii"),
        "url": page.url,
    }


async def _cmd_get_text(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """Return the page's text — INCLUDING its visible child frames.

    Used by the smoke test to verify cookie persistence by observing
    httpbin's echoed JSON body. Capped at 32KiB so a giant page can't
    blow the socket buffer.

    The frames matter. `snapshot` has walked child frames since the
    iframe work, so the EXECUTOR could always act on a form inside an
    iframe — but this returned `document.body.innerText` of the main
    frame alone, so the PLANNER, which reads ranked lines of this text,
    saw nothing. Measured on browser-use's own iframe stress test
    (2026-08-27): the snapshot listed the whole form, `get_text`
    returned fourteen characters, and the plan that followed named a
    button that was not on the page. Same frame list and the same
    visibility rule as the snapshot, so the two agree about what the
    page says.
    """
    page, _snap = await state.require_page()
    try:
        text = await page.evaluate(
            "() => (document.body && document.body.innerText) || ''"
        )
    except Exception as exc:
        return {
            "ok": False,
            "error": "get_text_failed",
            "detail": type(exc).__name__,
        }
    text_str = str(text or "")
    for frame, label in await _candidate_frames(page):
        try:
            inner = await frame.evaluate(
                "() => (document.body && document.body.innerText) || ''"
            )
        except Exception:  # noqa: BLE001 — a frame can detach mid-read
            continue
        inner_str = str(inner or "").strip()
        if inner_str:
            heading = f"-- inside iframe {label!r} --" if label else "-- inside iframe --"
            text_str = f"{text_str}\n{heading}\n{inner_str}"
    truncated = len(text_str) > 32_000
    # Where the page repeats itself. Best-effort: a page that refuses to
    # run the walk still returns its text, and the reader falls back to
    # the blank-line rule it used before this existed.
    # ONLY when asked. Every caller of `get_text` used to be handed this,
    # including the agent loop, whose tool output is model context — a
    # thirty-row page arrived as a second copy of itself and the gauntlet
    # went from 8 tool calls to 13 (2026-08-27). It also skips the DOM walk
    # for every caller that has no use for it.
    collections: list[dict[str, Any]] = []
    if not args.get("collections"):
        return {
            "ok": True,
            "url": page.url,
            "collections": collections,
            "text": text_str[:32_000],
            "truncated": truncated,
        }
    try:
        raw = await asyncio.wait_for(page.evaluate(_COLLECTIONS_JS), timeout=3.0)
        for group in raw or []:
            if not isinstance(group, dict):
                continue
            units = [
                [str(c) for c in unit if str(c).strip()]
                for unit in (group.get("units") or [])
                if isinstance(unit, list)
            ]
            units = [u for u in units if u]
            if len(units) >= 3:
                collections.append(
                    {"units": units, "heading": str(group.get("heading") or "")[:120]}
                )
    except Exception:  # noqa: BLE001 — a fence is an optimisation, never a gate
        collections = []
    return {
        "ok": True,
        "url": page.url,
        "collections": collections,
        "text": text_str[:32_000],
        "truncated": truncated,
    }


async def _cmd_find_line(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """Find the line carrying a marker, in the WHOLE page, and return it.

    `get_text` caps at 32 KiB so a giant page cannot blow the socket
    buffer, and that cap is right — but it makes a value further down
    unreachable rather than merely unshipped. Measured on curl's manual
    page: 263,039 characters rendered, the answer at 114,269, and the run
    reported "not on the page" about a page that says it plainly.

    So the search happens where the page is. What comes back is bounded by
    construction — the matching lines, capped, plus how many there were —
    which is what the caller needs to decide both "what does it say" and
    "is this anchor ambiguous", without shipping a quarter of a megabyte
    through a socket or into a prompt.
    """
    marker = str(args.get("contains") or "").strip()
    if not marker:
        return {"ok": False, "error": "missing_contains"}
    page, _snap = await state.require_page()
    try:
        found = await page.evaluate(
            """(marker) => {
                const text = (document.body && document.body.innerText) || '';
                // One kind of space on both sides. A page may hold a
                // NON-BREAKING space where the caller typed an ordinary
                // one — measured on nodejs.org, whose answer line is
                // `Type: <integer>\\u00a0Default: 65536` — and a caller
                // that quotes the page faithfully would otherwise find
                // nothing. The client flattens for its own search; this is
                // the same rule where the whole page is.
                const flat = (s) => s
                    .replace(/[\\u00a0\\u1680\\u2000-\\u200b\\u202f\\u205f\\u3000\\ufeff]/g, ' ')
                    .replace(/\\s+/g, ' ')
                    .trim()
                    .toLowerCase();
                const needle = flat(marker);
                const hits = [];
                let total = 0;
                for (const line of text.split('\\n')) {
                    if (flat(line).includes(needle)) {
                        total += 1;
                        if (hits.length < 8) hits.push(line.trim());
                    }
                }
                return {lines: hits, total: total, length: text.length};
            }""",
            marker,
        )
    except Exception as exc:
        return {"ok": False, "error": "find_line_failed", "detail": type(exc).__name__}
    payload = found if isinstance(found, dict) else {}
    return {
        "ok": True,
        "url": page.url,
        "lines": [str(x)[:400] for x in (payload.get("lines") or [])],
        "total": int(payload.get("total") or 0),
        "page_length": int(payload.get("length") or 0),
    }

async def _cmd_relevant_lines(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """The lines of the WHOLE page that could carry the asked-for value.

    Three measurements produced this, in order:

    * a planner shown no page writes anchors from paraphrase — blind 0/10
      against informed 5/10 on real sites, model held fixed;
    * a planner shown the whole page anchors on whatever is prominent
      rather than what was asked, which cost two fixture tasks;
    * a planner shown the first 30 KiB of a long page is shown the wrong
      part — on curl's manual and on docs.python.org the answer sits past
      the cap entirely.

    So: filtered where the page is, to lines that carry a value AND share
    a word with the task, capped. Validated offline against twelve real
    pages before this existed — the answer survives on ten of twelve, and
    the two it misses are the truncated ones this searches past.

    `words` are the caller's content words. `limit` bounds the reply, so a
    263 KB document costs the same as a small one.
    """
    words = [str(w).lower() for w in (args.get("words") or []) if str(w).strip()]
    limit = max(1, min(int(args.get("limit") or 40), 200))
    # "flat" is the pre-2026-08-25 scorer, kept ONLY as the control arm for
    # measurement. Never the default: it counts task words, unweighted, and
    # breaks ties by document order — so when the answer line scores 2 and
    # so do forty navigation lines, the answer is buried below the planner's
    # 2,000-char window. Measured offline on the 34-set: answer-in-window
    # 24/33 flat vs 31/33 BM25 + heading inheritance (0 model calls).
    scorer = "flat" if str(args.get("scorer") or "") == "flat" else "bm25"
    page, _snap = await state.require_page()
    try:
        found = await page.evaluate(
            """([words, limit, scorer]) => {
                const text = (document.body && document.body.innerText) || '';
                const valueish = /\\d|\\b(?:operational|enabled|disabled|active|yes|no)\\b/i;
                const tok = (s) => (s.toLowerCase().match(/[a-z0-9_]+/g) || []);
                // Headings, with their offsets in innerText, so a value line
                // inherits the heading it sits under: "Default: 8192" says
                // nothing; under "buffer.poolSize" it answers the question.
                const heads = [];
                let pos = 0;
                const t0 = performance.now();
                for (const h of document.querySelectorAll('h1,h2,h3,h4,h5,h6')) {
                    // A heading inside navigation (a TOC, a sidebar) is a
                    // LINK to a section, and its text appears before the
                    // section's own heading — binding to it mis-anchors
                    // every line that follows (Opus round 5, b).
                    if (h.closest('nav, aside, [role=navigation], header')) continue;
                    const t = ((h.innerText || '') + '').trim();
                    if (!t) continue;
                    const at = text.indexOf(t, pos);
                    if (at < 0) continue;
                    heads.push([at, t.slice(0, 80)]);
                    pos = at + t.length;
                }
                const cands = [];
                let off = 0, seen = 0, hi = 0;
                for (const raw of text.split('\\n')) {
                    const start = off;
                    off += raw.length + 1;
                    const line = raw.trim();
                    if (!line || !valueish.test(line)) continue;
                    seen += 1;
                    while (hi < heads.length && heads[hi][0] <= start) hi++;
                    const heading = hi > 0 ? heads[hi - 1][1] : '';
                    cands.push({line: line.slice(0, 300), low: line.toLowerCase(),
                                toks: tok(line + ' ' + heading), order: cands.length});
                }
                let ranked;
                if (scorer === 'flat' || !words.length) {
                    ranked = [];
                    for (const c of cands) {
                        let score = 0;
                        for (const w of words) if (c.low.includes(w)) score += 1;
                        if (words.length && !score) continue;
                        ranked.push([score, c]);
                    }
                    ranked.sort((a, b) => b[0] - a[0] || a[1].order - b[1].order);
                } else {
                    // BM25 with substring term matching (the planner's words
                    // are stems of what the page says: "redirect" vs
                    // "redirects"), IDF over the candidate lines, length
                    // normalisation. No hard "must contain a word" rule — a
                    // line under the right heading can carry no task word
                    // and still be the answer.
                    const N = cands.length || 1;
                    let total = 0;
                    for (const c of cands) total += c.toks.length;
                    const avgdl = total / N || 1;
                    const df = {};
                    for (const w of words) {
                        let n = 0;
                        for (const c of cands) if (c.toks.some(x => x.includes(w))) n += 1;
                        df[w] = n;
                    }
                    const k1 = 1.2, b = 0.75;
                    ranked = [];
                    for (const c of cands) {
                        const dl = c.toks.length || 1;
                        let score = 0;
                        for (const w of words) {
                            let f = 0;
                            for (const x of c.toks) if (x.includes(w)) f += 1;
                            if (!f) continue;
                            const n = df[w];
                            const idf = Math.log(1 + (N - n + 0.5) / (n + 0.5));
                            score += idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * dl / avgdl));
                        }
                        // A line that shares nothing with the task — not a
                        // word, not its heading — is filler, and forty lines
                        // of filler is the whole document again, which is
                        // the failure this command exists to avoid.
                        if (score > 0) ranked.push([score, c]);
                    }
                    ranked.sort((a, b) => b[0] - a[0] || a[1].order - b[1].order);
                }
                return {
                    lines: ranked.slice(0, limit).map(r => r[1].line),
                    considered: seen,
                    length: text.length,
                    elapsed_ms: Math.round(performance.now() - t0),
                };
            }""",
            [words, limit, scorer],
        )
    except Exception as exc:
        return {
            "ok": False,
            "error": "relevant_lines_failed",
            "detail": type(exc).__name__,
        }
    payload = found if isinstance(found, dict) else {}
    return {
        "ok": True,
        "url": page.url,
        "lines": [str(x) for x in (payload.get("lines") or [])],
        "considered": int(payload.get("considered") or 0),
        "page_length": int(payload.get("length") or 0),
        # The ranker's OWN cost, so a slower median downstream is never
        # attributed to it by inference (Opus round 5, c).
        "elapsed_ms": int(payload.get("elapsed_ms") or 0),
    }

#: How long one session_fetch may hold the daemon.
#:
#: Genuinely shorter than the client's own patience, which the previous
#: comment claimed and the number contradicted: 10.0 with a +2.0 wrapper is
#: a 12s ceiling against a caller (`rokan_do.fastpath.FAST_TIMEOUT_S`) that
#: gives up at 8, so the daemon held its GLOBAL state lock for four seconds
#: after the only party waiting had left, and every other task on that host
#: queued behind it.
#:
#: Six, so the +2.0 wrapper lands at 8 — the caller's own limit, reached at
#: the same moment rather than after.
_SESSION_FETCH_BUDGET_S = 6.0


async def _cmd_session_fetch(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """Fetch one URL from inside the page, using the page's own session.

    This is the synthetic-API verb: once a compiled operation knows which
    endpoint fed a page, later runs ask that endpoint directly instead of
    rendering anything. The request goes through the page so the browser's
    own cookies apply — no credential is ever copied out of the session and
    into a client.

    Deliberately NOT a general `evaluate` verb. An arbitrary-JS command in a
    process that holds live logged-in sessions is a standing invitation: any
    caller, or anything that can influence a caller, could read storage,
    exfiltrate cookies, or drive the page. This verb takes a URL and returns
    a body — the narrowest thing that makes compiled operations possible.

    Three rules, each learned rather than assumed:

    * **The caller must state the host it expects**, and a mismatch is
      refused BEFORE anything is navigated. The URL originates in recorded
      traffic, which includes CDNs, analytics and embedded widgets; an
      earlier version navigated first and checked second, which meant a
      compiled operation naming a third party would drive a browser full of
      live sessions to that third party's root before deciding it was not
      allowed.
    * **The origin check happens inside the page**, atomically with the
      fetch. Checking from here and evaluating afterwards leaves a window in
      which a meta-refresh or SPA route change moves the document.
    * **Redirects are errors, not journeys.** An open redirect on the target
      host would otherwise turn a passing same-origin check into an
      off-origin request carrying the page's cookies and Referer.
    """
    from urllib.parse import urlparse

    url = str(args.get("url", "") or "")
    expected = str(args.get("expect_host", "") or "").lower()
    if not url.lower().startswith(("http://", "https://")):
        return {"ok": False, "error": "invalid_url", "detail": "absolute http(s) only"}
    wanted = urlparse(url)
    if not expected:
        return {
            "ok": False,
            "error": "expect_host_required",
            "detail": "the caller must state which host this call is for",
        }
    if wanted.netloc.lower() != expected:
        return {
            "ok": False,
            "error": "cross_origin_refused",
            "detail": f"expected {expected}, url was {wanted.netloc}",
        }

    page, _snap = await state.require_page()
    current = urlparse(page.url or "")
    if current.netloc.lower() != wanted.netloc.lower():
        # `fetch` sends the cookies of the page it runs IN. After a completed
        # task the daemon's page is about:blank, whose origin has no cookies
        # at all — measured: the request came back with the sign-in page.
        # Safe to navigate now: the target has already been proven to be the
        # host the caller asked for.
        try:
            await page.goto(f"{wanted.scheme}://{wanted.netloc}/", wait_until="commit")
        except Exception as exc:
            return {
                "ok": False,
                "error": "session_fetch_failed",
                "detail": type(exc).__name__,
            }

    try:
        # Bounded on BOTH sides, and it needs to be.
        #
        # `page.evaluate` takes no timeout and is not governed by
        # `set_default_timeout` (only methods that accept the option are), so
        # this was the one unbounded browser await in the file — and
        # `_dispatch` holds the global state lock for the whole handler. A
        # compiled endpoint that accepts the connection and never answers (an
        # SSE route, a server incident) therefore parked the daemon's lock
        # for the full ten-minute idle timeout, and every task on that host
        # failed meanwhile. The caller's own 8s budget protects the CALLER,
        # not the daemon they share.
        #
        # The AbortSignal settles the page-side promise; the wait_for settles
        # ours if the page itself has stopped answering.
        result = await asyncio.wait_for(
            page.evaluate(
                """async ([target, expectedHost, budgetMs]) => {
                const u = new URL(target, location.href);
                // Checked HERE so the comparison and the fetch cannot be
                // separated by a navigation.
                if (u.host !== expectedHost || u.origin !== location.origin) {
                    return {refused: 'origin_moved'};
                }
                const r = await fetch(u.href, {
                    credentials: 'include',
                    redirect: 'error',
                    headers: {'Accept': 'application/json'},
                    signal: AbortSignal.timeout(budgetMs),
                });
                const body = await r.text();
                // Two megabytes, and the caller is TOLD when it was cut.
                // At 200 KB a real API response arrives sliced through the
                // middle of its JSON, which no parser can read — measured
                // on crates.io, whose crate document is 441 KB, so the one
                // route that reaches an Ember app's data could never
                // compile (2026-08-26). A body this size is a local socket
                // read, not a network cost.
                return {
                    status: r.status,
                    body: body.slice(0, 2000000),
                    truncated: body.length > 2000000,
                };
            }""",
                [url, expected, int(_SESSION_FETCH_BUDGET_S * 1000)],
            ),
            timeout=_SESSION_FETCH_BUDGET_S + 2.0,
        )
    except TimeoutError:
        return {
            "ok": False,
            "error": "session_fetch_timeout",
            "detail": f"no answer within {_SESSION_FETCH_BUDGET_S:.0f}s",
        }
    except Exception as exc:
        return {
            "ok": False,
            "error": "session_fetch_failed",
            "detail": type(exc).__name__,
        }
    if not isinstance(result, dict):
        return {"ok": False, "error": "session_fetch_failed", "detail": "no result"}
    if result.get("refused"):
        # NOT `cross_origin_refused`: that name belongs to the check above,
        # which fires when the CALLER built a bad request. This one fires
        # when the page's own origin is no longer the origin the operation
        # was learned against — an apex that now redirects to www, a host
        # that upgraded to https, an API split onto its own domain. That is
        # the SITE changing, and the caller must be able to tell the two
        # apart: one means "fix your code", the other means "this compiled
        # shortcut is stale and must be thrown away".
        return {
            "ok": False,
            "error": "origin_moved",
            "detail": str(result.get("refused")),
        }
    return {
        "ok": True,
        "status": int(result.get("status", 0) or 0),
        "body": str(result.get("body", "") or ""),
        "url": url,
    }


# --------------------------------------------------------------------------
# Tab verbs (W1) — list / switch / close
# --------------------------------------------------------------------------


async def _cmd_list_tabs(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    await state.ensure_browser()
    tabs: list[dict[str, Any]] = []
    for tid, page in state.pages:
        try:
            title = await page.title()
        except Exception:  # noqa: BLE001
            title = ""
        tabs.append(
            {
                "tab_id": tid,
                "url": page.url or "",
                "title": title or "",
                "active": tid == state.active_tab_id,
            }
        )
    return {"ok": True, "tabs": tabs}


async def _cmd_switch_tab(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    try:
        tab_id = int(args.get("tab_id"))  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return {"ok": False, "error": "bad_tab_id"}
    await state.ensure_browser()
    for tid, page in state.pages:
        if tid == tab_id:
            state.active_tab_id = tid
            try:
                await page.bring_to_front()
            except Exception:  # noqa: BLE001 — cosmetic in headless
                pass
            try:
                title = await page.title()
            except Exception:  # noqa: BLE001
                title = ""
            return {
                "ok": True,
                "active_url": page.url or "",
                "title": title or "",
                # Refs are per-tab; the switched-to tab needs a fresh
                # snapshot before any click — tell the caller loudly.
                "ref_stale": True,
            }
    return {"ok": False, "error": "tab_not_found"}


async def _cmd_close_tab(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    try:
        tab_id = int(args.get("tab_id"))  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return {"ok": False, "error": "bad_tab_id"}
    await state.ensure_browser()
    if len(state.pages) <= 1:
        # Never close the last tab — the mission would lose its browser.
        return {"ok": False, "error": "last_tab"}
    for tid, page in state.pages:
        if tid == tab_id:
            try:
                await page.close()
            except Exception as exc:  # noqa: BLE001
                return {
                    "ok": False,
                    "error": "close_failed",
                    "detail": type(exc).__name__,
                }
            state._closed_tab_ids.add(tid)
            state.sweep_closed()
            active = state.active_page()
            return {
                "ok": True,
                "active_url": (active.url if active is not None else "") or "",
            }
    return {"ok": False, "error": "tab_not_found"}


async def _cmd_ping(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """Cheap health probe — does NOT open the browser."""
    return {
        "ok": True,
        "mission_id": state.mission_id,
        # So the UI can say "running headless (no display)" honestly.
        "effective_headless": _effective_headless(),
    }


# --------------------------------------------------------------------------
# WebMCP (Tier 0) — consume a page's OWN declared tools over the CDP WebMCP
# domain, never the DOM. `rokan do` prefers these when a site ships them;
# see ~/dev/webmcp-private/docs/EXECUTION-PLAN.md §1 and
# docs/measurements/2026-08-29-tier0.md. The verbs list and invoke; the
# read/write policy and any verification live in rokan-do, not here.
# --------------------------------------------------------------------------

WEBMCP_QUIET_MS = 3000
WEBMCP_INVOKE_TIMEOUT_MS = 10000


async def _webmcp_session_on(
    page: Any, url: str, *, reload: bool
) -> tuple[Any, list[dict[str, Any]], str]:
    """Attach a CDP session, enable WebMCP, land on `url`, and collect the tools
    the page registers. Returns (cdp_session, tools, landed). `landed` is False
    when navigation failed OR the page did not end on the requested host — the
    caller must NOT return the tools of whatever page was already open (this
    daemon runs the user's real `channel=chrome` profile). `reload=True` forces
    a fresh load (list wants fresh tools); `reload=False` reuses the already
    loaded page (invoke, so a composed step does not wipe client-side state and
    does not pay a second navigation under the global lock).
    """
    ctx = page.context
    cdp = await ctx.new_cdp_session(page)
    # Deduplicate by name, LAST occurrence wins: `WebMCP.enable` replays tools
    # already registered, and a reload re-registers them with a FRESH frameId —
    # invoking with the stale (pre-reload) frameId gets no response.
    seen: dict[str, dict[str, Any]] = {}
    order: list[str] = []

    def _on_added(params: dict[str, Any]) -> None:
        for tool in params.get("tools", []) or []:
            name = tool.get("name")
            if not name:
                continue
            if name not in seen:
                order.append(name)
            seen[name] = tool

    cdp.on("WebMCP.toolsAdded", _on_added)
    try:
        await cdp.send("WebMCP.enable")
    except Exception:  # noqa: BLE001 — no WebMCP domain here: honestly "no tools"
        try:
            await cdp.detach()
        except Exception:  # noqa: BLE001
            pass
        return None, [], "no_webmcp"
    cur = (page.url or "").split("#", 1)[0].rstrip("/")
    target = url.split("#", 1)[0].rstrip("/")
    on_target = bool(cur) and cur == target
    nav_ok = True
    try:
        if on_target and not reload:
            pass  # reuse the loaded page (invoke): keeps in-page state
        elif on_target:
            await page.reload(wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS)
        else:
            await page.goto(url, wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS)
    except Exception:  # noqa: BLE001 — a nav failure must NOT return the open page's tools
        nav_ok = False
    # Host guard: a failed nav, or a redirect away from the requested host,
    # leaves us on some OTHER page (the user's tabs). Never surface its tools.
    landed = nav_ok and _registrable(_host_of(page.url)) == _registrable(_host_of(url))
    if not landed:
        return cdp, [], "nav_failed"
    # Settle until a tool arrives or the page goes quiet. A minimum dwell lets
    # a post-reload re-registration land so `seen` holds live frameIds.
    waited = 0
    step = 100
    while waited < WEBMCP_QUIET_MS:
        await asyncio.sleep(step / 1000)
        waited += step
        if seen and waited >= 800:
            break
    return cdp, [seen[n] for n in order], "ok"


async def _cmd_webmcp_list(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """List a page's native WebMCP tools (name/description/inputSchema/
    annotations). 0 model calls; DOM never read. On a navigation failure or a
    host mismatch, returns an error — NEVER the tools of the open page."""
    url = str(args.get("url") or "").strip()
    if not url.lower().startswith(("http://", "https://")):
        return {"ok": False, "error": "bad_url_scheme"}
    page, _snap = await state.require_page()
    cdp, tools, status = await _webmcp_session_on(page, url, reload=True)
    try:
        if status == "nav_failed":
            return {"ok": False, "error": "navigation_failed", "url": url}
        out = [
            {
                "name": t.get("name"),
                "description": t.get("description"),
                "inputSchema": t.get("inputSchema"),
                "annotations": t.get("annotations") or {},
            }
            for t in tools
            if t.get("name")
        ]
    finally:
        if cdp is not None:
            try:
                await cdp.detach()
            except Exception:  # noqa: BLE001 — detach is best-effort
                pass
    return {"ok": True, "url": page.url, "tools": out, "count": len(out)}


async def _cmd_webmcp_invoke(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """Invoke one native WebMCP tool by name. Reuses the already-loaded page (no
    re-navigation, so a composed step keeps client-side state and does not pay a
    second nav under the lock). Returns the tool's own output, never a page
    render. Read/write policy is the caller's (rokan-do)."""
    url = str(args.get("url") or "").strip()
    tool = str(args.get("tool") or "").strip()
    tool_input = args.get("input") or {}
    if not url.lower().startswith(("http://", "https://")):
        return {"ok": False, "error": "bad_url_scheme"}
    if not tool:
        return {"ok": False, "error": "missing_tool"}
    page, _snap = await state.require_page()
    cdp, tools, status = await _webmcp_session_on(page, url, reload=False)
    try:
        if status == "nav_failed":
            return {"ok": False, "error": "navigation_failed", "url": url}
        match = next((t for t in tools if t.get("name") == tool), None)
        if match is None:
            return {"ok": False, "error": "tool_not_found", "detail": tool[:64]}
        frame_id = match.get("frameId")
        began = time.monotonic()
        # Buffer EVERY toolResponded; correlate afterwards. A page can invoke its
        # own tools (our "Try as agent" does), so a foreign response — or one
        # from an earlier in-flight call — can arrive. We ignore anything that
        # landed before our invokeTool (index < baseline) and then match the
        # invocationId invokeTool returned; if the browser reports no id, we take
        # the first response that arrived after our call.
        inbox: list[dict[str, Any]] = []
        cdp.on("WebMCP.toolResponded", lambda p: inbox.append(p))
        baseline = len(inbox)
        try:
            # The CDP WebMCP domain takes `input` as an OBJECT (our Node CDP
            # harness passes it directly); a JSON string yields no response.
            sent = await cdp.send(
                "WebMCP.invokeTool",
                {"frameId": frame_id, "toolName": tool, "input": tool_input},
            )
            want_id = sent.get("invocationId") if isinstance(sent, dict) else None
        except Exception as exc:  # noqa: BLE001 — a CDP refusal is a tool error, not a crash
            return {"ok": False, "error": "invoke_refused", "detail": type(exc).__name__}

        def _match() -> dict[str, Any] | None:
            for p in inbox[baseline:]:
                if want_id is None or p.get("invocationId") in (None, want_id):
                    return p
            return None

        waited = 0
        responded = _match()
        while responded is None and waited < WEBMCP_INVOKE_TIMEOUT_MS:
            await asyncio.sleep(0.02)
            waited += 20
            responded = _match()
        elapsed_ms = int((time.monotonic() - began) * 1000)
        if responded is None:
            return {"ok": False, "error": "no_response", "elapsed_ms": elapsed_ms}
        resp_status = responded.get("status")
        return {
            "ok": resp_status == "Completed",
            "status": resp_status,
            "output": responded.get("output"),
            "elapsed_ms": elapsed_ms,
        }
    finally:
        if cdp is not None:
            try:
                await cdp.detach()
            except Exception:  # noqa: BLE001 — detach is best-effort
                pass


async def _cmd_set_headless(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """Escape hatch that REFUSES (3A): headless/headed is spawn-time only.

    A mid-session relaunch would wipe DOM, tabs, and in-page state — the
    cardinal sin this daemon exists to prevent. Finish (or kill) the
    mission and start the next one with the new setting instead.
    """
    return {
        "ok": False,
        "error": "headless_locked_at_spawn",
        "detail": (
            "headless/headed is decided when the browser launches; "
            "changing it now would relaunch and RESET all page/tab "
            "state. Start the next mission with "
            "ROKAN_BROWSER_HEADLESS / settings.browser_headless instead."
        ),
        "effective_headless": _effective_headless(),
    }


async def _cmd_record_start(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """Begin recording every response on every tracked page.

    Idempotent-ish: starting again clears the previous buffer, because a
    half-finished recording merged into a new one produces a session that
    describes no single task.
    """
    await state.ensure_browser()
    state.recorded = []
    state.record_dropped = 0
    state._record_seq = 0
    state.record_t0 = time.monotonic()
    state.recording = True
    return {"ok": True, "recording": True}


#: Most a `record_stop` reply may weigh. Two orders of magnitude under the
#: socket reader's 32 MB, and far more than any caller reads.
_RECORD_REPLY_BUDGET = 4 * 1024 * 1024


async def _cmd_record_stop(state: DaemonState, args: dict[str, Any]) -> dict[str, Any]:
    """Stop recording and return the session.

    ``rendered_text`` is captured here rather than by the caller so that
    the page text and the response set describe the same instant — the
    scorer compares them, and a page that navigated in between would make
    every overlap score meaningless.
    """
    state.recording = False
    responses = state.recorded
    state.recorded = []
    page = state.active_page()
    rendered_text = ""
    page_url = ""
    if page is not None:
        page_url = str(getattr(page, "url", "") or "")
        try:
            rendered_text = str(
                await page.evaluate("() => (document.body && document.body.innerText) || ''")
                or ""
            )
        except Exception:  # noqa: BLE001 — a wedged page still yields its responses
            rendered_text = ""
    # BOUNDED, because this reply travels on ONE line of a socket whose
    # reader stops at 32 MB (browser._READ_LIMIT). `state.recorded` holds
    # every response the page made, and a heavy SPA makes hundreds — on
    # zara.com the line did not fit and the client raised "Separator is not
    # found, and chunk exceed the limit", killing the task outright
    # (2026-08-27). `rendered_text` was already capped; the responses were
    # not, and they are the larger half by far.
    kept: list[dict[str, Any]] = []
    spent = 0
    for item in responses:
        weight = len(json.dumps(item, default=str))
        if spent + weight > _RECORD_REPLY_BUDGET:
            break
        kept.append(item)
        spent += weight
    return {
        "ok": True,
        "recording": False,
        "page_url": page_url,
        "rendered_text": rendered_text[:200_000],
        "responses": kept,
        "count": len(responses),
        # How many were left behind for size, as distinct from `dropped`,
        # which counts what the recorder's own buffer never held.
        "elided": len(responses) - len(kept),
        # Non-zero means the buffer filled and the recording is partial.
        # Reported so a truncated session is never scored as a whole one.
        "dropped": state.record_dropped,
    }


_DISPATCH = {
    "navigate": _cmd_navigate,
    "snapshot": _cmd_snapshot,
    "click_ref": _cmd_click_ref,
    "click_xy": _cmd_click_xy,
    "fill_ref": _cmd_fill_ref,
    "set_files": _cmd_set_files,
    "type": _cmd_type,
    "screenshot": _cmd_screenshot,
    "get_text": _cmd_get_text,
    "find_line": _cmd_find_line,
    "relevant_lines": _cmd_relevant_lines,
    "session_fetch": _cmd_session_fetch,
    "list_tabs": _cmd_list_tabs,
    "switch_tab": _cmd_switch_tab,
    "close_tab": _cmd_close_tab,
    "set_headless": _cmd_set_headless,
    "record_start": _cmd_record_start,
    "record_stop": _cmd_record_stop,
    "ping": _cmd_ping,
    "webmcp_list": _cmd_webmcp_list,
    "webmcp_invoke": _cmd_webmcp_invoke,
}


async def _overlay_set_step(state: DaemonState) -> None:
    """Best-effort pill-counter update on the active page. Never raises.

    The overlay re-installs at step 0 on every navigation (init script),
    so action commands bump and ``snapshot`` re-asserts the live count.
    Hard 2s cap: a wedged page must not stall the command pipeline for
    a cosmetic update.
    """
    if state.overlay_js is None:
        return
    page = state.active_page()
    if page is None:
        return
    try:
        await asyncio.wait_for(
            page.evaluate(
                # install() first (idempotent, id-guarded): an SPA that
                # rewrote <body> — or a document.write swap — removes the
                # pill node while the window-level API survives; every
                # step update self-heals it before setting the counter.
                "(n) => { if (window.__rokan_overlay) { "
                "window.__rokan_overlay.install(); "
                "window.__rokan_overlay.setStep(n); } }",
                state.overlay_step,
            ),
            timeout=2.0,
        )
    except Exception:  # noqa: BLE001 — cosmetic, never fatal
        pass


async def _dispatch(state: DaemonState, cmd: str, args: dict[str, Any]) -> dict[str, Any]:
    handler = _DISPATCH.get(cmd)
    if handler is None:
        return {"ok": False, "error": "unknown_cmd", "detail": cmd[:32]}
    # Serialise browser-touching commands so one page can't be torn by
    # two concurrent clients.
    async with state.lock:
        state.touch()
        # Tombstone sweep: page-close events fire off-lock and only mark;
        # the actual removal happens here, under the lock, before any
        # command resolves its active page.
        state.sweep_closed()
        try:
            result = await handler(state, args)
        except Exception as exc:
            logger.exception("dispatch %s failed", cmd)
            # A browser that was never downloaded fails here, not at spawn:
            # the daemon starts fine and only Playwright's first launch
            # discovers the missing executable. Without this branch the
            # caller reports it as a navigation failure and tells the user
            # to check their network, which sends first-run users the wrong
            # way entirely.
            if "executable doesn't exist" in str(exc).lower():
                return {
                    "ok": False,
                    "error": "chromium_missing",
                    "detail": "playwright chromium is not installed",
                }
            return {
                "ok": False,
                "error": "handler_exception",
                "detail": f"{type(exc).__name__}",
            }
        # Out-of-band events (JS dialogs / file choosers / downloads)
        # raised by THIS command — or pending from just before it — ride
        # on the response so the Brain sees what the page did. Attached
        # only when present, so exact-shape responses stay stable.
        events = state.drain_events()
        if events and isinstance(result, dict):
            result["events"] = events
        # Demo overlay: count viewer-meaningful actions; re-assert on
        # snapshot (the overlay resets to 0 whenever a page (re)loads).
        if state.overlay_js is not None and isinstance(result, dict) and result.get("ok"):
            if cmd in _OVERLAY_STEP_CMDS:
                state.overlay_step += 1
                await _overlay_set_step(state)
            elif cmd == "snapshot":
                await _overlay_set_step(state)
        return result


# --------------------------------------------------------------------------
# Socket server
# --------------------------------------------------------------------------


async def _handle_client(
    state: DaemonState,
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
) -> None:
    """One connection = many newline-delimited JSON requests until EOF.

    Each request gets a single newline-delimited JSON response. ``close``
    is the one command that triggers daemon shutdown after responding.
    """
    try:
        while True:
            try:
                line = await reader.readuntil(b"\n")
            except asyncio.IncompleteReadError:
                break
            except asyncio.LimitOverrunError:
                # Buffer overflow — kill the connection.
                response = {"ok": False, "error": "command_too_large"}
                writer.write((json.dumps(response) + "\n").encode("utf-8"))
                await writer.drain()
                break
            if not line:
                break
            if len(line) > MAX_COMMAND_BYTES:
                response = {"ok": False, "error": "command_too_large"}
                writer.write((json.dumps(response) + "\n").encode("utf-8"))
                await writer.drain()
                continue

            try:
                payload = json.loads(line.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                response = {"ok": False, "error": "bad_json"}
                writer.write((json.dumps(response) + "\n").encode("utf-8"))
                await writer.drain()
                continue
            if not isinstance(payload, dict):
                response = {"ok": False, "error": "bad_shape"}
                writer.write((json.dumps(response) + "\n").encode("utf-8"))
                await writer.drain()
                continue

            corr_id = payload.get("id")
            cmd = str(payload.get("cmd") or "").strip()
            args = payload.get("args")
            if not isinstance(args, dict):
                args = {}

            if cmd == "close":
                response = {"id": corr_id, "ok": True, "closing": True}
                writer.write((json.dumps(response) + "\n").encode("utf-8"))
                await writer.drain()
                state.shutdown_event.set()
                return

            result = await _dispatch(state, cmd, args)
            response = {"id": corr_id, **result}
            try:
                writer.write((json.dumps(response) + "\n").encode("utf-8"))
                await writer.drain()
            except (ConnectionResetError, BrokenPipeError):
                break
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass


async def _idle_watchdog(state: DaemonState) -> None:
    """Exit the daemon after ``IDLE_TIMEOUT_S`` of inactivity."""
    while not state.shutdown_event.is_set():
        try:
            await asyncio.wait_for(state.shutdown_event.wait(), timeout=30.0)
            return
        except TimeoutError:
            idle = time.monotonic() - state.last_activity
            if idle >= IDLE_TIMEOUT_S:
                logger.info(
                    "idle timeout reached (%.1fs) — shutting down", idle
                )
                state.shutdown_event.set()
                return


def _write_crashfile(socket_path: str, exc: BaseException) -> None:
    """Best-effort crash dump for post-mortem when the daemon dies."""
    crash_path = socket_path + ".crash"
    try:
        with open(crash_path, "w", encoding="utf-8") as fp:
            fp.write(f"exception: {type(exc).__name__}: {exc}\n\n")
            fp.write(traceback.format_exc())
    except OSError:
        pass


async def _run(socket_path: str, mission_id: str, user_data_dir: str) -> int:
    """Main daemon entry — start server, wait for shutdown, cleanup."""
    state = DaemonState(mission_id=mission_id, user_data_dir=user_data_dir)

    # Unix socket — pre-clean any orphaned file from a prior crash.
    try:
        os.unlink(socket_path)
    except FileNotFoundError:
        pass

    server = await asyncio.start_unix_server(
        lambda r, w: _handle_client(state, r, w),
        path=socket_path,
    )
    # Restrict the socket to the owner — other UIDs cannot pivot it.
    try:
        os.chmod(socket_path, 0o600)
    except OSError:
        pass

    # Signal handlers so kill -TERM / kill -INT exits cleanly.
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, state.shutdown_event.set)
        except (NotImplementedError, RuntimeError):
            # Some platforms (Windows / non-main-thread) lack signal handlers.
            pass

    watchdog_task = asyncio.create_task(_idle_watchdog(state))

    # READY marker for the parent (so it knows the socket is bindable).
    # ``headless=`` reports the EFFECTIVE mode (wish + CI/no-display
    # guard) so the UI can tell the user "running headless" honestly.
    print(
        f"READY {socket_path} "
        f"headless={'1' if _effective_headless() else '0'}",
        flush=True,
    )
    logger.info("daemon ready mission=%s socket=%s", mission_id, socket_path)

    try:
        async with server:
            await state.shutdown_event.wait()
    finally:
        watchdog_task.cancel()
        try:
            await watchdog_task
        except asyncio.CancelledError:
            pass
        await state.shutdown()
        try:
            os.unlink(socket_path)
        except FileNotFoundError:
            pass

    return 0


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="rokan_browser_daemon")
    parser.add_argument("--mission-id", required=True)
    parser.add_argument("--socket-path", required=True)
    parser.add_argument("--user-data-dir", required=True)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )
    ns = _parse_args(argv)
    mission_id = ns.mission_id
    if not _MID_RE.match(mission_id):
        sys.stderr.write(f"bad mission_id: {mission_id!r}\n")
        return 2
    try:
        return asyncio.run(_run(ns.socket_path, mission_id, ns.user_data_dir))
    except KeyboardInterrupt:
        return 0
    except BaseException as exc:  # noqa: BLE001 — top-level crash dump
        _write_crashfile(ns.socket_path, exc)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
