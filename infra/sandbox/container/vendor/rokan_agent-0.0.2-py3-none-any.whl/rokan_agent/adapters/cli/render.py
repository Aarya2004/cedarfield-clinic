"""How a result reads at 7am. Built to BUILD-PLAN Part A, not to taste.

The first version of this file invented its own format — ``ok:`` / ``skipped:``
prefixes and a flat sentence — because it was written without opening the spec.
It was replaced. What follows is A4, A5 and A7 rendered literally:

* **A4** — a warm success is **one line**. "The absence of output is the
  feature."
* **A5** — an abstention is calm, specific, structured (``class`` / ``why`` /
  ``next``), never apologises, and **ends with the trust line**. The spec names
  that last line "the trust line"; it is not decoration.
* **A7** — no spinners. Saffron only on ``⚡`` and the ok-state, never on body
  text. Silence is the default.

**Colour is emitted only to a TTY.** A7 asks for saffron; cron mail, pipes and
log files render ANSI as mojibake. Both concerns are real, so the escape codes
are conditional and the *text* is byte-identical either way — which is also
what makes the conformance tests meaningful.
"""

from __future__ import annotations

import os
import sys
import textwrap
from typing import TextIO

from ...core.reasons import is_no_repair
from ...core.result import Result, Status

#: A7: saffron #d97706. 256-colour 172 is its nearest terminal neighbour.
#: Used ONLY on ⚡ and the ok-state — never on body text, which is why there is
#: no "body" colour defined here to reach for later.
_SAFFRON = "\033[38;5;172m"
_DIM = "\033[2m"
_RESET = "\033[0m"

#: A7: "the operation is untouched; nothing was guessed at." The spec calls
#: this the trust line. It costs one line and is the reason a user lets an
#: unattended tool keep running after it declines.
TRUST_LINE = "the operation is untouched; nothing was guessed at"

#: A5's rationale line, for classes where repair has a 0% ceiling.
_WHY_NO_REPAIR = "0% of breaks in this class are safely auto-fixable"
_WHY_UNSAFE = "not confident enough to answer, so it did not"
#: A transient error is neither unrepairable nor a confidence problem, and
#: saying either would be a lie the user could check.
_WHY_RETRYABLE = "transient — the next scheduled check will try again"

_LABEL_WIDTH = 8


def _colour_ok(stream: TextIO) -> bool:
    """True only for an interactive terminal that has not opted out."""
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("TERM", "") == "dumb":
        return False
    return bool(getattr(stream, "isatty", lambda: False)())


def _sanitize_token(text: str) -> str:
    """A site's tool/host name into a one-line marker: printable, no control
    chars / ANSI / colons that would corrupt the `⚙ native:site:tool` grammar."""
    cleaned = "".join(c for c in text if c.isprintable() and c not in ":\n\r\t")
    return cleaned[:64]


def _evidence_value(evidence: object, key: str) -> str:
    """Pull `key=value` from a Result's evidence list (native provenance)."""
    if not isinstance(evidence, (list, tuple)):
        return ""
    prefix = f"{key}="
    for item in evidence:
        text = str(item)
        if text.startswith(prefix):
            return text[len(prefix):]
    return ""


#: A5 lays the block out as a value column. Continuation lines hang under it,
#: so a long `next` stays inside the column instead of running off the shape.
_WRAP_WIDTH = 92


def _field(label: str, value: str) -> list[str]:
    indent = "    " + " " * _LABEL_WIDTH
    wrapped = textwrap.wrap(value, width=_WRAP_WIDTH - len(indent)) or [""]
    head = f"    {label.ljust(_LABEL_WIDTH)}{wrapped[0]}"
    return [head] + [f"{indent}{line}" for line in wrapped[1:]]


def render(result: Result, *, stream: TextIO | None = None) -> int:
    """Print a result to Part A's shape and return the process exit code."""
    out: TextIO = stream if stream is not None else (
        sys.stderr if result.status is Status.ERROR else sys.stdout
    )
    colour = _colour_ok(out)
    lines: list[str] = []

    if result.status is Status.OK:
        # A4: one line, nothing else. The answer is the only thing in ink;
        # the timing sits behind it, dimmed.
        timing = f"{result.elapsed_ms}ms"
        bolt = ""
        if result.transport_used == "replay":
            bolt = f"  {_SAFFRON}⚡{_RESET}" if colour else "  ⚡"
        tail = f"{_DIM}{timing}{_RESET}" if colour else timing
        # Native (Tier 0): the site's OWN WebMCP tool answered. The marker sits
        # AFTER the ms tail so a bridge parser can $-anchor it behind the number,
        # and the answer text (which precedes the tail) can never be mistaken for
        # provenance. site/tool travel in evidence (`site=…`, `tool=…`).
        native_marker = ""
        if result.transport_used == "native":
            site = _sanitize_token(_evidence_value(result.evidence, "site"))
            tool = _sanitize_token(_evidence_value(result.evidence, "tool"))
            if site and tool:
                # A 0-call native answer (a replay of a remembered op) earns the
                # same ⚡ as a compiled replay — ⚡ means "no model call", whatever
                # the transport. A first-run native (1 call) shows only ⚙.
                if _evidence_value(result.evidence, "calls") == "0" and not bolt:
                    bolt = f"  {_SAFFRON}⚡{_RESET}" if colour else "  ⚡"
                mark = f"⚙ native:{site}:{tool}"
                native_marker = f"  {_SAFFRON}{mark}{_RESET}" if colour else f"  {mark}"
        # Strip OUR provenance glyphs from the answer text: a site whose tool
        # output contains `⚙`/`⚡` must not be able to forge a marker a
        # stdout-scraping parser would read (reviewer P2). The real marker is
        # appended by us, after the tail.
        answer = str(result.data).replace("⚙", "").replace("⚡", "")
        lines.append(f"  {answer}   {tail}{bolt}{native_marker}")
        # What the mask hides is the user's only window into a wrong mask —
        # if the value they care about got learned as noise, this is where
        # they find out. Dimmed: context, not the answer.
        for label in ("ignoring", "not_ignoring", "now_ignoring", "flap_line", "hint", "undo"):
            for entry in result.evidence:
                if entry.startswith(f"{label}="):
                    value = entry.split("=", 1)[1]
                    if label in ("hint", "undo"):
                        text_line = f"    Run: {value}"
                    else:
                        text_line = f"    {label.replace('_', ' ')} {value}"
                    lines.append(f"{_DIM}{text_line}{_RESET}" if colour else text_line)
    else:
        reason = result.reason
        code = reason.value if reason else "unknown"
        headline = "⏸ abstained" if result.status is Status.ABSTAINED else "✕ stopped"
        summary = _summary_for(code)
        lines.append("")
        lines.append(f"  {headline} — {summary}")
        lines.append("")
        lines.extend(_field("class", code))
        if reason is not None and is_no_repair(reason):
            why = _WHY_NO_REPAIR
        elif result.status is Status.ERROR:
            why = _WHY_RETRYABLE
        else:
            why = _WHY_UNSAFE
        lines.extend(_field("why", why))
        if result.next_step:
            lines.extend(_field("next", result.next_step))
        lines.append("")
        # A5's last line. Only honest for an abstention — an error may have got
        # partway, and claiming otherwise would be exactly the kind of
        # reassurance this line exists to earn.
        if result.status is Status.ABSTAINED:
            lines.append(f"  {TRUST_LINE}")

    for line in lines:
        print(line, file=out)
    return result.exit_code


def _summary_for(code: str) -> str:
    """One plain-language clause. A5's headline is a sentence a person reads,
    not a code they look up — the code is on the ``class`` line."""
    return _SUMMARIES.get(code, code.replace("_", " "))


_SUMMARIES: dict[str, str] = {
    "no_credential": "there is no stored login for this site",
    "login_rejected": "the site refused the stored password",
    "signup_page": "that link opens a sign-up form, not a sign-in one",
    "credential_may_be_exposed": (
        "the page moved while your password was being typed — change it"
    ),
    "credential_origin_refused": (
        "the sign-in page is on a different site, so nothing was typed"
    ),
    "abstained_planner_unavailable": "the model provider could not be reached",
    "totp_required_no_seed": "it wants a one-time code and none is stored",
    "email_code_required": "the code was sent by email, which Rokan does not read",
    "captcha_blocked": "a bot check is in the way",
    "login_form_not_found": "no password form here — probably SSO or a passkey",
    "submit_not_found": "the fields were there but nothing to submit them with",
    "session_unrecoverable": "signing in again did not work",
    "browser_unavailable": "the browser is not installed",
    "navigation_failed": "the page did not load",
    "invalid_url": "that is not a URL it can key a login to",
    "too_many_steps": "the page never settled",
    "quota_exhausted": "this period's runs are used up",
    "drift_detected": "the page changed shape, so it did not return stale data",
    "negative_postcondition_violated": "something changed that was not supposed to",
    "needs_approval": "this needs your approval first",
    "abstained_no_repair_class": "the page changed in a way it cannot safely repair",
    "abstained_low_confidence": "it was not confident enough to answer",
    "abstained_scorer_disagreement": "independent checks disagreed about the page",
}
