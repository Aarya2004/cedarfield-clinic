"""Finding the page when the user only knows the service.

The rest of the loop assumes a URL. On the public web that assumption breaks:
people know "my Vercel usage" and not
``vercel.com/dashboard/usage``. Discovery closes that gap — one search, one
URL, and the loop proceeds exactly as it does behind a login.

**This is a read layer for the OPEN web, and it is deliberately separate from
ours.** Rokan's own read layer sees pages that exist only inside the user's
session; no index can crawl those. Exa sees what is public and indexed. The
two do not overlap, which is why one cannot replace the other and why the
public-web path needed something new.

Three rules keep it honest:

* **Opt-in.** Nothing calls this unless the user asked for it or no URL could
  be found. A tool that silently phones a third party is not the tool we
  said we were building.
* **The query never carries the page's content.** Only the service name and
  the kind of page. What is behind a login stays behind it — discovery
  happens *before* anything is fetched, by construction.
* **A result is a candidate, not an answer.** The URL still goes through the
  same plan → execute → verify path, so a wrong guess from search fails the
  postcondition like any other wrong guess.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass

_ENDPOINT = "https://api.exa.ai/search"
_TIMEOUT = 20.0

#: What a discovery query may contain. Anything the user typed beyond the
#: service and the page kind is dropped — a task like "read my balance, my
#: account number is 1234" must not send that number to a search engine.
_MAX_QUERY_CHARS = 120


class DiscoveryUnavailable(RuntimeError):
    """No key, no network, or nothing found. Never fatal: the loop can still
    run when the user names a URL."""


@dataclass(frozen=True, slots=True)
class Candidate:
    url: str
    title: str


def key_present() -> bool:
    return bool(os.environ.get("EXA_API_KEY"))


#: The words that may describe a KIND of page. Discovery is allowed to say
#: "the API keys page on resend.com" and nothing else, so the query is
#: assembled from this list rather than filtered out of the user's sentence.
#:
#: A filter was the first implementation and it was not honest: dropping
#: non-alphabetic words removes account numbers and amounts but keeps NAMES,
#: so "read jane doe's balance on acme.com" sent "jane doe balance" to a
#: search engine while the disclosure promised it sent neither. An allow-list
#: cannot leak a word nobody wrote here.
_PAGE_WORDS = frozenset({
    "account", "accounts", "admin", "api", "billing", "console",
    "credential", "credentials", "dashboard", "developer", "developers",
    "docs", "documentation", "home", "invoice", "invoices", "key", "keys",
    "login", "overview", "payment", "payments", "plan", "pricing", "profile",
    "portal", "secret", "secrets", "settings", "signin", "status",
    "subscription", "token", "tokens", "usage",
})


def _bare_domain(service: str) -> str:
    """The host, with no scheme, no path, and no www."""
    return (
        service.strip().lower().split("://", 1)[-1].split("/", 1)[0].removeprefix("www.")
    )


def _clean_query(service: str, wanted: str) -> str:
    """Service plus page-kind, nothing else.

    This is the only text that leaves the machine during discovery, so it is
    assembled from a fixed vocabulary rather than passed through. Words the
    user wrote that are not page-kind words are simply not sent.
    """
    service = _bare_domain(service)
    kinds: list[str] = []
    for raw in wanted.strip().lower().split():
        word = "".join(character for character in raw if character.isalpha())
        if word in _PAGE_WORDS and word not in kinds:
            kinds.append(word)
    query = " ".join([service, *kinds, "page"]).strip()
    return query[:_MAX_QUERY_CHARS]


def find(service: str, wanted: str, *, limit: int = 3) -> list[Candidate]:
    """Candidate URLs for a page on a public service.

    Raises DiscoveryUnavailable rather than returning an empty list, so a
    caller cannot mistake "search is off" for "this page does not exist".
    """
    api_key = os.environ.get("EXA_API_KEY")
    if not api_key:
        raise DiscoveryUnavailable(
            "no EXA_API_KEY — name the page's URL, or set the key to let "
            "Rokan look it up"
        )
    payload = json.dumps(
        {
            "query": _clean_query(service, wanted),
            "numResults": max(1, min(limit, 10)),
            # Search the service itself. Without this a query for "vercel
            # usage" happily returns a blog post about Vercel usage, and the
            # planner would faithfully open the wrong page.
            #
            # A BARE domain: the caller passes whatever the gate parsed, which
            # is a full URL, and "https://vercel.com" is not a domain. Exa
            # either rejects it — leaving --discover silently dead, with the
            # message swallowed as "(search: …)" — or ignores it.
            "includeDomains": [_bare_domain(service)],
        }
    ).encode("utf-8")
    request = urllib.request.Request(
        _ENDPOINT,
        data=payload,
        headers={
            "x-api-key": api_key,
            "Content-Type": "application/json",
            "User-Agent": "rokan-do/0.0.1 (discovery)",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=_TIMEOUT) as response:
            body = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        # The key is in the header, so an error message that echoes the
        # request would carry it (C15: the guard covers construction AND
        # the call). Only the status is ever reported.
        raise DiscoveryUnavailable(f"search refused the request ({exc.code})") from None
    except Exception:  # noqa: BLE001 — a network failure is not an answer
        raise DiscoveryUnavailable("could not reach search") from None

    results = body.get("results") or []
    candidates = [
        Candidate(url=str(item.get("url", "")), title=str(item.get("title") or ""))
        for item in results
        if item.get("url")
    ]
    if not candidates:
        raise DiscoveryUnavailable("search found no page on that service")
    return candidates
