"""The seed pack — warm on the first call, on a machine that never ran anything.

A verified operation is a small, public thing: a typed plan (site, steps,
anchors, postcondition) and the question it answers. None of it is a
secret, none of it is a value, none of it is the user's. So the operations
WE verified on public pages can ship with the package and be installed
into a fresh store, and the first call anywhere on that list is
`replayed` — no model — instead of `planned`.

What a seeded operation is NOT: proof on the user's machine. It is admitted
as verified because it verified on ours; the replay path re-verifies every
hit against the live page, so a seed that has rotted is retired on first
contact exactly like a learned operation, and the ledger says `seeded` so
its survival is never counted as a cold success.

Format: one JSON list of ``{plan, said}`` — `plan` is `memory._plan_to_json`'s
shape (validated on import, like any stored row), `said` the question. No
page text, no values, no compiled endpoints (those need the user's own
traffic), no credentials by construction (`ir.validate` refuses literals).
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from importlib import resources
from pathlib import Path

from .accept import verifier_for
from .ir import InvalidPlan, Plan, Verb
from .memory import Memory, _behaviour_hash, _plan_from_json, _plan_to_json
from .verify import Verdict

#: The bundled pack, shipped inside the wheel.
BUNDLED = "seed_ops.json"

#: Verbs a seed may carry. Reads only: a seeded WRITE would replay an
#: action on a stranger's account on the strength of our run.
_SEEDABLE = frozenset({Verb.NAVIGATE, Verb.GET_TEXT, Verb.READ_VALUE, Verb.ASSERT_CONTAINS})


@dataclass(frozen=True, slots=True)
class SeedReport:
    installed: int
    skipped: int
    reasons: tuple[str, ...]


def export_ops(memory: Memory) -> list[dict[str, object]]:
    """Every live, read-only, PUBLIC operation with a learned question.

    Public: no login stored for the host. An export is meant to be
    published, and an operation learned behind the user's login carries
    their internal hostnames, paths and anchor text (Opus round 8, A5)."""
    out: list[dict[str, object]] = []
    for op in memory.library():
        if any(step.verb not in _SEEDABLE for step in op.plan.steps):
            continue
        if _has_login(op.plan.site):
            continue
        said = next((ln.strip() for ln in op.learned_said.splitlines() if ln.strip()), "")
        if not said:
            continue
        if op.plan.verify != verifier_for(op.plan.task_class, said, op.plan.site):
            # Learned under a verifier the question no longer earns: it
            # would not replay here either. A pack carries only live ops.
            continue
        out.append({"plan": json.loads(_plan_to_json(op.plan)), "said": said})
    return out


def _has_login(site: str) -> bool:
    try:
        from rokan_agent.core.proven import vault  # noqa: PLC0415

        host = vault.normalize_host(site)
        return vault.get(host) is not None or vault.find_sibling(host) is not None
    except ValueError:
        # The one fail-OPEN branch here, on purpose: the vault is keyed by
        # normalized host, so a site with no parseable host cannot hold a
        # login — there is nothing to protect.
        return False
    except Exception:  # noqa: BLE001 — unreadable vault: assume private
        return True


def _seedable(plan: Plan) -> str:
    """Why a plan may not be seeded, or "" when it may."""
    if any(step.verb not in _SEEDABLE for step in plan.steps):
        return "carries an action — writes are never seeded"
    if plan.verify == "key_used":
        return "a credential class — never seeded"
    if plan.task_class == "general":
        return "general mode — its proof is per page, not portable"
    return ""


def import_ops(memory: Memory, ops: list[dict[str, object]]) -> SeedReport:
    """Install a pack. Every plan is re-validated; anything unseedable is
    skipped and named. Each install is a ledger row with verdict
    `seeded`, so the half-life arithmetic can tell our proof from the
    user's."""
    installed = 0
    reasons: list[str] = []
    for item in ops:
        try:
            plan = _plan_from_json(json.dumps(item["plan"]))
        except (InvalidPlan, KeyError, TypeError, ValueError) as exc:
            reasons.append(f"unreadable plan: {type(exc).__name__}")
            continue
        why = _seedable(plan)
        if why:
            reasons.append(f"{plan.site}: {why}")
            continue
        said = str(item.get("said") or "").strip()
        if not said:
            reasons.append(f"{plan.site}: no question")
            continue
        expected = verifier_for(plan.task_class, said, plan.site)
        if plan.verify != expected:
            # The replay gate skips any stored plan whose verifier is not
            # the one the question earns TODAY. A pack built before a
            # verifier landed would install cleanly and never replay
            # (Opus round 8, A1). Loud at install, not silent at use.
            reasons.append(f"{plan.site}: verifier {plan.verify} is stale (now {expected})")
            continue
        state = memory.behaviour_state(_behaviour_hash(plan))
        if state:
            # Idempotent. A re-install must not count as another PROOF:
            # `remember` bumps `cold_proofs` on conflict, and three installs
            # would otherwise lift the compile quarantine on evidence that
            # is one run, looked at three times. Three facts, three
            # sentences: a person who forgot this is not told it is
            # installed (Opus round 9).
            reasons.append(f"{plan.site}: {state}")
            continue
        key = memory.remember(plan, Verdict(True, "seeded", None, ("seeded",)), said)
        if key is None:
            reasons.append(f"{plan.site}: not admitted")
            continue
        memory.record_use(key, path="planned", ok=True, verdict="seeded")
        installed += 1
    return SeedReport(installed=installed, skipped=len(reasons), reasons=tuple(reasons))


def _already_installed(memory: Memory, plan: Plan) -> bool:
    """Live OR retired OR forgotten. A retired seed stays retired: re-
    installing the pack must not resurrect what the live page refuted."""
    return bool(memory.behaviour_state(_behaviour_hash(plan)))


def bundled() -> list[dict[str, object]]:
    """The pack shipped in this build, or an empty list when none is."""
    try:
        raw = resources.files("rokan_do").joinpath(BUNDLED).read_text()
    except (FileNotFoundError, OSError):
        return []
    try:
        data = json.loads(raw)
    except ValueError:
        return []
    return data if isinstance(data, list) else []


def load(path: str | Path) -> list[dict[str, object]]:
    data = json.loads(Path(path).read_text())
    if not isinstance(data, list):
        raise ValueError("a seed pack is a JSON list")
    return data


__all__ = ["BUNDLED", "SeedReport", "bundled", "export_ops", "import_ops", "load"]
