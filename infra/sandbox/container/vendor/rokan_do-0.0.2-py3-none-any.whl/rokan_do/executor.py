"""Running a plan with no model in the room.

By the time execution starts, every decision has been made. The executor is
deliberately stupid: it walks the typed steps, dispatches each to the proven
browser daemon, and checks after each one that the page still looks like the
page the plan was written against. It cannot improvise, because improvising
is what the 20-33% success rates are made of.

Two things it does that a plain runner would not:

* **Secrets are resolved here, not planned here.** A step carrying
  ``vault://host/password`` is filled from the local vault at the moment of
  typing, so the plan — which was written by a model — never contained the
  credential (D4, extended to planning).
* **Every step is checked for drift** using the same anchor machinery the
  watcher uses, which has survived two adversarial review rounds. A step that
  lands on a login wall or an error page stops the run rather than typing
  into whatever happens to be there.
* **Every action is checked for a reported change** (2026-08-24, W5). The
  daemon reports, after each click / fill / type, whether the URL changed,
  the DOM fingerprint changed, or a tab opened. A click after which NOTHING
  is reported changed is a failed step, never a silent one. What this is
  not (yet): a proof the click caused the change — the fingerprint folds
  the page's whole text, so a clock or a toast flipping during the settle
  window reads as a change (Opus round 2, F1). Effect attribution is
  Tuesday's work. Action verbs run only under ``allow_actions``; the read
  classes never pass it, so their behaviour is unchanged.
"""

from __future__ import annotations

import asyncio
import os
import re
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from rokan_agent.core.proven import browser, login, vault
from rokan_agent.core.reasons import Reason

from . import fences, gates, httpread
from .ir import SECRET_SCHEME, Plan, Step, Verb
from .lines import beside as _beside
from .lines import flatten, value_after_label
from .redact import redact


class ExecutionFailed(RuntimeError):
    """A step could not be carried out. Carries the reason to abstain with."""

    def __init__(
        self,
        message: str,
        reason: Reason,
        step_index: int,
        trace: Trace | None = None,
        offers: tuple[str, ...] = (),
    ) -> None:
        super().__init__(message)
        self.reason = reason
        self.step_index = step_index
        #: The exact phrases that WOULD resolve, when the plan named a
        #: control the page has several of — each in the form `_resolve_ref`
        #: accepts back. Set only by the ambiguity refusal. Carried as data
        #: rather than left inside the message because the ladder cuts a
        #: failure message to 220 characters before the next prompt sees
        #: it, and six offered phrases do not fit in 220 characters.
        self.offers = offers
        #: What the run had seen when it stopped. Carried so the next rung is
        #: not blind: the commonest failure is an anchor the page does not
        #: use, and a bigger model given the same empty context makes the
        #: same mistake at three times the price. Measured: on the drift
        #: path, all three rungs planned with `context=""`.
        self.trace = trace


async def _find_past_the_cap(site: str, marker: str) -> str | None:
    """Ask the browser for the line, since the browser has the whole page.

    Three outcomes, and the third one matters for what the failure SAYS:
    the line, "" when the whole page was searched and held nothing usable,
    and None when the search could not happen at all. Collapsing the last
    two made a missing daemon claim we had read the whole document — an
    existing test caught that, which is the entire argument for the
    distinction.

    This is a rescue on a path that has already failed, so it may only turn
    a failure into a success, never a success into something else.

    An ambiguous marker returns "" ON PURPOSE. The verifier refuses an
    anchor matching several lines with different values, so handing one
    back here would produce a reading that is then refused anyway — with
    the difference that the refusal would name the wrong cause.
    """
    try:
        from rokan_agent.core.proven import browser, vault  # noqa: PLC0415

        session = await browser.session_for(vault.normalize_host(site))
        reply = await session.send("find_line", {"contains": marker})
    except Exception:  # noqa: BLE001 — a rescue that fails leaves the failure
        return None
    if not isinstance(reply, dict) or not reply.get("ok"):
        return None
    lines = [str(x).strip() for x in (reply.get("lines") or []) if str(x).strip()]
    if len(lines) != 1 or int(reply.get("total") or 0) != 1:
        return ""
    return lines[0]


async def _exists_past_the_cap(site: str, marker: str) -> bool | None:
    """Is the text anywhere on the whole page? Presence, not identity.

    None when the search could not happen — see `_find_past_the_cap`.
    """
    try:
        from rokan_agent.core.proven import browser, vault  # noqa: PLC0415

        session = await browser.session_for(vault.normalize_host(site))
        reply = await session.send("find_line", {"contains": marker})
    except Exception:  # noqa: BLE001 — a rescue that fails leaves the failure
        return None
    if not isinstance(reply, dict) or not reply.get("ok"):
        return None
    return int(reply.get("total") or 0) > 0


def _cut_off(trace: Trace) -> str:
    """Name truncation as a cause when it is one.

    "not on the page" and "we stopped reading before we got there" are
    different facts and only one of them is about the site. Measured on
    curl's manual page: 263,000 characters, the answer at 114,000, and the
    caller was handed the first 30,000 with a failure that read like the
    site simply did not say it.
    """
    if not trace.truncated:
        return ""
    if trace.searched_whole_page:
        # We looked. Repeating the excuse after checking would be the same
        # fault as never mentioning the cap, pointing the other way.
        return " — and the whole page was searched, not only the part that was shipped"
    return (
        f" — but only the first {len(trace.page_text):,} characters were "
        "read, and the page is longer than that, so the value may be past "
        "where we stopped"
    )


@dataclass(slots=True)
class Trace:
    """What actually happened — the narration and the evidence, in order."""

    said: list[str] = field(default_factory=list)
    #: The last page text the run saw. The verifier works on this, not on
    #: anything the model claimed.
    page_text: str = ""
    #: Values the plan explicitly read, keyed by their `contains` marker.
    read: dict[str, str] = field(default_factory=dict)
    #: Every link the page shows, by label, in document order. A list of
    #: ITEMS is almost always a list of links — story titles, crate names,
    #: product rows — and reading raw adjacent text lines instead gives
    #: back row fragments and sidebar navigation. Measured on crates.io,
    #: where five adjacent lines after the anchor were "Just Updated",
    #: "Most Recent Downloads", "Popular Keywords": real lines, real
    #: order, and not the answer to anything (2026-08-27).
    links: list[str] = field(default_factory=list)
    #: Which sequence the block was read from: the rendered text, or the
    #: page's links. The verifier checks the run against that same
    #: sequence, never against the other one.
    block_kind: str = "line"
    #: Where the page repeats itself: each entry is one set of same-shaped
    #: siblings, flattened to the text lines it covers. Used as a FENCE for
    #: `read_block` — the run stops at the first line outside the group —
    #: never as the source of the lines themselves.
    collections: list[list[list[str]]] = field(default_factory=list)
    #: A SECOND field of the same rows, when the plan asked for one — the
    #: prices beside the names. Same length as `block`, row for row, and
    #: every entry is the page's own line: the verifier checks it as its
    #: own column and only the answer puts a row's two fields together.
    block_extra: list[str] = field(default_factory=list)
    #: The lines a `read_block` returned, in page order. Kept apart from
    #: `read` because a list is proved differently: not "this value sits
    #: beside its label" but "these are the page's own lines, contiguous
    #: and in order".
    block: list[str] = field(default_factory=list)
    elapsed_ms: int = 0
    steps_run: int = 0
    #: Did a session for this host ever actually get established?
    #:
    #: NOT `FetchResult.authenticated`, which is set on every successful
    #: fetch and therefore means "a usable page came back" — measured
    #: 2026-08-24 on supabase.com's public homepage AND on githubstatus.com,
    #: where no account exists at all. Both reported True, which made the
    #: first version of the account-scoped guard inert.
    #:
    #: Fail-closed by default: a trace that was never told must not vouch
    #: for a session it does not have.
    authenticated: bool = False
    #: "http" when a public page was read without a browser, "browser"
    #: otherwise. Recorded because an optimisation nobody can see in the
    #: numbers is an optimisation nobody can check.
    transport: str = "browser"
    #: The URL the run actually REACHED.
    #:
    #: CODE REVIEW, HIGH: the HTTP→browser rescue re-fetched `plan.site`,
    #: which for a domain-only phrasing is the bare HOST while the plan
    #: navigated to a deep page — so the rescue loaded the HOMEPAGE and
    #: searched it. Best case a misleading refusal; worst case an anchor
    #: that also appears on the homepage reporting a value from the wrong
    #: page as verified, which is the Supabase-testimonial failure by
    #: another route.
    last_url: str = ""
    #: True when the page was longer than the fetch's text limit and what
    #: is in `page_text` is the first part of it. Carried so a failure can
    #: say WHY the value was not found.
    truncated: bool = False
    #: True once the browser has been asked about the WHOLE page. From that
    #: moment "the value may be past where we stopped" is no longer true,
    #: and saying it would be an excuse rather than a diagnosis — the same
    #: fault as the silence this flag was added to fix, pointing the other
    #: way.
    searched_whole_page: bool = False
    #: One entry per ACTION step, in order: ``{"step", "verb", "w5"}`` where
    #: w5 is the daemon's ``{url_changed, dom_changed, new_tab}`` report.
    #: A ref-addressed action carries one more key, ``ref_recovered`` —
    #: True when the injected ref was dead and the element's own durable
    #: selector recovered it. Absent when the action addressed no ref.
    #: The admission rule for a general run reads this — a plan whose
    #: actions are not all accounted for is not remembered.
    actions: list[dict[str, Any]] = field(default_factory=list)
    #: Ref health, counted over every ref-addressed action WHETHER OR NOT
    #: it succeeded. Deliberately not folded into `actions`: that list is
    #: the resume "already done" ledger, and an entry there for an action
    #: that FAILED would tell a resume the work was finished — the exact
    #: double-submit `_resume_note` exists to prevent.
    refs_addressed: int = 0
    refs_healed: int = 0
    #: The current snapshot's refs: ``"@e3" -> {"label", "role", ...}``.
    #: Emptied after every click, because the daemon drops its own map
    #: then — the page the refs described is gone.
    refs: dict[str, dict[str, Any]] = field(default_factory=dict)


#: A literal ref from a snapshot taken THIS run: ``e12`` / ``@e12``.
#: Anything else in a ``ref`` argument is a label to resolve against the
#: current snapshot — the durable form a remembered plan carries.
_LITERAL_REF = re.compile(r"^@?e\d+$")


async def _act(site: str, command: str, args: dict[str, Any]) -> dict[str, Any]:
    """One daemon command on this site's session. The seam tests replace.

    Our own failure to reach the daemon is BROWSER_UNAVAILABLE — never a
    verdict about the site or the plan.
    """
    try:
        host = vault.normalize_host(site)
    except ValueError as exc:
        # The same soft failure `login.fetch` gives such a site: nothing was
        # dialled, and this is not the browser's fault.
        raise ExecutionFailed(str(exc), Reason.INVALID_URL, -1) from exc
    try:
        session = await browser.session_for(host)
        reply = await session.send(command, args)
    except Exception as exc:  # noqa: BLE001 — every transport fault is one reason
        raise ExecutionFailed(
            f"the browser could not be reached for {command}: {type(exc).__name__}",
            Reason.BROWSER_UNAVAILABLE,
            -1,
        ) from exc
    return reply if isinstance(reply, dict) else {"ok": False, "error": "bad_reply"}


def _expect_host(site: str) -> str:
    """The hostname the daemon must see before it acts, or "" when the
    site has none — and "" is a REFUSAL upstream, never a payload.

    `urlparse("acme.example/x").hostname` is "" because there is no scheme,
    and `ir.validate` accepts such a site. The daemon reads an empty
    `expect_host` as "no origin check": a vault secret would have been typed
    into whatever context the ref resolved in, cross-origin iframe included
    (Opus round 3, B4, probe-proven). The `//` prefix is `normalize_host`'s
    own trick for schemeless input; unlike it, this never raises."""
    parsed = urlparse(site if "://" in site else f"//{site}")
    return (parsed.hostname or "").strip().lower()


#: How many alternative labels to name when a ref is ambiguous. Enough to
#: choose from; not so many that the message becomes the page.
_LABELS_NAMED = 6


#: What the refusal says when every candidate phrase failed the round
#: trip: the page HAS similar things, and none can be named unambiguously.
NOTHING_RESOLVES = "nothing that would resolve"


def _labels_like(trace: Trace, wanted: str, role: str = "") -> str:
    """`_phrases_like`, joined for a message."""
    return ", ".join(_phrases_like(trace, wanted, role)) or NOTHING_RESOLVES


def _phrases_like(trace: Trace, wanted: str, role: str = "") -> list[str]:
    """The phrases a plan could have used instead of an ambiguous one.

    Longest first, because the distinctive label is the long one: "Databases"
    matches four things, "Databases and Electronic Resources" matches one.

    When the labels are IDENTICAL a longer label does not exist, and
    listing 'Databases' four times tells the next rung nothing it can act
    on. The section each one sits under is what a person would use, so it
    is what gets offered — and in the exact form `_resolve_ref` accepts
    back, so the next plan can simply copy the phrase.
    """
    flat = flatten(wanted).lower()
    seen: list[str] = []
    for ref, entry in trace.refs.items():
        # ONE LINE each. A link wrapping a whole menu carries the menu as
        # its label, newlines included — apa.org's is "PUBLICATIONS &
        # DATABASES\nPublications and Databases\n\nAPA Pub…" — and a phrase
        # with newlines in it is not one a plan can copy into a string.
        # The resolver flattens both sides, so the flat form resolves.
        label = flatten(str(entry.get("label") or ""))
        if not label or flat not in label.lower():
            continue
        section = flatten(str(entry.get("section") or ""))
        if not section and label.lower() == flat:
            # The failed name, offered back as the way past its own
            # failure. Measured on streeteasy.com (2026-08-28): 'Buy' was
            # ambiguous and the offers were `'Buy' under 'This is where it
            # starts', 'How to Buy a Home in NYC', 'Buy'` — and the plan,
            # told to copy one exactly, copied the last. An offer must
            # name ONE element or it is not an offer.
            continue
        phrase = (
            f"{_quoted(_clipped(label, 60))} under {_quoted(_clipped(section, 40))}"
            if section
            else _quoted(_clipped(label, 60))
        )
        # ROUND-TRIP, or not offered. A phrase is built from one element
        # and must resolve back to that element: a clip can equal a
        # sibling's whole label and then name the sibling with no refusal
        # (Opus review, reproduced 2026-08-28), and a long label whose
        # clip resolves to nothing is advice nothing accepts. Checking
        # here is the one place that knows which element the phrase came
        # from — under the ROLE the step will resolve with, or the check
        # is of a different lookup than the one that will run.
        if phrase not in seen and _resolve_ref(trace, phrase, role) == ref:
            seen.append(phrase)
    seen.sort(key=len, reverse=True)
    return seen[:_LABELS_NAMED]


#: The ordinary names for the one control a page has exactly one of. A
#: search box is usually the only element of its kind on a page and often
#: carries no label at all — measured on the 30-task set, four of six
#: search tasks refused because the box had nothing to match on.
#: Input types nothing is typed into.
_NOT_TYPED_INTO = frozenset(
    {"checkbox", "radio", "submit", "button", "reset", "image", "file", "hidden"}
)

#: The word a page uses on the box itself, in a placeholder or an id.
_SAYS_SEARCH = re.compile(r"(?:^|\W)search(?:\W|$)")

_MEANS_A_SEARCH_BOX = re.compile(r"^(?:the\s+)?search(?:\s*(?:box|bar|field|input))?$")


def _clipped(text: str, limit: int) -> str:
    """At most `limit` characters, cut at a word boundary.

    A phrase the refusal offers has to RESOLVE when copied back, and the
    resolver matches a name whole or at a word boundary — never by prefix.
    Cut at 60 characters mid-word, apa.org's mega-menu label came back as
    "…Databases APA Psyc", which no rung could accept (2026-08-28). Cut
    at the last space instead, "…Databases APA" is a whole-word prefix
    the named-for-it rung finds.
    """
    if len(text) <= limit:
        return text
    head = text[:limit]
    cut = head.rfind(" ")
    return (head[:cut] if cut > 0 else head).rstrip()


#: "Databases under Research" — a label plus the section it sits under.
#: Greedy on the label, so the LAST "under" is the split.
_UNDER = re.compile(r"^(?P<what>.+)\s+under\s+(?P<section>[^\s].*)$", re.IGNORECASE)


#: An opening quote and the closing quote that MATCHES it. `'abc"` is
#: not a quotation, and stripping it was eating real characters (Opus
#: review, 2026-08-28).
_QUOTE_PAIRS = {"'": "'", '"': '"', "\u2018": "\u2019", "\u201c": "\u201d"}


def _quoted(text: str) -> str:
    """Wrap a name so that `_unquoted` gives it back UNCHANGED.

    `repr()` cannot be used for this. A label carrying an apostrophe comes
    back as `'It\\'s "Popular"'` — with a backslash the resolver then
    treats as part of the name, so the exact phrase the refusal offered
    resolves to nothing. Pick the quote the text does not contain instead
    of escaping anything.
    """
    if "'" not in text:
        return f"'{text}'"
    if '"' not in text:
        return f'"{text}"'
    return text  # carries both; bare is the only form that round-trips


def _unquoted(raw: str) -> str:
    """The text inside whatever quotes a plan wrapped it in.

    Strips one MATCHED outer pair only. Stripping any quote character from
    either end would eat a leading apostrophe that belongs to the name.
    """
    text = raw.strip()
    if len(text) >= 2 and _QUOTE_PAIRS.get(text[0]) == text[-1]:
        text = text[1:-1]
    return text.strip()


def _resolve_ref(trace: Trace, wanted: str, role: str = "") -> str:
    """The ref for a step's target: a literal ``eN`` from this run's
    snapshot, or the ONE element the plan is describing.

    Resolution walks from the most certain to the least, and STOPS at the
    first rung that finds exactly one element. Ambiguity always refuses —
    two "Delete" buttons is not a situation to guess in — and a target
    nothing resolves is drift: the page no longer has what the plan was
    written against.

    Why more than exact matching. A plan is written once, before the run,
    against a page it may never have seen: "click Health Library, then
    fill the search box" has to name a control that only exists after the
    click. Exact-label matching cannot express that, so every such task
    failed — and the apparent fix, re-planning after every step, is a
    model call per step, which is the cost this whole product exists to
    remove.

    None of these rungs GUESSES. Each one either identifies exactly one
    element or hands on to the next, and the last hands back a refusal.
    Measured on clevelandclinic.org (2026-08-27): the landing page has 107
    elements, no search control at all, and "Contact" does not match
    "Contact us".
    """
    if _LITERAL_REF.match(wanted):
        return wanted if wanted.startswith("@") else "@" + wanted
    # The page's own text FIRST, quotes and all — a label that literally
    # reads `"Hamlet"` is named by the plan that writes `"Hamlet"`, ahead
    # of a sibling called Hamlet (Opus review, 2026-08-28). Then without
    # the quotes a plan wrapped it in: the refusal offers every phrase
    # quoted — `'How to Buy a Home in NYC'` — and only the section rung
    # below ever unquoted, so a label-only offer copied verbatim was
    # refused by the very resolver that offered it. Measured on
    # streeteasy.com (2026-08-28). One matched outer pair comes off and
    # nothing else, so a possessive keeps its apostrophe.
    as_written = flatten(wanted).lower()
    flat_wanted = flatten(_unquoted(wanted)).lower()
    #: The page repeats this label and the plan said WHICH one. Tried
    #: first because it is the most specific thing a plan can say, and
    #: because the ambiguity refusal offers exactly this phrasing — a
    #: message that suggests a form nothing then accepts is worse than no
    #: message. Falls through when the section is gone: the label alone
    #: may still resolve, and if it does not, the ordinary refusal is the
    #: honest answer.
    said = _UNDER.match(wanted.strip())

    def names(entry: dict[str, Any]) -> list[str]:
        # The page names an element three ways, and a search box usually
        # has only the second: a label, a placeholder ("Search packages…"),
        # a DOM id ("search"). Measured on the 30-task set: 4 of 6 search
        # tasks refused because the box had no label to match.
        return [
            flatten(str(entry.get(key) or "")).lower()
            for key in ("label", "placeholder", "dom_id")
            if entry.get(key)
        ]

    def of_role(entry: dict[str, Any]) -> bool:
        return not role or str(entry.get("role") or "").lower() == role.lower()

    def pick(test: Callable[[dict[str, Any]], bool]) -> str:
        hits = [ref for ref, entry in trace.refs.items() if of_role(entry) and test(entry)]
        if len(hits) == 1:
            return hits[0]
        return "ambiguous" if hits else ""

    # 1. The page calls it exactly that. THIS RUNS FIRST, ahead of any
    #    reading of "under" as a section reference, and the order is the
    #    whole guard: "Books under $10" and "Gifts under $25" are LABELS
    #    on ordinary shopping pages. Split one of those and the two halves
    #    can each match something real — a "Gifts" link that happens to
    #    sit under a "Gifts under $25" heading — and the resolver clicks
    #    the wrong control while reporting no ambiguity at all. Both
    #    reviewers found it by that exact shape (2026-08-28). A name the
    #    page actually uses always beats an interpretation of that name.
    exact = pick(lambda e: as_written in names(e)) or pick(lambda e: flat_wanted in names(e))
    if exact:
        return exact

    # 2. "Databases under Research" — the one the plan MEANT, out of
    #    several the page calls the same thing. Only now that no element
    #    is called the whole phrase.
    if said:
        what = flatten(_unquoted(said.group("what"))).lower()
        where = flatten(_unquoted(said.group("section"))).lower()

        def under_it(match_name: Callable[[str], bool]) -> Callable[[dict[str, Any]], bool]:
            def test(entry: dict[str, Any]) -> bool:
                section = flatten(str(entry.get("section") or "")).lower()
                return bool(section and where in section) and any(
                    match_name(name) for name in names(entry)
                )

            return test

        # The label EXACTLY, before anything looser. The refusal offers
        # the page's own wording, so the phrase coming back names a label
        # in full — and "Movies" must not be answered by "Top Movies"
        # sitting in the same section, which is themoviedb.org's actual
        # shape and would refuse the very phrase we suggested.
        placed = pick(under_it(lambda name: name == what))
        if not placed:
            worded_in_section = re.compile(rf"(?:^|\W){re.escape(what)}(?:\W|$)")
            placed = pick(under_it(lambda name: bool(worded_in_section.search(name))))
        if placed:
            # Including "ambiguous": two things match BOTH the label and
            # the section, so no later rung can do better with a phrase
            # that is strictly less specific, and falling through would
            # report "is not on the page" about elements that are.
            return placed
        # Nothing sits under that section. Fall through with the phrase
        # WHOLE — never with the label alone.

    # 3. One element is NAMED for it — "Contact" for "Contact us", "Search"
    #    for "Search the site". At a word boundary, so "search" does not
    #    claim "Research & Innovations", and only when exactly one element
    #    answers to it.
    worded = re.compile(rf"(?:^|\W){re.escape(flat_wanted)}(?:\W|$)")
    named = pick(lambda e: any(worded.search(name) for name in names(e)))
    if named:
        return named

    # 4. The page does not NAME its search box; it is the only one there
    #    is. Only for the controls a page has exactly one of, and only
    #    when the plan asked for that kind of thing by its ordinary name.
    if _MEANS_A_SEARCH_BOX.search(flat_wanted):
        # A search box is rarely `type="search"`. Measured on
        # hindustantimes.com and clevelandclinic.org (2026-08-27): neither
        # landing page has one at all, and the boxes that do exist on the
        # pages behind them are ordinary text inputs whose only sign is the
        # word "search" in a placeholder or an id.
        #
        # Restricted to things that can be TYPED INTO, because a page that
        # has no box usually has a search BUTTON labelled "Search", and
        # filling a button is not a thing.
        def is_a_box(entry: dict[str, Any]) -> bool:
            kind = str(entry.get("input_type") or "").lower()
            role_now = str(entry.get("role") or "").lower()
            if role_now in ("link", "button") or kind in _NOT_TYPED_INTO:
                return False
            if kind == "search" or role_now == "searchbox":
                return True
            return any(_SAYS_SEARCH.search(name) for name in names(entry))

        return pick(is_a_box)
    return ""


async def _snapshot(plan: Plan, trace: Trace) -> None:
    """Refresh the ref map (and the page text) from the live page."""
    reply = await _act(plan.site, "snapshot", {})
    if not reply.get("ok"):
        raise ExecutionFailed(
            f"snapshot failed: {reply.get('error') or 'unknown'}",
            Reason.BROWSER_UNAVAILABLE,
            -1,
            trace,
        )
    refs = reply.get("ref_map") or {}
    trace.refs = {str(k): dict(v) for k, v in refs.items() if isinstance(v, dict)}
    # The page's links, by label, in the order the ref map lists them —
    # which is document order. This is the sequence a list of ITEMS is
    # read from: story titles, crate names, product rows are links, and
    # the adjacent text lines around them are row fragments and sidebar
    # navigation.
    trace.links = [
        label
        for entry in trace.refs.values()
        if str(entry.get("role") or "").lower() == "link"
        and (label := str(entry.get("label") or "").strip())
    ]
    texts = reply.get("page_text") or []
    if texts and not trace.page_text:
        # The snapshot's text is a DIGEST (≤40 items, each cut at 520
        # chars). It fills an empty trace so a read after an action has
        # something to look at, and it is marked as the partial copy it
        # is — never overwrites a full page already read.
        trace.page_text = "\n".join(str(t) for t in texts)
        trace.truncated = True
    trace.last_url = str(reply.get("url") or trace.last_url)


#: Total characters of repeat-structure worth keeping. Mirrors the daemon's
#: own budget; both exist because the per-group caps MULTIPLY.
_MAX_FENCE_CHARS = 256 * 1024


def _fences(reply: dict[str, Any]) -> list[list[list[str]]]:
    """The repeat-groups a `get_text` reply carried: groups of UNITS of cells.

    A unit is one row of the repeat — one story, one crate, one product —
    and its cells are that row's own text lines. The structure is kept
    rather than flattened because a list answer is one cell PER ROW, not
    five cells of the first row (measured on news.ycombinator.com,
    2026-08-27: a flat fence answered "the top 5 story titles" with the
    title, site, author, age and hide-link of story one — five real lines
    of the page, in order, and not the answer to the question).

    An older daemon does not send this at all; the reader then falls back
    to the blank-line rule, which is what it did before fences existed.
    """
    out: list[list[list[str]]] = []
    # A budget here as well as in the daemon. The daemon that sent this may
    # be older than this code — one was still serving the pre-rows shape
    # hours after that changed — and an unbounded payload does not merely
    # waste memory: it exceeds the socket reader's limit and kills the run.
    spent = 0
    for group in reply.get("collections") or []:
        if spent >= _MAX_FENCE_CHARS:
            break
        if not isinstance(group, dict):
            continue
        units: list[list[str]] = []
        raw_units = group.get("units")
        if not isinstance(raw_units, list):
            # A daemon from before this shape existed sends `units` as a
            # COUNT. It is still running in someone's session — including
            # ours, mid-change — and a fence is never worth an exception.
            continue
        for unit in raw_units:
            if not isinstance(unit, list):
                continue
            cells = [str(c) for c in unit if str(c).strip()]
            if cells:
                units.append(cells)
                spent += sum(len(c) for c in cells)
                if spent >= _MAX_FENCE_CHARS:
                    # Inside the group as well as between groups: one
                    # pathological repeat can hold two hundred rows on its
                    # own, and a budget a single group can overrun is not a
                    # budget.
                    break
        if len(units) >= 3:
            out.append(units)
    return out


#: Typography a page renders and a model retypes. A planner asked to copy
#: a line verbatim writes `"The world as we have created it"` where the
#: page wrote `“The world as we have created it”` — the same line to every
#: reader, and a different string to `==`. Measured on quotes.toscrape.com
#: (2026-08-27): the first attempt was refused for exactly this and the
#: second, having quoted the page's own curly form, verified.
_TYPOGRAPHY = str.maketrans(
    {
        "\u201c": '"', "\u201d": '"', "\u201e": '"', "\u2033": '"',
        "\u2018": "'", "\u2019": "'", "\u201a": "'", "\u2032": "'",
        "\u2013": "-", "\u2014": "-", "\u2212": "-", "\u00ad": "",
        "\u2026": "...", "\u00a0": " ",
    }
)


def _loose(text: str) -> str:
    """A line as a reader sees it: for MATCHING only, never for output.

    Whatever is returned to the user is still the page's own line, taken
    from the page's own text — this only decides which line that is.
    """
    return flatten(text.translate(_TYPOGRAPHY)).lower()


def _cell_in(unit: list[str], line: str) -> int:
    """Which cell of this row is `line`, or -1.

    Exact first. Failing that, the ONE cell that contains it: the named
    item may be part of its line — quotes.toscrape renders a quote and its
    author as one line, and a plan naming "by Albert Einstein (about)" is
    naming that line correctly, just not wholly. Two containing cells
    would be a guess about which column was meant.
    """
    want = _loose(line)
    flat = [_loose(cell) for cell in unit]
    exact = next((i for i, cell in enumerate(flat) if cell == want), -1)
    if exact >= 0:
        return exact
    # A line the planner was SHOWN CUT SHORT. `_lists_on_this_page` trims
    # each column head at 160 characters, appends "...", and instructs the
    # planner to "copy it cut short, exactly as printed" — and then this
    # matched exactly-or-contained, so the string with its literal "..."
    # was in neither. Every list whose first cell ran past 160 characters
    # was unreadable, and the refusal blamed the page for not containing a
    # line the page does contain. On news and shop listings that is the
    # norm (found independently by two reviewers, 2026-08-27).
    if want.endswith("..."):
        stem = want[:-3].strip()
        if stem:
            starts = [i for i, cell in enumerate(flat) if cell.startswith(stem)]
            if len(starts) == 1:
                return starts[0]
    hits = [i for i, cell in enumerate(flat) if want in cell]
    return hits[0] if len(hits) == 1 else -1


def _candidates(
    groups: list[list[list[str]]], line: str
) -> list[tuple[list[list[str]], int, int]]:
    """Every (group, first row, column) that `line` could be naming.

    A page can hold the same value in two different lists —
    stackexchange.com names Stack Overflow in the communities list AND in
    the footer's product links — so this does not choose. It collects, and
    the caller decides by walking each against the page.

    The GROUP and the ROW travel with the column because a second field of
    the same rows has to come from the same place: "the names and prices"
    is two columns of one list, not two lists that happen to be nearby.
    """
    found: list[tuple[list[list[str]], int, int]] = []
    for units in groups:
        # Scan DOWN the rows until the named cell is found: the anchor may
        # be an item partway into the list, not its first row.
        for row_i, unit in enumerate(units):
            col = _cell_in(unit, line)
            if col >= 0:
                found.append((units, row_i, col))
                break
    return found


def _column(units: list[list[str]], row_i: int, col: int) -> list[str]:
    """One column of a group, from `row_i` down."""
    return [row[col] for row in units[row_i:] if col < len(row)]


def _columns_of(groups: list[list[list[str]]], line: str) -> list[list[str]]:
    """Every column that `line` could be naming, one per repeat-group."""
    return [_column(u, r, c) for u, r, c in _candidates(groups, line)]


def _column_of(groups: list[list[list[str]]], line: str) -> list[str] | None:
    """Whether ANY list on this page has a column starting at `line`.

    Used to decide if a plan can be checked at all. Which of them is meant
    is a question for `_fenced_block`, which has the page to compare against.
    """
    columns = _columns_of(groups, line)
    return max(columns, key=len) if columns else None


def _walk(lines: list[str], start: int, wanted: int, column: list[str]) -> tuple[list[str], int]:
    """Follow one column down the page: its cells, in order, after `start`.

    Returns what was found and where it finished. A cell the page does not
    carry ends the walk rather than being stepped over — stepping over it
    would join row 1 to row 3 and call them adjacent.
    """
    block: list[str] = []
    cursor = start + 1
    last = start
    for cell in column:
        want = _loose(cell)
        found = next(
            (i for i in range(cursor, len(lines)) if _loose(lines[i]) == want),
            -1,
        )
        if found < 0:
            break
        block.append(lines[found])
        cursor, last = found + 1, found
        if len(block) == wanted:
            break
    return block, last


def column_complaint(groups: list[list[list[str]]], first: str) -> str:
    """Why this list read cannot be checked, or "" if it can.

    A page that repeats has rows, and rows have COLUMNS. Reading one
    without saying which column is a guess, and saying a column the page
    does not have is a different guess. Both are refusals rather than
    answers, and both are decided here so the decision can be tested
    without a browser.
    """
    if not groups:
        return ""
    if not first.strip():
        return (
            "this page's list has several columns — name the first item of "
            "the one you want in `first`, copied exactly from the page"
        )
    if _column_of(groups, first) is None:
        return f"{first!r} is not a line of any list this page repeats"
    return ""


def _fenced_rows(
    lines: list[str],
    start: int,
    wanted: int,
    groups: list[list[list[str]]],
    first: str,
    also: str,
) -> tuple[list[str], list[str]] | None:
    """Two fields of the SAME rows: the named column, and one beside it.

    "The names and prices", "the titles, metascores and critic counts" —
    five of browser-use's twenty read tasks ask for several fields per row,
    and a one-column answer cannot answer any of them. The cells were
    already there: a repeat-group keeps every row whole, and the second
    field is another column of the rows the first one walked.

    Both halves stay the page's own lines. Nothing is joined here — the
    verifier checks each column against the page separately, and only the
    ANSWER puts a row's two fields together.
    """
    for units, row_i, col in _candidates(groups, first):
        other = _cell_in(units[row_i], also)
        if other < 0 or other == col:
            continue
        primary = _column(units, row_i, col)
        secondary = _column(units, row_i, other)
        got: list[str] = []
        extra: list[str] = []
        cursor = start + 1
        for index, (head, tail) in enumerate(zip(primary, secondary, strict=False)):
            at = next(
                (i for i in range(cursor, len(lines)) if _loose(lines[i]) == _loose(head)),
                -1,
            )
            if at < 0:
                break
            # The second field must sit between its own row's first field
            # and the NEXT ROW'S — otherwise "Blazer" pairs with whatever
            # price the page shows next and every row is off by one. The
            # boundary is the next row's head, which is the only thing that
            # marks where this row ends.
            nxt = primary[index + 1] if index + 1 < len(primary) else ""
            stop = (
                next(
                    (j for j in range(at + 1, len(lines)) if _loose(lines[j]) == _loose(nxt)),
                    len(lines),
                )
                if nxt
                else len(lines)
            )
            beside = next(
                (j for j in range(at, stop) if _loose(lines[j]) == _loose(tail)),
                -1,
            )
            if beside < 0:
                break
            got.append(lines[at])
            extra.append(lines[beside])
            cursor = at + 1
            if len(got) == wanted:
                break
        if got:
            return got, extra
    return None


def _fenced_block(
    lines: list[str],
    start: int,
    wanted: int,
    groups: list[list[list[str]]],
    first: str = "",
) -> list[str] | None:
    """The `wanted` lines after `start` that are one cell each of successive
    rows of ONE repeat-group.

    The group is chosen by the first non-blank line after the anchor: it is
    the list the anchor introduces, or the list the anchor is an item of.
    Each returned line must then still be found on the page, in order,
    after the previous one — the group decides the SHAPE of the answer,
    the page remains the source of every line in it.

    Returns None when no group covers that line, and the caller keeps the
    blank-line rule it had before.
    """
    if not groups:
        return None
    # `first` names the COLUMN: a story row holds a rank, a title, a score
    # and an author, and the line that merely comes next is whichever of
    # them the page prints first. Falling back to that is better than
    # nothing on a plain list, and wrong on a rich one — which is why the
    # planner is asked for the first item by name.
    seed = first.strip() or next((ln for ln in lines[start + 1 :] if ln), "")
    if not seed:
        return None
    best: list[str] | None = None
    best_key: tuple[int, int] | None = None
    for column in _columns_of(groups, seed):
        block, last = _walk(lines, start, wanted, column)
        if not block:
            continue
        # More rows is a better reading of the page. Between two readings
        # of the same length, the one that finishes SOONER is the list the
        # anchor introduced rather than one further down: on
        # stackexchange.com both the communities list and the footer's
        # product links begin "Stack Overflow", and only the walk can tell
        # them apart (2026-08-27).
        key = (len(block), -last)
        if best_key is None or key > best_key:
            best, best_key = block, key
    return best


def _same_page(a: str, b: str) -> bool:
    """Do these two URLs name the page the planner actually looked at?

    Compared as STRINGS, they usually did not: `looked.url` is the task's
    site as the user wrote it, and the plan writes whatever the model
    wrote — most often the same address with a trailing slash. A mismatch
    silently costs the run the one guarantee that matters here, that the
    plan and the read see the SAME page.

    Measured on dailymail.co.uk (2026-08-27): the planner picked a
    headline off the pre-look, the executor re-fetched a homepage that
    rotates its lead story every few minutes, and the anchor was gone.
    That reads as drift and is really a stale plan.
    """
    def bare(url: str) -> str:
        cleaned = url.split("#", 1)[0].strip()
        return cleaned.rstrip("/").lower()

    return bool(a) and bare(a) == bare(b)


async def _get_past_any_wall(
    plan: Plan,
    trace: Trace,
    allow_actions: bool,
    may_act: Callable[..., str] | None,
    evidence: str = "",
) -> bool:
    """Dismiss a cookie/region/age wall standing in front of the page.

    Half the commercial web puts one between a visitor and the content,
    and a person clicks through it without thinking. Rokan could not:
    zara.com never got past "SELECT YOUR LOCATION … CONTINUE", and
    newegg.com's search ran against a page still showing "Change Country
    … GO TO CANADA … STAY AT NEWEGG.COM" (2026-08-27). Neither is bot
    detection and neither is a login.

    NEVER on a host the user is signed in to. There, `policy` counts every
    click as a write needing the human's grant, and this one has nobody's
    grant — so a signed-in host is left exactly as it was found, wall and
    all. What it may press is decided in `gates`, which prefers refusing
    consent over granting it and never leaves the site.

    Best-effort throughout: any failure leaves the page untouched, and the
    read that follows fails the way it would have failed anyway.
    """
    # Decided from the text we already hold, so an ordinary page costs
    # nothing: no snapshot, no extra daemon round-trip, and the sequence of
    # commands a passing run issues is unchanged.
    #
    # KNOWN LIMIT, measured rather than assumed: a wall that renders AFTER
    # the fetch resolves is invisible here. zara.com is one — `login.fetch`
    # returns "SKIP TO MAIN CONTENT" while a location modal fills the
    # screen a moment later. Catching that needs a snapshot on every
    # navigate, which changes the command sequence for every run in order
    # to help a few, and the honest place for it is a read that has already
    # failed to find its anchor.
    # A READ CLASS MAY NOT CLICK. `execution_policy` says so — "Read
    # classes: nothing beyond navigate/read, ever" — and this walked around
    # it: the first version ran after every navigate, so a "what does my
    # cart cost" task pressed Continue on a checkout page. Reproduced from
    # an adversarial review, 2026-08-27, and it is the worst kind of defect
    # this product can have, because the click is invisible in the answer.
    #
    # Belt as well as braces: the ONE caller is the click/fill branch,
    # which already requires `allow_actions`, and this refuses again here
    # so that a future caller cannot reintroduce the same hole.
    if not allow_actions:
        return False
    # `evidence` closes the known limit stated just above: a wall that
    # renders AFTER the fetch is invisible in `page_text`, but it is not
    # invisible to the click that just hit it — the daemon names what
    # covered the element, and those words are better evidence of a gate
    # than a page text taken before the gate existed.
    seen = evidence or trace.page_text
    if not seen or not gates.looks_like_a_gate(seen):
        return False
    if _signed_in(plan.site):
        return False
    snapped = await _act(plan.site, "snapshot", {})
    if not snapped.get("ok"):
        return False
    shown = "\n".join(str(t) for t in (snapped.get("page_text") or []))
    refs = {
        str(k): dict(v)
        for k, v in (snapped.get("ref_map") or {}).items()
        if isinstance(v, dict)
    }
    labels = [str(e.get("label") or "").strip() for e in refs.values()]
    press = gates.press_to_get_past(labels, f"{shown}\n{trace.page_text}")
    if not press:
        return False
    trace.refs = refs
    ref = _resolve_ref(trace, press)
    if ref in ("", "ambiguous"):
        return False
    # THE SAME TWO GUARDS EVERY OTHER CLICK PASSES. This was the one action
    # in the executor outside both, and it fires precisely when the plan
    # did not understand the page — the worst moment to be acting without
    # a check. Four reviewers found it independently (2026-08-27).
    entry = refs.get(ref) or {}
    denied = (
        may_act(
            str(entry.get("label") or press),
            "click_ref",
            str(entry.get("role") or ""),
            str(entry.get("href") or ""),
        )
        if may_act is not None
        else ""
    )
    if denied:
        return False
    expect_host = _expect_host(plan.site)
    if not expect_host:
        return False
    # `expect_host` matters more here than anywhere: a consent dialog is
    # very often a third-party CMP in a cross-origin iframe, and the
    # snapshot deliberately walks those frames. Without it this would be
    # the one click that lands wherever the page likes.
    clicked = await _act(plan.site, "click_ref", {"ref": ref, "expect_host": expect_host})
    if not clicked.get("ok"):
        return False
    trace.refs = {}
    trace.said.append(f"dismissed the {press!r} wall")
    await _refresh_text(plan, trace)
    return True


def _signed_in(site: str) -> bool:
    """Does the vault hold a login for this host? Any doubt answers YES."""
    try:
        from rokan_agent.core.proven import vault  # noqa: PLC0415

        host = vault.normalize_host(site)
        return vault.get(host) is not None or vault.find_sibling(host) is not None
    except Exception:  # noqa: BLE001 — an unreadable vault means assume signed in
        return True


async def _refresh_text(plan: Plan, trace: Trace) -> None:
    """After a click the page is a different page; read it before anything
    downstream checks it."""
    reply = await _act(plan.site, "get_text", {})
    if reply.get("ok"):
        trace.page_text = str(reply.get("text") or "")
        trace.truncated = bool(reply.get("truncated"))
        trace.last_url = str(reply.get("url") or trace.last_url)
        trace.collections = _fences(reply)


def _presses_enter(text: str) -> bool:
    """Did the plan mean the Enter KEY? A newline, or the word for it."""
    return "\n" in text or "\r" in text or text.strip().lower() in {"enter", "return"}


def _w5(reply: dict[str, Any]) -> dict[str, bool | None]:
    """The daemon's report, tri-state on EVERY field: `fill_ref` and `type`
    report only `dom_changed`, and "not measured" must not be written down
    as `False` — the admission rule reads these as facts."""
    return {
        key: (None if reply.get(key) is None else bool(reply.get(key)))
        for key in ("url_changed", "dom_changed", "new_tab")
    }


#: Address-shaped text. Deliberately NOT added to `redact`, which is about
#: SECRETS and is called on answers in sixteen places: a task may legitimately
#: ask for a contact address, and masking it there would break the answer.
#: Here the text is an accident — whatever happened to sit over a button —
#: and nobody asked for it.
_AN_ADDRESS = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")


def _said_safely(detail: str) -> str:
    """A click-failure diagnosis, minus anything personal it picked up.

    `covered_by` is whatever text was over the target. On a signed-in page
    that is very often a header reading "Signed in as someone@example.com",
    and this string travels into the failure evidence that a person and a
    model both read.
    """
    return _AN_ADDRESS.sub("[address]", redact(detail))


def _count_ref_health(trace: Trace, reply: dict[str, Any]) -> None:
    """Count one ref-addressed action, succeeded or not.

    Called before the ok-check, because the check raises. Measuring only
    the actions that worked counts refs that survived long enough to be
    clicked — the one population guaranteed to look healthy.
    """
    if reply.get("ref_recovered") is None:
        return
    trace.refs_addressed += 1
    if reply["ref_recovered"]:
        trace.refs_healed += 1


def _action_record(index: int, verb: str, reply: dict[str, Any]) -> dict[str, Any]:
    """One `trace.actions` entry.

    `ref_recovered` is present only when the daemon MEASURED it — a click
    or fill that addressed a ref. Absent means not measured, the same
    distinction `w5` draws with None, and the same reason: an action that
    addressed no ref has not got a healthy ref, it has got no ref.
    """
    record: dict[str, Any] = {"step": index, "verb": verb, "w5": _w5(reply)}
    if reply.get("ref_recovered") is not None:
        record["ref_recovered"] = bool(reply["ref_recovered"])
    return record


def resolve_secret(reference: str) -> str:
    """Turn ``vault://host/field`` into the credential, at fill time.

    Refuses anything else — a literal that reached here would mean the
    planner held a secret, which is the thing the IR exists to prevent.
    """
    if not reference.startswith(SECRET_SCHEME):
        raise ValueError("not a vault reference")
    remainder = reference[len(SECRET_SCHEME) :]
    host, _, wanted = remainder.partition("/")
    if not host or wanted not in {"username", "password"}:
        # `totp` is deliberately NOT resolvable here. A one-time code is
        # generated at the moment of typing by the proven login path; handing
        # a seed to a plan step would let a stale plan carry it.
        raise ValueError(f"unknown secret reference {reference!r}")
    record = vault.get(vault.normalize_host(host))
    if record is None:
        raise ExecutionFailed(f"no stored login for {host}", Reason.NO_CREDENTIAL, -1)
    value = record.username if wanted == "username" else record.password
    if not value:
        raise ExecutionFailed(f"{host} has no stored {wanted}", Reason.NO_CREDENTIAL, -1)
    return value


#: A value the CALLER supplies at run time — `param://recipient`. Same idea
#: as `vault://`: the plan names the slot, never the value, so one verified
#: operation replays for every recipient and the value never enters the
#: stored plan, the key, or the ledger.
PARAM_SCHEME = "param://"


def _resolved_args(step: Step, params: Mapping[str, str] | None = None) -> dict[str, Any]:
    """Vault references resolved; everything else passed through by SHAPE.

    `str(value)` on every argument was fine while every argument was a
    scalar. It is not fine now that a read step may carry a LIST of
    candidate anchors: the list arrived as its own repr, and a helper
    iterating it walked the characters — the executor picked `'['` as the
    anchor and read the line that happened to contain a bracket. Caught by
    the first test of the feature, which is what tests are for.
    """
    out: dict[str, Any] = {}
    for key, value in step.args.items():
        if isinstance(value, str) and value.startswith(SECRET_SCHEME):
            out[key] = resolve_secret(value)
        elif isinstance(value, str) and value.startswith(PARAM_SCHEME):
            name = value[len(PARAM_SCHEME) :].strip()
            if not name or params is None or name not in params:
                raise ExecutionFailed(
                    f"this operation needs a value for {name or '?'!r} — pass it in params",
                    Reason.ABSTAINED_LOW_CONFIDENCE,
                    -1,
                )
            out[key] = str(params[name])
        elif isinstance(value, list):
            # Secrets inside a list are refused by `ir.validate` before a
            # plan ever reaches here, so this needs no resolution — only to
            # stop being flattened into a string.
            out[key] = [str(item) for item in value]
        else:
            out[key] = str(value)
    return out


@dataclass(frozen=True, slots=True)
class AlreadyLooked:
    """A page fetched before planning, offered to the plan that follows.

    `_lines_worth_reading` loads the page to choose which lines the planner
    sees, and the plan's first step then loads the same page again. That
    second load is pure cost: measured on the fixture, 13,501 ms cold with
    it and 9,339 ms without when this was last in place.

    Only the FIRST navigation may be answered from here, and only when the
    URL matches exactly. A plan that navigates onward is doing so because
    the first page told it to, and answering that from a stale read would
    be showing it the page it just left.
    """

    url: str
    text: str
    truncated: bool = False
    #: Was the pre-fetch signed in? Travels with the page, because the plan
    #: reuses this text instead of fetching again — without it every
    #: look-first task looked PUBLIC to the account-scoped guard, and the
    #: fixture's ten account-scoped tasks began refusing (measured
    #: 2026-08-24, the same hour the guard shipped).
    authenticated: bool = False


async def _first_past_the_cap(site: str, candidates: list[str]) -> tuple[str, str] | str | None:
    """The first candidate the whole page holds on exactly one line.

    Walked in the plan's order, so a primary the page uses once still
    outranks every alternative; a primary the page uses TWICE (nodejs.org:
    `Type: <integer> Default:` names both `poolSize` and
    `INSPECT_MAX_BYTES`) is passed over for the next candidate, exactly as
    the verifier would have refused it. The three outcomes of
    `_find_past_the_cap` are kept apart: the pair when one line answered,
    "" when the whole page was walked and no candidate answered, None when
    the daemon could not be asked — nothing was learned, and the caller
    keeps what the shipped part gave.
    """
    for candidate in candidates:
        found = await _find_past_the_cap(site, candidate)
        if found is None:
            return None
        if found:
            return candidate, found
    return ""


def _anchor_the_page_has(args: dict[str, Any], page_text: str) -> str:
    """The first candidate anchor this page actually contains.

    The plan may carry ordered alternatives; the PAGE decides. Falls back
    to the primary anchor when none match, so the failure that follows is
    the same honest `drift_detected` as before — with the primary named,
    which is what the user asked about.

    Matching is flattened and case-insensitive, exactly as the read below
    does it, or a candidate could be chosen here and then not found there.
    """
    primary = str(args["contains"])
    candidates = [primary, *(str(a) for a in (args.get("alternatives") or []))]
    lowered = [(candidate, flatten(candidate).lower()) for candidate in candidates]
    flat_lines = [flatten(ln).lower() for ln in page_text.splitlines()]
    for candidate, flat in lowered:
        if any(flat in line for line in flat_lines):
            return candidate
    return primary


async def execute(
    plan: Plan,
    looked: AlreadyLooked | None = None,
    said: str = "",
    *,
    allow_actions: bool = False,
    may_act: Callable[[str, str, str, str], str] | None = None,
    params: Mapping[str, str] | None = None,
    force_browser: bool = False,
) -> Trace:
    """Walk the plan. Raise ExecutionFailed with a reason, or return a Trace.

    The first navigation goes through ``login.fetch``, which is the proven
    path: it signs in when the site asks, handles TOTP, and reuses the
    session on later runs. Everything after works on the text that returned.

    ``allow_actions`` lets ``click_ref`` / ``fill_ref`` / ``type`` /
    ``snapshot`` reach the daemon. Off by default — the read classes never
    act, and a verb with no policy behind it must not run on a real account.
    ``may_act(label, verb) -> ""`` or a reason is the caller's policy
    (`policy.may_act(host)`): consulted with the RESOLVED target's label
    immediately before a click or fill reaches the daemon — the page's
    own word for what the button does, not the plan's. ``params`` binds
    ``param://`` values at fill time, the way the vault binds secrets.
    """
    started = time.monotonic()
    trace = Trace()

    for index, step in enumerate(plan.steps):
        args = _resolved_args(step, params)

        if step.verb is Verb.NAVIGATE:
            if (
                looked is not None
                and not trace.page_text
                and _same_page(args["url"], looked.url)
            ):
                trace.page_text = looked.text
                trace.truncated = looked.truncated
                trace.authenticated = looked.authenticated
                trace.last_url = looked.url
                trace.said.append(step.says)
                trace.steps_run += 1
                continue
            # A public page needs no browser (browser-harness's own first
            # rule, measured at 10-25x on our own task pages). Eligibility
            # is a correctness gate, not a preference: never for a host we
            # hold a login for, never for a question about the user's
            # account, never for a non-public address.
            # OFF THE LOOP. `getaddrinfo` has no timeout and the fetch has
            # a 12 s one; under `rokan-do mcp` this is the same event loop
            # that serves the stdio transport, so one blackholed site froze
            # the whole server (CODE REVIEW, MEDIUM).
            # `force_browser`: the caller already tried the HTTP text and
            # it failed the postcondition — server HTML splits a table row
            # into cells, so "relation size" stood alone where the render
            # says "Maximum relation size 32 TB" (2026-08-25, the Postgres
            # replay that retired a proven operation). The optimisation
            # must never be the verdict.
            if (
                not force_browser
                and httpread.plan_may_use_http(plan)
                and await asyncio.to_thread(httpread.eligible, args["url"], said)
            ):
                quick = await asyncio.to_thread(httpread.read, args["url"])
                if quick is not None:
                    trace.page_text = quick
                    # The fast path is not the blind one: the same
                    # repeat-groups the browser computes from the live DOM,
                    # computed here from the markup we just parsed.
                    trace.collections = fences.groups(httpread.last_html(args["url"]))
                    # Honest about the cap (CODE REVIEW, MEDIUM).
                    trace.truncated = httpread.was_capped(quick)
                    trace.authenticated = False
                    trace.transport = "http"
                    trace.last_url = args["url"]
                    trace.said.append(step.says)
                    trace.steps_run += 1
                    continue
            fetched = await login.fetch(args["url"], reload=True)
            trace.transport = "browser"
            if not fetched.ok:
                raise ExecutionFailed(
                    fetched.message or "the page did not load",
                    _reason_for(fetched.reason),
                    index,
                    trace,
                )
            trace.page_text = str(fetched.text or "")
            trace.truncated = bool(getattr(fetched, "truncated", False))
            trace.last_url = args["url"]
            # The session state of the page we are actually reading. Not
            # OR-ed across steps: what matters is whether the page the
            # value came off was behind the login.
            trace.authenticated = bool(getattr(fetched, "session_backed", False))

        elif step.verb is Verb.GET_TEXT:
            if not trace.page_text:
                raise ExecutionFailed(
                    "get_text before any page was reached",
                    Reason.TOO_MANY_STEPS,
                    index,
                    trace,
                )

        elif step.verb is Verb.READ_BLOCK:
            # The page's own lines, in the page's own order. Nothing is
            # summarised, re-ordered or joined: whatever comes back must
            # still be findable as a contiguous run of the page, which is
            # the only way a LIST can be proved rather than asserted.
            after = str(args.get("after") or "")
            first_item = str(args.get("first") or "").strip()
            also_item = str(args.get("also") or "").strip()
            try:
                wanted = int(str(args["lines"]))
            except ValueError:
                wanted = 0
            if not 1 <= wanted <= MAX_BLOCK_LINES:
                raise ExecutionFailed(
                    f"a block of {args['lines']!r} lines is not a list anyone asked for",
                    Reason.ABSTAINED_LOW_CONFIDENCE,
                    index,
                    trace,
                )
            kind = str(args.get("kind") or "line").lower()
            # Structure first. `kind="link"` exists because raw adjacent
            # text lines used to give back row fragments — but a story row
            # holds five links (title, site, author, age, hide) exactly as
            # it holds five text lines, so link mode has the same defect
            # and no way to fix it: a link label is not a row. When the
            # plan named the first item AND the page says where it repeats,
            # the read goes through the structure that can prove it.
            if not trace.collections:
                probe = await _act(plan.site, "get_text", {"collections": True})
                if probe.get("ok"):
                    trace.collections = _fences(probe)
                    # And the TEXT that goes with them. The fence's cells
                    # are lines of the daemon's render; the page text may
                    # have come from `login.fetch`, which is a DIFFERENT
                    # render. Measured on quotes.toscrape.com (2026-08-27):
                    # the daemon shows the quote and its author as two
                    # lines, login.fetch as one, so a column found in the
                    # cells could not be found in the text and the read
                    # fell back to reading adjacent lines — quote, tags,
                    # quote. Two renders, one of them silent, is how a list
                    # gets read off a page nobody looked at.
                    probe_text = str(probe.get("text") or "")
                    if probe_text.strip():
                        trace.page_text = probe_text
                        trace.truncated = bool(probe.get("truncated"))
            complaint = column_complaint(trace.collections, first_item)
            if complaint:
                # Measured on quotes.toscrape.com (2026-08-27): a plan with
                # no `first` answered "the first 5 authors" with Login,
                # (about), change, deep-thoughts, thinking — five real link
                # labels in page order, checkable against nothing.
                raise ExecutionFailed(
                    complaint,
                    Reason.ABSTAINED_LOW_CONFIDENCE
                    if not first_item
                    else Reason.DRIFT_DETECTED,
                    index,
                    trace,
                )
            if trace.collections:
                # The structure can prove a line; it cannot prove a link
                # label, which is a fragment of a row rather than a row.
                kind = "line"
            if kind == "link":
                if not trace.links:
                    await _snapshot(plan, trace)
                lines = [ln for ln in trace.links if ln.strip()]
            else:
                # Blank lines are kept as BOUNDARY markers, not dropped: a
                # rendered page separates its blocks with them, and a run
                # that crosses one starts in a results list and finishes in
                # the footer. The anchor is still found anywhere on the
                # page; only the rows after it stop at the first gap (Opus
                # review F6).
                lines = [ln.strip() for ln in trace.page_text.splitlines()]
            flat_after = flatten(after).lower()
            start = (
                next(
                    (
                        i
                        for i, ln in enumerate(lines)
                        if ln and flat_after in flatten(ln).lower()
                    ),
                    -1,
                )
                if flat_after
                else -1
            )
            if start < 0 and first_item:
                # `after` is a HINT — the line the rows sit under. The first
                # item is the list itself, and it is the thing the plan was
                # asked to copy exactly. Measured on news.ycombinator.com
                # (2026-08-27): the plan anchored on "Hacker News", the two
                # renderings of that header differ by a tab, and a run that
                # knew the first story by name failed at the door.
                flat_first = flatten(first_item).lower()
                found = next(
                    (i for i, ln in enumerate(lines) if ln and flat_first in flatten(ln).lower()),
                    -1,
                )
                if found >= 0:
                    # -1 when the list opens the page: the walk begins at
                    # `start + 1`, so the first row is still included.
                    start = found - 1
            if start < 0:
                raise ExecutionFailed(
                    f"{after!r} is not on the page" + _cut_off(trace),
                    Reason.DRIFT_DETECTED,
                    index,
                    trace,
                )
            if kind == "link":
                block = lines[start + 1 : start + 1 + wanted]
            else:
                # The fence was fetched above, before the mode was even
                # decided. It knows that the crates.io owners list ends
                # where the categories begin, and that the whole Hacker
                # News front page is one list with no gap in it — neither
                # of which a blank line can say.
                paired = (
                    _fenced_rows(lines, start, wanted, trace.collections, first_item, also_item)
                    if also_item
                    else None
                )
                fenced: list[str] | None
                if paired is not None:
                    block, trace.block_extra = paired
                    fenced = block
                else:
                    fenced = _fenced_block(
                        lines, start, wanted, trace.collections, first_item
                    )
                    block = fenced if fenced is not None else []
                if fenced is None:
                    block = []
                    for row in lines[start + 1 :]:
                        if not row:
                            break
                        block.append(row)
                        if len(block) == wanted:
                            break
            if len(block) < wanted:
                raise ExecutionFailed(
                    f"the page shows {len(block)} lines after {after!r}, not {wanted}",
                    Reason.DRIFT_DETECTED,
                    index,
                    trace,
                )
            trace.block = block
            trace.block_kind = kind
            trace.read[after] = " · ".join(block)

        elif step.verb is Verb.READ_VALUE:
            primary = str(args["contains"])
            candidates = [primary, *(str(a) for a in (args.get("alternatives") or []))]
            marker = _anchor_the_page_has(args, trace.page_text)
            # Case-insensitively, because a model writing a plan copies the
            # user's phrasing: asked "how much usage have I used", it emits
            # `contains="usage"` against a page that says "Usage this month".
            # Measured over one pass of the eval set, exact matching cost a
            # model rung on five tasks out of six — one of them all the way
            # to the largest model — for nothing but a capital letter.
            # Flattened on both sides. The page may hold a NON-BREAKING
            # space where the model wrote an ordinary one — measured on
            # nodejs.org, where the answer line is
            # `Type: <integer>\xa0Default: 65536` — and a faithful
            # quotation that cannot be found is the worst kind of miss.
            flat_marker = flatten(marker).lower()
            line = next(
                (
                    ln.strip()
                    for ln in trace.page_text.splitlines()
                    if flat_marker in flatten(ln).lower()
                ),
                "",
            )
            if line and marker != primary and trace.truncated and trace.transport == "http":
                # An alternative was chosen only because the primary is not
                # in the part we were shipped — and the part was cut. Let
                # the browser, which has the whole page, decide instead.
                line = ""
            if not line and trace.transport == "http":
                # The fast path could not answer, so it was not an answer.
                # Re-read through the browser and try once more: JS-rendered
                # values, cookie walls and consent gates all look like this,
                # and the browser is what they need. Costs the fetch we just
                # saved; keeps accuracy identical by construction.
                refetched = await login.fetch(trace.last_url or plan.site, reload=True)
                if refetched.ok:
                    trace.page_text = str(refetched.text or "")
                    trace.truncated = bool(getattr(refetched, "truncated", False))
                    trace.authenticated = bool(getattr(refetched, "session_backed", False))
                    trace.transport = "browser"
                    marker = _anchor_the_page_has(args, trace.page_text)
                    flat_marker = flatten(marker).lower()
                    line = next(
                        (
                            ln.strip()
                            for ln in trace.page_text.splitlines()
                            if flat_marker in flatten(ln).lower()
                        ),
                        "",
                    )
            if trace.truncated and marker != primary:
                # The alternatives exist for a page that does not USE the
                # primary phrase — not for a page that was cut before it.
                # Measured on nodejs.org: the reference line `Type:
                # <integer> Default: 65536` sits past 32,000 characters, the
                # alternative "poolSize that is used as a pool" sits in the
                # first paragraph, and the read settled for the paragraph —
                # verified (it holds a number) and wrong on every replay.
                # The page decides over the WHOLE page, in the plan's
                # order: every candidate the shipped part lacks is asked of
                # the browser first, and the first one line answers.
                earlier = candidates[: candidates.index(marker)]
                past = await _first_past_the_cap(plan.site, earlier)
                if isinstance(past, tuple):
                    # The line came from the whole page, so the "value may
                    # be past the cut" caveat would contradict the read.
                    trace.searched_whole_page = True
                    marker, line = past
                    flat_marker = flatten(marker).lower()
                    trace.page_text = f"{trace.page_text}\n{line}"
            if not line and trace.truncated:
                # The page was longer than what came back, so "not found"
                # may only mean "not in the part we were shipped". Ask the
                # browser, where the whole page is, before concluding
                # anything about the site.
                # Every candidate, in the plan's order — httpd.apache.org's
                # `MaxKeepAliveRequests` names a directive on many lines of
                # a 150,000-character page, while its alternative
                # `MaxKeepAliveRequests 100` names the one line asked for
                # (head-to-head, 2026-08-25).
                past = await _first_past_the_cap(plan.site, candidates)
                trace.searched_whole_page = past is not None
                if isinstance(past, tuple):
                    marker, line = past
                    flat_marker = flatten(marker).lower()
                if line:
                    # Append it to the page text, because everything
                    # downstream checks THAT.
                    #
                    # Without this the rescue was worse than useless: the
                    # executor read a line the verifier could not find, so
                    # `verify_value_present` refused every rescued read with
                    # "is not on the page that was reached" — a true
                    # sentence about the truncated copy and a false one
                    # about the page. Measured on docs.python.org, where
                    # the value sits past 30,000 characters.
                    #
                    # The line came off the live page moments ago through
                    # the same browser, so this text is not a claim — it is
                    # the page, in the part we had to go and get.
                    trace.page_text = f"{trace.page_text}\n{line}"
            if not line:
                # Not a crash and not a guess: the value the plan expected is
                # not on the page it reached. The verifier will refuse, and
                # the caller decides whether to replan.
                raise ExecutionFailed(
                    f"{marker!r} is not on the page" + _cut_off(trace),
                    Reason.DRIFT_DETECTED,
                    index,
                    trace,
                )
            if not _beside(marker, line):
                # A bare label with its value on the next line. The pair is
                # joined HERE, not only in the verifier, because the answer
                # the person reads comes from this line.
                #
                # Measured on redis.io: verifying the pair while reporting
                # only the label showed "Time complexity:" as the answer and
                # called it verified. A check that passes on evidence the
                # user never sees is worse than the failure it replaced.
                page_lines = trace.page_text.splitlines()
                for position, candidate in enumerate(page_lines):
                    if candidate.strip() == line.strip():
                        below = value_after_label(page_lines, position)
                        if below:
                            line = f"{line.strip()} {below}"
                        break
            trace.read[marker] = line

        elif step.verb is Verb.ASSERT_CONTAINS:
            present = flatten(args["contains"]).lower() in flatten(trace.page_text).lower()
            if not present and trace.truncated:
                # Same rescue as the read step, and a weaker test: this
                # asks whether the text EXISTS, so several matching lines
                # answer it as well as one. Ambiguity is the read's
                # problem, not presence's.
                found_anywhere = await _exists_past_the_cap(plan.site, args["contains"])
                trace.searched_whole_page = found_anywhere is not None
                present = bool(found_anywhere)
            if not present:
                raise ExecutionFailed(
                    f"expected {args['contains']!r} on the page" + _cut_off(trace),
                    Reason.DRIFT_DETECTED,
                    index,
                    trace,
                )

        elif not allow_actions:
            # fill_ref / click_ref / type / snapshot reach the daemon
            # directly. The read classes do not need them, and a verb with
            # no policy behind it must not run on a real account.
            raise ExecutionFailed(
                f"{step.verb.value} is not executable without a write policy",
                Reason.ABSTAINED_NO_REPAIR_CLASS,
                index,
                trace,
            )

        elif step.verb is Verb.SNAPSHOT:
            await _snapshot(plan, trace)

        elif step.verb in (Verb.CLICK_REF, Verb.FILL_REF):
            if not trace.refs:
                await _snapshot(plan, trace)
            ref = _resolve_ref(trace, str(args["ref"]), str(args.get("role") or ""))
            if ref == "" and await _get_past_any_wall(plan, trace, allow_actions, may_act):
                # Nothing here answered to the plan — which is what a wall
                # standing in front of the page looks like from the inside.
                # Now that it is gone, look again before giving up.
                await _snapshot(plan, trace)
                ref = _resolve_ref(trace, str(args["ref"]), str(args.get("role") or ""))
            if ref in ("", "ambiguous"):
                # NAME the alternatives. The next rung is now told why the
                # last one failed, and "refusing to guess" tells it nothing
                # it can act on — measured on apa.org (2026-08-27), where a
                # plan clicked "Databases", the page had several, and the
                # retry had no way to know which labels it could have used
                # instead.
                phrases = (
                    _phrases_like(trace, str(args["ref"]), str(args.get("role") or ""))
                    if ref == "ambiguous"
                    else []
                )
                raise ExecutionFailed(
                    (
                        f"{args['ref']!r} matches several elements — refusing "
                        f"to guess. The page offers: "
                        f"{', '.join(phrases) or NOTHING_RESOLVES}"
                        if ref == "ambiguous"
                        else f"{args['ref']!r} is not on the page"
                    ),
                    Reason.DRIFT_DETECTED,
                    index,
                    trace,
                    # Carried whole, as data: the phrases are what the next
                    # plan copies, and the ladder's message cut would lose
                    # them (2026-08-28).
                    offers=tuple(phrases),
                )
            command = "click_ref" if step.verb is Verb.CLICK_REF else "fill_ref"
            # The policy sees the LABEL THE PAGE GIVES the target, resolved
            # a moment ago from the live snapshot — a plan for "update my
            # email" whose click lands on "Delete account" stops here.
            entry = trace.refs.get(ref) or {}
            label = str(entry.get("label") or args["ref"])
            role = str(entry.get("role") or "")
            href = str(entry.get("href") or "")
            denied = may_act(label, command, role, href) if may_act is not None else ""
            if denied:
                raise ExecutionFailed(denied, Reason.NEEDS_APPROVAL, index, trace)
            # `expect_host` makes the daemon refuse the action when the
            # document that would receive it is not on this site — the
            # same origin check the login path states for every keystroke.
            # The page's own hostname, computed HERE and never raising: the
            # first version called `vault.normalize_host` at the top of
            # `execute` for every plan, and it raises on single-label hosts
            # — every read run on `localhost:8477` died with an uncaught
            # ValueError and no ledger row (Opus round 2, B3, probe-proven).
            expect_host = _expect_host(plan.site)
            if not expect_host:
                raise ExecutionFailed(
                    f"{plan.site!r} names no host to check the action against",
                    Reason.INVALID_URL,
                    index,
                    trace,
                )
            payload: dict[str, Any] = {"ref": ref, "expect_host": expect_host}
            if step.verb is Verb.FILL_REF:
                payload["value"] = args["value"]
                if str(step.args.get("value", "")).startswith(SECRET_SCHEME):
                    # Belt to the braces above: the daemon REQUIRES an
                    # expect_host when told the value is a stored credential
                    # (`expect_host_required`), so the guard cannot be
                    # switched off by an empty string from anywhere.
                    payload["stored_credential"] = True
            reply = await _act(plan.site, command, payload)
            _count_ref_health(trace, reply)
            if (
                not reply.get("ok")
                and str(reply.get("error") or "") == "click_failed"
                and str(reply.get("covered_by") or "")
                # The click must be PROVEN not to have landed. This was
                # an assumption — "click_failed means the actionability
                # wait timed out, so nothing was dispatched" — and it is
                # false: Playwright's click waits for a navigation it
                # started, inside the same timeout, so a slow submit
                # throws AFTER the form went. Retrying on that assumption
                # submits twice. Both reviewers caught it (2026-08-28).
                #
                # The daemon now compares the page fingerprint and URL
                # from before the click. False means the page is exactly
                # as it was and there is nothing to repeat. None — the
                # fingerprint was unreadable — is NOT False: an unknown
                # page state fails closed, as `w5` does.
                and reply.get("page_changed") is False
                and await _get_past_any_wall(
                    plan,
                    trace,
                    allow_actions,
                    may_act,
                    evidence=str(reply["covered_by"]),
                )
            ):
                # A wall was over the target, the page is provably
                # untouched, and the wall has been dismissed. Try once.
                await _snapshot(plan, trace)
                ref = _resolve_ref(trace, str(args["ref"]), str(args.get("role") or ""))
                # A ref that no longer resolves must NOT fall back to the
                # one from the old snapshot: refs are re-minted per
                # snapshot, so `@e1` after the wall press is a different
                # element than `@e1` before it. Sending the stale one
                # clicks whatever now happens to be first.
                if ref not in ("", "ambiguous"):
                    payload["ref"] = ref
                    reply = await _act(plan.site, command, payload)
                    _count_ref_health(trace, reply)
            if not reply.get("ok"):
                raise ExecutionFailed(
                    f"{command} failed: {reply.get('error') or 'unknown'}"
                    + (
                        # REDACTED. `detail` can carry `covered_by`, which
                        # is whatever text sat over the target — and on a
                        # signed-in page that is often a header reading
                        # "Signed in as someone@example.com". This message
                        # travels into the failure evidence a person and a
                        # model both read.
                        f" ({_said_safely(str(reply['detail']))})"
                        if reply.get("error") == "click_failed" and reply.get("detail")
                        else ""
                    ),
                    _reason_for_action(str(reply.get("error") or "")),
                    index,
                    trace,
                )
            record = _action_record(index, step.verb.value, reply)
            w5 = record["w5"]
            trace.actions.append(record)
            # A fill can navigate too (a search box submitting on Enter, an
            # autocomplete that routes). The daemon keeps its ref map after
            # a fill and falls back to `stable_selector` when the primary
            # is gone — which can match a same-named element on the NEW
            # page. Refs after any action are a guess; drop them.
            trace.refs = {}
            if step.verb is Verb.CLICK_REF:
                # A click must change SOMETHING, and "unknown" is not
                # something: with the URL the same and the fingerprint
                # unreadable, the safe reading is that nothing happened.
                if not (w5["url_changed"] or w5["dom_changed"] or w5["new_tab"]):
                    raise ExecutionFailed(
                        f"clicking {args['ref']!r} changed nothing on the page",
                        Reason.DRIFT_DETECTED,
                        index,
                        trace,
                    )
                # The page the refs described is gone; so is the text.
                await _refresh_text(plan, trace)

        elif step.verb is Verb.UPLOAD_FILE:
            # A form that demands a document cannot be finished without one.
            # We create it — inside the daemon's upload sandbox, from text
            # the plan supplies — rather than reaching into the user's
            # files: an agent that can attach anything on disk is a
            # different and much worse product.
            if not trace.refs:
                await _snapshot(plan, trace)
            ref = _resolve_ref(trace, str(args["ref"]), "")
            if ref in ("", "ambiguous"):
                raise ExecutionFailed(
                    f"{args['ref']!r} is not a file input on this page",
                    Reason.DRIFT_DETECTED,
                    index,
                    trace,
                )
            entry = trace.refs.get(ref) or {}
            label = str(entry.get("label") or args["ref"])
            denied = may_act(label, "upload", str(entry.get("role") or ""), "") if may_act else ""
            if denied:
                raise ExecutionFailed(denied, Reason.NEEDS_APPROVAL, index, trace)
            name = _safe_filename(str(args["filename"]))
            body = str(args["content"])[:MAX_UPLOAD_BYTES]
            if _write_upload(name, body) is None:
                raise ExecutionFailed(
                    "uploads are not configured on this machine",
                    Reason.ABSTAINED_NO_REPAIR_CLASS,
                    index,
                    trace,
                )
            reply = await _act(plan.site, "set_files", {"ref": ref, "paths": [name]})
            if not reply.get("ok"):
                raise ExecutionFailed(
                    f"attaching {name!r} failed: {reply.get('error') or 'unknown'}",
                    _reason_for_action(str(reply.get("error") or "")),
                    index,
                    trace,
                )
            trace.actions.append(_action_record(index, step.verb.value, reply))

        elif step.verb is Verb.TYPE:
            # Enter submits whatever is focused; the policy sees it as the
            # submit it is (Opus round 6, B5: `type` had no check at all).
            text = str(args["text"])
            denied = may_act(text, "type", "", "") if may_act is not None else ""
            if denied:
                raise ExecutionFailed(denied, Reason.NEEDS_APPROVAL, index, trace)
            # The daemon TYPES text; only a newline presses the key. A plan
            # that says "Enter" meant the key — measured on pypi.org, where
            # the letters E-n-t-e-r went into the search box and the search
            # never ran (30-task set, all four search refusals).
            submits = _presses_enter(text)
            reply = await _act(plan.site, "type", {"text": "\n" if submits else text})
            if not reply.get("ok"):
                raise ExecutionFailed(
                    f"type failed: {reply.get('error') or 'unknown'}",
                    Reason.BROWSER_UNAVAILABLE,
                    index,
                    trace,
                )
            trace.actions.append(_action_record(index, step.verb.value, reply))
            # Enter in a search box is the classic navigating keystroke.
            trace.refs = {}
            if submits:
                # The page after a submit is a different page; read it
                # before anything downstream checks it.
                await _refresh_text(plan, trace)

        else:
            raise ExecutionFailed(
                f"{step.verb.value} is not executable",
                Reason.ABSTAINED_NO_REPAIR_CLASS,
                index,
                trace,
            )

        if step.says:
            trace.said.append(step.says)
        trace.steps_run += 1

    trace.elapsed_ms = int((time.monotonic() - started) * 1000)
    return trace


def _reason_for(raw: str | None) -> Reason:
    try:
        return Reason(raw or "")
    except ValueError:
        return Reason.ABSTAINED_LOW_CONFIDENCE


#: The daemon's action errors, mapped to the reason the run abstains with.
#: A ref the page no longer has is drift; a document on the wrong origin is
#: the credential guard; anything else is the browser's problem.
#:
#: Every key here is a string the daemon actually returns —
#: `test_w5.py` reads `scripts/rokan_browser_daemon.py` and checks, because
#: the first version mapped a `ref_gone` that no handler emits.
_ACTION_REASONS: dict[str, Reason] = {
    "ref_not_found": Reason.DRIFT_DETECTED,
    # An element the daemon FOUND and could not act on. Playwright scrolled
    # it into view and waited for it to be visible, stable, enabled and
    # hit-testable, and within five seconds it was not — which means
    # something is over it, it moved, it is disabled, or it detached. Every
    # one of those is a fact about the PAGE, and the page is what a re-plan
    # is for.
    #
    # These fell through to the default, `BROWSER_UNAVAILABLE`, which is a
    # WORLD failure — and `cascade.run` breaks out of the ladder on a world
    # failure without re-planning, because "a page that refused to load or a
    # login that was rejected will refuse the next model just as firmly".
    # So one unactionable button ended the whole run, with rungs unspent and
    # a resume note that was never written. Measured on apa.org
    # (2026-08-27): a run reached the Databases menu — the hard part — and
    # stopped there.
    # (No `fill_failed`: a fill that cannot act reports `ref_not_found` or
    # `frame_detached`, both already drift. `test_w5.py` reads the daemon
    # and refuses a key nothing emits — it caught exactly that here.)
    "click_failed": Reason.DRIFT_DETECTED,
    "type_failed": Reason.DRIFT_DETECTED,
    "select_failed": Reason.DRIFT_DETECTED,
    "frame_detached": Reason.DRIFT_DETECTED,
    "click_origin_refused": Reason.CREDENTIAL_ORIGIN_REFUSED,
    "fill_origin_refused": Reason.CREDENTIAL_ORIGIN_REFUSED,
    "cross_origin_refused": Reason.CREDENTIAL_ORIGIN_REFUSED,
    # The daemon's own belt (`stored_credential` without a host). If it ever
    # fires the braces above failed — a credential-guard refusal, never a
    # browser outage.
    "expect_host_required": Reason.CREDENTIAL_ORIGIN_REFUSED,
    "fill_origin_moved_mid_write": Reason.CREDENTIAL_MAY_BE_EXPOSED,
    "origin_moved": Reason.CREDENTIAL_MAY_BE_EXPOSED,
}


#: An uploaded file is one WE wrote, small and text-shaped: enough for the
#: document a form asks for, never a channel for arbitrary bytes.
MAX_UPLOAD_BYTES = 64 * 1024

#: The longest list worth proving. Past this the answer is a page, not an
#: answer, and every extra line is another chance to drift.
MAX_BLOCK_LINES = 25

#: Only a plain name, only these characters, always with an extension we
#: recognise. The daemon resolves and prefix-checks against its upload dir
#: as well — this is the client half of the same rule.
_SAFE_FILENAME = re.compile(r"[^A-Za-z0-9._-]+")
_ALLOWED_SUFFIXES = (".txt", ".md", ".csv", ".json", ".html", ".log")


def _safe_filename(wanted: str) -> str:
    """A name that cannot leave the upload directory."""
    stem = _SAFE_FILENAME.sub("-", wanted.rsplit("/", 1)[-1]).strip(".-")[:60] or "rokan"
    if not stem.lower().endswith(_ALLOWED_SUFFIXES):
        stem = f"{stem}.txt"
    return stem


def _write_upload(name: str, body: str) -> str | None:
    """Write the file inside the daemon's upload sandbox, or None when the
    machine has not configured one. Never overwrites outside that root."""
    root = os.environ.get("ROKAN_BROWSER_UPLOAD_DIR", "").strip()
    if not root:
        return None
    base = Path(root).resolve()
    target = (base / name).resolve()
    if target == base or not target.is_relative_to(base):
        return None
    base.mkdir(parents=True, exist_ok=True)
    target.write_text(body, encoding="utf-8")
    return str(target)


def _reason_for_action(error: str) -> Reason:
    return _ACTION_REASONS.get(error, Reason.BROWSER_UNAVAILABLE)
