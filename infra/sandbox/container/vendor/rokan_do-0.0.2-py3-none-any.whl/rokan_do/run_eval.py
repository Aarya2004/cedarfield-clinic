"""Run the pre-registered task set and print what may honestly be said.

    $ python -m rokan_do.run_eval

This is the only thing allowed to produce a number for public use. It runs
the real loop — real browser, real model, real login — against a fixture site
whose contents are known, scores each task against what was written down
BEFORE the run, and hands the outcomes to the measurement harness, which
computes Wilson intervals and compares them to bars registered on a date.

Three design choices that make the output worth trusting:

* **The fixture, not a live service.** A published rate needs the same task
  set every time; a live site can change under us and turn a regression into
  a mystery. Real sites are what the falsifier is for — that is a different
  question (does this work out there?) from this one (did we break it?).
* **Every task gets a fresh store.** A remembered plan would make the second
  run of a task measure memory rather than the loop, and the numbers would
  improve for a reason that has nothing to do with the product working.
* **Refusals are scored in the same pass.** Splitting them into a separate
  report is how "we accept almost nothing and succeed at all of it" gets
  published as a success rate.
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import json
import os
import sys
import tempfile
import textwrap
import time
from dataclasses import replace
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from rokan_agent.core.reasons import Reason
from rokan_agent.core.result import Result, Status

from . import hygiene, judge
from .accept import TaskRequest, accept
from .cascade import RunReport, run
from .evalset import ALL, REGISTERED, EvalTask
from .measure import Measurement, TaskOutcome, measure
from .redact import redact
from .service import perform


def _fixture_site() -> Any:  # noqa: ANN401
    """The same site the live tests use, imported from the test tree.

    Deliberately not copied here: two versions of the fixture would drift,
    and the eval would then be measuring a site the tests never see.
    """
    tests = Path(__file__).resolve().parents[2] / "tests"
    sys.path.insert(0, str(tests))
    from spa_site import SpaSite  # type: ignore[import-not-found]  # noqa: PLC0415

    return SpaSite()


def _real_sites(path: Path) -> tuple[list[EvalTask], dict[str, str]]:
    """Load labelled tasks against REAL sites, one independent unit each.

    The fixture set cannot clear the bar and no amount of rephrasing will
    change that: six pages, all passing, put the 95% lower bound at 0.610,
    and roughly 35 INDEPENDENT units are needed to reach 0.90. Independence
    is the missing ingredient, and only real sites supply it.

    What this cannot do is invent ground truth. An automated check of "did
    Rokan read the right number off a live page" is the product marking its
    own homework — the anchor is on the page because the executor put it
    there, which is the circularity `verify.py` was hardened against. So
    the expected answer is written by a person, in the file, before the
    run. That is the falsifier's discipline applied to success rather than
    to compilation.

    File shape (JSON list)::

        [{"site": "https://example.com",
          "said": "read the current status at example.com/status",
          "answer_contains": "operational",
          "because": "why this task is in the set"}]

    Real sites change. A run against them is dated evidence about the
    world on that day, not a regression test — which is why the fixture
    set stays exactly as it is and this is a separate command.
    """
    loaded = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(loaded, list) or not loaded:
        raise ValueError(f"{path} is not a non-empty JSON list of tasks")
    tasks: list[EvalTask] = []
    clusters: dict[str, str] = {}
    for row in loaded:
        said = str(row["said"])
        expected = str(row["answer_contains"])
        if not expected:
            raise ValueError(
                f"{said!r} has no expected answer. An unlabelled task cannot "
                "be scored, and scoring it as 'something was read' is the "
                "failure this set exists to avoid."
            )
        tasks.append(
            EvalTask(
                said=said,
                should_accept=bool(row.get("should_accept", True)),
                expects_class=str(row.get("expects_class", "read_value")),
                answer_contains=expected,
                because=str(row.get("because", "")),
                # The host was parsed here for clustering and thrown away;
                # the leak check needed it and got "" (S1).
                host=urlparse(str(row["site"])).netloc or str(row["site"]),
            )
        )
        # One SITE is one unit. Two questions about one page are not two
        # observations, which is the whole finding this option exists for.
        clusters[said] = urlparse(str(row["site"])).netloc or str(row["site"])
    return tasks, clusters


def _seed_account(base: str) -> None:
    """Give Rokan the account the user would already have.

    The premise of every task here is a person who is signed up and signed
    in; a run with an empty vault would be measuring whether Rokan can
    invent a password. Seeded per store, so no state carries between tasks.
    """
    from rokan_mcp import vault  # noqa: PLC0415
    from spa_site import PASSWORD, USERNAME  # noqa: PLC0415

    vault.save(vault.normalize_host(base), USERNAME, PASSWORD, None)


def _page_of(said: str, base: str) -> str:
    """The page a task is about — the unit whose failures correlate.

    Six phrasings of a question about /billing share a DOM, an anchor and a
    login. When that page changes, all six fail together, so counting them
    as six independent successes overstates the evidence in exactly the way
    counting repeats as trials did. Falls back to the whole task text, which
    makes the task its own group and changes nothing.

    The scheme is stripped because the two ends disagree about it: task text
    is built from `base_url.replace("http://", "")` while this is handed the
    full `base_url`. The first version partitioned on the wrong one, matched
    nothing, and every task became its own group — the clustering reported
    itself as absent instead of as broken, which is the worse of the two
    failures because the report then reads "these tasks are independent".
    """
    host = base.split("://", 1)[-1]
    if not host:
        # A real-site run has no single base, and `partition("")` raises
        # `ValueError: empty separator` — which arrived as a harness error
        # on every task of the first `--sites` run. The caller supplies the
        # cluster in that mode; here the task stands alone.
        return said
    _, _, rest = said.partition(host)
    page = rest.split()[0] if rest.strip() else ""
    return f"{host}{page.rstrip('.,')}" if page.startswith("/") else said


async def _score(
    task: EvalTask,
    said: str,
    base: str,
    *,
    warm: bool = False,
    baseline: dict[str, tuple[int, int]] | None = None,
) -> tuple[TaskOutcome, str]:
    """Run one task and say what happened, against what was expected.

    Returns the outcome and WHICH SPEED answered ("" on the cold path,
    "planned"/"replayed"/"compiled" under ``--warm``) — a harness that
    cannot see the path cannot claim to have measured it.
    """
    started = time.monotonic()
    path = ""

    accepted = accept(said)
    if isinstance(accepted, Result):
        # Refused. Whether that is right is decided by the pre-registered
        # expectation, not by how reasonable the refusal reads.
        return TaskOutcome(
            said=said,
            accepted=False,
            should_accept=task.should_accept,
            elapsed_ms=int((time.monotonic() - started) * 1000),
            note=str(accepted.reason.value if accepted.reason else ""),
        ), path

    if not task.should_accept:
        # Accepted something that should have been refused. Do NOT run it —
        # the eval must never be the thing that performs a task we said we
        # would not perform.
        return TaskOutcome(
            said=said,
            accepted=True,
            should_accept=False,
            verified=None,
            elapsed_ms=int((time.monotonic() - started) * 1000),
            note="MIS-ACCEPTED — not executed",
        ), path

    request = TaskRequest(
        task_class=accepted.task_class,
        site=accepted.site,
        slots=accepted.slots,
        said=said,
    )
    probe = task.probe.replace("{site}", base) or None
    if warm:
        # THE PRODUCT PATH — memory, replay, the compiled endpoint — via
        # the same `service.perform` the CLI calls. The default (cold)
        # branch below deliberately stays `cascade.run`: it measures the
        # LOOP, its numbers are the ones every prior artifact carries, and
        # routing it through the service would add remember/compile work
        # that changes what its latency means.
        performed = await perform(request, probe=probe)
        result, report = performed.result, performed.report
        path = performed.path
    else:
        result, report = await run(request, probe_url=probe)
    elapsed = int((time.monotonic() - started) * 1000)
    if result.reason is Reason.ABSTAINED_PLANNER_UNAVAILABLE:
        # The PROVIDER failed — no key, no network, no credit — not the
        # product. Round 4 of the 2026-08-24 flakiness design scored 15
        # billing-outage failures as "refused, honestly" (harness_errors 0),
        # inflating exactly the number this eval exists to earn. A harness
        # error, and NO verdict on the task in either direction: verified
        # stays None, because the task was never actually tried.
        detail = result.evidence[0] if result.evidence else result.reason.value
        return TaskOutcome(
            said=said,
            # NOT hardcoded True — the crash path's own rule: a harness fault
            # must never fabricate a gate error. Reachable only with
            # should_accept=True today (the mis-accept branch returns above),
            # but held by construction rather than by distance.
            accepted=task.should_accept,
            should_accept=task.should_accept,
            # The failed attempts' prompts DID leave the machine — a billing
            # 400 comes back after the request body is sent — so the leak
            # check must look at exactly these runs (Opus round 1, F2: the
            # first fix returned early and skipped it).
            credential_leak=_leaked(
                "", report, host=_host_of(task, base), baseline=baseline
            ),
            elapsed_ms=elapsed,
            model_calls=report.model_calls if report is not None else 0,
            harness_error=True,
            note=f"harness: planner unavailable — {detail}"[:200],
            cluster=_page_of(said, base),
            # An empty path, even under --warm: this run never planned,
            # replayed, or compiled, and counting it in the speeds would
            # let an outage read as cold-path coverage.
        ), ""
    # On the fast paths there is no cascade report; the answer is the
    # result's own payload — the same string the CLI renders.
    answer = report.proof if report is not None else str(result.data or "")
    # What the PRODUCT said, before the eval checks whether it was right.
    claimed = result.status is Status.OK
    verified = claimed
    if verified and task.expects_class and accepted.task_class != task.expects_class:
        # A routing regression — `get_api_key` quietly degrading to
        # `read_value`, so the key is returned and never spent — used to be
        # invisible: `expects_class` was written on every entry and compared
        # to nothing.
        verified = False
    if verified and task.answer_contains:
        # The postcondition passed AND the answer is the one the fixture
        # actually holds. A verifier can only prove the page said something;
        # this proves it said the right thing.
        verified = task.answer_contains.lower() in answer.lower()

    return TaskOutcome(
        said=said,
        accepted=True,
        should_accept=True,
        verified=verified,
        claimed=claimed,
        credential_leak=_leaked(
            answer, report, host=_host_of(task, base), baseline=baseline
        ),
        elapsed_ms=elapsed,
        model_calls=report.model_calls if report is not None else 0,
        # 200, not 60. The note exists to diagnose a failure, and 60
        # characters cut the diagnosis off mid-sentence — including, on the
        # first run that had one, the clause explaining that the page had
        # been truncated. A reason you cannot read is not a reason.
        # REDACTED. The note prints the line that was read, and on a
        # logged-in dashboard that line can be an API key — it reached the
        # terminal and every run log verbatim (S2).
        note="" if verified else _failure_note(result, answer, _host_of(task, base)),
        cluster=_page_of(said, base),
    ), path


async def _run_one(
    task: EvalTask, running: Any, warm: bool  # noqa: ANN401
) -> tuple[TaskOutcome, str]:
    """One trial, with the store policy the mode calls for.

    Cold (the default): a fresh store per task — otherwise the second task
    measures memory rather than the loop — with the browser closed INSIDE
    the temp-dir context, so Chromium is gone before the profile it owns is
    deleted (outside it, Python unwound the ``with`` first and Chromium
    flushed into an unlinked tree).

    Warm (``--warm``): the caller owns one store for the whole run and this
    touches neither the environment nor the browser between tasks — reuse
    is the thing being measured.

    Substituted ONCE, and used by both paths: the crash path used to record
    the raw ``{site}`` text, so ``measure`` saw a crash and a success on one
    task as two tasks — which hid the flakiness note and inflated n.
    """
    said = (
        task.said
        if running is None
        else task.said.replace("{site}", running.base_url.replace("http://", ""))
    )
    base = "" if running is None else running.base_url
    previous_home = os.environ.get("ROKAN_MCP_HOME")
    try:
        if warm:
            # The before picture, so the leak check judges only what THIS
            # task wrote to the shared store.
            return await _score(
                task, said, base, warm=True, baseline=_store_snapshot()
            )
        with tempfile.TemporaryDirectory(prefix=hygiene.eval_home_prefix()) as home:
            os.environ["ROKAN_MCP_HOME"] = home
            try:
                # A real site's account is the user's own and is not seeded
                # here: this path is read-only by construction, and writing
                # a fake credential for a real host would be both useless
                # and a thing left behind on the machine.
                if running is not None:
                    _seed_account(base)
                return await _score(task, said, base)
            finally:
                from rokan_agent.core.proven import browser  # noqa: PLC0415

                with contextlib.suppress(Exception):
                    await browser.close_all()
    except Exception as exc:  # noqa: BLE001
        # A crash on trial 150 used to discard all 168 outcomes, so "100%
        # success" was silently conditional on the run having finished — and
        # a harness failure and a product failure were the same number.
        return TaskOutcome(
            said=said,
            # NOT hardcoded True: a crash on a refusal task used to
            # fabricate a gate error out of a harness fault.
            accepted=task.should_accept,
            should_accept=task.should_accept,
            verified=False,
            harness_error=True,
            # KNOWN DEFERRAL (Opus rounds 1–2): no leak check on this path.
            # The prompts are unreachable — the report died with the frame —
            # and in cold mode the temp home is already unlinked when this
            # handler runs, so a disk scan would see nothing. The warm-mode
            # disk half is real and deliberately deferred; revisit if a
            # warm crash ever coincides with a leak suspicion.
            note=f"harness: {type(exc).__name__}: {exc}"[:120],
        ), ""
    finally:
        # Left pointing at a deleted directory otherwise. Under --warm the
        # caller set the home and this restores nothing it did not change.
        if not warm:
            if previous_home is None:
                os.environ.pop("ROKAN_MCP_HOME", None)
            else:
                os.environ["ROKAN_MCP_HOME"] = previous_home


def _host_of(task: EvalTask, base: str) -> str:
    """The host in play: the fixture's when there is one, else the task's.

    A `--sites` run has no `base` (there is no fixture server), which is
    how the leak check ended up looking up the empty host (S1).
    """
    return urlparse(base).netloc or base or task.host


def _failure_note(result: Result, answer: str, host: str) -> str:
    """Why it failed, in a form that can be acted on.

    An ABSTENTION carries no `data`, so the answer-shaped note rendered as
    `answer=''` and the reason never reached the operator — a lockout on a
    real account would have printed nothing at all (Opus round 2, F-B).
    The evidence can carry page-scraped text, so it goes through the same
    redaction as the answer.
    """
    if result.status is not Status.OK:
        detail = "; ".join(result.evidence[:2])
        reason = result.reason.value if result.reason else "unknown"
        return _redacted_note(f"{reason}: {detail}" if detail else reason, host)
    return _redacted_note(answer, host)


def _redacted_note(answer: str, host: str) -> str:
    """A failure note that cannot carry the secret it is diagnosing.

    Both layers: the vault's own values for this host (exact) and
    `redact`'s generic key/token patterns (for a credential read off a page
    that is not in any vault).
    """
    return f"answer={redact(answer, _vault_secrets(host))[:200]!r}"


def _vault_secrets(host: str) -> list[str]:
    """The credentials actually in play for a real host, from the vault.

    Not a fallback that finds nothing: a real-site task that signs in is
    replaying a stored password, and that password is the thing whose
    appearance in a prompt or a sqlite file would be the incident. A
    read-only task on a host with no stored login has nothing to leak, and
    the caller treats an empty list as "cannot check" rather than "clean".
    """
    if not host:
        return []
    try:
        from rokan_mcp import vault  # noqa: PLC0415

        credential = vault.get(host)
    except Exception:  # noqa: BLE001 — a vault we cannot read checks nothing
        return []
    if credential is None:
        return []
    found = [credential.password]
    if credential.totp_seed:
        found.append(credential.totp_seed.decode("utf-8", "replace"))
    return [s for s in found if s]


def _leaked(
    answer: str,
    report: RunReport | None,
    host: str = "",
    baseline: dict[str, tuple[int, int]] | None = None,
) -> bool:
    """Did any of the fixture's secrets reach anything we show, store, or send?

    Cheap and absolute. A credential incident is not a percentage point, and
    the only way to keep that true is to look on every single task rather
    than in a separate audit nobody runs.

    It looks for the API KEY as well as the password, which it did not, and
    that omission mattered: the key is what a `get_api_key` run legitimately
    handles, so it is the credential most likely to end up somewhere it
    should not — and the counter printed 0 while being structurally unable
    to see it.

    It looks at three places, because a secret can travel by three routes and
    the check used to watch only the first:

    * what we SHOW — the answer;
    * what we SEND — every prompt, including the ones from rungs that then
      failed, which are the retries most likely to be carrying something;
    * what we STORE — the sqlite files under the run's own home. That is
      where a compiled operation kept an API key in plaintext, and no amount
      of reading the answer would ever have revealed it.

    * On a REAL-SITE run there is no fixture module to import, and the
      secrets that matter are the ones actually in play: whatever the
      vault holds for the host this task named. The first version imported
      `spa_site` unconditionally and every real-site task died with
      `ModuleNotFoundError` before it ran — which the report correctly
      refused to give a verdict for, and which the reason-printing added
      earlier named in one line.
    """
    # UNION, and honest about why. The either/or version took the
    # fixture's secrets whenever `spa_site` imported and never looked in
    # the vault — under PYTEST, where the rootdir puts `tests/` on the
    # path. Through the real CLI it does NOT import (`tests/` reaches
    # `sys.path` only via `_fixture_site`, which `--sites` never calls), so
    # the vault branch did fire there and the defect was the empty host
    # alone. Corrected after the first claim overstated it (Opus round 2).
    # The union stays as defence in depth: it costs nothing and it makes
    # the two environments agree.
    #
    # Opus round 2 asked for the fixture half to be gated on a fixture
    # actually running, so the "cannot check" branch below stays reachable.
    # Measured cost of doing that: three suite-integrity tests that encode
    # "the leak check fires on fixture secrets" went red, and the branch it
    # protects is ALREADY alive where it matters — through the CLI on a
    # `--sites` run `spa_site` does not import, so `secrets` there is the
    # vault's alone. The gate would have bought a pytest-only nicety at the
    # price of the tests that prove this check can fire. Not taken.
    secrets: list[str] = list(_vault_secrets(host))
    try:
        from spa_site import API_KEY, PASSWORD  # noqa: PLC0415

        secrets += [s for s in (PASSWORD, API_KEY) if s]
    except ModuleNotFoundError:
        pass
    if not secrets:
        # Nothing to look FOR is not the same as nothing found. Saying "no
        # leak" here would be a clean number produced by an empty check.
        return False
    looked_at = [answer]
    # A fast-path answer has no report — and no prompts either: nothing was
    # sent to a model. The answer and the disk are still checked.
    for attempt in report.attempts if report is not None else []:
        looked_at.append(attempt.prompt_sent)
        if attempt.plan is not None:
            looked_at.extend(
                str(v) for s in attempt.plan.steps for v in s.args.values()
            )
    if any(secret in "\n".join(looked_at) for secret in secrets):
        return True
    return _on_disk(secrets, baseline)


def _store_snapshot() -> dict[str, tuple[int, int]]:
    """Every store file with its (mtime_ns, size) — the before picture."""
    home = os.environ.get("ROKAN_MCP_HOME", "")
    if not home or not Path(home).exists():
        return {}
    out: dict[str, tuple[int, int]] = {}
    for path in Path(home).rglob("*"):
        if not path.is_file():
            continue
        try:
            stat = path.stat()
        except OSError:
            continue
        out[str(path)] = (stat.st_mtime_ns, stat.st_size)
    return out


def _on_disk(
    secrets: list[str], baseline: dict[str, tuple[int, int]] | None = None
) -> bool:
    """Is a secret sitting in this run's own store, in the clear?

    The vault is encrypted and is meant to hold one; everything else is not
    and is not.

    With a ``baseline`` (the warm mode passes one), only files this task
    CREATED OR CHANGED are scanned. Without it the whole store is — which
    is right for the cold mode's per-task store and was wrong for the
    shared warm store: a `get_api_key` task legitimately handles the key,
    and every later task then scanned a store that had seen it, so one
    task's artefacts convicted the rest of the run (Opus review, F6). A
    leak verdict has to name the task that leaked, or the absolute check
    trains people to ignore it.
    """
    home = os.environ.get("ROKAN_MCP_HOME", "")
    if not home or not Path(home).exists():
        return False
    for path in Path(home).rglob("*"):
        if not path.is_file() or "vault" in path.name or "profiles" in path.parts:
            continue
        if baseline is not None:
            try:
                stat = path.stat()
            except OSError:
                continue
            before = baseline.get(str(path))
            if before == (stat.st_mtime_ns, stat.st_size):
                continue
        try:
            blob = path.read_bytes()
        except OSError:
            continue
        if any(secret.encode() in blob for secret in secrets):
            return True
    return False


#: Live browser daemons a warm pass may hold. Three keeps a handful of
#: hosts warm for the replay number; more is the crash above.
MAX_LIVE_DAEMONS = int(os.environ.get("ROKAN_MAX_LIVE_DAEMONS", "3"))


async def _cap_live_daemons(limit: int | None = None) -> None:
    from rokan_agent.core.proven import browser  # noqa: PLC0415

    cap = MAX_LIVE_DAEMONS if limit is None else limit
    live = len(getattr(browser, "_sessions", {}) or {})
    if live > cap:
        with contextlib.suppress(Exception):
            await browser.close_all()


async def _main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="rokan-do-eval", description="score the pre-registered task set"
    )
    parser.add_argument(
        "--json", action="store_true", help="machine-readable output as well"
    )
    parser.add_argument(
        "--only", default="", help="substring filter over the task text"
    )
    parser.add_argument(
        "--sites",
        default="",
        metavar="FILE",
        help=(
            "score labelled tasks against REAL sites instead of the fixture, "
            "one independent unit per site. Expected answers must be written "
            "by a person before the run; see _real_sites for the file shape "
            "and for why this cannot be automated."
        ),
    )
    parser.add_argument(
        "--warm",
        action="store_true",
        help=(
            "ONE store for the whole run, tasks routed through the same "
            "service.perform the CLI calls — so memory, replay and the "
            "compiled endpoint are exercised and scored. The default (cold) "
            "mode measures the loop with a fresh store per task and has "
            "never touched memory; before this flag existed, no eval had."
        ),
    )
    parser.add_argument(
        "--warm-home",
        default="",
        help=(
            "keep the warm run's store HERE instead of a temp dir — how a seed pack is "
            "built (rokan-do seed export) from a run that verified"
        ),
    )
    parser.add_argument(
        "--repeat",
        type=int,
        default=1,
        help=(
            "run the whole set N times. Reliability is a rate, and a rate "
            "needs trials: six clean tasks put the interval's lower bound at "
            "61 percent, honestly below a 90 percent bar. Repeats are trials of "
            "the LOOP, not additional tasks, and the report says so."
        ),
    )
    args = parser.parse_args(argv)
    if args.repeat < 1:
        parser.error("--repeat must be at least 1")

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print(
            "no ANTHROPIC_API_KEY — the cold runs would be skipped and the "
            "numbers would mean nothing",
            file=sys.stderr,
        )
        return 2

    # The H12 ritual (HANDOFF §1b), run by the harness so it cannot be
    # forgotten: SIGTERM unwinds like Ctrl-C instead of leaking the homes,
    # a previous killed run's orphans and dirs are cleared, and the
    # browser's weight is on the record before the first task.
    hygiene.die_cleanly_on_sigterm()
    hygiene.sweep()
    hygiene.memory_report("before")

    clusters: dict[str, str] = {}
    if args.sites:
        tasks, clusters = _real_sites(Path(args.sites))
        tasks = [t for t in tasks if args.only.lower() in t.said.lower()]
    else:
        tasks = [t for t in ALL if args.only.lower() in t.said.lower()]
    total = len(tasks) * args.repeat
    unique_sites = len(set(clusters.values()))
    origin = (
        f"{unique_sites} real site{'s' if unique_sites != 1 else ''}, "
        f"labelled in {args.sites}"
        if args.sites
        else f"set registered {REGISTERED}"
    )
    print(
        f"scoring {len(tasks)} tasks"
        + (f" × {args.repeat} passes = {total} trials" if args.repeat > 1 else "")
        + f" · {origin}\n"
    )

    outcomes: list[TaskOutcome] = []
    paths: list[str] = []
    site = contextlib.nullcontext(None) if args.sites else _fixture_site()
    done = 0
    # Under --warm, ONE store for the whole run: the point is to measure
    # what a store that has seen the earlier tasks does to the later ones —
    # memory, replay, the compiled endpoint — which is the product path the
    # per-task fresh store deliberately excludes.
    warm_home = (
        tempfile.TemporaryDirectory(prefix=hygiene.eval_home_prefix(warm=True))
        if args.warm and not args.warm_home
        else None
    )
    if args.warm_home and not args.warm:
        raise SystemExit("--warm-home only means something with --warm (nothing would be kept)")
    kept_home = str(args.warm_home) if args.warm and args.warm_home else ""
    run_home = os.environ.get("ROKAN_MCP_HOME")
    if warm_home is not None:
        os.environ["ROKAN_MCP_HOME"] = warm_home.name
    elif kept_home:
        # A seed pack is built from a run that verified: the store must
        # outlive the run, so it is the caller's directory and never reaped.
        os.makedirs(kept_home, exist_ok=True)
        os.environ["ROKAN_MCP_HOME"] = kept_home
    try:
        with site as running:
            if warm_home is not None and running is not None:
                _seed_account(running.base_url)
            for pass_number in range(1, args.repeat + 1):
                if args.repeat > 1:
                    print(f"  — pass {pass_number} of {args.repeat}")
                for task in tasks:
                    outcome, path = await _run_one(task, running, args.warm)
                    if args.warm:
                        # One Chromium per HOST stays alive across a warm
                        # pass so a replay is milliseconds, not a browser
                        # launch. A 116-host pre-warm therefore held 116
                        # browsers and the machine killed the process
                        # (2026-08-25, exit 137). Past the cap, everything
                        # closes; the next replay pays one launch.
                        await _cap_live_daemons()
                    if clusters:
                        # One site is one unit. Assigned here rather than in
                        # `_score`, which cannot know the file the tasks came
                        # from.
                        outcome = replace(
                            outcome, cluster=clusters.get(outcome.said, outcome.said)
                        )
                    outcomes.append(outcome)
                    paths.append(path)
                    done += 1
                    mark = (
                        "HARNESS"
                        if outcome.harness_error
                        else "refused"
                        if not outcome.accepted
                        else ("ok" if outcome.verified else "FAILED")
                    )
                    if path and path != "planned":
                        mark = f"{mark} ⚡"
                    wrong = outcome.accepted != outcome.should_accept
                    print(
                        f"  {done:>3}/{total}  {mark:<8}"
                        f"{'  ← GATE WRONG' if wrong else '':<15}{outcome.said[:52]}"
                    )
                    # WHY it failed, on the same line as the failure.
                    #
                    # The note was recorded and never printed, so a failed
                    # run said "FAILED" and nothing else. That is exactly the
                    # state the unexplained 76.7% run left behind: a number
                    # nobody could investigate because the harness had thrown
                    # away the answer it actually read.
                    if outcome.note and mark.startswith(("FAILED", "HARNESS")):
                        for chunk in textwrap.wrap(outcome.note, 96):
                            print(f"{'':>13}{chunk}")
            if warm_home is not None:
                from rokan_agent.core.proven import browser  # noqa: PLC0415

                with contextlib.suppress(Exception):
                    await browser.close_all()
    finally:
        if warm_home is not None or kept_home:
            if run_home is None:
                os.environ.pop("ROKAN_MCP_HOME", None)
            else:
                os.environ["ROKAN_MCP_HOME"] = run_home
        if warm_home is not None:
            with contextlib.suppress(OSError):
                warm_home.cleanup()
        # The AFTER picture (§1b): a run that leaves Chromium behind should
        # say so on its own last lines, not wait to be discovered at 76 GB.
        hygiene.memory_report("after")

    result: Measurement = measure(outcomes, filtered=args.only)
    print("\n" + result.report())
    if judge.enabled():
        # The experiment's own instrument: the plan's threshold is one
        # judge call per VERIFIED read, never per attempt.
        print(
            f"\n  judge calls: {judge.calls()} "
            "(refusal-only experiment, ROKAN_JUDGE=1)"
        )
    if args.warm:
        # WHICH SPEED answered, counted — a warm run whose every trial
        # quietly re-planned would otherwise read as green numbers about a
        # memory it never touched.
        ran = [p for p in paths if p]
        speeds = {name: ran.count(name) for name in ("planned", "replayed", "compiled")}
        print(
            "\n  warm run — speeds: "
            + " · ".join(f"{name} {count}" for name, count in speeds.items())
        )
        # Armed whenever reuse was POSSIBLE: repeated passes, or two
        # accepted tasks sharing a host within one pass. Gating on repeat
        # alone disarmed the alarm for exactly the single-pass real-site
        # runs it was built for (Opus review, F10).
        outcomes_hosts = [
            o.cluster or o.said
            for o in outcomes
            # Not harness failures: an outaged run is no evidence about
            # memory. Round 4's literal shape — pass 1 real, pass 2
            # billing-outaged — used to print this alarm as a false
            # memory regression.
            if o.accepted and o.should_accept and not o.harness_error
        ]
        # Duplicates ONLY — no `args.repeat > 1` disjunct. A pass that
        # actually ran twice produces its own duplicate host; gating on the
        # repeat FLAG armed the alarm for a pass 2 that never ran (Opus
        # round 2, N2). An empty list has no duplicates, so the all-outage
        # case disarms itself, and the F10 single-pass same-host case still
        # arms on its duplicate.
        reuse_possible = len(outcomes_hosts) != len(set(outcomes_hosts))
        if reuse_possible and speeds["replayed"] + speeds["compiled"] == 0:
            print(
                "  ⚠ NOTHING REPLAYED although the store was shared and "
                "reuse was possible — this run measured the cold path, "
                "not memory."
            )
    print(
        "\n  The interval is over DISTINCT tasks, and a task counts as a "
        "success only if every\n  attempt of it succeeded. Repeating the set "
        "does not narrow the interval — repeats\n  of one task against one "
        "fixture are one observation looked at many times, and\n  treating "
        "them as independent trials is what made an earlier run of this same\n"
        "  harness report MEETS THE BARS when it did not."
    )
    if args.warm:
        print(
            "  Latency here MIXES the three speeds — cold learns, replays "
            "answer in milliseconds —\n  so the median describes this run's "
            "blend, not any one path."
        )
    else:
        print(
            "  Latency here is cold on every task: a fresh store means a fresh "
            "browser profile and a\n  new daemon each time. A warm machine "
            "replays in milliseconds; that is what the three-speeds\n  test "
            "measures, and this number should never be quoted as the product's "
            "speed."
        )
    if args.json:
        print("\n" + result.to_json())
    if result.harness_errors:
        # Exit 2, not 1: CI must not read "the harness broke" as "failed
        # the bars" — nor rerun-until-green as if it were product flake.
        # The report prints the same distinction ("no verdict — ... fix the
        # harness and rerun").
        return 2
    return 0 if result.passes else 1


def main(argv: list[str] | None = None) -> int:
    return asyncio.run(_main(argv))


if __name__ == "__main__":
    raise SystemExit(main())
