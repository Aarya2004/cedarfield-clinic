"""A write needs a human's word — per site, per action, given once.

Reads are free to try because a wrong read is refused, not done. A write
is different: "cancel", "delete", "pay", "send" happen in the world and do
not come back. `accept._NEVER` refuses those words before any model sees
them. This module is the door through which a person lets ONE of them
through, for ONE site, deliberately:

    rokan-do allow notion.so cancel

Two checks, two places, on purpose:

* **At accept** — a task that asks for a `_NEVER` action runs only when the
  grant exists. Refused otherwise, with the exact command in `next_step`.
* **At dispatch** — inside the executor, immediately before a click or a
  fill reaches the daemon, the TARGET'S OWN LABEL is checked against the
  deny set. A plan for "update my billing email" that resolves a click onto
  a button labelled "Delete account" stops here, grant or no grant for
  "cancel". The label is what the page says the button does; the plan is
  what a model thought it was doing. When they disagree, the page wins.

Grants live in a small JSON file under the store's home. Not the vault (a
grant is not a secret), not the sqlite store (a person should be able to
read and edit it with `cat`).
"""

from __future__ import annotations

import json
import os
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from rokan_agent.core.proven import paths

from .lines import flatten
from .memory import _host, _host_matches

#: Button/link labels that name an irreversible, spending, or outbound
#: action, mapped to the action word a grant is given for. Checked as
#: whole words, case-insensitive, after flattening — "Delete", "Delete
#: account", "Yes, delete it" all resolve to "delete". Deliberately broad:
#: a false hit costs one `rokan-do allow`; a miss costs the thing itself.
DENY_LABELS: dict[str, str] = {
    "delete": "delete",
    "remove": "delete",
    "erase": "delete",
    "destroy": "delete",
    "cancel": "cancel",
    "unsubscribe": "cancel",
    "downgrade": "cancel",
    "close account": "cancel",
    "deactivate": "cancel",
    "pay": "pay",
    "pay now": "pay",
    "buy": "pay",
    "purchase": "pay",
    "checkout": "pay",
    "check out": "pay",
    "place order": "pay",
    "confirm payment": "pay",
    "subscribe": "pay",
    "upgrade": "pay",
    "transfer": "transfer",
    "withdraw": "transfer",
    "send": "send",
    "send message": "send",
    "post": "send",
    "publish": "send",
    "share": "send",
    "submit": "submit",
    "revoke": "rotate",
    "regenerate": "rotate",
    "rotate": "rotate",
    "reset": "rotate",
}

#: The action words a grant may name. Anything else is refused at `allow`
#: so a typo cannot create a grant nothing checks for.
ACTIONS: frozenset[str] = frozenset(DENY_LABELS.values()) | {"fill", "sign_up"}

_ALLOW_FILE = "allow.json"


@dataclass(frozen=True, slots=True)
class Grant:
    site: str
    action: str
    granted_at: str


def allow_path() -> Path:
    return Path(paths.home()) / _ALLOW_FILE


def _load() -> list[Grant]:
    path = allow_path()
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text() or "[]")
    except (OSError, ValueError):
        # An unreadable file grants NOTHING. Fail closed: a write that
        # should have been allowed is a refusal with a next step; a write
        # that should not have been is the thing this module exists for.
        return []
    out: list[Grant] = []
    for item in raw if isinstance(raw, list) else []:
        if not isinstance(item, dict):
            continue
        site = _host(str(item.get("site") or ""))
        action = str(item.get("action") or "").strip().lower()
        if site and action in ACTIONS:
            out.append(Grant(site, action, str(item.get("granted_at") or "")))
    return out


def _save(grants: list[Grant]) -> None:
    path = allow_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            [{"site": g.site, "action": g.action, "granted_at": g.granted_at} for g in grants],
            indent=2,
        )
        + "\n"
    )


def grants() -> list[Grant]:
    return _load()


def allow(site: str, action: str) -> Grant:
    """Grant one action on one site. Idempotent. Raises on an unknown action
    or a site with no host — a grant that checks nothing must not exist."""
    action = action.strip().lower()
    if action not in ACTIONS:
        raise ValueError(f"unknown action {action!r}; one of: {', '.join(sorted(ACTIONS))}")
    host = _host(site)
    if not host or "." not in host and host != "localhost":
        raise ValueError(f"{site!r} is not a site")
    current = _load()
    for g in current:
        if g.site == host and g.action == action:
            return g
    grant = Grant(host, action, datetime.now(UTC).isoformat())
    _save([*current, grant])
    return grant


def revoke(site: str, action: str) -> bool:
    host = _host(site)
    action = action.strip().lower()
    current = _load()
    kept = [g for g in current if not (g.site == host and g.action == action)]
    if len(kept) == len(current):
        return False
    _save(kept)
    return True


def permits(host: str, action: str) -> bool:
    """Is this action granted on this host (exact, or a subdomain of a
    granted site)? Unknown action → never."""
    action = action.strip().lower()
    if action not in ACTIONS:
        return False
    host = _host(host)
    return any(g.action == action and _host_matches(host, g.site) for g in _load())


_WORD = re.compile(r"[a-z0-9]+")


def action_for_label(label: str) -> str:
    """The deny-set action a target's label names, or "".

    Whole-word match on the flattened, lowercased label so "Delete account"
    and "Yes, delete it" both say "delete" while "Undelete" and "Deleted
    items" do not. Multi-word entries ("close account") must appear as a
    contiguous phrase.
    """
    words = _WORD.findall(flatten(label).lower())
    if not words:
        return ""
    joined = " " + " ".join(words) + " "
    for phrase, action in DENY_LABELS.items():
        if f" {phrase} " in joined:
            return action
    return ""


#: The executor's seam: ``(label, verb, role) -> ""`` to proceed, or a
#: reason string to refuse with. Built per host and per call, so the check
#: is one function call at the moment of the action.
MayAct = Callable[[str, str, str, str], str]

#: Roles whose click is NAVIGATION — it goes somewhere, it changes nothing.
_NAVIGATION_ROLES = frozenset({"link", "tab", "menuitem"})

#: ``ROKAN_GUARD_ALL_HOSTS=1``: treat EVERY host as one this machine holds a
#: login for. For a deployment where the vault says nothing about authority
#: — a shared or sandboxed browser whose sessions arrived some other way —
#: so that every non-navigation click and every Enter needs ``allow_write``
#: and a grant, public host or not. Unset: the vault decides, as below.
_GUARD_ALL_HOSTS_ENV = "ROKAN_GUARD_ALL_HOSTS"


def _guard_all_hosts() -> bool:
    return os.environ.get(_GUARD_ALL_HOSTS_ENV, "").strip().lower() in {"1", "true", "yes"}


def _has_authority(host: str) -> bool:
    """Does this machine hold a login for the host? Harm needs authority:
    a click on a page we are signed into can cancel, pay, delete; a click
    on a public page can, at worst, navigate. Deterministic, pre-run, and
    fail-closed — an unreadable vault reads as "yes, guarded"."""
    if _guard_all_hosts():
        return True
    try:
        from rokan_agent.core.proven import vault  # noqa: PLC0415

        # Exact host, or ANY stored login under the same apex: a session on
        # acme.example is authority on checkout.acme.example too (the site
        # boundary `ir.validate` lets a plan navigate across), and a plan
        # that hopped to an unguarded subdomain would otherwise click free.
        normalized = vault.normalize_host(host)
        return vault.get(normalized) is not None or vault.find_sibling(normalized) is not None
    except ValueError:
        # No hostname to look up (localhost, an IP): no vault entry can
        # exist, so there is no authority to protect.
        return False
    except Exception:  # noqa: BLE001 — a vault we cannot read is a vault we guard
        return True


def _submits(text: str) -> bool:
    lowered = text.strip().lower()
    return "\n" in text or "\r" in text or lowered in {"enter", "return"}


def may_act(host: str, *, allow_write: bool = False) -> MayAct:
    """The dispatch-time check for one host, for one call.

    The boundary is AUTHORITY, not a wordlist (Opus round 6, B5 — "stop my
    subscription" + a "Confirm" dialog walked through two wordlists that
    both missed). Rules, in order:

    * a fill is never denied — typing into a field is not the irreversible
      step; the click or Enter that submits is;
    * a target whose label names a deny-set action (delete, cancel, pay,
      send, submit, rotate…) needs ``allow_write`` AND the grant for that
      action — on ANY host, public included;
    * a click on a link / tab / menu item is navigation — allowed;
    * on a host this machine holds a LOGIN for, every other click and every
      Enter is a write: it needs ``allow_write`` AND some grant on the host
      (`submit` when no deny word names it). "Confirm", "Yes", "Continue",
      "Turn off auto-renew" all land here;
    * on a public host, an unlabeled button click is allowed — a contact
      form's "Send" is caught by the deny set, a search box's Enter is not
      a write.

    The deny set is UX now — it names WHICH grant to ask for — not the
    security boundary.
    """
    host = _host(host)
    guarded = _has_authority(host)

    def check(label: str, verb: str, role: str = "", href: str = "") -> str:
        if verb == "fill_ref":
            return ""
        if verb == "type":
            if not _submits(label):
                return ""
            label, role, href = "Enter", "", ""
        elif verb == "click_xy":
            # A coordinate click has no label the page gave it and no role:
            # nothing vouches for it. On a guarded host that is a write.
            label, role, href = label or "a click by coordinates", "", ""
        elif verb != "click_ref":
            return ""
        action = action_for_label(label)
        if action:
            if not allow_write:
                return (
                    f"{label!r} is a {action} action — call again with allow_write=true, "
                    f"and only if a person has run: rokan-do allow {host} {action}"
                )
            if not permits(host, action):
                return (
                    f"{label!r} is a {action} action and {host} has no grant for it — "
                    f"a person must run: rokan-do allow {host} {action}"
                )
            return ""
        if not guarded:
            return ""
        if role.lower() in _NAVIGATION_ROLES and href.strip():
            # Navigation: a link with somewhere to go. The ROLE alone is
            # the page's word (`<a role="link" onclick="delete()">`), and on
            # a signed-in host the page's word is not enough (Opus round 7,
            # c); the href is what makes it a link.
            return ""
        # Signed in here: anything that is not plainly navigation is a write.
        if not allow_write:
            return (
                f"{label!r} on {host} would act on your account — call again with "
                f"allow_write=true, and only if a person has run: rokan-do allow {host} submit"
            )
        if not any(_host_matches(host, g.site) for g in _load()):
            return (
                f"{label!r} on {host} would act on your account and {host} has no grant — "
                f"a person must run: rokan-do allow {host} submit"
            )
        return ""

    return check


def action_asked(said: str) -> str:
    """The grant an ASK needs, from the words it uses — the same words
    `accept._NEVER` refuses on. "" when the ask names no write action."""
    from .accept import _asks_for  # noqa: PLC0415 — accept imports this module

    word = _asks_for(said.lower())
    if not word:
        return ""
    return DENY_LABELS.get(word, "") or _ACCEPT_WORD_ACTIONS.get(word, "")


#: `accept._NEVER` words that are not button labels, mapped to the action
#: a grant is given for.
_ACCEPT_WORD_ACTIONS: dict[str, str] = {
    "wire": "transfer",
    "deposit": "transfer",
    "refund": "pay",
    "top up": "pay",
    "add funds": "pay",
    "place an order": "pay",
    "place the order": "pay",
    "invalidate": "rotate",
    "disable": "cancel",
    "suspend": "cancel",
    "close": "cancel",
    "generate": "rotate",
    "create": "rotate",
    "issue": "rotate",
    "get a new": "rotate",
    "get another": "rotate",
    "request a new": "rotate",
    "get rid of": "delete",
    "email": "send",
    "forward": "send",
    "upload": "send",
}
