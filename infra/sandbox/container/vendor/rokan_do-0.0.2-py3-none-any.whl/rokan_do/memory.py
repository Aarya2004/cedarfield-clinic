"""Remembering what worked, so the second run costs nothing.

The first run of a task is an agent: a model reads the page and writes a
program. Every run after should be the program. That is the whole difference
between a demo and a tool — and it is the single largest published lever in
the literature (Agent Workflow Memory: +24.6% Mind2Web / +51.1% WebArena;
caching plans: -50% cost, -27% latency). Note (2026-08-25): memory that is
fed BACK to a model vanishes at matched token budget (2606.15017); memory
that REPLACES the call — this file — is a different quantity.

**The admission rule is the safety property.** A plan enters memory only if
it *ran* and its postcondition *passed*. Nothing else qualifies — not a plan
that looked reasonable, not one that failed on a transient error, not one a
model liked. A remembered plan is replayed without any model reviewing it, so
admitting an unproven plan would be handing the future to a guess.

**Keys are the site and the class, not the sentence.** "read my usage on
vercel.com" and "how much usage is left on vercel.com" are the same
operation; keying on the raw words would miss the hit and re-plan for
nothing. The site + class pair is what the plan actually depends on.

Storage reuses the agent's proven store: content-addressed blobs for the
plan, and counters per operation.

**Counters AND a ledger.** `uses`, `replays` and `failures` are
UPDATE-in-place integers — honest about what a run did, but not evidence:
no timestamps, and a later bug could rewrite them. The evidence is
`op_use` (2026-08-24): one row per use of an operation at any speed,
append-only under the same `RAISE(ABORT)` triggers that make
`store.observation` a record. It is what the half-life `h` — the number
nobody has published — is computed from, and it distinguishes "the
operation failed" (`ok = 0`) from "no verdict this run" (`ok IS NULL`: our
daemon was down, a password was rejected), because a durability curve that
counts our outages as the site changing is a curve about the wrong thing.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import re
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from datetime import UTC, datetime

from rokan_agent.core.proven import paths
from rokan_agent.core.reasons import Reason
from rokan_agent.core.store import Store

from .accept import strip_locations
from .executor import ExecutionFailed
from .ir import Plan, Step, Verb, validate
from .lines import STOP_WORDS, flatten
from .verify import Verdict

_SCHEMA = """
CREATE TABLE IF NOT EXISTS operation (
    key          TEXT PRIMARY KEY,
    task_class   TEXT NOT NULL,
    site         TEXT NOT NULL,
    plan_hash    TEXT NOT NULL,
    learned_at   TEXT NOT NULL,
    last_used_at TEXT,
    uses         INTEGER NOT NULL DEFAULT 0,
    replays      INTEGER NOT NULL DEFAULT 0,
    failures     INTEGER NOT NULL DEFAULT 0,
    retired_at   TEXT
);

-- The durability ledger. One row per use, forever: which operation, when,
-- at which speed, and whether it worked — `ok` is three-valued on purpose
-- (1 worked, 0 the operation failed, NULL no verdict: our side or the
-- world said nothing about the operation). A planned run that learned
-- nothing writes a row under op_key '' so the ledger still holds every
-- perform.
CREATE TABLE IF NOT EXISTS op_use (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    op_key     TEXT NOT NULL DEFAULT '',
    at         TEXT NOT NULL,
    ok         INTEGER,
    latency_ms INTEGER NOT NULL DEFAULT 0,
    path       TEXT NOT NULL,
    verdict    TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS op_use_by_key ON op_use(op_key, at);

-- The ledger is evidence. The same rule as `store.observation`: a later
-- "tidy-up" must fail loudly rather than quietly rewrite the only record
-- of how long a learned operation kept working.
CREATE TRIGGER IF NOT EXISTS op_use_is_append_only_update
BEFORE UPDATE ON op_use
BEGIN SELECT RAISE(ABORT, 'op_use is append-only'); END;

CREATE TRIGGER IF NOT EXISTS op_use_is_append_only_delete
BEFORE DELETE ON op_use
BEGIN SELECT RAISE(ABORT, 'op_use is append-only'); END;
"""

#: Added after the schema shipped: an operation may carry a compiled
#: endpoint. Kept as a nullable column rather than a second table because a
#: compiled form belongs to exactly one operation and dies with it.
_COMPILED_COLUMN = "ALTER TABLE operation ADD COLUMN compiled TEXT"

#: How many runs in a row may fail to reach the compiled endpoint before we
#: stop paying for the attempt. Five, because the common cause is a machine
#: that has just restarted and the daemon catches up within one or two runs;
#: a fault that survives five is not a hiccup.
UNAVAILABLE_LIMIT = 5

_UNAVAILABLE_COLUMN = (
    "ALTER TABLE operation ADD COLUMN unavailable_runs INTEGER NOT NULL DEFAULT 0"
)

#: The question this operation was learned from. Diagnosed on the frozen
#: real-site set: replay coverage was 4 of 19 because the matcher knew only
#: the ANCHORS, which paraphrase the value's line ("By default the limit is
#: set to") while the question names the concept ({curl, follow,
#: redirects}) — zero overlap, so the same question re-planned every time.
#: The learned question is the missing half of the operation's identity.
_LEARNED_COLUMN = "ALTER TABLE operation ADD COLUMN learned_said TEXT NOT NULL DEFAULT ''"

#: The behaviour digest the replacement guards compare (see
#: `_behaviour_hash`); `plan_hash` stays the blob's content address.
_BEHAVIOUR_COLUMN = (
    "ALTER TABLE operation ADD COLUMN behaviour_hash TEXT NOT NULL DEFAULT ''"
)

#: When a PERSON forgot this operation. Distinct from `retired_at`, which
#: drift sets and a later re-learn clears: a user's forget must survive the
#: next identical re-plan, or the command is a lie. Opus round 7 proved the
#: unguarded version — one later `remember` cleared `retired_at`, restored
#: the compiled endpoint, and the 4 ms path that served Toronto's 1834
#: paragraph was live again on evidence from the run that was forgotten.
_FORGOTTEN_COLUMN = "ALTER TABLE operation ADD COLUMN forgotten_at TEXT"

#: How many FULL-VERIFIER proofs an operation needs before the compiled
#: path — which never calls `verify` — may serve it.
#:
#: The replayed path re-verifies every hit, so it needs no quarantine. The
#: compiled path does not verify at all, and it used to be attached on the
#: first cold success: one verified-but-wrong answer bought a permanent
#: 4 ms shortcut to that wrong value (the Toronto-1834 shape). Three,
#: because two is a coincidence a single flaky page can produce and the
#: cost of waiting is seconds on the first runs.
COMPILE_QUARANTINE_N = 3

#: Consecutive failed replays that retire an operation. Only DRIFT_DETECTED
#: retired one before, so an operation failing for any other repeated
#: reason stayed live to fail again forever.
DEMOTE_AFTER = 3

#: Proofs of THIS behaviour by the full verifier (cold admissions and
#: verified replays both count; a re-plan restarts it).
_PROOFS_COLUMN = (
    "ALTER TABLE operation ADD COLUMN cold_proofs INTEGER NOT NULL DEFAULT 0"
)
_CONSECUTIVE_COLUMN = (
    "ALTER TABLE operation ADD COLUMN consecutive_failures INTEGER NOT NULL DEFAULT 0"
)

#: When the source-hint compiler last looked for this operation's endpoint.
#: Looking costs a page fetch, a few bundle fetches and up to three probes,
#: and on a site that has no endpoint the answer will not change between one
#: replay and the next — so it is asked ONCE per behaviour, not per run.
_COMPILE_TRIED_COLUMN = "ALTER TABLE operation ADD COLUMN compile_tried_at TEXT"

#: Native (Tier 0) operations live in their OWN table, deliberately isolated
#: from `operation`/`answers()`. A native op replays ONLY on an exact repeat of
#: the SAME normalised question on the SAME host — never fuzzy anchor matching —
#: so "wool runners" can never collide with "cancel my order" (the collision
#: defect that historically served a wrong value as verified). The blob never
#: reaches `SyntheticOperation.from_json` or the Plan `recall`.
_NATIVE_SCHEMA = """
CREATE TABLE IF NOT EXISTS native_op (
    host       TEXT NOT NULL,
    said_key   TEXT NOT NULL,
    blob       TEXT NOT NULL,
    learned_at TEXT NOT NULL,
    uses       INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (host, said_key)
);
"""


@dataclass(frozen=True, slots=True)
class Use:
    """One row of the durability ledger."""

    op_key: str
    at: str
    #: True worked · False the operation failed · None no verdict this run.
    ok: bool | None
    latency_ms: int
    #: "compiled" | "replayed" | "planned".
    path: str
    #: "ok", a `Reason` value, or a short word for the no-verdict cases.
    verdict: str


@dataclass(frozen=True, slots=True)
class Remembered:
    key: str
    plan: Plan
    learned_at: str
    uses: int
    replays: int
    failures: int
    #: The synthetic API, when this operation earned one. JSON, or "".
    compiled: str = ""
    #: The question(s) this operation was learned from, one per line — the
    #: anchors' missing half when a repeat of the question asks to replay.
    learned_said: str = ""


#: Distinct phrasings kept per operation. A dozen covers every wording an
#: actual person cycles through; past that the extra vocabulary only makes
#: the matcher more permissive, which is the wrong direction to drift.
_MAX_PHRASINGS = 12


def _native_said_key(said: str, site: str = "") -> str:
    """A stable key for the EXACT question, so a native op replays only on a
    true repeat. Removes the site/host token (so the same question keys the same
    whether the caller passed ``allbirds.com`` or ``www.allbirds.com``, and the
    literal host string in the question does not shift the key), lowercases,
    collapses whitespace, drops surrounding punctuation — then hashes. This is an
    EXACT match, never fuzzy: a paraphrase (or dropping/adding a word like "at")
    gets a different key and honestly costs one model call again, so it can never
    serve a neighbouring question's answer the way the Plan `answers()` path
    could."""
    text = said or ""
    bare = _host(site).removeprefix("www.")
    for loc in (site, _host(site), bare, f"www.{bare}"):
        if loc:
            text = text.replace(loc, " ")
    # Strip only scheme+host from any URL, KEEP the path — the path is the
    # resource's identity (reviewer P1: deleting it collided /pages/faq with
    # /pages/returns → run 2 got run 1's answer at 0 calls).
    text = re.sub(r"https?://[^\s/]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip(" .?!,;:").lower()
    # The path of the SITE argument is folded in too: when the caller passes the
    # full URL as `site`, the loop above deletes it (path and all) from `text`,
    # so the path must re-enter the key here or two sibling resources collide.
    resource = _path(site)
    key_input = f"{text}\x00{resource}"
    if not text and not resource:
        return ""
    return hashlib.sha256(key_input.encode()).hexdigest()[:32]


def _host(site: str) -> str:
    return site.split("://", 1)[-1].split("/", 1)[0].lower()


def _path(site: str) -> str:
    """The path portion, normalised. The resource's identity on most real
    dashboards — /projects/alpha vs /projects/beta — lives HERE, and the
    first key design discarded it: identical anchors on sibling resources
    gave identical keys, so beta's question replayed alpha's plan and
    served alpha's number as beta's verified answer (Opus review, F1,
    probe-proven). The path is part of what an operation IS.

    The fragment is dropped (it never reaches the server); the query is
    KEPT, because `?project=beta` is how some sites name a resource."""
    rest = site.split("://", 1)[-1].split("#", 1)[0]
    path = rest.split("/", 1)[1] if "/" in rest else ""
    return "/" + path.strip("/").lower() if path.strip("/") else ""


def _host_matches(host: str, wanted: str) -> bool:
    """Does a stored host answer to what the user typed?

    Exact, or a subdomain of it — the same rule `PrivateIndex.forget`
    uses, so one mental model covers both erasures. Ports are compared
    BOTH ways: the store keeps them (an origin needs the port) while
    `vault.normalize_host` strips them, so `forget("localhost")` has to
    reach `localhost:8477` (Opus round 7).
    """
    if not wanted:
        return False
    bare_host = host.split(":", 1)[0]
    bare_wanted = wanted.split(":", 1)[0]
    return (
        host == wanted
        or host.endswith("." + wanted)
        or bare_host == bare_wanted
        or bare_host.endswith("." + bare_wanted)
    )


def _op_paths(plan: Plan) -> tuple[str, ...]:
    """Where the plan actually GOES — every navigate target's path, sorted.

    The first F1 fix read the path off `plan.site`, which is what the user
    NAMED. `ir.validate` lets a plan navigate anywhere on the same site,
    so a bare-host question ("read my usage on acme.com") learned a plan
    that navigates to /projects/alpha with a row path of "" — and the
    guard's `row_path and` clause switched itself off (Opus re-review, F1,
    probe-proven). The SECOND fix took the LAST navigate target — which is
    the login page for every plan that ends by signing in, so logged-in
    operations lost replay entirely and sibling resources whose plans both
    end at /login collapsed into one key again (Opus third round, F1,
    probe-proven). The set of paths is the truth about the resource: the
    key digests all of them, and a request naming a path replays when its
    path is AMONG them. `plan.site` is only the fallback when a plan
    somehow navigates nowhere."""
    paths = sorted({
        _path(str(step.args.get("url", "")))
        for step in plan.steps
        if step.verb is Verb.NAVIGATE and step.args.get("url")
    })
    paths = [x for x in paths if x]
    if paths:
        return tuple(paths)
    fallback = _path(plan.site)
    return (fallback,) if fallback else ()


def key_for(
    site: str,
    task_class: str,
    markers: tuple[str, ...] = (),
    path: str | None = None,
) -> str:
    """What makes two requests the same operation.

    Host, class, and WHAT IS READ — the plan's anchors, digested. The first
    design stopped at host + class ("the plan depends on where it goes and
    what it proves, not on how the ask was phrased"), and that was one value
    too coarse: a host has many values, so after "read my usage" was
    remembered, "what is my current plan" on the same site replayed the
    usage plan and served the usage line as the verified answer to the plan
    question — reproduced live, at compiled speed, 4ms, before this changed
    (`tests/test_memory_answers_the_question.py`).

    Phrasing still does not enter the key: two wordings of the usage
    question converge on the same anchors, and anchors are what the digest
    is made of. `recall` is where a question meets an operation.
    """
    base = f"{task_class}@{_host(site)}"
    flat = sorted(flatten(m).lower() for m in markers if m)
    if not flat:
        return base
    digest = hashlib.sha256(
        "\n".join([_path(site) if path is None else path, *flat]).encode()
    ).hexdigest()[:12]
    # `path` carries the joined navigate paths (see `_op_paths`); a plain
    # site path is the caller's fallback.
    return f"{base}#{digest}"


def _markers_of(plan: Plan) -> tuple[str, ...]:
    """The read anchors — the plan's own statement of what it answers."""
    return tuple(
        str(step.args.get("contains", ""))
        for step in plan.steps
        if step.verb is Verb.READ_VALUE
    )


def _words(text: str) -> set[str]:
    """Content words, at identifier boundaries, minus the shared stop list.

    `[a-z0-9_]{3,}` keeps `keepalive_timeout` whole — the same lesson the
    quantity matcher learned: a word-boundary split loses exactly the
    identifiers this product is asked about.

    NOT stemmed, and that was measured rather than assumed: a plural fold
    ("lines" -> "line") was added on the theory that it would raise real-
    site replay coverage, and it changed nothing — 4 replays against the
    baseline's 5, fixture speeds identical — because the anchors the
    planner actually chooses did not carry the plural the theory imagined.
    Reverted under the reproduce-or-revert rule
    (docs/measurements/2026-08-23-warm-real-sites.txt).
    """
    return {
        w
        # A NUMBER OF ANY LENGTH counts. `{3,}` dropped 5, 10, 25, 50, 90,
        # so "the top 5 story titles" and "the top 25 story titles" had
        # identical vocabulary and `answers()` could not tell them apart —
        # the learned 5 replayed for a question asking 25, and the stored
        # plan carries `lines=5`. Same for a price: "under $50" replayed a
        # question asking "under $90" (found by an external reviewer,
        # 2026-08-27). A quantity is the most load-bearing word in a list
        # question, and it was the one word being thrown away.
        for w in re.findall(r"[a-z0-9_]{3,}|\d+", flatten(text).lower())
        if w not in STOP_WORDS
    }


def _prose_words(said: str, *locations: str) -> set[str]:
    """The question's content words, with its URLs stripped as SUBSTRINGS.

    Substrings, never token sets. Subtracting URL tokens was measured wrong
    on the first warm eval: the path `/status` is spelled like the subject
    "status", so token subtraction deleted the subject from "read the
    current status at …/status" and the lone survivor "current" replayed
    the CURRENT PLAN operation — `Current plan Enterprise` served as the
    verified answer to a status question. A word that appears in the prose
    survives this strip even when it also names the path; a word that
    appears ONLY inside the URL does not.

    Stripped by PATTERN as well as by the byte-exact locations: a
    capitalised host, or a site rewritten by discovery, never matched the
    literal replace (Opus review, F5 — the same defect in two modules).
    """
    for location in locations:
        if not location:
            continue
        said = said.replace(location, " ")
        said = said.replace(location.split("://", 1)[-1], " ")
    return _words(strip_locations(said))


def answers(said: str, plan: Plan, site: str = "", learned_said: str = "") -> bool:
    """Does this plan answer this question?

    EVERY content word of the question — its URLs stripped — must be
    accounted for by what the operation IS: its read anchors, or the
    question it was learned from. Any-overlap was the first version, and it
    has a hole this product cannot afford: "how many seats are INCLUDED"
    shares "seats" with a remembered "Seats USED" operation, and one shared
    word would replay the wrong value as a verified answer.

    The learned question is the anchors' missing half, and it was
    diagnosed, not guessed: on the frozen real-site set the anchors
    paraphrase the value's line ("By default the limit is set to") while
    the question names the concept ({curl, follow, redirects}) — zero
    overlap, so replay coverage was 4 of 19 and THE SAME QUESTION re-ran
    the model every time. Counting the learned question's words closes
    exactly that: a repeat (or a rewording inside the same vocabulary)
    replays; a genuinely new question still needs the anchors to cover it,
    so the collision direction stays shut — {current, plan} is not in the
    usage question or the usage anchors.

    Biased to say NO on purpose: a false no costs one re-plan (seconds,
    converging back into memory under its own anchors); a false yes serves
    the wrong value as a verified answer, which is the one failure this
    product promises not to have. `run_eval --warm` measures the trade.
    """
    asked = _prose_words(said, site, plan.site)
    if not asked:
        return False
    anchored: set[str] = set()
    for marker in _markers_of(plan):
        anchored |= _words(marker)
    # Route 1: the anchors alone answer it — and SYMMETRICALLY. One-sided,
    # this was the widest door left after F3 (Opus re-review, F2): the
    # anchor "Plan usage" answered "what is my plan", which is the very
    # C12 defect this redesign began from, back through the untouched
    # route. A label that says more than the question was asked about is
    # a label for something else.
    if asked <= anchored and anchored <= asked:
        return True
    # Route 2: one stored phrasing matches, SYMMETRICALLY. The one-sided
    # subset over a pooled vocabulary was proved wrong by the Opus review
    # (F3): an op learned from "how many seats are used out of the seats
    # included" answered "how many seats are included" — the docstring's
    # own counterexample, re-opened by pooling. Symmetry closes it: the
    # phrasing must not carry content the question and anchors cannot
    # account for either, so a phrasing that mentions the NEIGHBOURING
    # value refuses ("out" is unaccounted) while an exact repeat or a
    # stopword-level rewording still replays.
    for phrasing in learned_said.splitlines():
        p_words = _prose_words(phrasing, site, plan.site)
        if not p_words:
            continue
        if asked <= (p_words | anchored) and p_words <= (asked | anchored):
            return True
    return False


def _behaviour_hash(plan: Plan) -> str:
    """What the plan DOES, digested — steps without their narration.

    The plan-replacement guards (compiled, learned_said) compared blob
    hashes, and the blob carries `says`. Every LLM re-plan varies its
    narration, so a behaviourally identical re-plan wiped the phrasings
    and threw the compiled endpoint away on every run — the "dozen
    wordings" design and the millisecond path were both dead in the field
    (Opus third round, F2, probe-proven). Narration stays in the stored
    blob for the CLI to speak; it no longer decides identity."""
    behaviour = json.dumps(
        {
            "task_class": plan.task_class,
            "site": plan.site,
            "verify": plan.verify,
            "steps": [{"verb": s.verb.value, "args": s.args} for s in plan.steps],
            "postconditions": list(plan.postconditions),
        },
        separators=(",", ":"),
        sort_keys=True,
    )
    return hashlib.sha256(behaviour.encode()).hexdigest()


def _plan_to_json(plan: Plan) -> str:
    return json.dumps(
        {
            "task_class": plan.task_class,
            "site": plan.site,
            "verify": plan.verify,
            "steps": [
                {"verb": s.verb.value, "args": s.args, "says": s.says}
                for s in plan.steps
            ],
            "postconditions": list(plan.postconditions),
        },
        separators=(",", ":"),
        sort_keys=True,
    )


def _plan_from_json(raw: str) -> Plan:
    data = json.loads(raw)
    plan = Plan(
        task_class=data["task_class"],
        site=data["site"],
        verify=data["verify"],
        steps=tuple(
            Step(verb=Verb(s["verb"]), args=dict(s["args"]), says=s.get("says", ""))
            for s in data["steps"]
        ),
        postconditions=tuple(dict(c) for c in data.get("postconditions") or ()),
    )
    # Re-validated on the way OUT as well as in. A stored plan is a file on
    # disk: it can be edited, corrupted, or written by an older build whose
    # rules were laxer. Replaying without re-checking would trust the disk.
    return validate(plan)


class Memory:
    """The operation library. One per store; cheap to construct."""

    def __init__(self, store: Store | None = None) -> None:
        self._store = store or Store()
        self._path = self._store.path
        with closing(self._connect()) as conn:
            conn.executescript(_SCHEMA)
            # Suppressed, not guarded. Two processes on a fresh store both
            # see the column missing and both ALTER; the loser used to die
            # with "duplicate column name" and exit 1. A scheduler run plus a
            # manual one on a machine that has never run `do` is exactly that
            # window.
            for statement in (
                _COMPILED_COLUMN, _UNAVAILABLE_COLUMN, _LEARNED_COLUMN,
                _BEHAVIOUR_COLUMN, _FORGOTTEN_COLUMN, _PROOFS_COLUMN,
                _CONSECUTIVE_COLUMN, _COMPILE_TRIED_COLUMN,
            ):
                with contextlib.suppress(sqlite3.OperationalError):
                    conn.execute(statement)
            conn.execute(_NATIVE_SCHEMA)
            conn.commit()

    def _connect(self) -> sqlite3.Connection:
        """A connection the CALLER must close.

        `with conn:` is a transaction context, not a close. `Store` and
        `PrivateIndex` both wrap this in `closing()`; this class was the one
        that did not, and `library()` opened one per row.
        """
        paths.home()
        # A longer busy timeout and WAL, because this store is written from
        # more than one place at once: a run writes its ledger row while a
        # scheduler or a second terminal reads. The default five seconds
        # and a rollback journal turn that into `database is locked` under
        # exactly the concurrency the product invites (security review,
        # 2026-08-26). WAL is per-database and sticky; setting it on every
        # connect is a no-op after the first.
        conn = sqlite3.connect(self._path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        with contextlib.suppress(sqlite3.DatabaseError):
            conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def remember(
        self, plan: Plan, verdict: Verdict, said: str = ""
    ) -> str | None:
        """Admit a plan — only if it ran and its postcondition passed.

        Returns the key it was stored under, or None when the plan did not
        earn admission. The refusal is silent by design: a caller that has to
        handle "not admitted" would be tempted to admit it anyway.

        ``said`` is the question this plan just answered — the anchors'
        missing half in `answers`. Two phrasings converging on one anchor
        digest UNION their vocabularies here, so either phrasing replays.
        """
        if not verdict.passed:
            return None
        if "self_reported" in verdict.evidence:
            # Belt to the braces: a self_reported verdict is never `passed`,
            # and even if a verifier ever produced one that was, the label
            # itself bars the door. A replay of a guess is a guess replayed.
            return None
        key = key_for(
            plan.site,
            plan.task_class,
            _markers_of(plan),
            path="|".join(_op_paths(plan)),
        )
        blob = _plan_to_json(plan)
        digest = self._store.put_blob(blob)
        behaviour = _behaviour_hash(plan)
        now = datetime.now(UTC).isoformat()
        with closing(self._connect()) as conn:
            conn.execute(
                "INSERT INTO operation "
                "(key, task_class, site, plan_hash, learned_at, last_used_at, "
                " uses, learned_said, behaviour_hash, cold_proofs) "
                "VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, 1) "
                "ON CONFLICT(key) DO UPDATE SET "
                "  plan_hash = excluded.plan_hash, "
                "  behaviour_hash = excluded.behaviour_hash, "
                "  last_used_at = excluded.last_used_at, "
                "  uses = operation.uses + 1, "
                # A forgotten key stays forgotten, full stop. Drift
                # retirement still clears — that is what re-learning is for
                # — but nothing a later run does may undo a person.
                #
                # The first version excused a BEHAVIOURALLY different plan
                # as "a new thing", and that escape hatch was empty: the key
                # digests the navigate paths AND the read anchors, so every
                # plan that can land on this key reads the same line on the
                # same page. A genuinely different reading already gets its
                # own key and its own row. All the clause did was let an
                # ordinary LLM re-plan — which varies its steps routinely —
                # resurrect the forgotten answer (Opus round 8), and let
                # any row predating `behaviour_hash` resurrect on an
                # identical re-plan, since '' never compares equal.
                "  retired_at = CASE WHEN operation.forgotten_at IS NOT NULL "
                "    THEN operation.retired_at ELSE NULL END, "
                # Phrasings accumulate as LINES, and only while the plan is
                # the same one. The first version pooled words with a space
                # and unioned unconditionally — two defects the Opus review
                # proved (F2, F3): an old question's vocabulary vouched for
                # a REPLACED plan, and pooling let a phrasing that mentioned
                # the neighbouring value answer for it. The CASE mirrors the
                # `compiled` guard below, for the same reason it exists.
                "  learned_said = CASE "
                "    WHEN operation.behaviour_hash = excluded.behaviour_hash "
                "    THEN trim(operation.learned_said || char(10) || "
                "              excluded.learned_said) "
                "    ELSE excluded.learned_said END, "
                # A compiled endpoint belongs to the plan it was learned
                # from. The key is site + class, so a re-plan onto a
                # different page of the same host keeps the key and changes
                # the plan — and the old endpoint would then answer first,
                # instantly, about the wrong page. Its own postcondition
                # cannot catch that: it validates against its own anchor.
                "  compiled = CASE "
                "    WHEN operation.behaviour_hash = excluded.behaviour_hash "
                "    THEN operation.compiled ELSE '' END, "
                # A proof of THIS behaviour. A re-plan is a different thing
                # to trust, so its predecessor's proofs do not carry over.
                "  cold_proofs = CASE "
                "    WHEN operation.behaviour_hash = excluded.behaviour_hash "
                "    THEN operation.cold_proofs + 1 ELSE 1 END, "
                "  consecutive_failures = 0, "
                # A re-plan is a different behaviour, so the search for its
                # endpoint starts over too — the old answer was about the
                # old plan.
                "  compile_tried_at = CASE "
                "    WHEN operation.behaviour_hash = excluded.behaviour_hash "
                "    THEN operation.compile_tried_at ELSE NULL END",
                (key, plan.task_class, plan.site, digest, now, now, said, behaviour),
            )
            # Bounded and deduplicated (Opus review, F9: 200 re-learns of
            # one question grew the column to 18 KB of copies, and the
            # accounted vocabulary only ever grew). Newest phrasings win.
            row = conn.execute(
                "SELECT learned_said FROM operation WHERE key = ?", (key,)
            ).fetchone()
            if row is not None:
                # Deduplicated keeping the LAST occurrence, so "newest
                # phrasings win" is true for a repeated phrasing too (the
                # first version kept first-seen order and evicted the
                # question asked fifty times as soon as twelve novel
                # rewordings arrived — Opus re-review, F5).
                seen_lines = [
                    line.strip()
                    for line in str(row["learned_said"] or "").splitlines()
                    if line.strip()
                ]
                phrasings = list(reversed(list(dict.fromkeys(reversed(seen_lines)))))
                trimmed = "\n".join(phrasings[-_MAX_PHRASINGS:])
                if trimmed != str(row["learned_said"] or ""):
                    conn.execute(
                        "UPDATE operation SET learned_said = ? WHERE key = ?",
                        (trimmed, key),
                    )
            conn.commit()
        return key

    def remember_native(self, site: str, said: str, blob: str) -> None:
        """Persist a native (Tier 0) op so the SAME question on the SAME host
        replays at 0 model calls. Isolated from `operation`/`answers()`; keyed
        on the exact normalised question, never fuzzy anchors."""
        host = _host(site).removeprefix("www.")
        key = _native_said_key(said, site)
        if not host or not key or not blob:
            return
        now = datetime.now(UTC).isoformat()
        with closing(self._connect()) as conn:
            conn.execute(
                "INSERT INTO native_op (host, said_key, blob, learned_at, uses) "
                "VALUES (?, ?, ?, ?, 1) "
                "ON CONFLICT(host, said_key) DO UPDATE SET "
                "  blob = excluded.blob, uses = native_op.uses + 1",
                (host, key, blob, now),
            )
            conn.commit()

    def forget_native(self, site: str) -> int:
        """Erase every remembered native op for a host — the escape valve a
        native op otherwise lacks (reviewer P1: a wrong tool/input choice frozen
        on run 1 would replay free forever). Hard delete: a native op carries no
        incident value the way a verified Plan does (it is only ``self_reported``),
        and the next run simply re-selects. Returns the number removed."""
        host = _host(site).removeprefix("www.")
        if not host:
            return 0
        with closing(self._connect()) as conn:
            cur = conn.execute("DELETE FROM native_op WHERE host = ?", (host,))
            conn.commit()
            return cur.rowcount

    def recall_native(self, site: str, said: str) -> str | None:
        """The stored native-op blob for this exact question on this host, or
        None. Bumps `uses`. The caller re-checks the tool's schema + read/write
        gate before invoking (native.replay) — a stored record is never trusted
        blind."""
        host = _host(site).removeprefix("www.")
        key = _native_said_key(said, site)
        if not host or not key:
            return None
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT blob FROM native_op WHERE host = ? AND said_key = ?",
                (host, key),
            ).fetchone()
            if row is None:
                return None
            conn.execute(
                "UPDATE native_op SET uses = uses + 1 WHERE host = ? AND said_key = ?",
                (host, key),
            )
            conn.commit()
        return str(row["blob"])

    def recall(
        self, site: str, task_class: str, said: str = ""
    ) -> Remembered | None:
        """The remembered plan for this operation, if one earned its place.

        With ``said``, only a plan that ANSWERS the question is returned —
        one whose read anchors share a content word with it. Without
        ``said`` (tooling, tests, the library listing) the most recently
        used operation on the host wins, which is the old behaviour.

        Rows are fetched by class and filtered by host in Python rather
        than by key, because one host now holds one row PER VALUE — and
        because rows written before the anchor-digest key (bare
        ``class@host``) are still candidates.

        HONESTY about those legacy rows (Opus review, F7): with no stored
        phrasings they match only questions the ANCHORS alone can account
        for, which most real questions are not — so a store predating
        ``learned_said`` largely re-earns its operations cold. That is a
        one-time cost per operation, and the alternative (any-overlap
        matching as a fallback) is the rule that was measured serving
        wrong answers.
        """
        host = _host(site)
        wanted_path = _path(site)
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT * FROM operation "
                "WHERE task_class = ? AND retired_at IS NULL "
                "ORDER BY last_used_at DESC",
                (task_class,),
            ).fetchall()
        for row in rows:
            if _host(str(row["site"])) != host:
                continue
            # A request that NAMES a path names a resource, and an
            # operation learned on a sibling resource must not answer it —
            # /projects/alpha's plan replayed for /projects/beta's question
            # and served alpha's number as beta's verified answer (Opus
            # review, F1, probe-proven). A bare-host request matches any
            # path; the word matching below still governs.
            found = self._as_remembered(row)
            if found is None:
                continue
            # Compared against where the plan GOES (`_op_paths`), never
            # against what was named — see `_op_paths` for both bypasses.
            row_paths = _op_paths(found.plan)
            if wanted_path and row_paths and wanted_path not in row_paths:
                continue
            if said and not answers(
                said, found.plan, site, found.learned_said
            ):
                continue
            return found
        return None

    def _as_remembered(self, row: sqlite3.Row) -> Remembered | None:
        blob = self._store.get_blob(row["plan_hash"])
        if blob is None:
            # The row outlived its plan. Treat as no memory rather than as an
            # error: re-planning is always available and always correct.
            return None
        try:
            plan = _plan_from_json(blob)
        except Exception:  # noqa: BLE001 — a corrupt plan is simply no plan
            return None
        return Remembered(
            key=str(row["key"]),
            plan=plan,
            learned_at=row["learned_at"],
            uses=int(row["uses"]),
            replays=int(row["replays"]),
            failures=int(row["failures"]),
            # sqlite3.Row has no .get; membership is over its keys() view,
            # and the column may be absent in a store written before it.
            compiled=str(row["compiled"] or "") if "compiled" in set(row.keys()) else "",
            learned_said=(
                str(row["learned_said"] or "")
                if "learned_said" in set(row.keys())
                else ""
            ),
        )

    def compiled_ready(self, key: str, compiled_json: str) -> None:
        """Attach a synthetic API to an operation that earned one.

        A newly earned shortcut starts its patience over: whatever outage
        history the previous one accumulated is not this one's.
        """
        with closing(self._connect()) as conn:
            conn.execute(
                "UPDATE operation SET compiled = ?, unavailable_runs = 0 "
                "WHERE key = ?",
                (compiled_json, key),
            )
            conn.commit()

    def compile_searched(self, key: str) -> bool:
        """Has the source-hint compiler already looked for this endpoint?

        One look per behaviour. A site with no endpoint gives the same
        answer every replay, and paying seven fetches to hear it again is
        the kind of cost that makes a fast path slower than the slow one.
        """
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT compile_tried_at FROM operation WHERE key = ?", (key,)
            ).fetchone()
        return row is not None and bool(row["compile_tried_at"])

    def compile_searched_now(self, key: str) -> None:
        """Record that the look happened, whatever it found."""
        with closing(self._connect()) as conn:
            conn.execute(
                "UPDATE operation SET compile_tried_at = ? WHERE key = ?",
                (datetime.now(UTC).isoformat(), key),
            )
            conn.commit()

    def compile_allowed(self, key: str) -> bool:
        """Has this operation been proven enough times to earn the path that
        does not verify?

        Counts proofs by the FULL verifier only: cold admissions and
        verified replays. A re-plan resets them, because the proofs belonged
        to the behaviour that was replaced.
        """
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT cold_proofs FROM operation WHERE key = ?", (key,)
            ).fetchone()
        return row is not None and int(row["cold_proofs"] or 0) >= COMPILE_QUARANTINE_N

    def demoted(self, key: str) -> bool:
        """Was this operation retired by a run of failures?"""
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT retired_at, consecutive_failures FROM operation WHERE key = ?",
                (key,),
            ).fetchone()
        if row is None:
            return False
        return row["retired_at"] is not None and (
            int(row["consecutive_failures"] or 0) >= DEMOTE_AFTER
        )

    def fast_path_unavailable(self, key: str) -> int:
        """Count a run where the shortcut could not even be attempted.

        Keeping a compiled operation through our own outages is right, and it
        has a cost that must not be paid indefinitely: every run then spends a
        daemon round trip and up to the fast-path timeout before falling back.
        Right for the first restart, wrong for the hundredth.

        Returns the new consecutive count. Any successful use resets it — the
        point is a *run* of failures, not a lifetime total.
        """
        with closing(self._connect()) as conn:
            conn.execute(
                "UPDATE operation SET unavailable_runs = unavailable_runs + 1 "
                "WHERE key = ?",
                (key,),
            )
            row = conn.execute(
                "SELECT unavailable_runs FROM operation WHERE key = ?", (key,)
            ).fetchone()
            conn.commit()
        return int(row["unavailable_runs"]) if row is not None else 0

    def fast_path_worked(self, key: str) -> None:
        """Forget the run of outages. One success proves the shortcut lives."""
        with closing(self._connect()) as conn:
            conn.execute(
                "UPDATE operation SET unavailable_runs = 0 WHERE key = ?", (key,)
            )
            conn.commit()

    def drop_compiled(self, key: str) -> None:
        """Throw the fast path away. Called the moment it stops agreeing with
        the page — the slow path is always correct, so losing the shortcut
        costs seconds, while keeping a wrong one costs the truth.

        The outage counter goes with it. Only `fast_path_worked` used to
        clear it, so after the first episode of five outages the count stood
        at five forever: every subsequently re-earned compiled endpoint was
        deleted on its FIRST transient failure. The docstring's "a run of
        failures, not a lifetime total" held only until the first drop.
        """
        with closing(self._connect()) as conn:
            conn.execute(
                "UPDATE operation SET compiled = NULL, unavailable_runs = 0 "
                "WHERE key = ?",
                (key,),
            )
            conn.commit()

    def record_use(
        self,
        op_key: str,
        *,
        path: str,
        ok: bool | None,
        latency_ms: int = 0,
        verdict: str = "",
    ) -> None:
        """Append one row to the durability ledger. Never updates, never
        deletes — the triggers make that structural.

        ``ok=None`` is the row for a run that said nothing about the
        operation: our daemon was down, the site rejected the password, a
        stored row would not parse. It is written so the ledger holds every
        attempt, and it is excluded from survival arithmetic so a laptop
        that was asleep for a week does not read as a site that changed.
        """
        with closing(self._connect()) as conn:
            conn.execute(
                "INSERT INTO op_use (op_key, at, ok, latency_ms, path, verdict) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    op_key,
                    datetime.now(UTC).isoformat(),
                    None if ok is None else int(ok),
                    int(latency_ms),
                    path,
                    verdict[:120],
                ),
            )
            conn.commit()

    def uses(self, op_key: str | None = None) -> list[Use]:
        """The ledger, oldest first — for one operation, or all of them."""
        with closing(self._connect()) as conn:
            if op_key is None:
                rows = conn.execute("SELECT * FROM op_use ORDER BY id").fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM op_use WHERE op_key = ? ORDER BY id", (op_key,)
                ).fetchall()
        return [
            Use(
                op_key=str(r["op_key"]),
                at=str(r["at"]),
                ok=None if r["ok"] is None else bool(r["ok"]),
                latency_ms=int(r["latency_ms"]),
                path=str(r["path"]),
                verdict=str(r["verdict"] or ""),
            )
            for r in rows
        ]

    def record_replay(
        self,
        key: str,
        *,
        passed: bool,
        path: str = "replayed",
        latency_ms: int = 0,
        verdict: str = "",
    ) -> None:
        """Every replay counts, especially the failures — they are what makes
        a durability number honest later.

        Writes the `op_use` row as well as bumping the counters, so the two
        cannot drift apart: a verified replay is `ok=1`, a failed one `ok=0`.
        ``path`` names which fast path this was ("compiled" for the endpoint,
        "replayed" for the browser plan)."""
        self.record_use(
            key,
            path=path,
            ok=passed,
            latency_ms=latency_ms,
            verdict=verdict or ("ok" if passed else "failed"),
        )
        now = datetime.now(UTC).isoformat()
        with closing(self._connect()) as conn:
            if passed:
                conn.execute(
                    # A verified replay ran the FULL verifier, so it is
                    # exactly the evidence the compile quarantine wants —
                    # without this a warm machine could never earn the
                    # shortcut at all.
                    "UPDATE operation SET replays = replays + 1, uses = uses + 1, "
                    "cold_proofs = cold_proofs + 1, consecutive_failures = 0, "
                    "last_used_at = ? WHERE key = ?",
                    (now, key),
                )
            else:
                conn.execute(
                    "UPDATE operation SET failures = failures + 1, uses = uses + 1, "
                    "consecutive_failures = consecutive_failures + 1, "
                    "last_used_at = ? WHERE key = ?",
                    (now, key),
                )
                # A run of failures is an operation that does not work.
                # Retiring it costs seconds (the next run re-plans) and
                # stops a broken replay being attempted forever.
                run = conn.execute(
                    "SELECT consecutive_failures FROM operation WHERE key = ?",
                    (key,),
                ).fetchone()
                if run is not None and int(run[0]) >= DEMOTE_AFTER:
                    conn.execute(
                        "UPDATE operation SET retired_at = ? "
                        "WHERE key = ? AND retired_at IS NULL",
                        (now, key),
                    )
            conn.commit()

    @staticmethod
    def failure_retires_the_plan(
        error: BaseException | None, verdict: Verdict | None
    ) -> bool:
        """Did this failure prove the plan is stale, or just that today went
        badly?

        Only one thing proves staleness, and it has two shapes: something
        found the page no longer carries what the plan was written against —
        a step, or the postcondition. Everything else — no daemon, a dead
        socket, a locked vault, a site down for a minute — says nothing about
        the plan, and retiring on it would delete proven work for a reason
        that will be gone in a minute. The user would never see an error;
        they would just find that every task had quietly become slow again.

        "The verifier failed" is NOT on its own such evidence, and treating
        it as evidence was a real defect: `verify_key_used` returns a failing
        verdict when there is no endpoint to spend the key against, so
        replaying a proven operation without repeating `--probe` destroyed
        it. The reason the verifier gives is the part that carries meaning.
        """
        if verdict is not None and not verdict.passed:
            return verdict.reason is Reason.DRIFT_DETECTED
        if verdict is None and isinstance(error, ExecutionFailed):
            return error.reason is Reason.DRIFT_DETECTED
        return False

    def retire(self, key: str) -> bool:
        """Stop replaying an operation, keep its record.

        Used when a remembered plan drifts: the next run re-plans from
        scratch, and the history of how long this one lasted survives.
        """
        with closing(self._connect()) as conn:
            cursor = conn.execute(
                "UPDATE operation SET retired_at = ? WHERE key = ? AND retired_at IS NULL",
                (datetime.now(UTC).isoformat(), key),
            )
            conn.commit()
            return cursor.rowcount > 0

    def forget(self, site: str, reads: str = "") -> list[tuple[str, str]]:
        """Retire every live operation on a host. Returns (key, reads) rows.

        The user-facing half of `retire`. A person who catches Rokan
        replaying a wrong answer had NO way to stop it — the poisoned
        Wikipedia operation in reality batch 4 was retired with hand-written
        SQL, which is not a product. Soft, like every other retirement here:
        the row stays as the incident record, `recall` skips it, the
        compiled shortcut goes with it, and the next run re-plans.

        Rows are read DIRECTLY rather than through `library()`, because a
        row whose plan blob is missing or corrupt is invisible there — and
        an operation you cannot see is exactly the one you most need to be
        able to forget.

        `reads` narrows to operations whose read anchors contain that text,
        for a host holding several: forgetting the population operation
        should not cost you the area one.
        """
        wanted = _host(site)
        found: list[tuple[str, str]] = []
        now = datetime.now(UTC).isoformat()
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT key, site, plan_hash FROM operation WHERE retired_at IS NULL"
            ).fetchall()
            for row in rows:
                host = _host(str(row["site"]))
                if not _host_matches(host, wanted):
                    continue
                anchors = ""
                readable = True
                blob = self._store.get_blob(str(row["plan_hash"]))
                if blob is not None:
                    try:
                        anchors = " · ".join(_markers_of(_plan_from_json(blob)))
                    except Exception:  # noqa: BLE001 — a corrupt plan still forgets
                        anchors, readable = "(unreadable plan)", False
                else:
                    anchors, readable = "(plan missing)", False
                # An unreadable row cannot be EXCLUDED on evidence, so
                # `--reads` never filters one out — the alternative is the
                # exact failure this method was written to avoid, one flag
                # deep: the poisoned row survives and the command reports
                # the host as empty (Opus round 7).
                if reads and readable and reads.lower() not in anchors.lower():
                    continue
                conn.execute(
                    # The shortcut goes with the operation. The compiled
                    # path never calls `verify`, so leaving it would let a
                    # resurrection serve the forgotten answer in four
                    # milliseconds on evidence the user rejected.
                    "UPDATE operation SET retired_at = ?, forgotten_at = ?, "
                    "  compiled = '', unavailable_runs = 0 WHERE key = ?",
                    (now, now, str(row["key"])),
                )
                found.append((str(row["key"]), anchors))
            conn.commit()
        return found

    def knows_behaviour(self, behaviour_hash: str) -> bool:
        """Has this exact behaviour EVER been stored — live, retired, or
        forgotten? `library()` hides retired rows, and a seed re-install
        that looked only there resurrected a rotted operation and bumped
        its proofs toward the compile quarantine on every install (Opus
        round 8, A2). A retired row is a record, and a record is a no."""
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT 1 FROM operation WHERE behaviour_hash = ? LIMIT 1",
                (behaviour_hash,),
            ).fetchone()
        return row is not None

    def behaviour_state(self, behaviour_hash: str) -> str:
        """"" when unknown; else why a seed with this behaviour is not
        installed again: live, retired by the page, or forgotten by a person."""
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT retired_at, forgotten_at FROM operation WHERE behaviour_hash = ? LIMIT 1",
                (behaviour_hash,),
            ).fetchone()
        if row is None:
            return ""
        if row["forgotten_at"] is not None:
            return "you forgot this one — ask the question to re-learn it"
        if row["retired_at"] is not None:
            return "retired here — the live page refuted it"
        return "already installed"

    def live_hosts(self) -> list[str]:
        """Hosts with at least one live operation — for an honest miss."""
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT DISTINCT site FROM operation WHERE retired_at IS NULL"
            ).fetchall()
        return sorted({_host(str(r["site"])) for r in rows})

    def library(self) -> list[Remembered]:
        """Every learned operation — by ROW, not by recall.

        Recalling by site+class here listed one operation per host and, once
        a host held several, listed the most recent one several times.
        """
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT * FROM operation "
                "WHERE retired_at IS NULL ORDER BY last_used_at DESC"
            ).fetchall()
        out: list[Remembered] = []
        for row in rows:
            found = self._as_remembered(row)
            if found is not None:
                out.append(found)
        return out
