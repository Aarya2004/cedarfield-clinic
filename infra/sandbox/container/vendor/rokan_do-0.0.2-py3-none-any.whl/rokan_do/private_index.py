"""Exa for the web only you can see.

Exa can tell you where Vercel's usage page lives because that URL is public.
It cannot tell you where *your* invoice for last March is, what your project
is called, or which of eleven dashboards holds the number you want — those
pages exist only inside your session, and no crawler will ever index them.

So Rokan indexes them itself. Every page the loop reaches is already fetched,
already authenticated, already in memory; recording a small, structured trace
of it costs nothing extra and turns the account you use every day into a
searchable map. Discovery then has two sources with one interface:

    public  → Exa      (what anyone can see)
    private → here     (what only this machine, with these cookies, can see)

**What is stored, and what is not.** Titles, URLs, and the anchor phrases
that identify lines — the skeleton of a page. Never the values beside those
anchors, never page bodies, never anything that looks like a credential. The
index answers *where to look*, not *what it said*: the value must be read
live, because a stored value is a stale value and reporting one would be the
quiet lie this whole product exists to avoid.

**It never leaves the machine.** No upload, no sync, no shared graph. That is
not a limitation to fix later — a private index that syncs is just someone
else's cloud holding your account map.
"""

from __future__ import annotations

import contextlib
import re
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from datetime import UTC, datetime

from rokan_agent.core.proven import paths
from rokan_agent.core.store import Store

_SCHEMA = """
CREATE TABLE IF NOT EXISTS page (
    url        TEXT PRIMARY KEY,
    host       TEXT NOT NULL,
    title      TEXT NOT NULL DEFAULT '',
    anchors    TEXT NOT NULL DEFAULT '',
    seen_lines TEXT NOT NULL DEFAULT '',
    seen_at    TEXT NOT NULL,
    times_seen INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS page_by_host ON page(host);
"""

#: A line worth indexing as an anchor: words, not values. "Usage this month"
#: is a landmark; "4,812,000" is data that will be wrong tomorrow.
_ANCHOR = re.compile(r"^[A-Za-z][A-Za-z ’'&/-]{3,48}$")

#: And SHORT. A label is two or three words; a sentence is content.
#:
#: Recurrence alone does not separate them, because a persistent header and
#: a standing notification card recur exactly as reliably as a section name
#: does. Run against a realistic authenticated page, recurrence kept "Signed
#: in as Arav Kekane", "Dr Melissa Chan biopsy results ready" and "Primary
#: care physician Dr Ann Lee" — a person's name, their doctor's name, and a
#: health event, on disk, in a file whose docstring promises the skeleton of
#: a page and never its body.
#:
#: Three words keeps every landmark the real pages use — "Usage this month",
#: "Amount due", "Two-factor", "Acme Cloud Console", "Uptime this month" —
#: and drops every sentence above, including "Billing address Toronto
#: Ontario", which is an address wearing a label's clothes.
#:
#: It is a blunt rule and it is the honest one: the alternative is a promise
#: the code does not keep. The cost is a landmark longer than three words
#: going unindexed, which costs one `--discover` miss and no correctness.
_MAX_ANCHOR_WORDS = 3

#: Lines that look like credentials or one-time codes never enter the index,
#: even as anchors — and neither does the line AFTER one, because a label and
#: its value are two lines and it is the second that matters.
_NEVER_INDEX = re.compile(
    r"(sk-|api[ _-]?keys?|bearer |password|secret|token|credential"
    r"|recovery phrase|seed phrase|mnemonic|one[ -]?time|verification code"
    r"|passphrase|2fa|otp\b|[0-9]{6}\b)",
    re.IGNORECASE,
)

#: How many anchors per page. Enough to identify a page, few enough that the
#: index stays a map rather than a copy.
_MAX_ANCHORS = 12

#: Candidates considered per visit before promotion. Larger than the anchor
#: cap, because only the ones that survive a second visit are kept.
_MAX_CANDIDATES = 40


@dataclass(frozen=True, slots=True)
class KnownPage:
    url: str
    title: str
    anchors: tuple[str, ...]
    seen_at: str
    times_seen: int

    def matches(self, words: tuple[str, ...]) -> int:
        """How many of the wanted words this page's skeleton accounts for."""
        haystack = f"{self.title} {' '.join(self.anchors)} {self.url}".lower()
        return sum(1 for word in words if word in haystack)


def _bare(url: str) -> str:
    """The page's address without its query or fragment.

    A URL is user-supplied and routinely carries a credential: a magic link,
    a password-reset token, a signed download. `_NEVER_INDEX` only ever saw
    page TEXT, so "read my balance at https://app.bank.com/login?token=SECRET"
    stored that token as a primary key and printed it back from `find`.
    """
    base, _, _ = url.partition("#")
    base, _, _ = base.partition("?")
    return base


def candidate_lines(page_text: str) -> tuple[str, ...]:
    """Lines that COULD be landmarks. Not yet trusted to be.

    Shape alone cannot tell a label from a message. "Usage this month" and
    "Dr Melissa Chan biopsy results ready" are both a run of words, and the
    first version of this file indexed both — along with "Signed in as Arav
    Kekane" and, after correctly refusing the line "Recovery phrase", the
    twelve words on the line below it.

    So this returns candidates, and `record` promotes only the ones that were
    still there on a later visit. See `PrivateIndex.record`.
    """
    found: list[str] = []
    skip_next = False
    for raw in page_text.splitlines():
        line = raw.strip()
        if not line:
            skip_next = False
            continue
        if _NEVER_INDEX.search(line):
            # And whatever follows it: a secret's label is what we can
            # recognise, and the secret itself is the next line.
            skip_next = True
            continue
        if skip_next:
            skip_next = False
            continue
        # Strip a trailing value so "Usage this month 42 GB" indexes as its
        # label. Keeps the landmark, drops the datum.
        # The value must start at a WORD boundary. Without the leading
        # whitespace requirement this ate the "-1" out of "Region us-east-1"
        # and indexed the mangled "Region us-east" — a landmark that is not
        # on the page, which is worse than no landmark at all.
        label = re.sub(r"[\s:·—][\s:·—-]*[\d][\d,.\s%A-Za-z$€£]*$", "", line).strip()
        candidate = label or line
        if (
            _ANCHOR.match(candidate)
            and len(candidate.split()) <= _MAX_ANCHOR_WORDS
            and candidate not in found
        ):
            found.append(candidate)
        if len(found) >= _MAX_CANDIDATES:
            break
    return tuple(found)


def anchors_from(page_text: str) -> tuple[str, ...]:
    """Kept for callers that want the raw candidates. NOT what is stored."""
    return candidate_lines(page_text)


class PrivateIndex:
    """The map of pages this machine has actually reached, signed in."""

    def __init__(self, store: Store | None = None) -> None:
        self._store = store or Store()
        self._path = self._store.path
        with closing(self._connect()) as conn:
            conn.executescript(_SCHEMA)
            # Suppressed rather than guarded: two processes on a fresh store
            # both see the column missing, both ALTER, and the loser used to
            # die with "duplicate column name".
            with contextlib.suppress(sqlite3.OperationalError):
                conn.execute("ALTER TABLE page ADD COLUMN seen_lines TEXT DEFAULT ''")
            conn.commit()

    def _connect(self) -> sqlite3.Connection:
        """A connection the CALLER must close.

        `with conn:` is a transaction context, not a close — every call here
        used to leak a connection and its file descriptor until GC. Callers
        wrap this in `closing()`.
        """
        paths.home()
        conn = sqlite3.connect(self._path)
        conn.row_factory = sqlite3.Row
        return conn

    def record(self, url: str, page_text: str, title: str = "") -> KnownPage:
        """Index one page the loop just reached. Called after every success.

        **Only what was there twice becomes an anchor.** A label recurs every
        visit; a message subject, a person's name, a doctor's note and a
        balance do not. Shape cannot tell those apart — "Usage this month"
        and "Dr Melissa Chan biopsy results ready" are both a run of words —
        so recurrence does the work a regex could not, and the file's claim
        to store landmarks rather than content becomes structural.

        The cost is that a page is not findable until its second visit. That
        is the right trade for an index of pages behind someone's login.
        """
        url = _bare(url)
        host = url.split("://", 1)[-1].split("/", 1)[0].lower()
        candidates = candidate_lines(page_text)
        now = datetime.now(UTC).isoformat()
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT seen_lines, anchors FROM page WHERE url = ?", (url,)
            ).fetchone()
            before = tuple(
                line for line in (row["seen_lines"].split("\n") if row else []) if line
            )
            # The intersection, in this visit's order: what the page still
            # says that it also said last time.
            kept = tuple(line for line in candidates if line in set(before))[
                :_MAX_ANCHORS
            ]
            if not title:
                title = kept[0] if kept else host
            conn.execute(
                "INSERT INTO page "
                "(url, host, title, anchors, seen_lines, seen_at, times_seen) "
                "VALUES (?, ?, ?, ?, ?, ?, 1) "
                "ON CONFLICT(url) DO UPDATE SET "
                "  title = excluded.title, anchors = excluded.anchors, "
                "  seen_lines = excluded.seen_lines, "
                "  seen_at = excluded.seen_at, times_seen = page.times_seen + 1",
                (
                    url,
                    host,
                    title,
                    "\n".join(kept),
                    "\n".join(candidates),
                    now,
                ),
            )
            conn.commit()
            times = int(
                conn.execute(
                    "SELECT times_seen FROM page WHERE url = ?", (url,)
                ).fetchone()["times_seen"]
            )
        return KnownPage(url, title, kept, now, times)

    def find(self, service: str, wanted: str, *, limit: int = 3) -> list[KnownPage]:
        """Pages on this service whose skeleton matches what was asked for.

        Ranked by how much of the ask a page accounts for, then by how often
        it has been visited — a page you open weekly is more likely the one
        you mean than one seen once.
        """
        host = service.split("://", 1)[-1].split("/", 1)[0].lower().removeprefix("www.")
        words = tuple(
            w for w in re.findall(r"[a-z]{3,}", wanted.lower()) if w not in _STOPWORDS
        )
        with closing(self._connect()) as conn:
            rows = conn.execute(
                # ESCAPE, because the host comes from the user's sentence and
                # `%` in it would otherwise match every host in the index —
                # and `--discover` then opens an unrelated site.
                "SELECT * FROM page WHERE host = ? OR host LIKE ? ESCAPE '\\'",
                (host, "%." + host.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")),
            ).fetchall()
        pages = [
            KnownPage(
                url=row["url"],
                title=row["title"],
                anchors=tuple(a for a in row["anchors"].split("\n") if a),
                seen_at=row["seen_at"],
                times_seen=int(row["times_seen"]),
            )
            for row in rows
        ]
        scored = [(page.matches(words), page.times_seen, page) for page in pages]
        scored = [entry for entry in scored if entry[0] > 0]
        scored.sort(key=lambda entry: (-entry[0], -entry[1]))
        return [page for _, _, page in scored[:limit]]

    def known_hosts(self) -> list[str]:
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT host, COUNT(*) AS n FROM page GROUP BY host ORDER BY n DESC"
            ).fetchall()
        return [row["host"] for row in rows]

    def forget(self, host: str) -> int:
        """Erase everything known about a service. The index is a
        convenience; a user must be able to unmake it.

        The host is normalised exactly as `record` normalises it. It was
        not, so `forget("Acme.com")` and `forget("https://acme.com")` both
        matched nothing and reported success — which is the worst possible
        answer for a command whose entire purpose is erasure.
        """
        host = host.split("://", 1)[-1].split("/", 1)[0].lower().removeprefix("www.")
        with closing(self._connect()) as conn:
            cursor = conn.execute(
                "DELETE FROM page WHERE host = ? OR host LIKE ? ESCAPE '\\'",
                (host, "%." + host.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")),
            )
            conn.commit()
            return cursor.rowcount


_STOPWORDS = frozenset(
    {
        "the", "my", "for", "and", "how", "much", "many", "what", "which",
        "read", "get", "check", "from", "with", "this", "that", "page",
        "your", "please", "show",
    }
)
