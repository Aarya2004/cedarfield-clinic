"""Reading a public page without starting a browser.

browser-harness's skill contract puts this first, and we were breaking it
on every task: *"A basic fetch of public information needs no browser. If
a plain HTTP request can read it — a public page, an API, docs — use
`curl` and leave the browser alone… If a direct fetch fails or returns a
shell page, then escalate to the browser."*

Measured before this file existed
(`docs/measurements/2026-08-24-http-first-premise.md`):

* **120–341 ms** on our own task pages against a **3,400 ms** cold median
  with Chromium — 10–25×, and the RAM as well as the time;
* **34 of 34** labelled answers on the registered set are findable in the
  text this module produces, including the two the browser path currently
  answers WRONGLY.

**This can only ever be an optimisation.** It is not a second way to be
right: the same postconditions run on the same text, and anything this
cannot answer falls through to the browser exactly as before. It never
runs for a host with a stored login or for a question about the user's
own account, because the session lives in the browser profile and an
HTTP fetch would be signed out — reading the logged-OUT page as if it
were the user's is the Supabase failure with a faster clock.
"""

from __future__ import annotations

import html as htmllib
import http.client
import ipaddress
import re
import socket
import urllib.request
from typing import Any
from urllib.parse import urlsplit

#: Text past this is not read. A 200 MB page must not become 200 MB of
#: RAM: this project has already taken a laptop down once.
MAX_TEXT_CHARS = 400_000

#: Bytes read off the socket, before any decoding.
_MAX_BYTES = 4_000_000

_TIMEOUT_S = 12.0

#: Below this, "the fetch worked" is not the same as "the page is here" —
#: a JS shell returns 200 and a nearly empty body. Escalate instead.
_SHELL_CHARS = 200

#: Sent so a site sees an ordinary reader rather than a bare urllib. Not a
#: spoof of a browser we are not: no Sec-CH-UA, no fabricated build.
_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) rokan-do/0.1",
    "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}

_DROP_ELEMENTS = re.compile(
    r"(?is)<(script|style|noscript|svg|template|iframe)[^>]*>.*?</\1>"
)
_BLOCK_END = re.compile(
    r"(?i)<br\s*/?>|</(p|div|li|tr|td|th|h[1-6]|section|article|pre|dt|dd)>"
)
_TAG = re.compile(r"(?s)<[^>]+>")
_INLINE_SPACE = re.compile(r"[ \t\xa0  ]+")


class NotFetchable(RuntimeError):
    """The URL is not a public http(s) target this path may open."""


#: Redirect hops allowed. urllib's own default is 10; a public page that
#: needs more than a handful is not a page we are reading in a hurry.
_MAX_REDIRECTS = 5


class _GuardedRedirects(urllib.request.HTTPRedirectHandler):
    """Every hop is checked, not only the first.

    CODE REVIEW, HIGH: `check_public` validated the URL we were given and
    then `urlopen` followed `Location` with the default opener, which
    re-validates nothing. A page the user names could redirect the fetch
    to 127.0.0.1 or to 169.254.169.254 — the cloud metadata endpoint —
    and the body came back as page text. This module's own docstring
    already claimed redirects somewhere private were handled; now they
    are.
    """

    max_redirections = _MAX_REDIRECTS

    def redirect_request(  # noqa: PLR0913
        self,
        req: urllib.request.Request,
        fp: Any,
        code: int,
        msg: str,
        headers: Any,
        newurl: str,
    ) -> urllib.request.Request | None:
        check_public(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def to_text(body: str) -> str:
    """HTML to line-structured text, close enough to `innerText` to anchor on.

    Block ends become newlines because every anchor in this product is
    LINE-scoped: collapse two table cells onto one line and an anchor
    matches a line whose value belongs to something else. Non-breaking
    spaces are normalised for the same reason a measurement once cost us
    an answer — nodejs.org writes `Type: <integer>\\xa0Default: 65536`.
    """
    without_code = _DROP_ELEMENTS.sub(" ", body)
    broken = _BLOCK_END.sub("\n", without_code)
    stripped = _TAG.sub(" ", broken)
    unescaped = htmllib.unescape(stripped)
    lines = (_INLINE_SPACE.sub(" ", line).strip() for line in unescaped.splitlines())
    return "\n".join(line for line in lines if line)[:MAX_TEXT_CHARS]


def was_capped(text: str) -> bool:
    """Did `to_text` cut this page off?

    CODE REVIEW, MEDIUM: the HTTP path reported `truncated=False`
    unconditionally while `to_text` slices at `MAX_TEXT_CHARS`, so on a
    long page the trace stated a falsehood — the past-the-cap rescue
    never ran and the user was told a value was "not on the page" when it
    was. That is the curl-manpage failure the field exists for.
    """
    return len(text) >= MAX_TEXT_CHARS


def looks_like_a_shell(text: str) -> bool:
    """Did we get a page, or the wrapper a page renders into?"""
    return len(text.strip()) < _SHELL_CHARS


def check_public(url: str) -> None:
    """Refuse anything that is not a public http(s) host.

    This path fetches a URL with no browser and none of the daemon's
    origin discipline, so without this it is an SSRF gadget: loopback,
    link-local (169.254.169.254 is the cloud metadata endpoint), and
    private ranges are all refused, before any connection is made.
    """
    parts = urlsplit(url)
    if parts.scheme not in {"http", "https"}:
        raise NotFetchable(f"{parts.scheme or 'that'} is not an http(s) URL")
    host = parts.hostname or ""
    if not host:
        raise NotFetchable("no host in that URL")
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise NotFetchable("a local host is not a public page")
    candidates: list[str] = []
    try:
        candidates.append(str(ipaddress.ip_address(host)))
    except ValueError:
        try:
            resolved = socket.getaddrinfo(host, None)
        except OSError as exc:  # noqa: PERF203 — a host we cannot resolve
            raise NotFetchable(f"cannot resolve {host}") from exc
        candidates.extend(str(info[4][0]) for info in resolved)
    for raw in candidates:
        try:
            # macOS returns scoped addresses like `fe80::1%en0`, which
            # `ip_address` refuses. A host that resolves to something we
            # cannot parse is not a public page (CODE REVIEW, LOW: this
            # escaped `eligible` as a bare ValueError).
            address = ipaddress.ip_address(raw)
        except ValueError as exc:
            raise NotFetchable(f"{host} resolves to an unparseable address") from exc
        if (
            address.is_private
            or address.is_loopback
            or address.is_link_local
            or address.is_reserved
            or address.is_multicast
            or address.is_unspecified
        ):
            raise NotFetchable(f"{host} resolves to a non-public address")


def _vault_has(host: str) -> bool:
    try:
        from rokan_mcp import vault  # noqa: PLC0415

        return vault.get(host) is not None
    except Exception:  # noqa: BLE001 — a vault we cannot read grants nothing
        return True


def _has_credential(host: str) -> bool:
    """Does this host, or a parent of it, have a stored login?

    CODE REVIEW, MEDIUM: the lookup was exact, so a login stored for
    `vercel.com` did not stop the fast path on `app.vercel.com` — and the
    signed-OUT page would then be read as if it were the user's. Walks up
    to the registrable-looking parent, stopping before the public suffix.
    """
    parts = host.split(".")
    for depth in range(len(parts) - 1):
        candidate = ".".join(parts[depth:])
        if candidate.count(".") == 0:
            break
        if _vault_has(candidate):
            return True
    return False


def eligible(url: str, said: str) -> bool:
    """May this task read without a browser?

    Three ways to be ineligible, and each is a correctness rule rather
    than a preference: the host has a stored login (the session is in the
    browser profile, so HTTP would read the signed-OUT page), the question
    is about the user's own account (same reason, from the other side), or
    the target is not a public address.
    """
    from .verify import needs_a_session  # noqa: PLC0415

    if needs_a_session(said):
        return False
    try:
        check_public(url)
    except NotFetchable:
        return False
    host = urlsplit(url).hostname or ""
    return not _has_credential(host)


_OPENER = urllib.request.build_opener(_GuardedRedirects())


def _open(url: str, timeout: float) -> bytes:
    request = urllib.request.Request(url, headers=_HEADERS)
    with _OPENER.open(request, timeout=timeout) as response:  # noqa: S310
        return bytes(response.read(_MAX_BYTES))


def read(url: str) -> str | None:
    """The page's text, or None — and None always means "use the browser".

    Every failure is silent by design. A refusal, a timeout, a shell page,
    a redirect somewhere private: none of them is an answer, and all of
    them mean the same thing to the caller.
    """
    try:
        check_public(url)
        raw = _open(url, _TIMEOUT_S)
    except (NotFetchable, OSError, ValueError, http.client.HTTPException):
        # `HTTPException` subclasses neither OSError nor ValueError, so a
        # malformed status line or a short body raised straight out of
        # `execute` (CODE REVIEW, MEDIUM) — the opposite of what this
        # docstring promises.
        return None
    # Capped again HERE, not only inside `_open`: the cap must belong to
    # this function, not to one implementation of the fetch.
    html = raw[:_MAX_BYTES].decode("utf-8", "replace")
    text = to_text(html)
    if looks_like_a_shell(text):
        return None
    _LAST_HTML[url] = html
    return text


#: The markup of the most recent successful `read`, so a caller that needs
#: the page's STRUCTURE — where it repeats itself, for a list — does not
#: have to fetch it twice. One entry: the reader wants the page it is
#: holding, and a cache that grows is a memory leak in a long session.
_LAST_HTML: dict[str, str] = {}


def last_html(url: str) -> str:
    """The markup `read(url)` parsed, or "" if that was not the last read."""
    return _LAST_HTML.get(url, "")


#: A line carries a value if it holds a digit or one of the state words the
#: daemon's own filter uses. Mirrored from `_cmd_relevant_lines`'s JS so the
#: HTTP path and the browser path choose the same lines — two filters that
#: disagree would make the fast path a different product.
_VALUEISH = re.compile(
    r"\d|\b(?:operational|enabled|disabled|active|yes|no)\b", re.IGNORECASE
)


def relevant_lines(text: str, words: list[str], limit: int = 40) -> list[str]:
    """The lines that could carry the asked-for value, best first.

    The Python twin of the daemon's `relevant_lines`, kept deliberately
    identical in rule: a line must carry a value AND share a task word,
    scored by how many words it shares, capped. A test holds the two
    implementations to the same answers.
    """
    scored: list[tuple[int, str]] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or not _VALUEISH.search(line):
            continue
        low = line.lower()
        score = sum(1 for word in words if word in low)
        if words and not score:
            continue
        scored.append((score, line[:300]))
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [line for _score, line in scored[:limit]]


def plan_may_use_http(plan: object) -> bool:
    """Is this a plan the fast path may serve at all?

    A plan that ASSERTS is a plan the browser runs. `read_value`
    escalates to the browser when the fast text misses; `assert_contains`
    has no such rescue, so a JS-rendered assertion started failing on
    pages that passed before the fast path existed (CODE REVIEW,
    MEDIUM). Keeping the whole plan on one transport is simpler than two
    escalation paths, and assertions are rare.

    A plan that ACTS is a browser plan too: a click or a fill needs the page
    loaded in the browser it acts on. Over the HTTP text the browser still
    shows whatever the previous task left open, so the action would land on
    a stale page — and the misread fallback would then run it a second time
    (round 10).
    """
    from .ir import ACTION_VERBS, Verb  # noqa: PLC0415

    steps = getattr(plan, "steps", ())
    return not any(
        step.verb is Verb.ASSERT_CONTAINS or step.verb in ACTION_VERBS for step in steps
    )
