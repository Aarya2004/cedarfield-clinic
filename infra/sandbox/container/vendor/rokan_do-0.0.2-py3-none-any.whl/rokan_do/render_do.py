"""Saying no in this product's own words.

`rokan-agent`'s renderer is right for a watcher: when a watch abstains, "the
page changed in a way it cannot safely repair" is exactly what happened. When
a *task* is refused because Rokan has no way to prove it, that same sentence
is nonsense — it describes a page nobody opened, for a request that never got
that far.

Rather than fork a conformance-tested renderer, this module supplies the two
lines that are genuinely different (the headline and the reason clause) and
hands everything else — the shape, the trust line, the colour rules, exit 0 —
back to the original. Part A stays the single source of shape.
"""

from __future__ import annotations

import sys
from typing import TextIO

from rokan_agent.adapters.cli import render as agent_render
from rokan_agent.core.result import Result, Status

#: Headlines for the refusals this product actually produces. A key absent
#: here falls through to the agent's summary, which is correct for the
#: reasons that mean the same thing in both products (no credential, bot
#: check, browser missing).
_HEADLINES: dict[str, str] = {
    "abstained_no_repair_class": "Rokan cannot prove this one, so it will not try",
    "abstained_low_confidence": "not enough to go on yet",
    "drift_detected": "the page was not what the plan expected",
    "navigation_failed": "the page did not load",
    "abstained_planner_unavailable": "Rokan could not reach its model provider",
    # Same words as the agent's summary — the entry exists so the refusal
    # takes THIS module's path and earns a `next` in this product's
    # commands, instead of the shared table's watcher guidance.
    "captcha_blocked": "a bot check is in the way",
}

#: Why, in this product's terms. The agent's "0% of breaks in this class are
#: safely auto-fixable" is about repairing a broken watch; here the honest
#: sentence is about proof.
_WHY: dict[str, str] = {
    "abstained_no_repair_class": (
        "there is no way to check it worked, and an unchecked action is a guess"
    ),
    "abstained_low_confidence": "the request is missing something Rokan will not invent",
    "drift_detected": "what it found does not match what it planned against",
    # Was absent while its headline was present, so the "why" field rendered
    # blank — and `reasons.py` says in as many words that blank guidance is
    # worse than none.
    "navigation_failed": "the page could not be reached, so nothing was read",
    "abstained_planner_unavailable": (
        "planning is the one step that needs a model, and it did not answer"
    ),
    "captcha_blocked": (
        "the site wants a person to pass a challenge, and Rokan never solves "
        "one itself"
    ),
}

#: Phrases that mark guidance as belonging to the watcher rather than to
#: `do`. Cheap, and checked rather than assumed: the shared reason table is
#: right for its own product and wrong here.
_WATCHER_COMMANDS = ("rokan watch", "rokan check", "rokan history", "<id>")

#: What to actually DO about it, in this product's commands. Without this the
#: guidance came from the shared reason table and told a `do` user to run
#: "rokan watch relearn <id>" — a command for a thing they never created,
#: about an id that does not exist. This module's docstring says that
#: mismatch is why it exists; the headline and the why were fixed and the
#: line the user would actually type was not.
_NEXT: dict[str, str] = {
    "drift_detected": (
        'The page moved. Run it again with --fresh to re-plan from scratch: '
        'rokan-do --fresh "<your task>"'
    ),
    "navigation_failed": (
        "Check the address, and that you can open it in your own browser. "
        "If it was a blip, running the same command again is safe."
    ),
    "abstained_low_confidence": (
        'Name the site and what to read, for example: '
        'rokan-do "read my usage at <site>"'
    ),
    "captcha_blocked": (
        'Solve it in a real window: ROKAN_BROWSER_WATCH=1 rokan-do "<your '
        'task>" — the session it earns is kept, so the normal run works '
        "after that."
    ),
}


def render(result: Result, *, stream: TextIO | None = None) -> int:
    """Part A's shape, this product's words."""
    out: TextIO = stream if stream is not None else (
        sys.stderr if result.status is Status.ERROR else sys.stdout
    )
    if result.status is Status.OK or result.reason is None:
        return agent_render.render(result, stream=out)

    code = result.reason.value
    headline = _HEADLINES.get(code)
    why = _WHY.get(code)
    if headline is None and why is None:
        return agent_render.render(result, stream=out)

    colour = agent_render._colour_ok(out)  # noqa: SLF001 — shape stays shared
    # "abstained" is a specific claim — Rokan declined, and exit 0 says so.
    # Printing it above an exit-1 error told the user the opposite of what
    # happened: `drift_detected` and `navigation_failed` are ERRORs, and the
    # loop's own doctrine ("exhaustion is an abstention, never a shrug")
    # cannot be enforced by the word alone.
    verb = "abstained" if result.status is Status.ABSTAINED else "stopped"
    mark = "⏸" if result.status is Status.ABSTAINED else "✕"
    lines: list[str] = [
        "",
        f"  {mark} {verb} — {headline or code.replace('_', ' ')}",
        "",
    ]
    lines.extend(agent_render._field("class", code))  # noqa: SLF001
    # The detail, when there is one worth reading. Every refusal carried a
    # `last=` in evidence and none of it ever reached the screen — including
    # "no ANTHROPIC_API_KEY … run: export ANTHROPIC_API_KEY=...", which is
    # the entire answer for a first-time user.
    detail = next(
        (e.split("=", 1)[1] for e in result.evidence if e.startswith("last=")), ""
    )
    if detail:
        lines.extend(agent_render._field("detail", detail))  # noqa: SLF001
    lines.extend(agent_render._field("why", why or ""))  # noqa: SLF001
    # The result's own next_step wins when the gate wrote one — it names the
    # actual missing slot, which no table can. It loses when it came from the
    # shared reason table, because that table's guidance is the watcher's and
    # sends a `do` user to a command about an id they never created.
    following = result.next_step
    if not following or any(w in following for w in _WATCHER_COMMANDS):
        following = _NEXT.get(code, "")
    if following:
        lines.extend(agent_render._field("next", following))  # noqa: SLF001
    lines.append("")
    if result.status is Status.ABSTAINED:
        trust = agent_render.TRUST_LINE
        lines.append(f"  \033[2m{trust}\033[0m" if colour else f"  {trust}")

    for line in lines:
        print(line, file=out)
    return result.exit_code
