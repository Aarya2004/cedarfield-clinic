"""Turning a proven operation into the API the site never published.

A browser is a slow way to read a number. The number came from somewhere — a
JSON response the page fetched and rendered — and once we know *which*
response, the browser stops being necessary: the next run asks that endpoint
directly, inside the same authenticated session, and answers in milliseconds.

This is the synthetic API. Not a scraper and not a guess at a public API:
the site's own internal endpoint, discovered from traffic we already caused,
bound to the user's own session.

**How the endpoint is found, with no per-site rules.** `identify.py` scores
every recorded response by weighted leaf-value overlap with the rendered page:
a telemetry beacon shares nothing with the screen, the endpoint that fed the
table shares almost everything. Its own docstring states the bet — if this
needs hand-tuning per site, the feature is a consultancy and should not exist.

**Why compilation is earned, never assumed.** An operation is compiled only
after it was verified by the loop, and the compiled form is *re-verified the
first time it replays*. If the fast path answers with something the
postcondition refuses, it is thrown away and the browser path returns — a
compiled operation is a shortcut, never an authority.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from urllib.parse import urlparse

from rokan_mcp.identify import RecordedSession, identify_data_response

#: Below this, the winning response did not really carry the page's data —
#: forcing a synthetic API here would build a fast way to be wrong. The
#: falsifier's job is to tell us whether this number is right on real sites;
#: until it has run, it is a starting point, not a tuned value.
MIN_CONFIDENCE = 0.35

#: How far ahead of the runner-up the winner must be. A near-tie means two
#: responses look equally like the page, and picking one is a coin flip.
MIN_MARGIN = 0.10


@dataclass(frozen=True, slots=True)
class SyntheticOperation:
    """One endpoint that answers what a page load answered, without the page."""

    url: str
    method: str
    #: The line the browser path produced, kept so replay can prove it agrees
    #: with what the page showed rather than merely returning JSON.
    expected_anchor: str
    confidence: float
    margin: float
    compiled_at: str
    #: Where in the response the value lived, as a dotted path. Recorded for
    #: the ledger and for humans; replay re-searches rather than trusting it,
    #: because a shape that moved is exactly what drift looks like.
    value_path: str = ""
    #: The exact token the answer was made of at compile time. Replay
    #: re-reads the live value using this as its landmark; it is never
    #: returned as the answer itself.
    value_marker: str = ""
    #: Every slot that carried this value at compile time, when more than
    #: one did. Replay requires them to STILL agree: they were one fact
    #: then, and a divergence means the fact has split. Empty for the
    #: ordinary single-slot case, where `value_path` says everything.
    value_paths: tuple[str, ...] = ()
    #: WHERE that token sat in the anchor line, as offsets.
    #:
    #: `locate_value` computes a whole-token span precisely so the marker
    #: "24" cannot bind to the "24" inside "2024" — and then the replay threw
    #: that work away by doing a plain first-occurrence `str.replace`.
    #: Measured: anchor "Aug 2024 - 24 GB used" with the endpoint now
    #: reporting 99 replayed as "Aug 2099 - 24 GB used" — the year mangled
    #: AND the stale value still displayed, in five milliseconds, with every
    #: check passing.
    value_start: int = -1
    value_end: int = -1
    #: Which embedded blob on the page holds the value, when the answer is
    #: not the response body itself: "__NEXT_DATA__", "script#…",
    #: "window.__X__". Empty for an ordinary endpoint. A server-rendered
    #: page has no endpoint to call, but it carries the state it rendered
    #: from — measured over 25 sites, that state holds the answer on 13 of
    #: the 21 that render at all (2026-08-27).
    extract: str = ""
    #: How this operation was found: "" for the identifier's ranking over
    #: recorded traffic, "source_hint" for an endpoint the site's own code
    #: (or its own address) named. The two populations must never be
    #: averaged — a ranking reports a measured margin, a source hint has
    #: none to report (security review, 2026-08-26).
    source: str = ""
    #: The page this operation was learned from, WITH its port. An origin
    #: check is not a credential lookup: the vault strips ports (one login
    #: serves a site whatever its port), and comparing against a stripped
    #: host refused every dev server and non-standard-port site — measured.
    page_url: str = ""

    def to_json(self) -> str:
        return json.dumps(
            {
                "url": self.url,
                "method": self.method,
                "expected_anchor": self.expected_anchor,
                "confidence": round(self.confidence, 4),
                "margin": round(self.margin, 4),
                "compiled_at": self.compiled_at,
                "source": self.source,
                "extract": self.extract,
                "value_path": self.value_path,
                "value_paths": list(self.value_paths),
                "value_marker": self.value_marker,
                "value_start": self.value_start,
                "value_end": self.value_end,
                "page_url": self.page_url,
            },
            separators=(",", ":"),
            sort_keys=True,
        )

    @classmethod
    def from_json(cls, raw: str) -> SyntheticOperation:
        data = json.loads(raw)
        return cls(
            url=data["url"],
            method=data.get("method", "GET"),
            expected_anchor=data.get("expected_anchor", ""),
            confidence=float(data.get("confidence", 0.0)),
            margin=float(data.get("margin", 0.0)),
            compiled_at=data.get("compiled_at", ""),
            value_path=data.get("value_path", ""),
            value_marker=data.get("value_marker", ""),
            value_start=int(data.get("value_start", -1)),
            value_end=int(data.get("value_end", -1)),
            page_url=data.get("page_url", ""),
            value_paths=tuple(data.get("value_paths") or ()),
            source=data.get("source", ""),
            extract=data.get("extract", ""),
        )


class CannotCompile(RuntimeError):
    """The traffic did not contain a defensible answer. Not an error — the
    browser path keeps working, which is the whole point of having one."""


@dataclass(frozen=True, slots=True)
class _Leaf:
    """One scalar in a response, and whether JSON called it a number.

    The type is load-bearing. "Contains a digit" put order ids, ISO dates,
    quarters and region codes in the same bucket as the value someone asked
    for, and the bucket's tie-break then picked whichever came first on the
    line — which, for an id or a date, is always the wrong one. JSON already
    knows the difference: 4812 is a number and "2026-08-20" is a string.
    """

    path: str
    text: str
    #: JSON's own number type, OR a string that is entirely a number.
    #: Money and percentages arrive as strings far more often than not
    #: ("88.20", "1204.55"), and leaving them out of the numeric bucket let
    #: an order id win a line it shared with a price.
    numeric: bool
    #: True if any part of the path is a list index. Positions inside a list
    #: are not stable — an appended row shifts nothing, a prepended one shifts
    #: everything — so these cannot be compiled against.
    in_list: bool


def _is_number(node: object, text: str) -> bool:
    if isinstance(node, int | float):
        return True
    try:
        float(text.replace(",", ""))
    except ValueError:
        return False
    return True


def _leaves(body: str) -> list[_Leaf]:
    """Every scalar in the response, with its path and its JSON type."""
    try:
        parsed = json.loads(body)
    except ValueError:
        return []
    found: list[_Leaf] = []

    def walk(node: object, path: str, in_list: bool) -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                walk(value, f"{path}.{key}" if path else str(key), in_list)
        elif isinstance(node, list):
            for index, value in enumerate(node[:50]):
                walk(value, f"{path}[{index}]", True)
        elif node is not None and not isinstance(node, bool):
            text = str(node).strip()
            if text:
                found.append(_Leaf(path, text, _is_number(node, text), in_list))

    walk(parsed, "", False)
    return found


#: Words that mark the number after them as a bound rather than the value:
#: "4812 GB of 10000", "3 out of 5", "12/100". A quota is a number on the
#: same line that will still be there next year, and it is the single most
#: common way for two numbers to appear together on a page.
#: A digit anywhere — the shape of a value that varies.
_HAS_DIGIT = re.compile(r"\d")

_BOUND_WORDS = re.compile(r"(?:\bof\b|\bout of\b|\bmax\b|\blimit\b|/)\s*$")


def _match_spans(line: str, value: str) -> list[tuple[int, int]]:
    """EVERY place ``value`` appears in ``line`` as a whole token.

    All of them, because one leaf can appear more than once on a line and
    the occurrences are not interchangeable: "Pro features enabled -
    current plan Pro" has the value at the label and a mention of it in
    prose, and only one of them is the answer. Returning the first match
    put the stored offsets on the wrong one, and the self-consistency check
    could not tell, because both occurrences are the same string.

    Whole-token, because a substring match would bind the marker "0" to the
    zero inside "10000" and then report the quota as the answer.

    The span, not just the offset, because the caller needs the text AS THE
    PAGE WROTE IT. A JSON `1204.55` matching a page reading "1,204.55" must
    record the page's spelling: the marker is later substituted into the
    anchor line, and substituting the JSON spelling replaced nothing, which
    made every formatted currency value self-destruct the first time it
    moved — reported as site drift that had not happened.
    """
    candidates = [value]
    if any(character.isdigit() for character in value):
        # A number the page may have written with separators. Build a pattern
        # that tolerates them rather than stripping the line, so the span
        # stays a real slice of the original.
        digits = value.replace(",", "")
        candidates.append(digits)
    for needle in candidates:
        if not needle:
            continue
        loose = re.escape(needle).replace(r"\.", r"\.")
        if any(character.isdigit() for character in needle):
            # Allow a comma or thin space between any two digits.
            loose = "[,\u202f\u00a0 ]?".join(re.escape(c) for c in needle)
        spans = [
            (match.start(), match.end())
            for match in re.finditer(loose, line)
            if not (line[match.start() - 1] if match.start() else " ").isalnum()
            and not (line[match.end()] if match.end() < len(line) else " ").isalnum()
        ]
        if spans:
            return spans
    return []


def locate_value(anchor_line: str, body: str) -> tuple[str, str, int, int] | None:
    """Which leaf is the answer, and where — (marker, path, start, end).

    Read off the DATA, never guessed from the words. Two earlier versions got
    this wrong in ways that both end the same way — an instant, confident,
    stale answer — so the rule is now stated as narrowly as it can be, and
    anything it cannot separate is refused.

    1. Only leaves JSON calls NUMBERS compete as numbers. "Contains a digit"
       put order ids, ISO dates, quarters and region codes in the same bucket
       as the value, and then picked the leftmost — which for an id or a date
       is always the wrong one.
    2. A number introduced by a bound word ("of 10000", "out of 5", "/100")
       is a quota, not the value, and drops out.
    3. If more than one number still matches, we cannot tell which one was
       asked for. Refuse. The browser path answers in seconds and is right;
       a guess here is wrong in milliseconds and stays wrong.
    4. With no number at all, the answer is text, and a text value follows
       its label — so the match that ends latest wins.

    The marker returned is the page's spelling of the value, sliced out of
    the anchor line, because the marker is later substituted back into that
    line.
    """
    line = anchor_line.strip()
    numeric: list[tuple[int, int, _Leaf]] = []
    #: Guarded below, once the marker is known: a marker that occurs TWICE
    #: on the anchor line cannot be accounted for. Splicing one occurrence
    #: leaves the other stale ("Free features enabled - current plan Pro");
    #: splicing both FABRICATES the second ("Current plan: Pro — upgrade to
    #: Pro Max" became "upgrade to Free Max", a tier that does not exist).
    #: Both are horns of one dilemma and the house rule settles it: what we
    #: cannot separate, we refuse (Opus review F1, reproduced 2026-08-27).
    textual: list[tuple[int, int, _Leaf]] = []
    for leaf in _leaves(body):
        spans = _match_spans(line, leaf.text)
        if not spans:
            continue
        if leaf.in_list:
            # A position inside a list does not survive the list changing,
            # and "row 0" silently becoming a different row is a wrong answer
            # wearing the right label.
            continue
        # One entry per leaf, at its best occurrence — earliest for a number
        # (a value follows its label and the constants follow the value),
        # latest for text (a text value is what trails the label). Adding one
        # entry per OCCURRENCE would make a single leaf mentioned twice look
        # like the two-values ambiguity that refuses.
        if leaf.numeric:
            start, end = spans[0]
        else:
            start, end = max(spans, key=lambda s: s[1])
        (numeric if leaf.numeric else textual).append((start, end, leaf))

    if numeric:
        real = [
            (start, end, leaf)
            for start, end, leaf in numeric
            if not _BOUND_WORDS.search(line[:start])
        ]
        if len(real) > 1:
            # Two numbers on one line and nothing separating them. An
            # unresolvable choice must not be resolved.
            return None
        if real:
            start, end, leaf = real[0]
            if len(_match_spans(line, line[start:end])) > 1:
                return None
            return line[start:end], leaf.path, start, end
        return None
    if textual:
        start, end, leaf = max(textual, key=lambda item: item[1])
        if _HAS_DIGIT.search(line) and not _HAS_DIGIT.search(line[start:end]):
            # The line carries a number, and the token we would compile
            # against does not. That token is the LABEL, not the value:
            # `express 5.2.1` compiled against `pkg.name = "express"` still
            # says 5.2.1 after the package ships 5.3.0 — instantly,
            # confidently, and wrong (found by a test, 2026-08-27). A
            # string value that CONTAINS the number ("1.0.229") is
            # unaffected, which is the crates.io case.
            return None
        # Rule 3, for text. The latest-ending span is a real decision when
        # two leaves match DIFFERENT spans of the line ("Pro" and "current
        # plan Pro"). It is not a decision when two leaves claim the SAME
        # span: their spans are equal, so the winner is whichever
        # `_leaves` happened to yield first — JSON document order.
        #
        # Measured by the Opus reviewer on a Statuspage-shaped summary
        # carrying "All Systems Operational" in both `status.description`
        # and a denormalised `page.status_description`: the copy won, the
        # site later reported a major outage, the copy was never updated,
        # `agrees_with_page` passed (the path still exists), the status
        # shape passed (still a state word) — and the wrong answer was
        # served in nine milliseconds, forever. An unresolvable choice
        # must not be resolved.
        claimants = sorted(
            other.path
            for other_start, other_end, other in textual
            if (other_start, other_end) == (start, end)
        )
        if len(claimants) > 1:
            # More than one slot carries this value. Which one the page
            # meant is unknowable HERE — but it is checkable LATER: see
            # `locate_agreeing_paths`, which compiles all of them and
            # refuses the moment they stop agreeing. `locate_value` keeps
            # the strict single-slot contract its callers rely on.
            return None
        if len(_match_spans(line, line[start:end])) > 1:
            return None
        return line[start:end], leaf.path, start, end
    return None


def locate_agreeing_paths(
    anchor_line: str, body: str
) -> tuple[str, tuple[str, ...], int, int] | None:
    """`locate_value`, but a tie is kept rather than refused.

    Rich APIs carry the same fact in several slots. crates.io reports
    `1.0.229` at `crate.max_version`, `crate.newest_version`,
    `crate.default_version` AND `crate.max_stable_version` — four names for
    what is, today, one number. `locate_value` refuses that, correctly:
    guessing which slot the page meant is how a denormalised copy gets
    served through a real outage (Opus round 13).

    There is a third answer between guessing and refusing: **compile all of
    them, and require that they still agree.** They agree now, so any of
    them is the value; if they ever diverge, the fact they were standing in
    for has split and nobody knows which one the page means — which is
    exactly when the browser should answer instead. The ambiguity becomes a
    checkable invariant rather than a coin flip.

    Returns (marker, paths, start, end) with `paths` in a stable order, or
    None when nothing matched or a number was ambiguous (numbers keep the
    old rule: two different numbers on a line are not one fact).
    """
    single = locate_value(anchor_line, body)
    if single is not None:
        marker, path, start, end = single
        return marker, (path,), start, end
    line = anchor_line.strip()
    textual: list[tuple[int, int, _Leaf]] = []
    for leaf in _leaves(body):
        if leaf.in_list or leaf.numeric:
            continue
        spans = _match_spans(line, leaf.text)
        if spans:
            textual.append((*max(spans, key=lambda s: s[1]), leaf))
    if not textual:
        return None
    start, end, _ = max(textual, key=lambda item: item[1])
    claimants = sorted(
        {
            leaf.path
            for other_start, other_end, leaf in textual
            if (other_start, other_end) == (start, end)
        }
    )
    if len(claimants) < 2:
        return None
    if len(_match_spans(line, line[start:end])) > 1:
        return None
    return line[start:end], tuple(claimants), start, end


def locate_span(anchor_line: str, body: str) -> tuple[str, str, int, int] | None:
    """`locate_value`, with the position it chose.

    The position comes from the SAME decision as the marker, and it has to.
    An earlier version re-derived it by searching the line again — which
    returns the FIRST whole-token match, while `locate_value` deliberately
    takes the one that ends latest for text. On a line where the marker
    occurs twice the stored offsets then pointed at the wrong occurrence,
    and the self-consistency check could not notice because both
    occurrences are the same string:

        anchor "Pro features enabled - current plan Pro"  marker "Pro"
        endpoint now says "Free"
        served "Free features enabled - current plan Pro"

    The user had downgraded and the labelled position still read Pro. That
    is the same class of defect the offsets were introduced to fix, brought
    back by the helper that was supposed to carry them.
    """
    return locate_value(anchor_line, body)


def payload_of(operation: SyntheticOperation, body: str) -> str:
    """The text this operation's value lives in.

    Ordinarily the response body itself. For an operation compiled from a
    page's embedded state, the blob named by `extract` — re-found by name
    on the page as it is NOW, never by position, because a page that
    reorders its script tags has not changed its data.
    """
    if not operation.extract:
        return body
    from .source_hint import embedded_state  # noqa: PLC0415 — one direction only

    for name, blob in embedded_state(body):
        if name == operation.extract:
            return blob
    return ""


def read_live_value(operation: SyntheticOperation, body: str) -> str | None:
    """The value as the endpoint reports it NOW — not as it was compiled.

    Returning the stored anchor would make the fast path a cache with no
    expiry, which is the one failure this product cannot have: an answer that
    is instant, confident, and last week's.

    The re-read is positional, not textual. At compile time we recorded WHERE
    in the response the value sat (``value_path``); the live value is
    whatever sits there now. Searching the body for the old value instead
    would find nothing precisely when the number has changed — which is the
    only case that matters.
    """
    if not operation.value_marker or not operation.value_path:
        # A row with no recorded position — written by a build before
        # positions existed, or edited on disk. There is nothing to re-read,
        # and the only thing left to return would be the compiled anchor,
        # which is the staleness this whole function exists to refuse.
        return None
    # The blob this was compiled from, re-found on the page as it is NOW.
    # When it is gone, this is "" — and `_read_at_path` refuses a body that
    # is not JSON, so the drift is caught one line below rather than here.
    # (No second guard: the duplicate had no surviving mutant, which is
    # what redundancy looks like.)
    body = payload_of(operation, body)
    found = _read_at_path(body, operation.value_path)
    if operation.value_paths:
        # They stood for one fact at compile time. If they have stopped
        # agreeing, the fact has split and which one the page means is
        # unknowable — so this is drift, and the browser answers.
        readings = {_read_at_path(body, path) for path in operation.value_paths}
        if len(readings) != 1 or None in readings:
            return None
        found = next(iter(readings))
    if found is None:
        # The shape moved. That IS drift — the field this operation was
        # compiled against is not where it was — and the browser path is the
        # answer to it.
        return None

    anchor = operation.expected_anchor
    if len(_match_spans(anchor, operation.value_marker)) > 1:
        # A row written before the compile-time rule existed, or edited on
        # disk. Splicing one occurrence leaves the other stale; splicing
        # both fabricates the second. Neither is an answer.
        return None
    start, end = operation.value_start, operation.value_end
    if not (0 <= start < end <= len(anchor)):
        # A row from before positions were recorded, or an edited one. The
        # only remaining option would be a text replace, which is what
        # produced "Aug 2099 - 24 GB used" from a page reporting 99.
        return None
    if anchor[start:end] != operation.value_marker:
        # The row disagrees with itself. Nothing here can be trusted to
        # place a fresh value correctly.
        return None

    # EVERY occurrence of the value, not just the one that was chosen.
    #
    # Choosing one and splicing it leaves the other stale, and the line then
    # says both things at once. Both halves of that have now been served:
    # "Free features enabled - current plan Pro" when the earliest occurrence
    # won, and "Pro features enabled - current plan Free" when the latest
    # did. A user reading either has to guess which clause is current.
    #
    # Splicing all of them is safe because the spans are whole-token, which
    # is what makes "Aug 2024" immune while "24" is replaced. The chosen span
    # still decides WHICH leaf this is; it just no longer decides which of
    # its mentions gets to stay wrong.
    spans = _match_spans(anchor, operation.value_marker)
    if (start, end) not in spans:
        return None
    rewritten = anchor
    for span_start, span_end in sorted(spans, reverse=True):
        rewritten = rewritten[:span_start] + found + rewritten[span_end:]
    return rewritten
    # The shape moved. That IS drift — the field this operation was compiled
    # against is not where it was — and the browser path is the answer to it.
    return None


def _read_at_path(body: str, path: str) -> str | None:
    """Follow a dotted path recorded at compile time, e.g. ``usage.used``."""
    try:
        node: object = json.loads(body)
    except ValueError:
        return None
    for part in re.findall(r"[^.\[\]]+", path):
        if isinstance(node, dict) and part in node:
            node = node[part]
        elif isinstance(node, list) and part.isdigit() and int(part) < len(node):
            node = node[int(part)]
        else:
            return None
    if isinstance(node, dict | list) or node is None:
        return None
    return str(node)


def _one_row_per_endpoint(session: RecordedSession) -> RecordedSession:
    """Collapse repeat calls that returned the SAME answer.

    A run may load the page more than once — a plan that navigates and then
    re-reads, a retry after a slow first paint — and every load fires the same
    requests again. Ranked as they arrive, the endpoint that fed the screen
    appears twice with identical scores, the margin is exactly zero, and the
    coin-flip guard refuses to compile. That guard is right about two
    DIFFERENT endpoints looking equally like the page, and exactly wrong
    about one endpoint seen twice, which is corroboration rather than a tie.

    **Identical bodies only.** Collapsing by URL alone is wrong wherever one
    endpoint serves many queries, which is the normal case on GraphQL and RPC
    sites: three POSTs to /graphql — a viewer query, the usage query that fed
    the table, and a notifications poll — are three candidates whose thin
    margin is a correct refusal. Merging them manufactures a single candidate,
    picks whichever came last, and turns that refusal into a confident wrong
    compile.
    """
    seen: dict[tuple[str, str, str], object] = {}
    for response in session.responses:
        key = (
            response.method or "GET",
            response.url,
            response.resp_body or "",
        )
        seen[key] = response
    if len(seen) == len(session.responses):
        return session
    return replace(session, responses=list(seen.values()))  # type: ignore[arg-type]


def compile_operation(session: RecordedSession, *, anchor_line: str) -> SyntheticOperation:
    """Find the endpoint that fed the page, or refuse to compile.

    ``anchor_line`` is the line the verified browser run actually read. It is
    what the compiled form must reproduce, so a synthetic API that returns
    *something* but not *this* is caught immediately rather than shipped.
    """
    session = _one_row_per_endpoint(session)
    ranking = identify_data_response(session)
    best = ranking.best
    if best is None:
        raise CannotCompile("no response in this page load carried the page's data")

    # The candidate came from RECORDED TRAFFIC — every response the page
    # fired, including CDNs, analytics and embedded widgets. A third-party
    # beacon that echoes the page's numbers scores well by construction, and
    # compiling it would point later runs at someone else's origin while
    # carrying the user's session. The operation may only ever name the host
    # it was learned from.
    page_host = urlparse(session.page_url or "").netloc.lower()
    candidate_host = urlparse(best.response.url).netloc.lower()
    if page_host and candidate_host and candidate_host != page_host:
        raise CannotCompile(
            f"the best candidate lives on {candidate_host}, not {page_host} — "
            "a compiled operation may only call the site it was learned from"
        )
    if (best.response.method or "GET").upper() != "GET":
        # Replay issues a credentialed GET with no body (`session_fetch`), so
        # a compiled POST could never reproduce the response it was compiled
        # from. Refusing here is the honest place to say so; compiling it
        # would build a shortcut guaranteed to fail on first use and to be
        # thrown away as site drift that never happened.
        raise CannotCompile(
            f"the best candidate is a {best.response.method} — replay can only "
            "repeat a GET, so this cannot be compiled yet"
        )
    # `Ranking` already computes score[0] - score[1] and documents why a thin
    # margin means auto-selection should not be trusted. Recomputing it here
    # would be a second opinion that drifts from the first.
    margin = ranking.margin
    if best.score < MIN_CONFIDENCE:
        raise CannotCompile(
            f"the best candidate scored {best.score:.2f} — below the bar where "
            "a synthetic API would be a fast way to be wrong"
        )
    if margin < MIN_MARGIN:
        raise CannotCompile(
            f"two responses look equally like the page (margin {margin:.2f}) — "
            "picking one would be a coin flip"
        )

    # WHICH leaf of the response is the answer, and where it sits. Both, or
    # neither: a compiled operation that knows the value but not its position
    # cannot re-read it on a later run, so it can only ever repeat the value
    # it was compiled with — a cache with no expiry, answering instantly and
    # confidently with last week's number. Refusing to compile is strictly
    # better than that, because the browser path still works.
    located = locate_value(anchor_line, best.response.resp_body or "")
    if located is None:
        raise CannotCompile(
            "no leaf of this response matches the value that was read, so a "
            "compiled call could not be checked against a fresh answer"
        )
    marker, path, start, end = located
    return SyntheticOperation(
        url=best.response.url,
        method=best.response.method or "GET",
        expected_anchor=anchor_line.strip(),
        confidence=float(best.score),
        margin=float(margin),
        compiled_at=datetime.now(UTC).isoformat(),
        value_path=path,
        value_marker=marker,
        value_start=start,
        value_end=end,
        page_url=session.page_url or "",
    )


def agrees_with_page(operation: SyntheticOperation, response_body: str) -> bool:
    """Does the endpoint still carry THE value — not merely a number?

    The check is on the token the answer was made of, because "any number
    from the anchor is still present" is unfalsifiable: quotas, plan tiers
    and years persist while the value moves. Measured: an anchor of
    "Usage 42 GB of 100" agreed with a body reporting 99, on the strength
    of the unchanged 100.

    Agreement here means the value is FINDABLE, not that it is unchanged —
    a moved number is the normal case and the whole point of re-reading.
    """
    if not operation.expected_anchor or not operation.value_marker:
        return False
    # Positional, always. "Some number is present" is true of an error page
    # ("502 Bad Gateway") and therefore proves nothing, so an operation with
    # no recorded position cannot agree with anything — it can only be
    # recompiled by a browser run.
    if not operation.value_path:
        return False
    return _read_at_path(payload_of(operation, response_body), operation.value_path) is not None
