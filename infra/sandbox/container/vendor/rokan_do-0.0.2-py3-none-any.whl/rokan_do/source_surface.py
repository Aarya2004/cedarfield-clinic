"""Operations from SOURCE, not the render — the extraction floor (spike, 2026-08-26).

A site's shipped JavaScript names its operations before any click: the
endpoints it calls, the methods, the parameter shapes, and — where the site
ships production source maps — the original function that makes the call.
This module recovers that surface with no browser and no model: fetch the
landing page, its script bundles and their source maps, and read.

What comes out is a list of `Affordance`s: typed, with evidence (file and
line). What does NOT come out is a claim that any of them can be called —
that is Q3 of the pre-registered spike (`plans/SOURCE-LEVER-SPIKE-2026-08-26.md`),
and it is answered in-page, with the observed headers, not here.

Pure stdlib on purpose: this is a floor, and a floor should be cheap to
re-measure on any machine.
"""

from __future__ import annotations

import html as htmllib
import ipaddress
import json
import re
import socket
import urllib.request
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlsplit

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/128.0 Safari/537.36"
)
#: A plain-urllib fetch is refused by crates.io, npmjs and producthunt; the
#: same request with a browser's ordinary headers is not. Nothing here is a
#: disguise — it is what every browser sends.
_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "identity",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Upgrade-Insecure-Requests": "1",
}
#: Per-fetch and per-site byte caps: a bundle set can run to tens of MB, and
#: the floor is measured on the first few, not the whole build.
MAX_BYTES_PER_FILE = 3_000_000
MAX_BUNDLES = 8
MAX_MAPS = 8
TIMEOUT_S = 15


@dataclass(frozen=True, slots=True)
class Affordance:
    """One operation the source names: where a request goes and how."""

    method: str
    path: str
    #: The enclosing function's name when a source map gave us the original
    #: code; "" in minified bundles, where names are single letters.
    function: str
    #: Parameter names seen beside the call (object-literal keys in the body
    #: or query), best effort.
    params: tuple[str, ...]
    #: Where this came from: `<file>:<line>`.
    evidence: str
    #: "read" for GET, "write" otherwise — the same line the executor draws.
    kind: str


@dataclass(slots=True)
class SourceSurface:
    site: str
    bundles: int = 0
    bundle_bytes: int = 0
    source_maps: int = 0
    original_files: int = 0
    affordances: list[Affordance] = field(default_factory=list)
    graphql_documents: int = 0
    published: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def summary(self) -> dict[str, object]:
        reads = sum(1 for a in self.affordances if a.kind == "read")
        return {
            "site": self.site,
            "bundles": self.bundles,
            "kb": self.bundle_bytes // 1024,
            "source_maps": self.source_maps,
            "original_files": self.original_files,
            "affordances": len(self.affordances),
            "reads": reads,
            "writes": len(self.affordances) - reads,
            "named": sum(1 for a in self.affordances if a.function),
            "graphql": self.graphql_documents,
            "published": self.published,
            "errors": self.errors[:3],
        }


# --- transport ---------------------------------------------------------------


def _is_public(url: str) -> bool:
    """Only http(s) to a public address: a bundle fetcher must never be turned
    into a way to read the user's own network."""
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        return False
    try:
        for info in socket.getaddrinfo(parts.hostname, None):
            if ipaddress.ip_address(info[4][0]).is_private:
                return False
    except (socket.gaierror, ValueError):
        return False
    return True


def fetch(url: str, limit: int = MAX_BYTES_PER_FILE) -> tuple[int | None, str, str]:
    """(status, text, content-type). None status = not fetched (refused or failed)."""
    if not _is_public(url):
        return None, "", "refused: not public"
    try:
        req = urllib.request.Request(url, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=TIMEOUT_S) as r:  # noqa: S310 — public http(s) only, checked above
            return (
                r.status,
                r.read(limit).decode("utf-8", "ignore"),
                r.headers.get("content-type", ""),
            )
    except Exception as exc:  # noqa: BLE001 — a failed fetch is a fact about the site, recorded
        return None, "", type(exc).__name__


# --- discovery ---------------------------------------------------------------

_SCRIPT_SRC = re.compile(r"<script[^>]+src=[\"']([^\"']+)[\"']", re.IGNORECASE)
_MODULEPRELOAD = re.compile(
    r"<link[^>]+rel=[\"']modulepreload[\"'][^>]+href=[\"']([^\"']+)[\"']", re.IGNORECASE
)
_DYNAMIC_IMPORT = re.compile(r"""import\(\s*[\"'`]([^\"'`]+\.js)[\"'`]\s*\)""")
_INLINE_SCRIPT = re.compile(
    r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>", re.IGNORECASE | re.DOTALL
)


def inline_scripts(html: str) -> list[str]:
    """Script bodies embedded in the page: config, API bases, bootstraps."""
    return [b for b in _INLINE_SCRIPT.findall(html) if len(b.strip()) > 40]


_SOURCE_MAP = re.compile(r"//[#@]\s*sourceMappingURL=(\S+)")


def script_urls(site: str, html: str) -> list[str]:
    """Script bundles the landing page loads, first-party first."""
    apex = _apex(site)
    seen: list[str] = []
    candidates = [htmllib.unescape(src) for src in _SCRIPT_SRC.findall(html)]
    # SvelteKit / Vite apps start from an inline `import("/_app/…/start.js")`
    # and `<link rel="modulepreload">`; the page has no <script src> at all.
    candidates += [htmllib.unescape(h) for h in _MODULEPRELOAD.findall(html)]
    for body in inline_scripts(html):
        candidates += _DYNAMIC_IMPORT.findall(body)
    for src in candidates:
        url = urljoin(site, src)
        if url.split("?")[0].endswith((".css", ".json", ".wasm")):
            continue
        if url not in seen:
            seen.append(url)

    def rank(u: str) -> tuple[int, int]:
        return (0 if _apex(u) == apex else 1, 0 if u.split("?")[0].endswith(".js") else 1)

    return sorted(seen, key=rank)


def _apex(url: str) -> str:
    host = (urlsplit(url).hostname or "").lower()
    return ".".join(host.rsplit(".", 2)[-2:]) if host else ""


# --- extraction --------------------------------------------------------------

#: A request path as a string literal: absolute-path API-looking, or a
#: same-site absolute URL. Template placeholders (`${id}`) are cut at `$`.
_PATH_LITERAL = re.compile(
    r"""[\"'`](/(?:[A-Za-z0-9_\-.]+/){0,3}(?:api|graphql|gql|v\d+|rest|internal|_next/data|ajax|rpc|"""
    r"""[A-Za-z0-9_\-]*\.json)[A-Za-z0-9_\-./:{}?=&%$]*)[\"'`]"""
)
#: Only API-looking absolute URLs count: a same-site link to `/about-us` is
#: navigation, not an operation, and Instagram's bundle holds thousands.
_API_PATH = re.compile(r"/(?:api|graphql|gql|v\d+|rest|internal|_next/data|ajax|rpc)\b|\.json$")
_API_HOST = re.compile(r"^(?:api|gql|graphql|gateway|data)[.-]", re.IGNORECASE)
_ABS_URL_LITERAL = re.compile(r"""[\"'`](https?://[A-Za-z0-9_\-.]+/[A-Za-z0-9_\-./:{}]*)[\"'`]""")
_METHOD_NEAR = re.compile(
    r"""method\s*:\s*[\"'`](GET|POST|PUT|PATCH|DELETE)[\"'`]""", re.IGNORECASE
)
_FETCH_CALL = re.compile(r"\b(?:fetch|axios(?:\.\w+)?|\$\.ajax|got|ky)\s*\(")
_GRAPHQL_DOC = re.compile(r"\b(?:query|mutation|subscription)\s+([A-Za-z_]\w*)\s*[({]")
_FUNCTION_NAME = re.compile(
    r"(?:function\s+([A-Za-z_$][\w$]*)\s*\(|(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>|([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{|(?:async\s+)?([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{)"
)
_GENERIC_NAMES = frozenset({"if", "for", "while", "switch", "catch", "function", "return", "await"})


def extract(text: str, filename: str, site: str, named: bool) -> tuple[list[Affordance], int]:
    """Affordances named in one file, plus how many GraphQL documents it holds.

    `named` says whether `text` is original source (from a map), in which
    case the enclosing function's name is worth recording; a minified bundle
    has names like `t` and `n`, which carry nothing.

    The method and the parameters are read from the text that FOLLOWS each
    path literal, up to the next path literal — a minified line holds many
    calls, and a `method: "POST"` belongs to the call it follows, not to
    every call on the line.
    """
    out: list[Affordance] = []
    seen: set[tuple[str, str]] = set()
    apex = _apex(site)
    lines = text.splitlines()
    for lineno, line in enumerate(lines, 1):
        hits: list[tuple[int, int, str]] = []
        for m in _PATH_LITERAL.finditer(line):
            hits.append((m.start(), m.end(), m.group(1)))
        for m in _ABS_URL_LITERAL.finditer(line):
            parts = urlsplit(m.group(1))
            if _apex(m.group(1)) != apex:
                continue
            if _API_HOST.match(parts.hostname or "") or _API_PATH.search(parts.path):
                # Same host as the site: the path alone. Another host under the
                # apex (api.weather.gov beside www.weather.gov): keep the host.
                same = (parts.hostname or "").lower() == (urlsplit(site).hostname or "").lower()
                hits.append(
                    (m.start(), m.end(), parts.path if same else f"{parts.hostname}{parts.path}")
                )
        if not hits:
            continue
        hits.sort()
        tail = "\n".join(lines[lineno : lineno + 4])
        function = _enclosing_function(lines, lineno) if named else ""
        for i, (_start, stop, raw) in enumerate(hits):
            following = (
                line[stop : hits[i + 1][0]] if i + 1 < len(hits) else line[stop:] + "\n" + tail
            )
            following = following[:400]
            method_m = _METHOD_NEAR.search(following)
            method = method_m.group(1).upper() if method_m else "GET"
            path = raw.split("?")[0].split("$")[0].rstrip("/") or raw
            if len(path) < 4 or (method, path) in seen:
                continue
            seen.add((method, path))
            out.append(
                Affordance(
                    method=method,
                    path=path,
                    function=function,
                    params=_params_near(following),
                    evidence=f"{filename}:{lineno}",
                    kind="read" if method == "GET" else "write",
                )
            )
    return out, len(_GRAPHQL_DOC.findall(text))


def _enclosing_function(lines: list[str], lineno: int) -> str:
    """The nearest function declared above the call — original source only."""
    for back in range(lineno - 1, max(-1, lineno - 60), -1):
        m = _FUNCTION_NAME.search(lines[back])
        if m:
            name = next((g for g in m.groups() if g), "")
            if name and name not in _GENERIC_NAMES:
                return name
    return ""


def _params_near(window: str) -> tuple[str, ...]:
    """Keys of the object literal handed to the call as body/params/query.

    Both spellings count: `{user_id: e}` and the shorthand `{ subscriptionId,
    reason }` — original source uses the second constantly.
    """
    body = _BODY_OBJECT.search(window)
    if not body:
        return ()
    keys: list[str] = []
    for segment in body.group(1).split(","):
        m = _LEADING_IDENT.match(segment)
        if m and m.group(1) not in _GENERIC_NAMES:
            keys.append(m.group(1))
    return tuple(dict.fromkeys(keys))[:12]


_BODY_OBJECT = re.compile(
    r"(?:body|params|data|variables|query|searchParams)\s*:\s*(?:JSON\.stringify\()?\s*\{([^}]{0,300})\}"
)
_LEADING_IDENT = re.compile(r"\s*([A-Za-z_]\w*)")


# --- source maps -------------------------------------------------------------


def original_sources(map_text: str) -> list[tuple[str, str]]:
    """(filename, content) pairs a Source Map V3 carries inline, if any."""
    try:
        data = json.loads(map_text)
    except ValueError:
        return []
    names = data.get("sources") or []
    contents = data.get("sourcesContent") or []
    pairs = []
    for name, content in zip(names, contents, strict=False):
        if isinstance(content, str) and content.strip() and "node_modules" not in str(name):
            pairs.append((str(name), content))
    return pairs


# --- the floor ---------------------------------------------------------------

_PUBLISHED = ("/llms.txt", "/openapi.json", "/swagger.json", "/.well-known/ai-plugin.json")


def surface(site: str, *, max_bundles: int = MAX_BUNDLES, published: bool = True) -> SourceSurface:
    """Q1 of the spike: everything the landing bundle set names, no browser, no model."""
    out = SourceSurface(site=site)
    status, html, ct = fetch(site)
    if not html:
        out.errors.append(f"landing: {ct or status}")
        return out
    if status != 200:
        out.errors.append(f"landing status {status}")
    for i, body in enumerate(inline_scripts(html)):
        found, gql = extract(body, f"inline#{i}", site, named=False)
        out.affordances.extend(found)
        out.graphql_documents += gql
    urls = script_urls(site, html)[:max_bundles]
    maps_fetched = 0
    for url in urls:
        s, js, note = fetch(url)
        if not js:
            out.errors.append(f"{url[-40:]}: {note or s}")
            continue
        if (
            "javascript" not in note
            and "ecmascript" not in note
            and not js.lstrip().startswith(
                (
                    "!function",
                    "(function",
                    "var ",
                    '"use strict"',
                    "'use strict'",
                    "/*",
                    "//",
                    "import",
                    "(()",
                )
            )
        ):
            out.errors.append(f"{url[-40:]}: not js ({note[:24]})")
            continue
        out.bundles += 1
        out.bundle_bytes += len(js)
        found, gql = extract(js, url.rsplit("/", 1)[-1], site, named=False)
        out.affordances.extend(found)
        out.graphql_documents += gql
        maps = _SOURCE_MAP.findall(js)
        m = maps[-1] if maps else None
        if m and maps_fetched < MAX_MAPS:
            maps_fetched += 1
            ms, map_text, note2 = fetch(urljoin(url, m))
            if not map_text:
                out.errors.append(f"map {m[-30:]}: {note2 or ms}")
            if map_text:
                out.source_maps += 1
                for name, content in original_sources(map_text):
                    out.original_files += 1
                    named_found, gql2 = extract(content, name.rsplit("/", 1)[-1], site, named=True)
                    out.affordances.extend(named_found)
                    out.graphql_documents += gql2
    out.affordances = _dedupe(out.affordances)
    if published:
        for spec in _PUBLISHED:
            s, body, ct2 = fetch(urljoin(site, spec), 20_000)
            if s == 200 and body and "<html" not in body[:300].lower():
                out.published.append(spec)
    return out


def _dedupe(items: list[Affordance]) -> list[Affordance]:
    """One row per (method, path); a named (source-mapped) row beats a minified one."""
    best: dict[tuple[str, str], Affordance] = {}
    for a in items:
        key = (a.method, a.path)
        if key not in best or (a.function and not best[key].function):
            best[key] = a
    return list(best.values())


def main(argv: list[str] | None = None) -> int:
    import sys

    sites = argv if argv is not None else sys.argv[1:]
    if not sites:
        print("usage: python -m rokan_do.source_surface SITE [SITE…]")
        return 2
    for site in sites:
        s = surface(site)
        print(json.dumps(s.summary()))
        for a in sorted(s.affordances, key=lambda a: (a.kind, a.path))[:12]:
            params = ",".join(a.params)[:40]
            name = a.function or "-"
            print(f"   {a.method:6s} {a.path:60s} {name:28s} {params:40s} {a.evidence}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
