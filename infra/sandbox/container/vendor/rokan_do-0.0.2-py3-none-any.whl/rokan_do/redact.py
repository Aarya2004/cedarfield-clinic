"""Nothing a page showed us goes back to a model provider as itself.

The cascade forwards the page text to the next rung, so a bigger model is not
asked to solve the same problem blind. That is right, and for `get_api_key`
it had a consequence nobody wrote down: **the page text IS the key.** Measured
on a stubbed three-rung run, the acquired key appeared verbatim in the prompt
of rungs two and three.

The claim in `planner.py` — that a prompt cannot contain what the planner
never held — was true only while the planner saw nothing but a snapshot. The
moment a retry could see what the last attempt read, it stopped being true,
and the credential-incident counter could not see it happen because it was
looking for a different string.

So the forwarded text is scrubbed here, at the one place it crosses from
"what the browser saw" to "what we send". Two passes, because either alone
leaves a hole:

* **the credentials the run actually handled** — passed in by the caller,
  and ONLY for a class that handles credentials. An earlier version passed
  every read line for every class, and split each into tokens it then
  replaced page-wide: after a failed read of "Timezone America/Toronto" the
  word "Timezone" no longer existed anywhere in the escalated context, so
  the bigger model could not find the longer anchor the failure was asking
  for. That is not safety, it is a blindfold — and it cost the most on the
  most expensive rung.
* **anything else key-shaped** — long unbroken tokens with a credential-ish
  prefix, or high enough entropy to be a secret rather than a word. This is
  the weak pass, and it exists for the page's OTHER secrets: a second key
  further down, a session id in a debug panel.

Structure is kept: a redacted line still has its label, its length and its
position, so a model can still plan around it. What it cannot do is repeat it.
"""

from __future__ import annotations

import re
from collections.abc import Iterable

#: Vendor prefixes that announce a credential, and the generic shape of one.
#: A token has to be long AND mixed-case-or-digit-bearing to qualify on shape
#: alone — English words are neither, and refusing them would redact the page
#: into uselessness.
_PREFIXED = re.compile(
    r"(?<![A-Za-z0-9_-])"
    r"(?:sk|pk|rk|re|ghp|gho|ghs|github_pat|xox[bpasr]|shpat)"
    r"[-_][A-Za-z0-9_-]{8,}",
    re.IGNORECASE,
)

#: The vendors whose keys carry no separator, so the prefix runs straight
#: into the secret. Case-sensitive on purpose: lower-casing "akia" would
#: match ordinary words.
_BARE_PREFIXED = re.compile(
    r"(?<![A-Za-z0-9_-])(?:AKIA|ASIA|ABIA|ACCA|AIza|ya29)[A-Za-z0-9_-]{8,}"
)
_JWT = re.compile(r"(?<![A-Za-z0-9_-])eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_.-]{8,}")
#: Twenty, because an AWS key is exactly twenty and English words that long
#: are rare — and `_looks_random` has to agree before anything is removed.
_LONG_TOKEN = re.compile(r"(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{20,}(?![A-Za-z0-9_-])")

#: A long unbroken run of digits: an account number, an order id, a card.
#: Thirteen, because that is the shortest card number — and no case or
#: entropy test can see one, since digits have neither.
_LONG_DIGITS = re.compile(r"(?<![A-Za-z0-9_-])\d{13,}(?![A-Za-z0-9_-])")

MASK = "[redacted]"

#: A key in its armoured form. Matched as a BLOCK, before anything else: the
#: base64 body is full of "+" and "/", which split every line into runs too
#: short for any token rule to see.
_BLOCK = re.compile(
    r"-----BEGIN[^-]*-----.*?-----END[^-]*-----", re.DOTALL | re.IGNORECASE
)

#: A secret identified by POSITION rather than shape: whatever follows one of
#: these labels is the secret, however short or word-like it looks. This is
#: what catches `Authorization: Basic dXNlcjpwdw==`, a session cookie, and a
#: passphrase of ordinary words — none of which any entropy test would flag.
_LABELLED = re.compile(
    r"((?:authorization|proxy-authorization|cookie|set-cookie|x-api-key|"
    r"api[-_ ]?key|secret|token|password|passphrase|recovery phrase|"
    r"seed phrase|private[-_ ]?key)\s*[:=]\s*)"
    r"\S[^\n]*",
    re.IGNORECASE,
)

#: The password in a connection string: `postgres://user:pw@host/db`.
_USERINFO = re.compile(r"([a-z][a-z0-9+.-]*://[^\s:@/]+:)[^\s@/]+@", re.IGNORECASE)


def _looks_random(token: str) -> bool:
    """Is this a secret rather than a long word or a URL slug?

    Cheap and deliberately conservative: a real English identifier is one
    case and mostly letters. A secret mixes cases, or carries digits among
    letters, across a long unbroken run.
    """
    if token.isdigit():
        # A long run of digits is an account, an order, or a card. None of
        # them belong in a prompt either, and no case test would catch one.
        return len(token) >= 13
    has_digit = any(c.isdigit() for c in token)
    has_upper = any(c.isupper() for c in token)
    has_lower = any(c.islower() for c in token)
    if not (has_digit or (has_upper and has_lower)):
        return False
    # A hyphenated Title-Case phrase is a label, not a secret:
    # "Two-Factor-Authentication", "Enterprise-Annual-2026". Its parts are
    # short and word-like; a secret's are not.
    parts = re.split(r"[-_]", token)
    if len(parts) > 1 and all(len(p) <= 20 and p.isalnum() for p in parts):
        wordish = sum(1 for p in parts if p.isalpha() and len(p) >= 3)
        if wordish >= len(parts) - 1:
            return False
    return True


def redact(text: str, values: Iterable[str] = ()) -> str:
    """The page as a model may see it: structure kept, secrets removed."""
    if not text:
        return text
    out = text
    # Longest first, so a secret that contains another is not half-replaced.
    # Replaced whole and only whole: splitting a value into tokens and
    # replacing each page-wide destroyed ordinary words that happened to
    # appear in it.
    for value in sorted({v for v in values if v}, key=len, reverse=True):
        out = out.replace(value, MASK)
    out = _BLOCK.sub(MASK, out)
    out = _LABELLED.sub(lambda m: m.group(1) + MASK, out)
    out = _USERINFO.sub(lambda m: m.group(1) + MASK + "@", out)
    out = _PREFIXED.sub(MASK, out)
    out = _BARE_PREFIXED.sub(MASK, out)
    out = _JWT.sub(MASK, out)
    out = _LONG_DIGITS.sub(MASK, out)
    return _LONG_TOKEN.sub(
        lambda m: MASK if _looks_random(m.group(0)) else m.group(0), out
    )
