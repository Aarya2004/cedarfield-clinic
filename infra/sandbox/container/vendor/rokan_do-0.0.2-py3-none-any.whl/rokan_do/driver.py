"""The cold driver seam — rent the best loop, keep the proof.

`docs/DERIVATION-2026-08-24.md` D10: a first run can beat theirs without a
better model by renting the best rentable loop (Yutori Navigator n1.5,
97.3% Online-Mind2Web, third-party verified) and keeping everything that is
ours around it — our daemon executes, our policy gates every action, our
W5 checks every step, our postconditions decide the label.

What a driver is: something that, given the task and what the page looks
like, says what to do next. What it is NOT: the judge of whether it worked
(`verify_general` is), the memory (a coordinate trace does not replay — a
Yutori-driven run is admitted only when it can be re-expressed as a typed
plan, which is later work), or the policy (`policy.may_act` is consulted
before every click it asks for, exactly as for a planned click).

`YutoriDriver` speaks the Navigator API (OpenAI-shaped chat completions;
tool calls `left_click {coordinates: [x, y]}` in a 1000×1000 space,
`type {text}`, `scroll`, `navigate`; a reply with no tool call means done).
Transport is injected so the loop is tested without a network.
"""

from __future__ import annotations

import json
import os
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from typing import Any

from rokan_agent.core.reasons import Reason

from .executor import ExecutionFailed, Trace, _act, _refresh_text, _w5
from .ir import Plan

#: The viewport the daemon actually runs (`_daemon.py` launch_persistent_
#: context). The daemon refuses a coordinate click whose echoed viewport
#: disagrees with the live one — the first version said 1280×800 and would
#: have had every click refused (Opus round 8, D1). A test holds this equal
#: to the daemon's constant.
VIEWPORT = {"width": 1366, "height": 768}

#: Screenshots kept in the conversation. Every step appends one; without
#: pruning a 24-step run ships 300 image slots to the model.
_KEEP_IMAGES = 3

#: Steps a rented loop may take. Twenty-four is the IR's own plan ceiling;
#: a loop that needs more is wandering, and wandering is what the 20-33%
#: success rates are made of (R1).
MAX_STEPS = 24

YUTORI_URL = "https://api.yutori.com/v1/chat/completions"
YUTORI_MODEL = "n1.5-latest"

#: One model call: messages in, an OpenAI-shaped completion out.
Transport = Callable[[list[dict[str, Any]]], Awaitable[dict[str, Any]]]


@dataclass(slots=True)
class DriveResult:
    trace: Trace
    steps: int
    model_calls: int
    #: What the model said when it stopped, for the record (redacted upstream).
    said_done: str = ""
    actions: list[dict[str, Any]] = field(default_factory=list)


def denormalize(coordinates: list[float], width: int, height: int) -> tuple[int, int]:
    """Yutori's 1000×1000 space → viewport pixels."""
    x = max(0, min(width - 1, round(float(coordinates[0]) * width / 1000)))
    y = max(0, min(height - 1, round(float(coordinates[1]) * height / 1000)))
    return x, y


def _screenshot_message(png_b64: str, note: str) -> dict[str, Any]:
    return {
        "role": "user",
        "content": [
            {"type": "text", "text": note},
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{png_b64}"}},
        ],
    }


def _tool_calls(reply: dict[str, Any]) -> list[tuple[str, dict[str, Any], str]]:
    """(name, arguments, call_id) for each tool call in an OpenAI-shaped reply."""
    out: list[tuple[str, dict[str, Any], str]] = []
    choices = reply.get("choices") or []
    if not choices:
        return out
    message = choices[0].get("message") or {}
    for call in message.get("tool_calls") or []:
        fn = call.get("function") or {}
        raw = fn.get("arguments")
        args = raw if isinstance(raw, dict) else {}
        if isinstance(raw, str):
            try:
                args = json.loads(raw)
            except ValueError:
                args = {}
        out.append((str(fn.get("name") or call.get("name") or ""), args, str(call.get("id") or "")))
    return out


def _assistant_text(reply: dict[str, Any]) -> str:
    choices = reply.get("choices") or []
    if not choices:
        return ""
    return str((choices[0].get("message") or {}).get("content") or "")


class YutoriDriver:
    """The Navigator loop, executed by OUR daemon under OUR policy."""

    def __init__(
        self,
        transport: Transport,
        *,
        may_act: Callable[[str, str, str, str], str] | None = None,
        max_steps: int = MAX_STEPS,
    ) -> None:
        self._transport = transport
        self._may_act = may_act
        self._max_steps = max_steps
        self._viewport = dict(VIEWPORT)

    async def drive(
        self, plan: Plan, task_text: str, params: Mapping[str, str] | None = None
    ) -> DriveResult:
        """Open the site through the proven login path, then loop.

        `plan` carries the site and the postconditions; its steps are not
        executed — the driver decides the steps. The caller verifies.
        """
        from rokan_agent.core.proven import login  # noqa: PLC0415

        trace = Trace()
        fetched = await login.fetch(plan.site, reload=True)
        if not getattr(fetched, "ok", False):
            raise ExecutionFailed(
                str(getattr(fetched, "message", "") or "the page did not load"),
                Reason.NAVIGATION_FAILED,
                0,
                trace,
            )
        trace.page_text = str(getattr(fetched, "text", "") or "")
        trace.last_url = plan.site
        trace.authenticated = bool(getattr(fetched, "session_backed", False))
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": _instruction(task_text, params)}
        ]
        model_calls = 0
        result = DriveResult(trace=trace, steps=0, model_calls=0)
        for step in range(self._max_steps):
            shot = await _act(plan.site, "screenshot", {})
            if not shot.get("ok"):
                raise ExecutionFailed("screenshot failed", Reason.BROWSER_UNAVAILABLE, step, trace)
            _prune_images(messages)
            messages.append(
                _screenshot_message(
                    str(shot.get("png_b64") or ""),
                    f"Step {step + 1}. Current page: "
                    + _safe_url(str(shot.get("url") or trace.last_url)),
                )
            )
            reply = await self._transport(messages)
            model_calls += 1
            calls = _tool_calls(reply)
            messages.append(
                {
                    "role": "assistant",
                    "content": _assistant_text(reply),
                    "tool_calls": (reply.get("choices") or [{}])[0]
                    .get("message", {})
                    .get("tool_calls")
                    or [],
                }
            )
            if not calls:
                result.said_done = _assistant_text(reply)
                break
            for name, args, call_id in calls:
                report = await self._one(name, args, plan, trace, step, params)
                result.actions.append({"step": step, "verb": name, "w5": report.get("w5")})
                messages.append(
                    {"role": "tool", "tool_call_id": call_id, "content": json.dumps(report)}
                )
            result.steps = step + 1
        else:
            raise ExecutionFailed(
                f"the driver took {self._max_steps} steps without finishing",
                Reason.TOO_MANY_STEPS,
                self._max_steps,
                trace,
            )
        result.model_calls = model_calls
        trace.actions = result.actions
        return result

    async def _one(
        self,
        name: str,
        args: dict[str, Any],
        plan: Plan,
        trace: Trace,
        step: int,
        params: Mapping[str, str] | None,
    ) -> dict[str, Any]:
        if name in ("left_click", "click"):
            coords = args.get("coordinates") or [args.get("x"), args.get("y")]
            try:
                pair = [float(coords[0]), float(coords[1])]
            except (TypeError, ValueError, IndexError):
                # Model-controlled input: a malformed click is the model's
                # problem to correct, not a traceback (Opus round 8, D4).
                return {"ok": False, "error": "left_click needs coordinates [x, y]"}
            x, y = denormalize(pair, self._viewport["width"], self._viewport["height"])
            # A coordinate click has no label the page gave it. The policy
            # sees it as what it is — a click on a guarded host with nothing
            # to vouch for it — and on a signed-in host that means a grant.
            denied = self._may_act("", "click_xy", "", "") if self._may_act is not None else ""
            if denied:
                raise ExecutionFailed(denied, Reason.NEEDS_APPROVAL, step, trace)
            reply = await _act(
                plan.site, "click_xy", {"x": x, "y": y, "viewport": dict(self._viewport)}
            )
            live_vp = reply.get("viewport")
            if reply.get("error") == "viewport_mismatch" and isinstance(live_vp, dict):
                # The daemon tells us its live viewport; adopt it and retry
                # ONCE, so a popup or a resize does not re-open D1 and burn
                # 24 steps (Opus round 9).
                self._viewport = {"width": int(live_vp["width"]), "height": int(live_vp["height"])}
                x, y = denormalize(pair, self._viewport["width"], self._viewport["height"])
                reply = await _act(
                    plan.site, "click_xy", {"x": x, "y": y, "viewport": dict(self._viewport)}
                )
            if not reply.get("ok"):
                return {"ok": False, "error": str(reply.get("error") or "click_failed")}
            w5 = _w5(reply)
            trace.refs = {}
            await _refresh_text(plan, trace)
            return {"ok": True, "w5": w5}
        if name == "type":
            text = str(args.get("text") or "")
            for key, value in (params or {}).items():
                text = text.replace(f"param://{key}", value)
            submits = "\n" in text or "\r" in text
            denied = self._may_act(text, "type", "", "") if self._may_act is not None else ""
            if denied:
                raise ExecutionFailed(denied, Reason.NEEDS_APPROVAL, step, trace)
            reply = await _act(plan.site, "type", {"text": text})
            if not reply.get("ok"):
                return {"ok": False, "error": str(reply.get("error") or "type_failed")}
            if submits:
                trace.refs = {}
                await _refresh_text(plan, trace)
            return {"ok": True, "w5": _w5(reply)}
        if name in ("navigate", "goto"):
            url = str(args.get("url") or "")
            from .ir import _same_site  # noqa: PLC0415

            if not url.lower().startswith(("http://", "https://")) or not _same_site(
                url, plan.site
            ):
                return {"ok": False, "error": "navigation refused: not on the site the task named"}
            reply = await _act(plan.site, "navigate", {"url": url})
            if not reply.get("ok"):
                return {"ok": False, "error": str(reply.get("error") or "navigation_failed")}
            trace.last_url = url
            trace.refs = {}
            await _refresh_text(plan, trace)
            return {"ok": True, "w5": {"url_changed": True, "dom_changed": True, "new_tab": False}}
        # scroll / extract_elements / find / execute_js: not executed. The
        # daemon has no scroll verb yet, and execute_js is never run on a
        # user's session by policy. Told to the model honestly so it can
        # choose another action.
        return {"ok": False, "error": f"{name} is not available in this browser"}


def _safe_url(url: str) -> str:
    """What the model is told about where it is: scheme, host, path — never
    the query or fragment. A page controls its own URL, and a fragment is a
    text channel straight into a user-role message (Opus round 8, D2)."""
    from urllib.parse import urlsplit  # noqa: PLC0415

    parts = urlsplit(url)
    path = parts.path[:80] if parts.path else "/"
    return f"{parts.scheme}://{parts.netloc}{path}" if parts.netloc else "(no url)"


def _prune_images(messages: list[dict[str, Any]]) -> None:
    """Keep the last `_KEEP_IMAGES` screenshots; older ones become a note."""
    image_turns = [
        m for m in messages if m.get("role") == "user" and isinstance(m.get("content"), list)
    ]
    for old in image_turns[: max(0, len(image_turns) - (_KEEP_IMAGES - 1))]:
        old["content"] = [
            part
            if part.get("type") != "image_url"
            else {"type": "text", "text": "(earlier screenshot omitted)"}
            for part in old["content"]
        ]


def _instruction(task_text: str, params: Mapping[str, str] | None) -> str:
    names = ", ".join(sorted(params)) if params else ""
    text = (
        "You are driving a real browser on the user's own machine, signed in as them. "
        "Do exactly the task below and nothing else. Never solve a CAPTCHA, never "
        "create an account, never enter a payment. When the task is complete, reply "
        "without any tool call and say what you see that proves it.\n\n"
        f"Task: {task_text}"
    )
    if names:
        text += (
            "\n\nValues you may type are given by NAME; write param://<name> and the "
            f"runner fills it: {names}"
        )
    return text


async def yutori_transport(messages: list[dict[str, Any]]) -> dict[str, Any]:
    """The real Navigator call. Key from YUTORI_API_KEY; never logged.
    Standard library only — no new dependency for one POST."""
    import asyncio  # noqa: PLC0415
    import urllib.request  # noqa: PLC0415

    key = os.environ.get("YUTORI_API_KEY", "")
    if not key:
        raise ExecutionFailed("no YUTORI_API_KEY", Reason.ABSTAINED_PLANNER_UNAVAILABLE, -1)
    body = json.dumps({"model": YUTORI_MODEL, "messages": messages, "tool_choice": "auto"}).encode()
    request = urllib.request.Request(
        YUTORI_URL,
        data=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        method="POST",
    )

    def call() -> dict[str, Any]:
        with urllib.request.urlopen(request, timeout=90) as response:
            data: dict[str, Any] = json.loads(response.read().decode("utf-8", "replace"))
            return data

    return await asyncio.to_thread(call)


def available() -> bool:
    return bool(os.environ.get("YUTORI_API_KEY"))


__all__ = [
    "MAX_STEPS",
    "VIEWPORT",
    "DriveResult",
    "Transport",
    "YutoriDriver",
    "available",
    "denormalize",
    "yutori_transport",
]
