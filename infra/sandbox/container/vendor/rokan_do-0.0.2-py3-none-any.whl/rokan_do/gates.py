"""Getting past the thing standing in front of the page.

Half the commercial web puts a wall between a visitor and the content: a
cookie banner, a GDPR dialog, a country or language selector, an age gate.
A person clicks through it without thinking. Rokan could not click through
it at all — there is no overlay handling anywhere in this codebase — and
two of browser-use's twenty read tasks are blocked on exactly that:

  zara.com    "SELECT YOUR LOCATION … CONTINUE" before any product exists
  newegg.com  "Change Country … GO TO CANADA … STAY AT NEWEGG.COM"

Neither is bot detection. Neither is a login. They are ordinary furniture,
and getting past them is ordinary browsing.

Two rules govern what this may press.

**Never consent to anything.** Choosing a cookie button is making a privacy
decision on someone else's behalf, so this presses only what refuses,
stays, or dismisses. There is no "accept" here at all: a wall that cannot
be cleared without accepting is refused, and the person is told so. An age
gate is worse than a cookie wall — pressing it asserts something about the
person — so those pages are not treated as walls at all.

**Never leave where the person asked to be.** A region gate offers to send
you somewhere else; the answer is always the one that stays.

And when two controls tie, this refuses, exactly as ref resolution does: a
wall with two equally plausible ways past it is not a situation to guess
in.
"""

from __future__ import annotations

import re

#: The page has to READ like a gate before any of its buttons are pressed.
#: An article that mentions cookies is not a cookie wall — so this is
#: required IN ADDITION to a dismiss-shaped control, and only near the top,
#: because an overlay renders before the content it covers.
_GATE_WORDS = re.compile(
    r"\b(?:cookies?|consent|tracking|gdpr|"
    r"select\s+your\s+(?:location|country|region|language)|"
    r"choose\s+your\s+(?:location|country|region|language)|"
    r"change\s+country|shipping\s+country)\b",
    re.IGNORECASE,
)

#: How much of the page counts as "the top".
_GATE_WINDOW = 3000

#: Longest a wall's button plausibly is. "STAY AT NEWEGG.COM" is 18
#: characters, "Accept all cookies" is 18, "CONTINUE" is 8.
_MAX_BUTTON = 40

#: Controls this must never press, whatever else they look like. Leaving
#: the site, or doing something on the person's account, is not dismissing
#: a wall.
_NEVER = re.compile(
    r"\b(?:go\s+to|take\s+me\s+to|visit|switch\s+to|change\s+(?:country|region|language)|"
    r"sign\s+in|log\s?in|sign\s?up|register|create\s+account|"
    r"subscribe|buy|add\s+to|checkout|pay|donate|delete|remove)\b",
    re.IGNORECASE,
)

#: In order. The first rank with exactly one match wins.
#:
#: There is deliberately NO rank for "accept / agree / proceed / continue /
#: enter / yes". Every bad press four reviewers found came from one:
#: "Continue to payment" on a checkout, "Yes, sign me up!" and "Keep me
#: updated" on a newsletter modal, "Enter to win" on a sweepstakes,
#: "Proceed" on an ordinary page, "Enter site" on an age gate. A wall this
#: cannot clear with a refusal, a stay, or a dismissal is a wall we refuse
#: — that is a `next_step` for the user, not a reason to press a button
#: whose meaning we are guessing at.
_RANKS: tuple[re.Pattern[str], ...] = (
    # 1. Minimal consent, and it discloses nothing.
    re.compile(
        r"^(?:reject(?:\s+all)?|decline(?:\s+all)?|refuse(?:\s+all)?|"
        r"only\s+necessary|necessary\s+only|essential\s+only|"
        r"strictly\s+necessary|continue\s+without\s+accepting|"
        r"manage\s+(?:choices|preferences|cookies)|cookie\s+settings|"
        r"customi[sz]e(?:\s+choices)?)\b",
        re.IGNORECASE,
    ),
    # 2. Stay where the person asked to be. "stay"/"remain" ONLY: "keep me"
    #    is how a newsletter says "keep me updated".
    re.compile(r"^(?:stay|remain)\b", re.IGNORECASE),
    # 3. Just get rid of it. Discloses nothing and commits to nothing.
    re.compile(
        r"^(?:close|dismiss|no\s+thanks|not\s+now|maybe\s+later|skip)\b",
        re.IGNORECASE,
    ),
)


def looks_like_a_gate(page_text: str) -> bool:
    """Does the top of this page read like something standing in the way?"""
    return bool(_GATE_WORDS.search(page_text[:_GATE_WINDOW]))


def press_to_get_past(labels: list[str], page_text: str) -> str:
    """The ONE control to press to reveal the page, or "".

    Requires two independent signals — the page reads like a gate, and it
    offers a control shaped like a way past one — and returns nothing when
    a rank holds more than one candidate.
    """
    if not looks_like_a_gate(page_text):
        return ""
    usable = [
        label
        for label in dict.fromkeys(lbl.strip() for lbl in labels if lbl and lbl.strip())
        # A wall's button is short. Anything longer is a sentence, a link
        # into an article, or a paragraph of a consent notice.
        if len(label) <= _MAX_BUTTON and not _NEVER.search(label)
    ]
    for rank in _RANKS:
        hits = [label for label in usable if rank.search(label)]
        if len(hits) == 1:
            return hits[0]
        if hits:
            # Two ways past, and no basis to choose. The resolver refuses
            # ambiguity for the same reason.
            return ""
    return ""
