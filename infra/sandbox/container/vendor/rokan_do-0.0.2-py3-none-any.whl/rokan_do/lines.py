"""How a line on a page is read: the anchor, and the value beside it.

A leaf module on purpose. `verify` needs these to check a reading and
`executor` needs them to make one, and when `executor` imported them from
`verify` the two formed a cycle — `verify` already imports `Trace` from
`executor`. Neither is the natural owner, so neither owns them.

The two must agree, which is the real reason this is one file rather than
two copies. When they disagreed, the verifier accepted a reading whose
value the executor had not put in the answer: redis.io reported "Time
complexity:" as the answer and called it verified.
"""

from __future__ import annotations

import re

#: What a value looks like, for pairing a label with the line beneath it.
#: Deliberately the same shape the daemon filters on.
CARRIES_A_VALUE = re.compile(
    r"\d|\b(?:operational|enabled|disabled|active|yes|no|none)\b", re.IGNORECASE
)

#: Words too common to narrow anything. Shared by the planner's line filter
#: (which drops them from the page search) and memory's recall matcher
#: (which drops them before asking whether a question and an anchor share a
#: word) — one vocabulary, or the two ends disagree about what a content
#: word is.
#:
#: "default" is here, and it looks wrong: it is a content word in a
#: documentation question, and three of seven failures at the time were
#: "what is the DEFAULT x" on pages offering a `Syntax:` row and a
#: `Default:` row. Removing it was measured and changed nothing — 12/19
#: either way, with nginx and apache passing a single run and failing under
#: three. It helps sometimes, which is not the same as helping.
STOP_WORDS = frozenset(
    {
        "what",
        "is",
        "the",
        "at",
        "my",
        "a",
        "an",
        "of",
        "for",
        "how",
        "much",
        "many",
        "which",
        "does",
        "read",
        "check",
        "when",
        "where",
        "who",
        "why",
        "long",
        "and",
        "to",
        "in",
        "on",
        "from",
        "get",
        "this",
        "that",
        "by",
        "com",
        "org",
        "www",
        "html",
        "docs",
        "give",
        "show",
        "tell",
        "find",
        "look",
        "up",
        "me",
        "your",
        "please",
        "default",
        # "what" was here from the start; "whats" — the apostrophe-less way
        # people type it — was not, and the one surviving token blocked replays
        # the anchors fully covered. Measured before added (the F8 sweep,
        # docs/measurements/2026-08-24-f8-matcher-stop-list.md): +2 rewording
        # replays, nothing lost, no collision opened on either corpus.
        "whats",
    }
)


#: Every space the web uses that a person's keyboard does not: non-breaking,
#: thin, hair, figure, narrow, zero-width, and the ideographic one.
_ODD_SPACES = re.compile(r"[\u00a0\u1680\u2000-\u200b\u202f\u205f\u3000\ufeff]")


def flatten(text: str) -> str:
    """One kind of space, so a copied line matches the line it was copied from.

    Measured on nodejs.org: the page renders `Type: <integer> Default:
    65536` and the character between `<integer>` and `Default:` is U+00A0,
    a NON-BREAKING SPACE. A model shown that line writes it back with the
    space its tokeniser knows, and the anchor then matches nothing — a
    faithful quotation that cannot be found.

    Non-breaking spaces are not exotic. They hold prices together, units to
    their numbers, and labels to their values, which is precisely where a
    read_value anchor lands.
    """
    return " ".join(_ODD_SPACES.sub(" ", text).split())


def beside(anchor: str, line: str) -> str:
    """What is left of a line once its anchor is removed — the value.

    Stripped character-by-character on purpose: `.strip()` takes a SET of
    characters, not a suffix, which makes multi-character arguments quietly
    wrong. The separators a label can wear are single glyphs.
    """
    return re.sub(re.escape(flatten(anchor)), "", flatten(line), count=1, flags=re.I).strip(
        " :\t·—–-…"
    )


#: A line that is announcing something rather than saying it: one ending in
#: a colon, or left hanging on a copula or preposition.
#:
#: gov.uk renders "The standard VAT rate is" and "20%" on separate lines,
#: with no colon between them. A trailing "is" is as clear an announcement
#: as a colon and a good deal more common in prose — and the danger it
#: opens is closed by the same rule as the colon's: whatever follows must
#: itself carry a value, so "The balance is" cannot capture "Plan Pro".
_ANNOUNCES_A_VALUE = re.compile(r"(?::|\b(?:is|are|was|were|of|to|at|equals)\s*)$", re.IGNORECASE)


def value_after_label(lines: list[str], index: int) -> str:
    """The value on the NEXT line, when this line is a bare label.

    Two real sites, rendered by different tools, split a label from its
    value: redis.io shows "Time complexity:" then "O(1)", nginx shows
    "Default:" then "keepalive_timeout 75s;". Read one line at a time both
    are "present but carries no value" — true about the line and false
    about the page, which reads them as a pair.

    Narrow on purpose, in two ways that were each supplied by a test:

    * only a line that ANNOUNCES a value pairs — one ending in a colon, or
      left hanging on a copula ("The standard VAT rate is"). Without that,
      a dashboard which failed to load would take the next row's number as
      its answer;
    * and the next line must itself carry a value. Without that, the rule
      joined "QUARTERLY REVENUE:" to "Plan Pro" — a label welded to
      whatever prose followed, which is a worse lie than reporting no
      value at all.
    """
    if index < 0 or index >= len(lines):
        return ""
    if not _ANNOUNCES_A_VALUE.search(lines[index]):
        return ""
    for following in lines[index + 1 :]:
        candidate = following.strip()
        if not candidate:
            continue
        return candidate if CARRIES_A_VALUE.search(candidate) else ""
    return ""
