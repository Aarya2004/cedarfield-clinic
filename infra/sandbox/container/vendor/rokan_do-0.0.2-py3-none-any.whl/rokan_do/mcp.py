"""The gateway: `rokan do` as a tool another agent calls.

Until this file existed, `do` was a CLI — a human's entrypoint. The agent is
the user (ledger §K), so the agent needs its own door: one typed tool that
takes a task in words and returns an outcome, never a page and never a step.

What the caller gets back is the SAME shape the CLI renders, as JSON:
``status`` (``ok`` / ``abstained`` / ``error``), ``value``, ``speed`` (which
of the three speeds answered — ``compiled`` / ``replayed`` / ``planned`` /
``refused``), and on anything but plain success a ``reason`` and a
``next_step`` the caller can act on. Those two fields are the agent's voice
to the human who bought it; they are product, not logging.

Four things this tool will not do, on purpose:

* **Run before the human has consented — twice.** `do` sends logged-in page
  text to a model provider on the planned path; the CLI discloses that on the
  first task. The gateway additionally hands RESULTS (for ``get_api_key``, the
  key) to the calling agent, whose transcript goes to its own provider — a
  different promise, so it has its own consent: ``rokan-do allow-agents``,
  run by the human in their own terminal. Absent either record, the tool
  refuses and names the command. An agent cannot consent for its owner.
* **Take a `probe`.** The CLI's ``--probe`` lets a human name the endpoint an
  acquired key is spent against. From an untrusted caller that is a channel
  to exfiltrate the key to an attacker's host (Opus review, proven with a
  loopback oracle). Not exposed here; verifiers use their own defaults.
* **Run two tasks at once.** One browser job at a time (H12): a module lock
  serialises ``rokan_do`` calls from a client that dispatches in parallel.
* **Accept a credential.** Same rule as `rokan_mcp.server`: a secret pasted
  into a task is refused by `accept` before anything else happens.
"""

from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import sys
from typing import Any

from rokan_agent.core.result import Result
from rokan_mcp import login

from . import service
from .accept import accept, accept_general, classes_offered
from .cascade import _lines_worth_reading
from .memory import Memory
from .redact import redact

logger = logging.getLogger("rokan_do.mcp")

SERVER_NAME = "rokan-do"
SERVER_VERSION = "0.0.2"

#: What the human must run, once, in their own terminal.
FIRST_RUN_COMMAND = 'rokan-do "read the default keepalive_timeout at nginx.org"'
ALLOW_AGENTS_COMMAND = "rokan-do allow-agents"

#: One browser-driving job at a time, whoever is calling.
_ONE_AT_A_TIME = asyncio.Lock()

TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "name": "rokan_browse",
        "description": (
            "Have Rokan do ANY task on a named site — read a value, fill a form, "
            "sign in and act, send a message, cancel a plan — behind the user's "
            "logins, and label the result: `verification` is `verified` (a "
            "deterministic postcondition on the final page passed), "
            "`self_reported` (the run finished; nothing on the page could confirm "
            "it), or `refused` (declined, with `reason` and `next_step`).\n\n"
            "Writes — anything that deletes, pays, cancels, sends, or submits — run "
            "only with allow_write=true AND a grant the human gave once in their own "
            "terminal (`rokan-do allow <site> <action>`); otherwise the result is "
            "`refused` with that exact command in `next_step`. Values you already "
            "hold (a recipient, a message) go in `params`, never in the task text: "
            "one verified operation then replays for every value, with 0 model calls."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "The task in words, naming the site.",
                    "minLength": 4,
                },
                "allow_write": {
                    "type": "boolean",
                    "description": "Permit an action that changes state. Default false.",
                    "default": False,
                },
                "params": {
                    "type": "object",
                    "description": (
                        "Values the plan may bind at fill time, by name "
                        "(e.g. {\"recipient\": \"Ada\"}). Never a secret."
                    ),
                    "additionalProperties": {"type": "string"},
                    "default": {},
                },
                "fresh": {
                    "type": "boolean",
                    "description": "Skip memory and re-plan. Default false.",
                    "default": False,
                },
            },
            "required": ["task"],
            "additionalProperties": False,
        },
    },
    {
        "name": "rokan_page",
        "description": (
            "Read one page as the user's browser sees it — text plus the lines that "
            "carry values — with NO model call and no action. Behind the user's "
            "logins when a session exists. Secrets on the page are redacted."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "An absolute http(s) URL."}
            },
            "required": ["url"],
            "additionalProperties": False,
        },
    },
    {
        "name": "rokan_do",
        "description": (
            "Have Rokan do one task on the web, behind the user's logins, and "
            "return a VERIFIED result or an honest refusal. Say the task in words, "
            "naming the site: 'get my api key from resend.com', 'what is my current "
            "plan on vercel.com', 'read the default keepalive_timeout at nginx.org'.\n\n"
            "The result carries `status` (ok | abstained | error), `value`, and "
            "`speed`: `compiled` (milliseconds, no browser), `replayed` (no model), "
            "or `planned` (a first run — seconds). A repeat of a task that worked is "
            "fast and calls no model. Anything not proven by a deterministic check "
            "comes back `abstained` with a `reason` and a `next_step` — follow that "
            "rather than retrying the same call.\n\n"
            "Rokan never solves bot checks, never creates accounts, and never "
            "accepts a password in a task; it reports each honestly. Call "
            "rokan_do_can to see the task classes it accepts."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "The task in words, naming the site.",
                    "minLength": 4,
                },
                "fresh": {
                    "type": "boolean",
                    "description": "Skip memory and re-plan. Default false.",
                    "default": False,
                },
                "discover": {
                    "type": "boolean",
                    "description": (
                        "Let Rokan search for the right public page first when only "
                        "the service is named. Default false."
                    ),
                    "default": False,
                },
            },
            "required": ["task"],
            "additionalProperties": False,
        },
    },
    {
        "name": "rokan_do_ops",
        "description": (
            "What Rokan has already learned to do on this machine: one row per "
            "proven operation with its site, what it reads, use/replay/failure "
            "counts and its speed. `instant` means a synthetic API exists for it. "
            "Call this to know which sites are warm before planning work."
        ),
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "rokan_do_can",
        "description": (
            "The task classes rokan_do accepts, one line each. Everything else is "
            "refused with a reason."
        ),
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
]


def _consented() -> bool:
    """Both records: the first-run disclosure AND the gateway consent."""
    from .cli import _disclosure_shown, _gateway_allowed

    return _disclosure_shown() and _gateway_allowed()


def _consent_refusal() -> dict[str, Any]:
    from .cli import _disclosure_shown

    step = (
        f"run {ALLOW_AGENTS_COMMAND}"
        if _disclosure_shown()
        else f"run {FIRST_RUN_COMMAND} and then {ALLOW_AGENTS_COMMAND}"
    )
    return {
        "status": "abstained",
        "speed": "refused",
        "value": None,
        "reason": "consent_required",
        "next_step": (
            "The human must consent, once, in their own terminal, before another "
            f"agent may call Rokan: {step}. Then call this tool again."
        ),
    }


def _result_json(result: Result, speed: str) -> dict[str, Any]:
    out: dict[str, Any] = {
        "status": result.status.value,
        "speed": speed,
        "value": result.data,
        "elapsed_ms": result.elapsed_ms,
    }
    if result.reason is not None:
        out["reason"] = result.reason.value
    if result.next_step:
        out["next_step"] = result.next_step
    if result.evidence:
        out["evidence"] = list(result.evidence)
    return out


async def tool_do(args: dict[str, Any]) -> dict[str, Any]:
    """Accept → consent gate → the three speeds, one at a time → JSON."""
    task = accept(str(args.get("task", "")))
    if isinstance(task, Result):
        # Refused before any model, browser, or network: the class is not
        # offered, a slot is missing, or a secret was pasted.
        return _result_json(task, "refused")

    if not _consented():
        return _consent_refusal()

    async with _ONE_AT_A_TIME:
        performed = await service.perform(
            task,
            fresh=bool(args.get("fresh", False)),
            use_discovery=bool(args.get("discover", False)),
            warn=lambda message: logger.warning("%s", message),
        )
    out = _result_json(performed.result, performed.path)
    if performed.path == "planned" and performed.narration:
        out["narration"] = list(performed.narration)
    return out


def tool_ops() -> dict[str, Any]:
    if not _consented():
        # Which services the human has accounts on is theirs to share.
        return _consent_refusal()
    rows: list[dict[str, Any]] = []
    for item in Memory().library():
        host = item.plan.site.split("://", 1)[-1].split("/", 1)[0]
        reads = [
            str(step.args.get("contains", ""))
            for step in item.plan.steps
            if step.verb.value == "read_value"
        ]
        rows.append(
            {
                "operation": item.plan.task_class,
                "site": host,
                "reads": reads,
                "uses": item.uses,
                "replays": item.replays,
                "failures": item.failures,
                "speed": "instant" if item.compiled else "replayed",
                "learned_at": item.learned_at,
            }
        )
    return {"operations": rows, "count": len(rows)}


def tool_can() -> dict[str, Any]:
    return {"can": list(classes_offered())}


#: Page text handed back by `rokan_page`. A page is not a transcript.
_PAGE_CHARS = 12_000


async def tool_browse(args: dict[str, Any]) -> dict[str, Any]:
    """General mode: accept_general → consent → perform → labeled JSON."""
    raw_params = args.get("params") or {}
    params = {str(k): str(v) for k, v in raw_params.items()} if isinstance(raw_params, dict) else {}
    task = accept_general(
        str(args.get("task", "")), allow_write=bool(args.get("allow_write", False))
    )
    if isinstance(task, Result):
        out = _result_json(task, "refused")
        out["verification"] = "refused"
        return out
    if not _consented():
        out = _consent_refusal()
        out["verification"] = "refused"
        return out
    async with _ONE_AT_A_TIME:
        performed = await service.perform(
            task,
            fresh=bool(args.get("fresh", False)),
            params=params,
            warn=lambda message: logger.warning("%s", message),
        )
    out = _result_json(performed.result, performed.path)
    out["verification"] = performed.verification
    if performed.path == "planned" and performed.narration:
        out["narration"] = list(performed.narration)
    # Param VALUES never echo: the value is the caller's, and a result that
    # repeats it is a second place it can leak from.
    for value in params.values():
        if value and value in json.dumps(out):
            out = json.loads(json.dumps(out).replace(value, "[param]"))
    return out


async def tool_page(args: dict[str, Any]) -> dict[str, Any]:
    """Read-only: the page's text and value lines, redacted, no model."""
    url = str(args.get("url", "")).strip()
    if not url.lower().startswith(("http://", "https://")):
        return {
            "status": "abstained",
            "speed": "refused",
            "reason": "invalid_url",
            "next_step": "give an absolute http(s) URL",
            "model_calls": 0,
        }
    if not _consented():
        return _consent_refusal()
    from .accept import TaskRequest  # noqa: PLC0415

    async with _ONE_AT_A_TIME:
        fetched = await login.fetch(url)
        if not getattr(fetched, "ok", False):
            return {
                "status": "abstained",
                "speed": "refused",
                "reason": str(getattr(fetched, "reason", "") or "navigation_failed"),
                "next_step": str(getattr(fetched, "message", "") or "the page did not load"),
                "model_calls": 0,
            }
        lines, _looked = await _lines_worth_reading(
            TaskRequest(task_class="read_value", site=url, slots={}, said="")
        )
    text = redact(str(getattr(fetched, "text", "") or ""))
    return {
        "status": "ok",
        "speed": "page",
        "url": url,
        "text": text[:_PAGE_CHARS],
        "truncated": bool(getattr(fetched, "truncated", False)) or len(text) > _PAGE_CHARS,
        "lines": [ln for ln in lines.splitlines()[1:] if ln.strip()],
        "authenticated": bool(getattr(fetched, "session_backed", False)),
        "model_calls": 0,
    }


async def dispatch(name: str, args: dict[str, Any]) -> dict[str, Any]:
    if name == "rokan_browse":
        return await tool_browse(args)
    if name == "rokan_page":
        return await tool_page(args)
    if name == "rokan_do":
        return await tool_do(args)
    if name == "rokan_do_ops":
        return tool_ops()
    if name == "rokan_do_can":
        return tool_can()
    return {"status": "error", "reason": "unknown_tool", "next_step": f"no tool named {name}"}


def _store_busy(exc: sqlite3.OperationalError) -> bool:
    detail = str(exc).lower()
    return "locked" in detail or "busy" in detail


async def _run_tool(name: str, args: dict[str, Any]) -> str:
    try:
        payload = await dispatch(name, args)
    except sqlite3.OperationalError as exc:
        if not _store_busy(exc):
            raise
        # A neighbour — the CLI, the scheduler — holds a write lock. Waiting
        # is the answer; the CLI says the same (cli.main).
        logger.warning("store busy during %s", name)
        payload = {
            "status": "error",
            "speed": "refused",
            "reason": "store_busy",
            "next_step": "another Rokan is mid-write on this machine; wait a moment and retry",
        }
    except Exception as exc:  # noqa: BLE001 — a tool must never crash the server
        logger.exception("tool %s failed", name)
        # Generic on purpose: internals never reach the caller (security rule 5).
        payload = {
            "status": "error",
            "speed": "refused",
            "reason": "internal_error",
            "next_step": (
                f"rokan-do hit an internal error ({type(exc).__name__}); retry once, then report it"
            ),
        }
    return json.dumps(payload, ensure_ascii=False, default=str)


# The SDK derives each tool's input schema from the function signature, so
# these signatures ARE the served contract; `TOOL_SCHEMAS` above is the same
# contract written out for the legacy SDK and for the caller-facing text.
# A test holds the two together.


async def rokan_do(task: str, fresh: bool = False, discover: bool = False) -> str:
    return await _run_tool("rokan_do", {"task": task, "fresh": fresh, "discover": discover})


async def rokan_browse(
    task: str,
    allow_write: bool = False,
    params: dict[str, str] | None = None,
    fresh: bool = False,
) -> str:
    return await _run_tool(
        "rokan_browse",
        {"task": task, "allow_write": allow_write, "params": params or {}, "fresh": fresh},
    )


async def rokan_page(url: str) -> str:
    return await _run_tool("rokan_page", {"url": url})


async def rokan_do_ops() -> str:
    return await _run_tool("rokan_do_ops", {})


async def rokan_do_can() -> str:
    return await _run_tool("rokan_do_can", {})


TOOL_FUNCTIONS: dict[str, Any] = {
    "rokan_browse": rokan_browse,
    "rokan_page": rokan_page,
    "rokan_do": rokan_do,
    "rokan_do_ops": rokan_do_ops,
    "rokan_do_can": rokan_do_can,
}


def sdk_major() -> int:
    """Same dual-SDK rule as `rokan_mcp.server`: whatever the client resolved."""
    try:
        from mcp.server.mcpserver import MCPServer  # noqa: F401
    except ImportError:
        return 1
    return 2


def build_server() -> Any:
    if sdk_major() >= 2:
        from mcp.server.mcpserver import MCPServer

        server = MCPServer(name=SERVER_NAME, version=SERVER_VERSION)
        for schema in TOOL_SCHEMAS:
            server.add_tool(
                TOOL_FUNCTIONS[schema["name"]],
                name=schema["name"],
                description=schema["description"],
                structured_output=False,
            )
        return server

    from mcp.server import Server
    from mcp.types import TextContent, Tool

    legacy: Any = Server(SERVER_NAME, version=SERVER_VERSION)

    @legacy.list_tools()  # type: ignore[untyped-decorator, unused-ignore]
    async def _list_tools() -> list[Tool]:
        return [Tool(**schema) for schema in TOOL_SCHEMAS]

    @legacy.call_tool()  # type: ignore[untyped-decorator, unused-ignore]
    async def _call_tool(name: str, arguments: dict[str, Any] | None) -> list[TextContent]:
        return [TextContent(type="text", text=await _run_tool(name, arguments or {}))]

    return legacy


async def serve() -> None:
    """Run the stdio server — what `rokan-do mcp` starts."""
    server = build_server()
    if sdk_major() >= 2:
        await server.run_stdio_async()
        return

    from mcp.server.stdio import stdio_server

    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main() -> int:
    # stdout is the MCP transport; every log line goes to stderr or the
    # JSON-RPC stream is corrupted by the first library that logs.
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    asyncio.run(serve())
    return 0
