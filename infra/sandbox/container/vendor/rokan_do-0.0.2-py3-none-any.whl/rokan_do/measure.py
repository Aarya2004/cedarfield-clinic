"""The numbers, computed the same way whether they flatter us or not.

Everything this product claims will be a proportion measured on a small
sample — tasks accepted, tasks verified, tasks refused. Small-sample
proportions are exactly where the obvious method lies: the textbook interval
collapses to zero width at 0% and 100%, so "ten for ten" would report
"100%, ± 0%", which is a falsehood with a decimal point on it.

So every rate here comes back as a Wilson interval, and the verdict is
computed against bars that were written down BEFORE anything ran. That is
the only arrangement in which a number can disappoint us.

The four things worth measuring, and why each:

* **verified success** — of the tasks Rokan accepted, how many did it prove?
  This is the headline, and it is deliberately not "attempted" — a task the
  gate refused was never a failure, it was a refusal.
* **coverage** — of everything asked, how much did it accept? A narrow gate
  gets a perfect success rate by doing nothing; publishing coverage beside it
  is what makes the success rate honest.
* **gate correctness** — of every call the gate made, how many were right,
  in BOTH directions? Counted rather than rated: one wrong accept is an event
  to investigate, and a gate that refuses everything must not score perfectly
  on safety.
* **credential incidents** — an absolute count with a bar of zero. Not a rate:
  one is a stop-everything event, and averaging it would hide it.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime

from rokan_agent.core.metrics import Rate, wilson

#: Pre-registered, dated, and not to be adjusted after seeing results. These
#: are the bars the product must clear to be described in public.
BARS = {
    #: Judged on the interval's lower bound — a lucky small sample must not
    #: clear it.
    "verified_success": 0.90,
    #: Counts, not rates: one wrong gate call or one leaked credential is an
    #: event to investigate, and a Wilson lower bound can never reach 1.0 at
    #: any finite sample, so rating these would make perfection unpassable.
    "gate_errors": 0,
    "credential_incidents": 0,
}
BARS_REGISTERED = "2026-08-22"


@dataclass(frozen=True, slots=True)
class TaskOutcome:
    """One task, and what actually happened to it."""

    said: str
    #: Did the gate accept it? A refusal is not a failure.
    accepted: bool
    #: Should it have been accepted? Written by a human BEFORE the run, so a
    #: gate that quietly widens is caught rather than congratulated.
    should_accept: bool
    #: Did the postcondition pass? None when it never ran.
    verified: bool | None = None
    #: Did the PRODUCT report success, whatever the answer turned out to
    #: be? Separate from `verified`, which also checks the answer was the
    #: right one, and the gap between them is the number that matters
    #: most: a task the product refused is a task it was honest about, and
    #: a task it answered wrongly is not.
    claimed: bool | None = None
    #: Did a credential appear anywhere it should not have?
    credential_leak: bool = False
    elapsed_ms: int = 0
    model_calls: int = 0
    note: str = ""
    #: True when the HARNESS failed, not the product. Kept separate because
    #: a run that crashed on trial 150 and one that failed a postcondition
    #: are different facts, and averaging them makes both unreadable.
    harness_error: bool = False
    #: The unit within which failures CORRELATE — for the fixture set, the
    #: page. Empty means "this task stands alone".
    #:
    #: Distinct task text was already the fix for counting repeats as
    #: trials. It is not the whole fix. Six phrasings of a question about
    #: one page share a DOM, an anchor and a login: when that page breaks,
    #: all six break together, which is precisely the dependence a binomial
    #: interval assumes away. Measured on the registered set: 30 accepted
    #: tasks, 20 distinct values, 6 pages — lower bounds of 0.886, 0.839
    #: and 0.610 for the same perfect run.
    cluster: str = ""


@dataclass(frozen=True, slots=True)
class Measurement:
    """What can honestly be said, and whether it clears the bars."""

    verified_success: Rate
    credential_incidents: int
    trials: int
    #: How many DIFFERENT tasks those trials came from. This is the number
    #: the interval is computed over, and the reason is worth stating in
    #: full, because the first published run got it wrong:
    #:
    #: twelve repeats of one task, against one fixture, through a
    #: deterministic gate and a cached prompt, are ONE observation with
    #: twelve looks at it — not twelve independent trials. Treating them as
    #: independent took a lower bound of 0.610 to 0.949 and turned "does not
    #: meet the bars" into "MEETS THE BARS". The flag that inflated the count
    #: was the flag that made it pass.
    #:
    #: So a task counts once, and it counts as a success only if EVERY
    #: attempt of it succeeded. That is the conservative reading, and the
    #: conservative reading is the only one worth publishing.
    distinct_tasks: int
    repeats: int
    #: Bare fractions, deliberately without intervals. `accept` is a
    #: deterministic lookup with no model in it, so these have no sampling
    #: variance at all — an interval on them would be a confidence interval
    #: on a constant, which is the exact thing this module exists to refuse.
    accepted_tasks: int
    gate_errors: int
    median_ms: int
    total_model_calls: int
    harness_errors: int = 0
    #: Tasks the product claimed to have done, and got wrong. THE number
    #: for a product whose promise is "verified, or refused" — a refusal
    #: costs a person a retry, and a wrong answer costs them whatever they
    #: did with it.
    wrong_answers: int = 0
    #: Tasks the product declined rather than guess at.
    refused_after_trying: int = 0
    #: The same rate computed over correlated groups instead of task texts.
    #: Reported ALWAYS, and it is the one the verdict uses. Publishing the
    #: friendliest of several defensible clusterings is the same move as
    #: publishing repeats as trials, one level up.
    clustered_success: Rate | None = None
    clusters: int = 0
    #: Set when the run was filtered. A filtered run is a spot check and may
    #: never print a verdict — its output would otherwise be textually
    #: indistinguishable from the pre-registered one.
    filtered: str = ""
    registered: str = BARS_REGISTERED
    notes: list[str] = field(default_factory=list)

    @property
    def coverage(self) -> str:
        return f"{self.accepted_tasks}/{self.distinct_tasks}"

    @property
    def passes(self) -> bool:
        """Every bar, on the LOWER bound of an interval over DISTINCT tasks.

        A filtered run never passes: it did not run the registered set.
        """
        if self.filtered:
            return False
        # The CONSERVATIVE of the available clusterings, never the kindest.
        #
        # Tightening a gate after seeing the data is not the thing
        # pre-registration forbids — it forbids LOOSENING one. This can only
        # ever fail a run that the old rule passed, so it cannot manufacture
        # a pass, which is the only direction that would be dishonest.
        rate = self.verified_success
        if self.clustered_success is not None and (
            self.clustered_success.low < rate.low
        ):
            rate = self.clustered_success
        return (
            self.credential_incidents == BARS["credential_incidents"]
            and self.gate_errors == 0
            and self.harness_errors == 0
            and rate.low >= BARS["verified_success"]
        )

    def report(self) -> str:
        verdict = (
            "no verdict — this was a filtered spot check, not the registered set"
            if self.filtered
            else (
                f"no verdict — {self.harness_errors} run(s) failed inside "
                "the harness; fix the harness and rerun"
                if self.harness_errors
                else ("MEETS THE BARS" if self.passes else "does not meet the bars")
            )
        )
        # Stated as a product only when it IS one. `repeats` is the MAXIMUM
        # attempts any task got, so "45 × 2 = 90" is arithmetic that stops
        # being true the moment one task is attempted more often than
        # another — and printing a false sum beside an honest interval
        # undermines the interval.
        exact = self.distinct_tasks * self.repeats == self.trials
        per_task = (
            f"{self.distinct_tasks} tasks × {self.repeats} attempts "
            f"= {self.trials} runs"
            if self.repeats > 1 and exact
            else f"{self.trials} runs over {self.distinct_tasks} tasks"
            if self.repeats > 1
            else f"{self.trials} runs"
        )
        if self.harness_errors:
            # The header counts RUNS; the rates below exclude the
            # harness-failed ones. Printing 90 runs above a rate computed
            # over 12 observations, unannotated, advertises a sample size
            # the interval never saw.
            per_task += (
                f" ({self.harness_errors} harness-failed, excluded from rates)"
            )
        lines = [
            f"{per_task} · median {self.median_ms}ms · "
            f"{self.total_model_calls} model calls",
            f"  verified success   {self.verified_success}",
            "                     (over DISTINCT tasks; a task counts as a "
            "success only if every attempt succeeded)",
            *(
                [
                    f"  by page            {self.clustered_success}",
                    "                     (over the "
                    f"{self.clusters} groups whose failures correlate — the "
                    "unit the verdict uses)",
                ]
                if self.clustered_success is not None
                else []
            ),
            f"  coverage           {self.coverage} tasks accepted",
            f"  refused, honestly  {self.refused_after_trying}",
            f"  ANSWERED WRONGLY   {self.wrong_answers}",
            f"  gate errors        {self.gate_errors}",
            f"  credential leaks   {self.credential_incidents}",
            f"  harness errors     {self.harness_errors}",
            f"  bars (registered {self.registered}): "
            f"success ≥{BARS['verified_success']:.0%} (lower bound) · "
            "gate errors 0 · leaks 0",
            f"  verdict            {verdict}",
        ]
        if self.notes:
            lines.append("  notes")
            lines.extend(f"    · {note}" for note in self.notes)
        return "\n".join(lines)

    def to_json(self) -> str:
        return json.dumps(
            {
                "measured_at": datetime.now(UTC).isoformat(),
                "registered": self.registered,
                "trials": self.trials,
                "distinct_tasks": self.distinct_tasks,
                "repeats": self.repeats,
                "filtered": self.filtered,
                "verified_success": {
                    "point": self.verified_success.point,
                    "low": self.verified_success.low,
                    "high": self.verified_success.high,
                    "n": self.verified_success.total,
                    "unit": "distinct tasks, all-attempts-must-pass",
                },
                "clustered_success": (
                    {
                        "point": self.clustered_success.point,
                        "low": self.clustered_success.low,
                        "high": self.clustered_success.high,
                        "n": self.clustered_success.total,
                        "unit": "correlated groups, all-tasks-must-pass",
                    }
                    if self.clustered_success is not None
                    else None
                ),
                "coverage": self.coverage,
                "credential_incidents": self.credential_incidents,
                "gate_errors": self.gate_errors,
                "wrong_answers": self.wrong_answers,
                "refused_after_trying": self.refused_after_trying,
                "harness_errors": self.harness_errors,
                "median_ms": self.median_ms,
                "model_calls": self.total_model_calls,
                "passes": self.passes,
            },
            separators=(",", ":"),
        )


def measure(outcomes: list[TaskOutcome], *, filtered: str = "") -> Measurement:
    """Compute what can be said. Never rounds in our favour.

    Everything is computed over DISTINCT TASKS, keyed by what was said. See
    `Measurement.distinct_tasks` for why, at length: it is the difference
    between a lower bound of 0.610 and one of 0.949, and therefore between
    a run that clears the bar and one that does not.
    """
    if not outcomes:
        return Measurement(
            verified_success=wilson(0, 0),
            credential_incidents=0,
            trials=0,
            distinct_tasks=0,
            repeats=0,
            accepted_tasks=0,
            gate_errors=0,
            median_ms=0,
            total_model_calls=0,
            filtered=filtered,
            notes=["nothing was run"],
        )

    by_task: dict[str, list[TaskOutcome]] = {}
    for outcome in outcomes:
        by_task.setdefault(outcome.said, []).append(outcome)

    # A task is a success only if EVERY attempt of it succeeded. One failure
    # in twelve is a task that does not reliably work, and reporting it as
    # 11/12 successes is how a flaky operation reads as a working one.
    # A harness failure — a crash, a provider outage — is counted below
    # (`harness_errors`, which voids the verdict) but it is not an
    # OBSERVATION of the product, and it must not sit in any success
    # denominator, refusal column, or attempt list, in either direction.
    # Round 4, 2026-08-24: an API-billing outage scored as 15 honest
    # refusals; before that, a crash counted as a product failure while a
    # note said no verdict was possible.
    observed = {
        said: [o for o in runs if not o.harness_error]
        for said, runs in by_task.items()
    }
    scored = {
        said: runs
        for said, runs in observed.items()
        if any(o.verified is not None for o in runs)
    }
    verified_success = wilson(
        sum(1 for runs in scored.values() if all(o.verified for o in runs)),
        len(scored),
    )

    # Same rule one level up: a GROUP succeeds only if every task in it did.
    by_cluster: dict[str, list[TaskOutcome]] = {}
    for said, runs in scored.items():
        key = next((o.cluster for o in runs if o.cluster), "")
        by_cluster.setdefault(key or said, []).extend(runs)
    clustered = (
        wilson(
            sum(1 for runs in by_cluster.values() if all(o.verified for o in runs)),
            len(by_cluster),
        )
        if by_cluster and len(by_cluster) < len(scored)
        else None
    )

    accepted_tasks = sum(
        1 for runs in by_task.values() if any(o.accepted for o in runs)
    )
    gate_errors = sum(
        1
        for runs in by_task.values()
        if any(o.accepted != o.should_accept for o in runs)
    )
    # Of the tasks that did not verify: which did the product ANSWER, and
    # which did it decline? Counted over distinct tasks, like everything
    # else here.
    failed = [
        runs
        for runs in scored.values()
        if not all(o.verified for o in runs)
    ]
    # CLAIMED AND WRONG, not merely claimed.
    #
    # The first version asked `any(o.claimed)`, which counted a task that
    # PASSED one attempt and refused the others as answered wrongly —
    # because the passing run claimed, correctly. It reported 6 wrong and 0
    # refused on a set where two tasks only ever refused, and I nearly
    # published it.
    wrong_answers = sum(
        1 for runs in failed if any(o.claimed and not o.verified for o in runs)
    )
    refused_after_trying = len(failed) - wrong_answers

    ran = [o for o in outcomes if o.verified is not None and not o.harness_error]
    durations = sorted(o.elapsed_ms for o in ran) or [0]
    median = durations[len(durations) // 2]
    repeats = max(len(runs) for runs in by_task.values())

    notes: list[str] = []
    if 0 < len(scored) < 20:
        notes.append(
            f"only {len(scored)} distinct scored tasks — the interval is wide "
            "on purpose; repeating the set does not narrow it, and is not "
            "meant to"
        )
    mis_accepted = [
        said
        for said, runs in by_task.items()
        if any(o.accepted and not o.should_accept for o in runs)
    ]
    if mis_accepted:
        notes.append(
            f"{len(mis_accepted)} task(s) accepted that should have been "
            "refused: " + "; ".join(s[:40] for s in mis_accepted[:3])
        )
    mis_refused = [
        said
        for said, runs in by_task.items()
        if any(not o.accepted and o.should_accept for o in runs)
    ]
    if mis_refused:
        # Named as well as counted. Only the dangerous direction used to be
        # disclosed, which lets a gate quietly narrow itself into a perfect
        # score on the half that gets printed.
        notes.append(
            f"{len(mis_refused)} task(s) refused that should have been "
            "accepted: " + "; ".join(s[:40] for s in mis_refused[:3])
        )
    flaky = [
        said
        for said, runs in scored.items()
        if any(o.verified for o in runs) and not all(o.verified for o in runs)
    ]
    if flaky:
        notes.append(
            f"{len(flaky)} task(s) succeeded on some attempts and not others: "
            + "; ".join(s[:40] for s in flaky[:3])
        )
    harness_errors = sum(1 for o in outcomes if o.harness_error)
    if harness_errors:
        notes.append(
            f"{harness_errors} run(s) failed inside the harness, not the "
            "product — no verdict is possible until they are fixed"
        )
    if any(o.credential_leak for o in outcomes):
        notes.append("CREDENTIAL INCIDENT — stop and investigate before anything else")
    if filtered:
        notes.append(
            f"filtered to tasks matching {filtered!r} — a spot check, not the "
            "registered set, and therefore not a result"
        )

    return Measurement(
        verified_success=verified_success,
        credential_incidents=sum(1 for o in outcomes if o.credential_leak),
        trials=len(outcomes),
        distinct_tasks=len(by_task),
        repeats=repeats,
        clustered_success=clustered,
        clusters=len(by_cluster),
        accepted_tasks=accepted_tasks,
        gate_errors=gate_errors,
        wrong_answers=wrong_answers,
        refused_after_trying=refused_after_trying,
        median_ms=median,
        total_model_calls=sum(o.model_calls for o in outcomes),
        harness_errors=harness_errors,
        filtered=filtered,
        notes=notes,
    )
