"""The two commands that keep the operation library honest by hand.

    rokan-do allow <site> <action>   a person's grant for one write, once
    rokan-do recheck [site]          the half-life clock: replay everything,
                                     planning forbidden, every try a ledger row

Split out of `cli.py` when it crossed 500 lines (2026-08-25).
"""

from __future__ import annotations

import argparse
import asyncio
import sys

from .memory import Memory


def _out(line: str = "") -> None:
    print(line)


def _err(line: str = "") -> None:
    print(line, file=sys.stderr)


def cmd_allow(args: argparse.Namespace) -> int:
    """Grant one write action on one site — the human's word, given once.

    `rokan_browse` refuses "cancel", "delete", "pay", "send" (and the rest of
    `accept._NEVER`) until this has been run for that site and that action,
    in a terminal, by a person. An agent cannot run it for its owner: the
    gateway has no such tool."""
    from .policy import ACTIONS, allow, grants, revoke  # noqa: PLC0415

    if args.list:
        rows = grants()
        if not rows:
            _out("no grants — nothing may write anywhere")
            return 0
        for g in rows:
            _out(f"  {g.site:32s} {g.action:10s} granted {g.granted_at[:19]}")
        return 0
    if not args.site or not args.action:
        _err("usage: rokan-do allow <site> <action>   (or --list / --revoke)")
        _err("  actions: " + ", ".join(sorted(ACTIONS)))
        return 2
    if args.revoke:
        gone = revoke(args.site, args.action)
        _out(f"  {'revoked' if gone else 'no such grant:'} {args.action} on {args.site}")
        return 0
    try:
        grant = allow(args.site, args.action)
    except ValueError as exc:
        _err(f"  {exc}")
        return 2
    _out()
    _out(f"  granted: {grant.action} on {grant.site}")
    _out("  An agent may now do this through rokan_browse(allow_write=true) —")
    _out("  the page's own button label is checked again at the moment of the click.")
    _out(f"  Undo: rokan-do allow {grant.site} {grant.action} --revoke")
    _out()
    return 0


def cmd_recheck(args: argparse.Namespace) -> int:
    """Replay every learned operation with planning forbidden, and write
    each outcome to the `op_use` ledger — `docs/DERIVATION` E1's clock.
    Sequential: one browser job at a time."""
    from .recheck import recheck, render  # noqa: PLC0415 — keeps `run` light

    report = asyncio.run(recheck(Memory(), site=args.site))
    _out()
    for line in render(report):
        _out(line)
    _out()
    return 0


def cmd_seed(args: argparse.Namespace) -> int:
    """`rokan-do seed install [FILE]` — warm this machine with operations
    verified elsewhere; `rokan-do seed export FILE` — write this machine's
    read-only operations for another."""
    from . import seed  # noqa: PLC0415

    memory = Memory()
    if args.what == "export":
        if not args.file:
            _err("usage: rokan-do seed export FILE")
            return 2
        ops = seed.export_ops(memory)
        import json  # noqa: PLC0415
        from pathlib import Path  # noqa: PLC0415

        Path(args.file).write_text(json.dumps(ops, indent=1) + "\n")
        _out(f"  exported {len(ops)} operation{'s' if len(ops) != 1 else ''} to {args.file}")
        return 0
    if args.what == "install":
        ops = seed.load(args.file) if args.file else seed.bundled()
        if not ops:
            _out("  nothing to install" + ("" if args.file else " — this build ships no pack"))
            return 0
        report = seed.import_ops(memory, ops)
        _out()
        _out(f"  installed {report.installed} · skipped {report.skipped}")
        for why in report.reasons[:10]:
            _out(f"    skip: {why}")
        _out("  Each replays on first use and is re-verified against the live page;")
        _out("  a seed that has rotted retires itself. `rokan-do ops` lists them.")
        _out()
        return 0
    _err("usage: rokan-do seed install [FILE] | rokan-do seed export FILE")
    return 2
