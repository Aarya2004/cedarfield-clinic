"""The Plan IR — what the planner is allowed to say.

The whole reliability argument rests on this file being narrow. The planner
(an LLM) runs ONCE and emits a typed plan; the executor runs the plan
deterministically with no model in the loop. Anything the IR cannot express,
the system cannot do — which is the point. Every verb here maps 1:1 onto a
proven daemon command; there is no "improvise" instruction.

Secrets never appear in a plan. A step that needs one carries a
``vault://host/field`` reference which the executor's broker resolves at the
moment of filling — the planner sees placeholders, plans around them, and
could not leak what it never held (the D4 rule, extended to planning).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any
from urllib.parse import urlparse

#: The scheme a secret reference must use. A plan containing a literal that
#: looks like a credential is rejected before execution (see `validate`).
SECRET_SCHEME = "vault://"


class Verb(StrEnum):
    """Exactly the daemon's proven surface — nothing speculative."""

    NAVIGATE = "navigate"
    SNAPSHOT = "snapshot"
    GET_TEXT = "get_text"
    FILL_REF = "fill_ref"
    CLICK_REF = "click_ref"
    TYPE = "type"
    #: Attach a file to an <input type=file>. The file is CREATED by us,
    #: inside the daemon's upload sandbox, from text the plan supplies —
    #: a form that demands a document is otherwise unfinishable, and
    #: measured on browser-use's own stress tests that was the single
    #: remaining blocker after thirteen fields filled correctly.
    UPLOAD_FILE = "upload_file"

    #: Read a RUN of lines the page already shows, starting at an anchor.
    #: A list answer is only provable if it is the page's own lines, in the
    #: page's own order — 42 of browser-use's 100 benchmark tasks ask for
    #: one ("the top 5 communities", "the first 10 assets"), and every
    #: verifier we had proved exactly one value on exactly one line.
    READ_BLOCK = "read_block"

    # Client-side only — never sent to the daemon. Assertions run over the
    # text/snapshot the daemon returned; keeping them out of the browser is
    # what makes them an independent check rather than a self-report.
    READ_VALUE = "read_value"
    ASSERT_CONTAINS = "assert_contains"


#: Verbs that act on the page. A plan carrying one is a WRITE for every rule
#: that cares: it never compiles, it is admitted to memory only verified, and
#: it never runs over the HTTP text — an action needs the page loaded in the
#: browser it acts on.
ACTION_VERBS = frozenset({Verb.CLICK_REF, Verb.FILL_REF, Verb.TYPE, Verb.UPLOAD_FILE})


@dataclass(frozen=True, slots=True)
class Step:
    verb: Verb
    #: Arguments for the verb. `fill_ref` values may be literals (usernames,
    #: search terms) or `vault://` references (secrets) — never raw secrets.
    args: dict[str, Any] = field(default_factory=dict)
    #: What this step is for, in the user's language, past tense when done —
    #: "entered one-time code". Narration is part of the product surface.
    says: str = ""


@dataclass(frozen=True, slots=True)
class Plan:
    """One accepted task, planned once, executed deterministically."""

    task_class: str
    site: str
    steps: tuple[Step, ...]
    #: The postcondition registry key that must pass for this plan's result
    #: to be believed. A plan without a verifiable postcondition is invalid
    #: by construction — "it looked done" is not a result.
    verify: str
    #: General mode only: what the run must prove, declared by the planner
    #: on the PLAN (the executor never sees these; only `verify.general`
    #: does). Each is one ``{kind: argument}`` — ``url_reached``,
    #: ``confirmation_text``, ``state_changed``, ``no_validation_error``. A
    #: general plan that declares none is `self_reported`, never `verified`.
    postconditions: tuple[dict[str, str], ...] = ()

    def secret_refs(self) -> tuple[str, ...]:
        found: list[str] = []
        for step in self.steps:
            for value in step.args.values():
                if isinstance(value, str) and value.startswith(SECRET_SCHEME):
                    found.append(value)
        return tuple(found)


class InvalidPlan(ValueError):
    """The planner emitted something the IR forbids. Refused, never patched."""


#: Argument keys whose values are allowed to be vault references.
_SECRETABLE_KEYS = frozenset({"value"})

#: How many anchor candidates a plan may carry. Four is enough for "the
#: phrase the question uses, the phrase the page probably uses, and two
#: near-misses"; more is a planner guessing rather than quoting the lines
#: it was shown.
_MAX_ALTERNATIVES = 4

#: Shortest anchor that can plausibly identify one line on a page. Four
#: characters is not a calibrated number — it is the smallest bar that
#: rejects the anchors measured to be useless ("api", "the", "id").
_MIN_ANCHOR_CHARS = 4

#: What each verb cannot work without. Measured need, not bureaucracy: the
#: first real model call produced `navigate({})` and `read_value({})` — a
#: plan that navigates nowhere and verifies nothing, which the validator
#: happily accepted because it was structurally fine. A step missing its
#: essential argument is not a plan, it is a shape.
_REQUIRED_ARGS: dict[Verb, tuple[str, ...]] = {
    Verb.NAVIGATE: ("url",),
    Verb.FILL_REF: ("ref", "value"),
    Verb.CLICK_REF: ("ref",),
    Verb.TYPE: ("text",),
    Verb.UPLOAD_FILE: ("ref", "filename", "content"),
    Verb.READ_VALUE: ("contains",),
    # `after` is NOT required: `first` — the list's own first line — locates
    # the rows better than the heading above them does, and a plan that
    # names it needs no heading at all. `first` IS required: on a page that
    # repeats, a read that does not say which column it wants cannot be
    # checked against anything (measured on quotes.toscrape.com,
    # 2026-08-27 — "the first 5 authors" answered with Login, (about),
    # change, deep-thoughts, thinking).
    Verb.READ_BLOCK: ("lines", "first"),
    Verb.ASSERT_CONTAINS: ("contains",),
}

#: Strings that must never appear as literals in any plan argument. The
#: planner does not hold secrets, so a hit means either a prompt leak or a
#: hallucinated credential — both are refusal-grade.
_FORBIDDEN_LITERAL_MARKERS = ("password", "totp", "secret", "token")

#: A credential written out in full, anywhere in any argument: a marker word
#: bound to a value. This is what catches
#: ``navigate(url=".../reset?token=9fK2...")`` — a step whose key is not one
#: that may hold secrets, and which the original check therefore skipped.
#:
#: The bare marker WORD is not enough on its own outside a secretable field:
#: `read_value(contains="API token")` is the entire get_api_key class, and
#: refusing it would refuse the product.
_LITERAL_SECRET = re.compile(
    r"(?:password|passwd|pwd|secret|token|totp|api[_-]?key)\s*[=:]\s*\S{4,}",
    re.IGNORECASE,
)


#: The generic postconditions a general plan may declare. Kept here, next
#: to the verbs, because a plan is validated against this set on the way in
#: AND on the way out of memory — an edited row cannot smuggle in a kind the
#: verifier does not check.
POSTCONDITION_KINDS: frozenset[str] = frozenset(
    {"url_reached", "confirmation_text", "state_changed", "no_validation_error"}
)

#: A plan longer than this is not a plan for v1's two classes — it is a
#: corrupt or edited row. `_plan_from_json` exists because "a stored plan is
#: a file on disk: it can be edited, corrupted", and a size bound is the one
#: check that matters for an edited row: 5000 navigate steps replay as 5000
#: page loads, with no model, no ceiling and no wall clock.
MAX_STEPS = 24


def validate(plan: Plan, *, resuming: bool = False) -> Plan:
    """The gate between "the model said" and "the machine does".

    Raises InvalidPlan rather than repairing: a plan that needed repair came
    from a planner that misunderstood the task, and executing a patched
    misunderstanding is how agents "succeed" at the wrong thing.

    `resuming` says the browser is ALREADY on the page, mid-task, holding
    work that a reload would destroy — so this plan is allowed to have no
    navigate step. Everything else is checked exactly as before, and a plan
    that DOES navigate is still held to the same-site rule. Never set for a
    cold plan: without a navigate a cold run would act on whatever page
    happened to be open.
    """
    if not plan.steps:
        raise InvalidPlan("a plan with no steps plans nothing")
    if len(plan.steps) > MAX_STEPS:
        raise InvalidPlan(
            f"{len(plan.steps)} steps is not a plan for this task class — "
            f"the ceiling is {MAX_STEPS}"
        )
    if not plan.verify:
        raise InvalidPlan("a plan without a postcondition cannot be believed")
    for index, condition in enumerate(plan.postconditions):
        if not isinstance(condition, dict) or len(condition) != 1:
            raise InvalidPlan(
                f"postcondition {index}: one {{kind: argument}} pair, not {condition!r}"
            )
        kind, argument = next(iter(condition.items()))
        if kind not in POSTCONDITION_KINDS:
            raise InvalidPlan(
                f"postcondition {index}: {kind!r} is not one of {sorted(POSTCONDITION_KINDS)}"
            )
        if not isinstance(argument, str) or not argument.strip():
            raise InvalidPlan(f"postcondition {index}: {kind} needs an argument")
    seen_anchors: dict[str, int] = {}
    for index, step in enumerate(plan.steps):
        for needed in _REQUIRED_ARGS.get(step.verb, ()):
            value = step.args.get(needed)
            if not isinstance(value, str) or not value.strip():
                raise InvalidPlan(
                    f"step {index}: {step.verb.value} without {needed!r} — "
                    "a step missing its essential argument is a shape, not a plan"
                )
        if step.verb is Verb.READ_VALUE:
            # Normalised inline rather than through `lines.flatten`: this
            # module is imported by everything and owes nothing to anyone.
            anchor = " ".join(str(step.args.get("contains") or "").split()).lower()
            if anchor in seen_anchors:
                # Reads are keyed by their anchor, so two steps with the
                # same one are ONE read. A question asking for two things
                # then comes back with one value and calls it verified —
                # measured on dailymail.co.uk (2026-08-27), where "identify
                # the headline AND note its publication time" was planned
                # as the headline anchor, twice, with the time words tucked
                # into `alternatives` where they change nothing.
                raise InvalidPlan(
                    f"step {index}: read_value repeats step "
                    f"{seen_anchors[anchor]}'s anchor — two steps reading "
                    "the same line are one read, and cannot answer two "
                    "questions. Anchor the second on the second thing."
                )
            seen_anchors[anchor] = index
        if step.verb is Verb.NAVIGATE:
            url = step.args["url"]
            if not url.lower().startswith(("http://", "https://")):
                raise InvalidPlan(
                    f"step {index}: navigate to {url!r} — a plan may only "
                    "navigate to an absolute http(s) url it was given"
                )
            if not _same_site(url, plan.site):
                # The plan is written by a model that has just read an
                # untrusted page. "Absolute http(s)" was the only rule, so a
                # page could name its own destination and the run would go
                # there, read something, and report it as the verified answer
                # to a question about somewhere else. The site the user named
                # is the boundary.
                raise InvalidPlan(
                    f"step {index}: navigate to {url!r} leaves {plan.site!r} — "
                    "a plan may only move within the site it was asked about"
                )
        if step.verb in (Verb.READ_VALUE, Verb.ASSERT_CONTAINS):
            _refuse_literal_secrets(step, index)
            anchor = step.args["contains"].strip()
            # Measured on the first real planner run: haiku emitted
            # `read_value(contains='api')` — an anchor that matches a
            # navigation link, a heading, and the value line equally. A weak
            # anchor turns verification into coincidence, so the grammar's
            # requiredness is not enough: the anchor must be able to identify
            # a line.
            if len(anchor) < _MIN_ANCHOR_CHARS:
                raise InvalidPlan(
                    f"step {index}: {anchor!r} is too short to identify a "
                    "line — an anchor that matches anything verifies nothing"
                )
            # ORDERED ALTERNATIVES. The measured failure (2026-08-24) is a
            # planner forced to pre-commit to one exact wording before the
            # page is read: every real-site failure was `drift_detected`,
            # and the answer sat in the lines we had already shown it in 9
            # of 10 cases. browser-use has no such failure because its
            # model can grep the page after seeing it (`search_page`, "zero
            # LLM cost") — we take the same accuracy deterministically by
            # letting the plan carry candidates and the PAGE decide.
            #
            # Every guarantee the primary anchor carries applies to each
            # alternative, or the weakest link decides what gets verified.
            alternatives = step.args.get("alternatives") or []
            if not isinstance(alternatives, list):
                raise InvalidPlan(f"step {index}: alternatives must be a list")
            if len(alternatives) > _MAX_ALTERNATIVES:
                raise InvalidPlan(
                    f"step {index}: {len(alternatives)} alternatives — at most "
                    f"{_MAX_ALTERNATIVES}. A long list is a planner guessing "
                    "rather than quoting what it was shown."
                )
            for other in alternatives:
                if not isinstance(other, str) or len(other.strip()) < _MIN_ANCHOR_CHARS:
                    raise InvalidPlan(
                        f"step {index}: {other!r} is too short to identify a "
                        "line — alternatives are anchors and are held to the "
                        "same rule"
                    )
            continue
        _refuse_literal_secrets(step, index)
    _refuse_unsatisfiable(plan, resuming)
    _refuse_navigating_while_resuming(plan, resuming)
    return plan


#: Which verb a postcondition cannot do without. A plan promising
#: `value_present` with nothing that reads a value is refused before it runs:
#: it can only fail, and failing costs a full model rung. Measured live, on
#: the task "read the current status".
_VERIFY_NEEDS: dict[str, Verb] = {
    "value_present": Verb.READ_VALUE,
    "key_used": Verb.READ_VALUE,
    # Added the day after the quantity verifier itself: `verifier_for`
    # started returning this key and nothing updated the registry here, so a
    # quantity task whose plan forgot read_value slipped this guard and paid
    # a full model rung to fail at verify time — the exact cost the guard
    # exists to prevent. A completeness test now holds the two registries
    # together so the next verifier cannot repeat this.
    "value_present_quantity": Verb.READ_VALUE,
    "value_present_status_code": Verb.READ_VALUE,
    "value_present_code_point": Verb.READ_VALUE,
    "value_present_status_word": Verb.READ_VALUE,
    # `general` needs no particular verb: its proof is the declared
    # postcondition list, checked in `verify.general`.
    "general": Verb.NAVIGATE,
    # A list is proved against a RUN of the page, so a plan promising one
    # without a read_block has nothing to prove and would burn a rung
    # discovering that at verify time.
    "block_present": Verb.READ_BLOCK,
}


def _refuse_unsatisfiable(plan: Plan, resuming: bool = False) -> None:
    needed = _VERIFY_NEEDS.get(plan.verify)
    if resuming and needed is Verb.NAVIGATE:
        # The browser is already there and the page holds the work. Measured
        # on browser-use's stress form: told (correctly) not to reload, the
        # resuming plan had no navigate step and this rule refused it — the
        # two halves of the same fix contradicting each other.
        return
    if needed is not None and not any(s.verb is needed for s in plan.steps):
        raise InvalidPlan(
            f"this plan promises {plan.verify!r} but has no "
            f"{needed.value} step — it could only ever fail"
        )


def _refuse_navigating_while_resuming(plan: Plan, resuming: bool) -> None:
    """A resuming plan may not re-open the page it is standing on.

    The resume note asks for this in words, and asking is not enough:
    measured on clevelandclinic.org (2026-08-27), a run clicked into the
    Health Library, stumbled on the search box's label, and the next rung
    began by navigating to the site root — throwing away the click it had
    just been told about and arriving back where it started.

    A resuming plan that needs a different page CLICKS to it. That is what
    the browser being mid-task means.
    """
    if not resuming:
        return
    for index, step in enumerate(plan.steps):
        if step.verb is Verb.NAVIGATE:
            raise InvalidPlan(
                f"step {index}: this plan is RESUMING — the browser is "
                "already on the page and holds the work already done. "
                "Navigating re-opens it and throws that away. Start with "
                "snapshot, and click to reach anywhere else."
            )


def _same_site(url: str, site: str) -> bool:
    """Is this URL on the site the user named?

    Equal hosts, or a subdomain of it — a login that lives at
    accounts.example.com is the same site, and "example.com.attacker.net" is
    not, because it does not END with ".example.com".
    """
    here = urlparse(url).netloc.lower().removeprefix("www.")
    there = urlparse(site if "://" in site else f"https://{site}")
    named = there.netloc.lower().removeprefix("www.")
    if not named:
        return True
    return here == named or here.endswith("." + named)


def _refuse_literal_secrets(step: Step, index: int) -> None:
    """No argument of any step may carry a credential as a literal.

    EVERY string argument, not only the ones allowed to hold secrets. The
    first version checked `marker in value AND key in _SECRETABLE_KEYS`,
    which is the condition inverted: it looked for credentials only in the
    fields that are permitted to have them, so
    ``navigate(url=".../reset?token=abc")`` and ``type(text="hunter2")``
    passed untouched — and the read verbs skipped the check entirely.
    """
    for key, value in step.args.items():
        if isinstance(value, list):
            # A list argument (candidate anchors) is scanned MEMBER BY
            # MEMBER. The scalar-only loop below skipped it entirely, so a
            # credential could ride into a plan inside a list and pass the
            # check that exists to stop exactly that.
            for item in value:
                if isinstance(item, str):
                    _refuse_literal_secrets(
                        Step(step.verb, {key: item}, step.says), index
                    )
            continue
        if not isinstance(value, str):
            continue
        if value.startswith(SECRET_SCHEME):
            if key not in _SECRETABLE_KEYS:
                raise InvalidPlan(
                    f"step {index}: a secret reference may only fill a "
                    f"field value, not {key!r}"
                )
            continue
        lowered = value.lower()
        looks_secret = (
            any(marker in lowered for marker in _FORBIDDEN_LITERAL_MARKERS)
            if key in _SECRETABLE_KEYS
            else _LITERAL_SECRET.search(value) is not None
        )
        if looks_secret:
            raise InvalidPlan(
                f"step {index}: {key!r} carries a literal that looks like a "
                "credential — secrets travel as vault:// references only"
            )
