"""Clean up after killed eval runs, and say what the browser is costing.

Born from ENGINEERING-LOG H12: overlapping evals plus headless Chromium left
alive by killed runs drove the laptop to Chrome 76 GB. The ritual in
HANDOFF-2026-08-24 §1b (log memory, reap after kills, delete
``rokan-eval-*``) was manual, so it was skipped exactly on the chaotic
nights it existed for. This module is that ritual, run by ``run_eval``
itself on every start.

Two rules keep it from doing harm:

* **Nothing is killed by process name.** The product's browser daemon is
  *deliberately* long-lived — it is adopted across CLI invocations and a
  signalled daemon can cost the user a signed-in session (measured; see
  ``rokan_mcp.browser``). A process dies here only when its command line
  points into an eval home whose owning run is dead — and an eval home is
  throwaway by construction.
* **Ownership is in the directory name.** Eval homes are now named
  ``rokan-eval-{pid}-…`` / ``rokan-eval-warm-{pid}-…``, so "is the run that
  made this still alive?" is one ``kill(pid, 0)`` rather than a guess.
  Legacy dirs without a pid can only come from code before this change, so
  age alone decides for them — with a two-hour grace in case an old
  checkout is mid-run on the same machine.
"""

from __future__ import annotations

import contextlib
import os
import re
import shutil
import signal
import subprocess
import tempfile
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

#: A dir (or a path in a process's argv) that an eval run owns. The pid is
#: the run's, captured at naming time; ``warm`` shares the group so one
#: pattern serves both modes.
_EVAL_DIR = re.compile(r"rokan-eval-(?:warm-)?(\d+)-")
_LEGACY_DIR = re.compile(r"rokan-eval-(?:warm-)?(?!\d+-)")

#: How old a LEGACY-format dir must be before it is presumed dead. New-format
#: dirs never wait: their owner pid answers immediately.
LEGACY_AGE_SECONDS = 2 * 60 * 60

#: What counts as browser weight in the memory report. Matching here only
#: REPORTS — it never kills (see module docstring for why).
_BROWSER_MARKS = (
    "ms-playwright",
    "chrome-headless",
    "headless_shell",
    "rokan_mcp/_daemon.py",
    "rokan_browser_daemon",
)


@dataclass(frozen=True)
class Proc:
    pid: int
    rss_kb: int
    command: str


def eval_home_prefix(warm: bool = False) -> str:
    """The tempdir prefix that makes this run's homes attributable to it."""
    kind = "rokan-eval-warm-" if warm else "rokan-eval-"
    return f"{kind}{os.getpid()}-"


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # Not ours to signal — but somebody's, so alive.
        return True
    return True


def owner_is_dead(name: str, mtime: float, now: float) -> bool:
    """Whether the run that made an eval dir (by basename) is gone.

    New format: the embedded pid decides. Legacy format: age decides, with
    the grace window. Anything that is not an eval dir at all is never
    stale — this function is the only guard between the sweep and
    somebody else's files, so it fails closed.
    """
    match = _EVAL_DIR.search(name)
    if match:
        # No self-pid special case: the running process's own pid is alive
        # by definition, so the liveness check already covers it (a mutant
        # proved an explicit clause here untestable — dead code).
        return not _pid_alive(int(match.group(1)))
    if _LEGACY_DIR.search(name):
        return (now - mtime) > LEGACY_AGE_SECONDS
    return False


def _processes() -> list[Proc]:
    """Every process, via ``ps`` — portable across the two dev machines
    (macOS laptop, WSL2), unlike /proc."""
    try:
        out = subprocess.run(
            ["ps", "-eo", "pid=,rss=,args="],
            capture_output=True,
            text=True,
            timeout=10,
            check=True,
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    procs: list[Proc] = []
    for line in out.splitlines():
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        try:
            procs.append(Proc(pid=int(parts[0]), rss_kb=int(parts[1]), command=parts[2]))
        except ValueError:
            continue
    return procs


def browser_processes(procs: list[Proc] | None = None) -> list[Proc]:
    found = _processes() if procs is None else procs
    return [p for p in found if any(mark in p.command for mark in _BROWSER_MARKS)]


def orphan_processes(procs: list[Proc]) -> list[Proc]:
    """Processes whose argv points into an eval home with a dead owner.

    The dir itself may already be deleted — a killed run's Chromium keeps
    running against unlinked files (H12 found exactly this) — so the
    verdict comes from the PATH STRING in the command line, not from disk.

    A kill needs PROVABLE ownership: an embedded pid that is dead. Nothing
    else qualifies. The first version also killed on legacy-shaped
    references whose dir was missing — and its own smoke test SIGTERM'd
    the developer's shell, because the shell's argv held the eval path as
    unexpanded text (``rokan-eval-${DEAD}-``: legacy-shaped, unstattable).
    Legacy DIRS still age out in ``stale_eval_dirs``; a process that merely
    mentions one is left alone.
    """
    orphans: list[Proc] = []
    for proc in procs:
        if proc.pid == os.getpid():
            continue
        for token in re.findall(r"\S*rokan-eval-\S*", proc.command):
            if "/" not in token:
                # A bare mention is not a home: `grep rokan-eval-123-` in
                # someone's terminal must not get that terminal killed.
                continue
            match = _EVAL_DIR.search(token)
            if match and not _pid_alive(int(match.group(1))):
                orphans.append(proc)
                break
    return orphans


def _kill(procs: list[Proc]) -> None:
    for proc in procs:
        if proc.pid <= 1:
            continue
        with contextlib.suppress(OSError):
            os.kill(proc.pid, signal.SIGTERM)
    deadline = time.time() + 3.0
    remaining = [p for p in procs if p.pid > 1]
    while remaining and time.time() < deadline:
        time.sleep(0.1)
        remaining = [p for p in remaining if _pid_alive(p.pid)]
    for proc in remaining:
        with contextlib.suppress(OSError):
            os.kill(proc.pid, signal.SIGKILL)


def stale_eval_dirs(tmp_root: Path | None = None, now: float | None = None) -> list[Path]:
    root = Path(tempfile.gettempdir()) if tmp_root is None else tmp_root
    clock = time.time() if now is None else now
    stale: list[Path] = []
    try:
        entries = list(root.iterdir())
    except OSError:
        return []
    for entry in entries:
        try:
            if entry.is_dir() and owner_is_dead(entry.name, entry.stat().st_mtime, clock):
                stale.append(entry)
        except OSError:
            continue
    return stale


def sweep(
    tmp_root: Path | None = None,
    out: Callable[[str], None] = print,
) -> tuple[list[Proc], list[Path]]:
    """Kill orphaned eval-run processes, then delete stale eval homes.

    In that order: rmtree first would leave the orphans referencing nothing
    and still eating memory, which is the H12 failure mode itself. Prints
    every action — a sweep that finds a mess should be visible in the run
    log, because it means a previous run was killed uncleanly. Quiet (and
    one listdir cheap) when there is nothing to do, which is every healthy
    start and every unit test.
    """
    stale = stale_eval_dirs(tmp_root)
    orphans = orphan_processes(_processes()) if stale or tmp_root is None else []
    if not stale and not orphans:
        return [], []
    for proc in orphans:
        out(f"  hygiene: killing orphan of a dead eval run — pid {proc.pid} "
            f"({proc.rss_kb // 1024} MB) {proc.command[:80]}")
    _kill(orphans)
    removed: list[Path] = []
    for path in stale:
        try:
            shutil.rmtree(path)
            removed.append(path)
        except OSError as exc:
            out(f"  hygiene: could not remove {path}: {exc}")
    if removed:
        out(f"  hygiene: removed {len(removed)} stale eval dir(s) left by killed runs")
    return orphans, removed


def memory_report(label: str, out: Callable[[str], None] = print) -> int:
    """One line: what browser-shaped processes weigh right now.

    Returned and printed in MB. Always prints, even at zero — §1b says log
    before AND after every run, and a silent "after" is indistinguishable
    from a forgotten one.
    """
    procs = browser_processes()
    total_mb = sum(p.rss_kb for p in procs) // 1024
    out(f"  browser memory {label}: {len(procs)} process(es) · {total_mb} MB")
    return total_mb


def die_cleanly_on_sigterm() -> None:
    """Make ``kill``/``pkill`` unwind like Ctrl-C instead of leaking.

    A SIGTERM'd Python exits without running ``with`` blocks, which is how
    every ``rokan-eval-*`` dir in the 30-hour pile got left behind. Raising
    SystemExit from the handler gives SIGTERM the same unwind SIGINT
    already has: contexts run, temp dirs delete, the browser is told to
    close. SIGKILL still can't be caught — that is what ``sweep`` on the
    NEXT start is for.
    """
    def _raise(signum: int, frame: object) -> None:
        raise SystemExit(128 + signum)

    with contextlib.suppress(ValueError, OSError):  # not the main thread
        signal.signal(signal.SIGTERM, _raise)
