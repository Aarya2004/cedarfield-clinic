"""The three speeds of one operation, and the rule that keeps them honest.

    first run     browser, model, ~6s     — an agent works it out
    remembered    browser, no model, ~60ms — the plan replays
    compiled      no browser at all, ~ms   — the endpoint answers

Each speed is earned by the one before it, and each is checked by the same
postcondition. That last part is the whole design: a fast answer is only
allowed to be *fast*, never allowed to be *trusted*. If the compiled endpoint
returns something the page would not have said, this module throws the
compiled form away and the slower path takes over — silently to the user,
loudly in the ledger.

**Why record during a run rather than a separate visit.** The traffic that
proves which endpoint fed the page is the traffic of the page load we are
already doing. Recording it costs nothing and, crucially, describes the same
instant as the text the verifier read — a second visit could land on a
different page and the overlap signal would be measuring two things.
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TypeVar
from urllib.parse import urlparse

from rokan_agent.core.proven import browser, vault
from rokan_mcp import recorder
from rokan_mcp.identify import RecordedSession
from rokan_mcp.recorder import RecordingError

from .compile_op import (
    CannotCompile,
    SyntheticOperation,
    agrees_with_page,
    compile_operation,
    read_live_value,
)

T = TypeVar("T")

#: A compiled call that takes longer than this is not worth the risk it
#: carries — the browser path is a few seconds and always correct.
log = logging.getLogger(__name__)

FAST_TIMEOUT_S = 8.0

#: Daemon answers that are positive evidence the SITE changed. Only these may
#: retire a compiled operation.
#:
#: The list is short, and deliberately a DENY-list rather than an allow-list of
#: our own faults. The first version had it the other way round and was wrong
#: in both directions at once: it named `unknown_command` (the daemon says
#: `unknown_cmd`), it named two errors this path cannot produce, and it named
#: none of `daemon_unreachable` / `daemon_crashed` / `timeout` / `bad_response`
#: — every machinery failure the client actually returns — so a daemon that
#: had self-reaped deleted the user's compiled operation and logged it as
#: drift.
#:
#: The asymmetry is the point. Keeping a stale shortcut costs a wasted round
#: trip, and the value check catches it before any answer is served. Deleting
#: a good one costs a thousandfold speedup, permanently and silently. So an
#: unrecognised error keeps the shortcut.
_SITE_MOVED = frozenset({"origin_moved"})


@dataclass(frozen=True, slots=True)
class FastResult:
    value: str
    elapsed_ms: int
    url: str


class FastPathRefused(RuntimeError):
    """The world changed: the endpoint moved, or stopped reporting this value.

    The compiled form is now wrong, and the caller both falls back AND throws
    the shortcut away.
    """


class FastPathUnavailable(RuntimeError):
    """Our machinery failed: no daemon, a wedged socket, a timeout.

    Distinct from :class:`FastPathRefused` because the two demand opposite
    responses and the first version conflated them. A compiled operation is
    earned once, over a real run; deleting it because a daemon was restarted
    would silently downgrade the user from milliseconds to seconds, forever,
    and log it as drift. The caller falls back for THIS run and keeps the
    shortcut for the next one.
    """


async def record_while(
    host: str, task_label: str, action: Callable[[], Awaitable[T]]
) -> tuple[T, RecordedSession | None]:
    """Run ``action`` with traffic recording on, returning (result, session).

    The recording is best-effort by design: a task that succeeds but whose
    traffic could not be captured is still a success — it simply does not get
    compiled this time.
    """
    try:
        session = await browser.session_for(vault.normalize_host(host))
    except Exception:  # noqa: BLE001 — no daemon means no recording, not a failure
        return await action(), None

    try:
        async with recorder.recording(
            session, host=host, task_label=task_label
        ) as sink:
            result = await action()
    except RecordingError:
        # `recording()` calls `record_start`, which raises on any non-ok
        # reply — including `unknown_cmd` from a daemon an older install left
        # running. The docstring above says recording is best-effort, and it
        # was not: `rokan-do "…"` exited 1 with `error: RecordingError` and
        # never attempted the task at all.
        return await action(), None
    recorded = sink[0] if sink else None
    return result, recorded


def try_compile(
    recorded: RecordedSession | None, anchor_line: str
) -> SyntheticOperation | None:
    """Compile if the traffic supports it; otherwise leave the loop as it is.

    Returns None rather than raising: not compiling is the normal case on
    server-rendered pages, and treating it as an error would make the common
    path look broken.
    """
    if recorded is None or not recorded.responses:
        return None
    if recorded.dropped:
        # A truncated recording is a partial view of the page load, and the
        # identifier's signal is exactly "which response covers the screen".
        # Scoring a partial view would answer a different question.
        return None
    try:
        return compile_operation(recorded, anchor_line=anchor_line)
    except CannotCompile:
        return None


async def session_get(host: str, url: str) -> tuple[int, str]:
    """One credentialed GET inside the user's session — (status, body).

    The same daemon primitive `run_fast` uses (`session_fetch`, a narrow
    fetch-and-return, NOT an arbitrary evaluate), exposed so the
    source-hint compiler can probe a candidate before it is stored.

    **The same-site check happens HERE, client side.** `session_fetch`
    derives its origin guard from the URL it is handed, so handing it an
    arbitrary URL makes that guard a tautology — and past it the daemon
    navigates the browser holding every live session to that URL's root
    with `credentials: 'include'`. `run_fast` has always compared the
    URL's host against its operation's own site before sending; this
    mirrors it (security review, 2026-08-26).

    Any failure comes back as (0, "") — a probe that cannot run is a
    candidate that does not compile, never an error that aborts a task
    that already succeeded.
    """
    expected_host = urlparse(url).netloc.lower()
    site_host = vault.normalize_host(host).lower()
    if expected_host.split(":")[0].removeprefix("www.") != site_host.removeprefix("www."):
        return 0, ""
    try:
        session = await browser.session_for(vault.normalize_host(host))
        reply = await asyncio.wait_for(
            session.send("session_fetch", {"url": url, "expect_host": expected_host}),
            timeout=FAST_TIMEOUT_S,
        )
    except Exception as exc:  # noqa: BLE001 — a probe that cannot run does not compile
        # Said out loud: a wedged daemon and a site with no endpoint are
        # otherwise indistinguishable, silently and forever.
        log.debug("session_get(%s) failed: %s", url, type(exc).__name__)
        return 0, ""
    if not isinstance(reply, dict) or not reply.get("ok"):
        log.debug("session_get(%s) refused: %s", url, (reply or {}).get("error"))
        return 0, ""
    if reply.get("truncated"):
        # A body cut mid-document is not the document. Compiling from the
        # part that arrived would bind a value to a position the real
        # response does not have.
        log.debug("session_get(%s): body truncated, not usable", url)
        return 0, ""
    return int(reply.get("status", 0) or 0), str(reply.get("body", "") or "")


async def run_fast(operation: SyntheticOperation, host: str) -> FastResult:
    """Ask the endpoint directly, inside the user's own session.

    The call is made from the page context so the browser's cookies apply —
    no credential is copied out of the session, and nothing is stored. A
    response that does not agree with what the page said is refused here.
    """
    # The operation's own host, WITH its port: an origin comparison is not a
    # credential lookup. `vault.normalize_host` strips the port because one
    # login serves a site regardless of port; an origin check cannot.
    expected_host = urlparse(operation.url).netloc.lower()
    site_host = urlparse(operation.page_url or operation.url).netloc.lower()
    if expected_host.removeprefix("www.") != site_host.removeprefix("www."):
        # A compiled operation may only ever call its own site. This is the
        # second of two checks on purpose: compile refuses off-host
        # candidates, and replay refuses them again in case a stored row was
        # written by an older build or edited on disk.
        raise FastPathRefused("this operation points at a different site")

    started = time.monotonic()
    # `session_for` keys on the NORMALISED host — the same key `login.fetch`
    # uses. Passing a full URL here silently opens a DIFFERENT profile with
    # no cookies, and the fast path comes back with the sign-in page. Measured
    # the hard way.
    async def ask() -> object:
        session = await browser.session_for(vault.normalize_host(host))
        return await session.send(
            "session_fetch",
            # The host is stated by the CALLER, from the operation's own
            # site — so the daemon can refuse a mismatch before navigating
            # a browser full of live sessions anywhere.
            {"url": operation.url, "expect_host": expected_host},
        )

    try:
        # The budget covers getting a session as well as using one. Timing
        # only the send would leave the expensive half unbounded: on a cold
        # machine `session_for` spawns the daemon and can wait 30s before the
        # send it was supposed to be racing has even started.
        reply = await asyncio.wait_for(ask(), timeout=FAST_TIMEOUT_S)
    except TimeoutError:
        # The point of this path is milliseconds. Past the timeout the browser
        # path would already have answered, correctly — so stop waiting and
        # let it. Without this the constant below was decorative and a wedged
        # socket hung the command indefinitely.
        raise FastPathUnavailable(
            f"the endpoint did not answer within {FAST_TIMEOUT_S:.0f}s"
        ) from None
    except Exception as exc:  # noqa: BLE001 — our side broke, not the site's
        raise FastPathUnavailable(f"the fast path could not run: {exc}") from None

    if not isinstance(reply, dict) or not reply.get("ok"):
        detail = (
            (reply or {}).get("error", "no answer")
            if isinstance(reply, dict)
            else "no answer"
        )
        if detail in _SITE_MOVED:
            raise FastPathRefused(f"the site moved ({detail})")
        # Everything else — ours, transient, or unrecognised — keeps the
        # shortcut. See _SITE_MOVED for why the default runs this way.
        raise FastPathUnavailable(f"the fast path could not run ({detail})")
    status = int(reply.get("status", 0) or 0)
    body = str(reply.get("body", "") or "")
    if status in (401, 403):
        raise FastPathRefused("the session no longer authorises this endpoint")
    if status >= 400 or not body:
        raise FastPathRefused(f"the endpoint answered {status}")
    if not agrees_with_page(operation, body):
        # The endpoint still exists but no longer reports this quantity.
        # That is drift, and drift must never be served fast.
        raise FastPathRefused("the endpoint no longer carries this value")

    # THE value, as the endpoint reports it NOW. Returning the compiled
    # anchor instead would make this a cache with no expiry — instant,
    # confident, and possibly last week's. Measured before this line
    # existed: a body reporting 99 was served as "42".
    live = read_live_value(operation, body)
    if live is None:
        raise FastPathRefused("the value could not be re-read from the endpoint")

    elapsed = int((time.monotonic() - started) * 1000)
    return FastResult(value=live, elapsed_ms=elapsed, url=operation.url)
