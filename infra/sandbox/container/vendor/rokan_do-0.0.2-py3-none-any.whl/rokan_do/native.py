"""Tier 0 — consume a site's OWN WebMCP tools, never the DOM.

`rokan do` prefers a site's declared WebMCP tools when it ships them: the
daemon lists them over the CDP WebMCP domain (`webmcp_list`) and invokes one
(`webmcp_invoke`); this module owns the read/write policy, the record a
remembered native operation carries, and the 0-model-call replay. Selecting
which tool + input answers a *new* question (one model call, planner-driven)
is wired into ``service.perform`` (`_try_native`/`select_native`/`_native_replay`);
this module owns the policy and the record, never planning on its own.

See ~/dev/webmcp-private/docs/EXECUTION-PLAN.md §1 and
docs/measurements/2026-08-29-tier0.md. Contract with the daemon:
- ``webmcp_list {url}``   -> {ok, url, tools:[{name,description,inputSchema,annotations}], count}
- ``webmcp_invoke {url,tool,input}`` -> {ok, status, output, elapsed_ms}
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

#: Names beginning with these read verbs are treated as safe reads even when the
#: site sets no `readOnlyHint` (measured: Shopify annotates none of its 10).
_SAFE_READ_VERBS = frozenset(
    {
        "search",
        "get",
        "list",
        "browse",
        "show",
        "read",
        "find",
        "lookup",
        "check",
        "view",
        "fetch",
        "query",
        "count",
    }
)

#: A write verb appearing as ANY name segment forces write-class even when the
#: name begins with a read verb. On the `rokan do` native path there is no human
#: Enter, so this name gate is the last line of defence (a prefix-only check let
#: `get_and_delete_cart` / `search_and_buy` through — reviewer P1). Ambiguous
#: words (order, address) are deliberately excluded to avoid denying real reads.
_WRITE_SEGMENTS = frozenset(
    {
        "update", "delete", "remove", "cancel", "add", "create", "submit",
        "place", "buy", "purchase", "pay", "checkout", "manage", "put", "post",
        "send", "book", "reserve", "apply", "confirm", "edit", "modify",
        "destroy", "drop", "upload", "register", "subscribe", "unsubscribe",
        "change", "save", "write", "set", "login", "logout", "signin",
        "signout", "signup", "clear", "reset", "approve", "reject", "enroll",
    }
)

#: Unambiguous write substrings caught even without a segment boundary
#: (`check_out` → "checkout"). Kept tiny so no real read tool matches.
_WRITE_SUBSTRINGS = ("checkout", "purchase", "payment")


def _name_segments(name: str) -> list[str]:
    """Split a tool name into lowercase words on `_` and camelCase boundaries."""
    import re  # noqa: PLC0415

    return [s for s in re.split(r"[_\s]+|(?<=[a-z])(?=[A-Z])", name) if s]


def _is_write_name(name: str) -> bool:
    lower = name.lower()
    if any(seg.lower() in _WRITE_SEGMENTS for seg in _name_segments(name)):
        return True
    flat = lower.replace("_", "")
    return any(sub in flat for sub in _WRITE_SUBSTRINGS)

#: Native tool output is untrusted content — capped like every buffer that
#: leaves the tab (PLAN §4 / COMPOSE §6; matches the terminal's 1.5 K budget).
_OUTPUT_BUDGET = 1500


@dataclass(frozen=True, slots=True)
class NativeTool:
    """One tool a site declared over WebMCP."""

    name: str
    description: str
    input_schema: dict[str, Any]
    annotations: dict[str, Any]

    @property
    def annotated_read(self) -> bool:
        a = self.annotations or {}
        return bool(a.get("readOnlyHint") or a.get("readOnly"))

    @property
    def consequential(self) -> bool:
        a = self.annotations or {}
        return bool(a.get("consequential") or a.get("destructiveHint"))

    @property
    def auto_invokable(self) -> bool:
        """May the planner select this tool automatically (a read), or must a
        human approve it as a write step?

        WebMCP annotations are hints and MOST sites (Shopify included, measured
        2026-08-29) do not set `readOnlyHint`, so the annotation alone cannot
        gate. Rule: auto-invokable iff it is annotated read OR its name begins
        with a safe read verb — and NEVER if it is annotated consequential. A
        write-class tool (`update_cart`, `proceed_to_checkout`, `cancel_cart`,
        `manage_orders`) is never auto-selected; forged as a step it is
        CONSEQUENTIAL and runs only on the human's Enter. This is belt-and-
        braces: the terminal's keypress gates every step regardless.
        """
        if self.consequential or _is_write_name(self.name):
            return False
        if self.annotated_read:
            return True
        head = _name_segments(self.name)[0].lower() if _name_segments(self.name) else ""
        return head in _SAFE_READ_VERBS


@dataclass(frozen=True, slots=True)
class NativeOp:
    """A remembered native operation: which tool on which site, with the input
    template that answered the question. Replays at zero model calls. Stored as
    the ``operation`` row's compiled/plan blob with ``kind="native"``.
    """

    site: str
    tool: str
    input: dict[str, Any]
    #: Hash of the tool's inputSchema at learn time; a changed schema forces a
    #: re-select rather than a blind replay (tool-framing defence, arXiv 2606.06387).
    schema_hash: str

    def to_json(self) -> str:
        return json.dumps(
            {
                "kind": "native",
                "site": self.site,
                "tool": self.tool,
                "input": self.input,
                "schema_hash": self.schema_hash,
            },
            sort_keys=True,
        )

    @staticmethod
    def from_json(blob: str) -> NativeOp:
        d = json.loads(blob)
        if not isinstance(d, dict) or d.get("kind") != "native":
            raise ValueError("not a native op")
        tool_input = d.get("input")
        if not isinstance(tool_input, dict):
            raise ValueError("native op input must be an object")
        try:
            return NativeOp(
                site=str(d["site"]),
                tool=str(d["tool"]),
                input=tool_input,
                schema_hash=str(d["schema_hash"]),
            )
        except KeyError as exc:  # a hand-edited row missing a field
            raise ValueError(f"native op missing {exc}") from exc


def is_native_blob(blob: str) -> bool:
    """True when a stored blob is a native op. Called by `_native_replay` on a
    `native_op` row before `NativeOp.from_json`; must NEVER raise on a
    hand-edited or non-object row (reviewer: ``[]``/``null``/``1``/``"x"`` all
    parse but have no ``.get``). (Native blobs never reach the SyntheticOperation
    fast paths — they live in a separate table — so this is a belt-and-braces
    guard, not the isolation mechanism.)"""
    if not blob:
        return False
    try:
        parsed = json.loads(blob)
    except Exception:  # noqa: BLE001 — a row that will not parse is simply not native
        return False
    return isinstance(parsed, dict) and parsed.get("kind") == "native"


def schema_hash(schema: dict[str, Any] | None) -> str:
    import hashlib

    canonical = json.dumps(schema or {}, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode()).hexdigest()[:16]


# --------------------------------------------------------------------------
# Daemon-facing calls. The seam these use (`browser.session_for`) is the same
# one `executor._act` uses; tests replace it.
# --------------------------------------------------------------------------


async def _session(site: str) -> Any:
    from rokan_agent.core.proven import browser, vault  # noqa: PLC0415

    return await browser.session_for(vault.normalize_host(site))


async def list_tools(site: str, url: str) -> list[NativeTool]:
    """The site's declared WebMCP tools, or [] when it ships none / the browser
    cannot reach it. Never raises for a site that simply has no tools."""
    try:
        session = await _session(site)
        reply = await session.send("webmcp_list", {"url": url})
    except Exception:  # noqa: BLE001 — an unreachable daemon is "no native tools", not a crash
        return []
    if not isinstance(reply, dict) or not reply.get("ok"):
        return []
    out: list[NativeTool] = []
    for t in reply.get("tools") or []:
        name = t.get("name")
        if not name:
            continue
        out.append(
            NativeTool(
                name=name,
                description=str(t.get("description") or ""),
                input_schema=t.get("inputSchema") or {},
                annotations=t.get("annotations") or {},
            )
        )
    return out


@dataclass(frozen=True, slots=True)
class NativeResult:
    ok: bool
    value: str
    is_error: bool
    elapsed_ms: int
    raw: Any = None


def _flatten_output(output: Any) -> tuple[str, bool]:
    """Reduce a WebMCP tool result to (text, is_error). WebMCP tools answer in
    MCP shape: {content:[{type:'text', text}], structuredContent?, isError?}."""
    if isinstance(output, dict):
        is_error = bool(output.get("isError"))
        parts = output.get("content")
        if isinstance(parts, list):
            texts = [
                str(p.get("text"))
                for p in parts
                if isinstance(p, dict) and p.get("type") == "text" and p.get("text")
            ]
            if texts:
                return "\n".join(texts), is_error
        sc = output.get("structuredContent")
        if sc is not None:
            return json.dumps(sc), is_error
        return json.dumps(output), is_error
    return str(output), False


def _clean_output(text: str) -> str:
    """Native output is untrusted content: redact secrets through the same choke
    point as everything that leaves the tab, then cap to the output budget."""
    from rokan_do.redact import redact  # noqa: PLC0415 — deferred to avoid an import cycle

    redacted = redact(text)
    if len(redacted) > _OUTPUT_BUDGET:
        redacted = redacted[:_OUTPUT_BUDGET] + "…[truncated]"
    return redacted


def _refused(reason: str) -> NativeResult:
    return NativeResult(ok=False, value="", is_error=True, elapsed_ms=0, raw={"refused": reason})


async def invoke(
    site: str,
    url: str,
    tool: str,
    tool_input: dict[str, Any],
    *,
    require_read: bool = True,
    tool_meta: NativeTool | None = None,
) -> NativeResult:
    """Invoke one native tool, its output redacted and capped. By default only a
    READ-class tool is allowed (`require_read`); a caller confirming a write step
    (the human's Enter) passes `require_read=False`. `tool_meta`, when given,
    is checked against the read/write policy before anything is sent — a caller
    that forgets it and asks for `require_read` on an unknown tool is refused.

    A tool answering with an error body is `ok=False, is_error=True` (a
    `Completed` CDP status with an `isError` payload is still a failure)."""
    if require_read:
        if tool_meta is None:
            return _refused("read policy requires tool metadata")
        if not tool_meta.auto_invokable:
            return _refused(f"{tool} is not a read-class tool; needs human approval")
    try:
        session = await _session(site)
        reply = await session.send(
            "webmcp_invoke", {"url": url, "tool": tool, "input": tool_input}
        )
    except Exception:  # noqa: BLE001
        return NativeResult(ok=False, value="", is_error=True, elapsed_ms=0)
    if not isinstance(reply, dict):
        return NativeResult(ok=False, value="", is_error=True, elapsed_ms=0)
    elapsed = int(reply.get("elapsed_ms") or 0)
    if not reply.get("ok") or reply.get("status") != "Completed":
        return NativeResult(ok=False, value="", is_error=True, elapsed_ms=elapsed, raw=reply)
    text, is_error = _flatten_output(reply.get("output"))
    return NativeResult(
        ok=not is_error and bool(text.strip()),
        value=_clean_output(text),
        is_error=is_error,
        elapsed_ms=elapsed,
        raw=reply.get("output"),
    )


async def replay(op: NativeOp, url: str, tool_meta: NativeTool) -> NativeResult:
    """Re-run a remembered native op at ZERO model calls — but only if the tool's
    inputSchema still hashes to what it did at learn time. A changed schema means
    the site's contract moved under us; refuse and force a re-select rather than
    replay a stale shape blind (tool-framing defence, arXiv 2606.06387)."""
    if schema_hash(tool_meta.input_schema) != op.schema_hash:
        return _refused("tool schema changed since learn — re-select required")
    # A remembered op is a read by construction (writes are never auto-learned),
    # but re-check the live annotations in case the site changed the tool.
    return await invoke(
        op.site, url, op.tool, op.input, require_read=True, tool_meta=tool_meta
    )


# --------------------------------------------------------------------------
# select_native — the ONE model call that picks a read tool and fills its
# input schema from the question. DOM is never read; only the tool list +
# schemas go to the model. Injectable (`_ask`) so tests never call a model.
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class NativeSelection:
    tool: NativeTool
    input: dict[str, Any]


def _selection_prompt(said: str, candidates: list[NativeTool]) -> str:
    example = (
        'schema {required:[catalog], catalog:{required:[query]}} and question '
        '"wool runners" produces input {"catalog": {"query": "wool runners"}}'
    )
    lines = [
        "You are given a website's own tools and their JSON input schemas. Pick the "
        "ONE tool that answers the question, then build `input` as a COMPLETE, VALID "
        "instance of that tool's inputSchema:",
        "- fill EVERY required field with a value taken from the question;",
        "- respect nesting exactly: if a required field is an object, return the "
        f"nested object (e.g. {example});",
        "- never return an empty input object when the schema has required fields.",
        "If no tool fits, return an empty tool name and empty input.",
        f"\nQuestion: {said}\n\nTools:",
    ]
    for t in candidates:
        lines.append(f"- {t.name}: {t.description}")
        lines.append(f"  inputSchema: {json.dumps(t.input_schema)}")
    return "\n".join(lines)


async def _ask(said: str, candidates: list[NativeTool]) -> tuple[str, dict[str, Any]]:
    """One structured model call → (tool_name, input). Reuses the planner's
    Anthropic client + timeout. Raises on an unavailable/refusing model so the
    caller falls through to the normal ladder rather than pretending."""
    import asyncio  # noqa: PLC0415

    from pydantic import BaseModel  # noqa: PLC0415

    from rokan_do.planner import LADDER, PLAN_TIMEOUT_S, _client  # noqa: PLC0415

    class _Sel(BaseModel):
        tool: str
        # A JSON object literal for the tool's input. A STRING (not a dict) on
        # purpose: a free-form dict field lets structured output return `{}` as
        # valid and the model never fills the nested schema; a string forces it
        # to actually write the JSON, which we parse and validate below.
        input_json: str

    client: Any = _client()
    prompt = _selection_prompt(said, candidates)

    def _call() -> Any:
        return client.messages.parse(
            model=LADDER[0],
            max_tokens=512,
            system=[
                {"type": "text", "text": "You choose a website's own tool to answer a question."}
            ],
            messages=[{"role": "user", "content": prompt}],
            output_format=_Sel,
            extra_body={"temperature": 0},
        )

    resp = await asyncio.wait_for(asyncio.to_thread(_call), timeout=PLAN_TIMEOUT_S)
    parsed = resp.parsed_output
    if parsed is None:  # model returned nothing parsable → fall through to the ladder
        return "", {}
    raw = (parsed.input_json or "").strip()
    try:
        tool_input = json.loads(raw) if raw else {}
    except (ValueError, TypeError):
        tool_input = {}
    if not isinstance(tool_input, dict):
        tool_input = {}
    return str(parsed.tool or ""), tool_input


async def select_native(
    said: str,
    tools: list[NativeTool],
    *,
    ask: Any = None,
) -> NativeSelection | None:
    """Choose a READ-class native tool and its input for `said` (one model call).
    Only read tools are offered — a write is never auto-selected. Returns None
    when no read tool fits, so the caller falls through to the normal ladder."""
    candidates = [t for t in tools if t.auto_invokable]
    if not candidates:
        return None
    asker = ask or _ask
    name, tool_input = await asker(said, candidates)
    chosen = next((t for t in candidates if t.name == name), None)
    if chosen is None or not isinstance(tool_input, dict):
        return None
    return NativeSelection(tool=chosen, input=tool_input)
