"""Where a page repeats itself, read out of its HTML.

A list on a page is a set of siblings that share a shape: table rows,
result cards, nav items. Knowing where those groups are is what lets a
list be read as *one cell per row* instead of "the lines after the
heading until a blank line" — punctuation standing in for structure.

The browser computes this from the live DOM (`_COLLECTIONS_JS` in the
daemon). This module computes the same thing from fetched HTML, so the
fast HTTP path is not the blind one. Measured on news.ycombinator.com
(2026-08-27): the page is served over HTTP in 400ms and never touches a
browser, so without this the fastest transport was the only one that
could not read a list.

Stdlib only, bounded everywhere, and never raises: a fence is an
optimisation and a shape check, never a gate. A page this cannot parse
comes back as no groups at all and the reader falls back to what it did
before.
"""

from __future__ import annotations

from html.parser import HTMLParser

#: Elements that hold no reader-visible text.
#: `httpread._DROP_ELEMENTS` drops these wholesale, so their text is not
#: part of the page and must not be part of a row. `iframe` was missing:
#: a fallback string inside one became a cell that no page line contains.
_INVISIBLE = frozenset(
    {"script", "style", "noscript", "template", "svg", "head", "iframe"}
)
#: Elements that never wrap anything.
_VOID = frozenset(
    {
        "area",
        "base",
        "br",
        "col",
        "embed",
        "hr",
        "img",
        "input",
        "link",
        "meta",
        "param",
        "source",
        "track",
        "wbr",
    }
)
MAX_GROUPS = 60
MAX_UNITS = 200
MAX_CELLS = 12
MIN_UNITS = 3
MAX_LINE = 300
#: A page far larger than this is a document dump, not a list page, and
#: walking it costs more than the fence is worth.
MAX_HTML = 4_000_000


#: A line ending inside a node's contents: a `<br>`, or a newline in the
#: source. Carried in `items` so `_cells` breaks exactly where `to_text`
#: does, rather than only at element boundaries.
_BREAK = "\n"


class _Node:
    """One element: its shape, and its contents IN DOCUMENT ORDER.

    Order is the whole point. HN writes a story's source as
    `<span> (<a>businessinsider.com</a>)</span>`, and a node that keeps
    its own text apart from its children renders that as "( ) …" while
    the page text says "( … )" — so the cell is not a line of the page
    and the list refuses. Text and children share one list.
    """

    __slots__ = ("tag", "shape", "items")

    def __init__(self, tag: str, shape: str) -> None:
        self.tag = tag
        self.shape = shape
        self.items: list[str | _Node] = []

    @property
    def kids(self) -> list[_Node]:
        return [i for i in self.items if isinstance(i, _Node)]


class _Tree(HTMLParser):
    """A tree of elements, their class/role shape, and their own text.

    Only what the fence needs: no attributes beyond class and role, no
    positions, no entity fidelity beyond what the parser gives free.
    """

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.root = _Node("#root", "#root")
        self._stack: list[_Node] = [self.root]
        self._muted = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in _INVISIBLE:
            self._muted += 1
            return
        if tag in _VOID:
            # `<br>` is the one tag in both _VOID and _BREAKS, and returning
            # here meant no node was ever made for it, so `n.tag in _BREAKS`
            # could not fire and the "literal mirror of `_BLOCK_END`" was one
            # element short from the start. `to_text` DOES break on it, and
            # it is the tag most likely to appear inside a row.
            if tag == "br" and not self._muted:
                self._stack[-1].items.append(_BREAK)
            return
        klass = ""
        role = ""
        for name, value in attrs:
            if name == "class" and value:
                klass = ".".join(sorted(value.split()))
            elif name == "role" and value:
                role = value
        node = _Node(tag, f"{tag}|{klass}|{role}")
        self._stack[-1].items.append(node)
        self._stack.append(node)

    # NOT handled, on purpose: implied end tags. `<li>One<li>Two` leaves
    # each item nested inside the previous one, so no group is found and
    # the reader falls back. That is the CONSISTENT answer rather than a
    # missing feature: `to_text` breaks on `</li>`, which such markup never
    # writes, so the whole list is one line of page text — and a fence
    # whose rows are not page lines could only produce a refusal or a wrong
    # match. Where the page has no lines to give, the fence has no rows.

    def handle_endtag(self, tag: str) -> None:
        if tag in _INVISIBLE:
            self._muted = max(0, self._muted - 1)
            return
        if tag in _VOID:
            return
        # Unbalanced markup is the norm, not the exception: close back to
        # the nearest matching open tag and no further, so one stray </div>
        # cannot unwind the whole document.
        for depth in range(len(self._stack) - 1, 0, -1):
            if self._stack[depth].tag == tag:
                del self._stack[depth:]
                return

    def handle_data(self, data: str) -> None:
        if self._muted:
            return
        # `to_text` collapses spaces and tabs but NOT newlines — its
        # `_INLINE_SPACE` deliberately excludes `\n`, so a source newline
        # inside a text node ends a line. `" ".join(data.split())` ate it,
        # and pretty-printed markup with a wrapped text node is most
        # server-rendered HTML, including the pages this module exists for.
        for index, piece in enumerate(data.split("\n")):
            if index:
                self._stack[-1].items.append(_BREAK)
            text = " ".join(piece.split())
            if text:
                self._stack[-1].items.append(text)


#: Exactly the tags `httpread.to_text` ends a line on. The fence's rows
#: must split into the SAME lines the page text did, or a row's cell is
#: not findable on the page and every list read over HTTP refuses. Kept
#: as a literal mirror of `_BLOCK_END` rather than "block-ish tags",
#: because approximately-the-same is a silent miss.
_BREAKS = frozenset(
    {
        "br",
        "p",
        "div",
        "li",
        "tr",
        "td",
        "th",
        "section",
        "article",
        "pre",
        "dt",
        "dd",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
    }
)


def _cells(node: _Node) -> list[str]:
    """One row's own text lines, in document order, capped.

    Inline runs stay on the line they belong to; a line ends where the
    page's text would end it.
    """
    out: list[str] = []
    buf: list[str] = []

    def flush() -> None:
        if buf:
            joined = " ".join(buf).strip()
            if joined:
                out.append(joined[:MAX_LINE])
            buf.clear()

    def walk(n: _Node) -> None:
        if len(out) >= MAX_CELLS:
            return
        for item in n.items:
            if item is _BREAK:
                flush()
                continue
            if isinstance(item, str):
                buf.append(item)
                continue
            walk(item)
            if len(out) >= MAX_CELLS:
                return
        if n.tag in _BREAKS:
            flush()

    walk(node)
    flush()
    return out[:MAX_CELLS]


def groups(html: str) -> list[list[list[str]]]:
    """Every repeat-group in the page: groups of rows of cells.

    Never raises. An unparseable page, or one with nothing that repeats,
    is an empty list and the caller falls back.
    """
    if not html or len(html) > MAX_HTML:
        return []
    tree = _Tree()
    try:
        tree.feed(html)
        tree.close()
    except Exception:  # noqa: BLE001 — malformed markup must not end a run
        pass
    found: list[list[list[str]]] = []
    stack = [tree.root]
    while stack and len(found) < MAX_GROUPS:
        node = stack.pop()
        stack.extend(node.kids)
        if len(node.kids) < MIN_UNITS:
            continue
        by_shape: dict[str, list[_Node]] = {}
        for kid in node.kids:
            by_shape.setdefault(kid.shape, []).append(kid)
        for siblings in by_shape.values():
            if len(siblings) < MIN_UNITS or len(found) >= MAX_GROUPS:
                continue
            units = [c for c in (_cells(s) for s in siblings[:MAX_UNITS]) if c]
            if len(units) >= MIN_UNITS:
                found.append(units)
    return found
