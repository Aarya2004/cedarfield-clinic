"""`rokan-do recheck` — the instrument for the number nobody has published.

The structural half-life `h` of a learned operation is the binding number
of the whole theory (`docs/DERIVATION-2026-08-24.md`, E1): how long does a
verified, anchored program keep working against a site that does not know
it exists? No paper measures it. Measuring it needs two things this module
provides — a way to try every remembered operation on a schedule, and the
append-only `op_use` ledger those tries are written to.

What a recheck IS: each live operation is asked again, with the question it
was learned from, through the same `service.perform` the product uses — so
the compiled path and the replayed path are exercised exactly as a user
would exercise them — with planning FORBIDDEN. Nothing leaves the machine:
no discovery, no model. An operation that no longer replays is retired by
the ordinary drift rule and its death is a row in the ledger, which is the
data point. A run our own daemon could not make is a row with no verdict,
which is not.

Sequential by construction: one browser job at a time is the rule that
kept this laptop alive.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from .accept import TaskRequest
from .memory import Memory, Remembered, Use, _host, _host_matches
from .service import Performed, perform

#: The `perform` seam, so a test can watch what recheck asks for.
PerformFn = Callable[..., Awaitable[Performed]]


@dataclass(frozen=True, slots=True)
class Rechecked:
    """One operation's recheck, read back from the ledger rows it wrote."""

    key: str
    host: str
    reads: str
    #: The last speed that produced a verdict, or "" when none did.
    path: str
    #: True alive · False dead (retired this run) · None no verdict.
    ok: bool | None
    verdict: str
    latency_ms: int


@dataclass(slots=True)
class RecheckReport:
    checked: list[Rechecked] = field(default_factory=list)
    #: (key, reads, why) for operations that could not be rechecked at all.
    skipped: list[tuple[str, str, str]] = field(default_factory=list)

    @property
    def alive(self) -> int:
        return sum(1 for r in self.checked if r.ok is True)

    @property
    def dead(self) -> int:
        return sum(1 for r in self.checked if r.ok is False)

    @property
    def no_verdict(self) -> int:
        return sum(1 for r in self.checked if r.ok is None)


def _reads(op: Remembered) -> str:
    return " · ".join(
        str(step.args.get("contains", ""))
        for step in op.plan.steps
        if step.verb.value == "read_value"
    )


def _learned_question(op: Remembered) -> str:
    """The most recent phrasing this operation was learned from.

    Newest wins (`memory.remember` keeps the last dozen, newest last), so a
    recheck asks the question the way it was most recently asked."""
    lines = [line.strip() for line in op.learned_said.splitlines() if line.strip()]
    return lines[-1] if lines else ""


def _verdict_from(rows: list[Use]) -> Rechecked | None:
    """The recheck's outcome is what the ledger says happened, not what the
    result object claims — the ledger is the record the half-life is
    computed from, so the report must agree with it by construction."""
    if not rows:
        return None
    # The LAST row, chronologically — not the last decided one. A compiled
    # endpoint that stopped agreeing with the page (ok=0) followed by a
    # browser replay our daemon could not make (ok NULL) is an operation
    # whose fate is unknown this run, not a dead one: the browser plan is
    # what the operation IS, and it was never tried.
    last = rows[-1]
    return Rechecked(
        key=last.op_key,
        host="",
        reads="",
        path=last.path,
        ok=last.ok,
        verdict=last.verdict,
        latency_ms=last.latency_ms,
    )


async def recheck(
    memory: Memory,
    *,
    site: str = "",
    perform_fn: PerformFn = perform,
) -> RecheckReport:
    """Try every live operation (on ``site``, or all), planning forbidden.

    Returns what the ledger recorded for each. Writes the "could not even be
    recalled" case itself — a matcher that no longer recognises its own
    learned question is OUR defect, not the site's, and it must be a
    no-verdict row rather than silence.
    """
    report = RecheckReport()
    wanted = _host(site) if site else ""
    for op in memory.library():
        host = _host(op.plan.site)
        if wanted and not _host_matches(host, wanted):
            continue
        reads = _reads(op)
        said = _learned_question(op)
        if not said:
            report.skipped.append((op.key, reads, "no learned question to ask"))
            continue
        if op.plan.verify == "key_used":
            # A credential operation is proven by SPENDING the key against a
            # probe endpoint, which recheck does not have. Without it the
            # verifier abstains every time: a full browser login, a nightly
            # credential re-submission, and a guaranteed zero-information
            # row (Opus review, F6). Say so instead.
            report.skipped.append((op.key, reads, "credential class: needs --probe"))
            continue
        before = len(memory.uses(op.key))
        task = TaskRequest(task_class=op.plan.task_class, site=op.plan.site, slots={}, said=said)
        kwargs: dict[str, Any] = {"memory": memory, "replay_only": True}
        performed = await perform_fn(task, **kwargs)
        if performed.key and performed.key != op.key:
            # `recall` answered the learned question with a DIFFERENT
            # operation on the same host — so the rows this run wrote belong
            # to that one, and THIS operation was never tried. Attributing
            # by row-count delta here double-counted the other op's survival
            # and recorded this one as a matcher failure, into a table that
            # cannot be corrected (Opus review, B1, probe-proven). Our
            # matcher, not the site: a no-verdict row, and no speed.
            memory.record_use(op.key, path="", ok=None, verdict="recalled_other")
        rows = memory.uses(op.key)[before:]
        if not rows:
            # Nothing replayed, so no speed is named (the same rule
            # `service.perform` states for its own empty path).
            memory.record_use(op.key, path="", ok=None, verdict="not_recalled")
            rows = memory.uses(op.key)[before:]
        outcome = _verdict_from(rows)
        assert outcome is not None  # a row was just written
        report.checked.append(
            Rechecked(
                key=op.key,
                host=host,
                reads=reads,
                path=outcome.path,
                ok=outcome.ok,
                verdict=outcome.verdict,
                latency_ms=outcome.latency_ms,
            )
        )
    return report


def render(report: RecheckReport) -> list[str]:
    """Lines for the terminal. Counts first, then every operation."""
    lines: list[str] = []
    if not report.checked and not report.skipped:
        lines.append("nothing learned yet — nothing to recheck")
        return lines
    for r in report.checked:
        mark = {True: "alive", False: "DEAD ", None: "  ?  "}[r.ok]
        speed = f"{r.path} {r.latency_ms} ms" if r.path else "no speed answered"
        lines.append(f"  {mark}  {r.host:28s} {r.reads[:40]:40s} {speed} · {r.verdict}")
    for key, reads, why in report.skipped:
        lines.append(f"  skip   {key:28s} {reads[:40]:40s} {why}")
    lines.append("")
    lines.append(
        f"  {report.alive} alive · {report.dead} dead · {report.no_verdict} no verdict"
        f" · {len(report.skipped)} skipped — every try is a row in op_use"
    )
    return lines
