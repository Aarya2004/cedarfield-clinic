"""Proof, not a story.

Every other stage of the loop can be fooled. The planner can misread a page,
the executor can land somewhere plausible, and a model asked "did that work?"
will say yes at a rate the literature measures and nobody should rely on
(under 60% paired accuracy on the abstention benchmarks; LLM judges never
exceeded 70% precision). So the last word belongs to a deterministic check
that does not care what anything else believed.

The two v1 verifiers, and why they are honest:

* ``key_used`` — an API key is proven by **spending it**. We send an
  authenticated request to the service and require a non-auth response. A key
  that came from the wrong element, a truncated key, a placeholder from the
  docs, or a stale key all fail this, and no amount of confident narration
  passes it. This is the gauntlet's `key_used=True` assertion, promoted from
  an eval to a product postcondition.
* ``value_present`` — a read is proven by the value still being on the page
  the run actually reached, under an anchor strong enough to identify one
  line, with the page still recognisable as the page that was planned
  against. The last part reuses the watcher's anchor machinery, which
  survived two adversarial review rounds and one live regression.

A class with no verifier cannot be accepted (see :mod:`accept`), so this
registry and that allowlist are the same promise seen from two directions.
"""

from __future__ import annotations

import hashlib
import json
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, field

from rokan_agent.core.reasons import Reason

from .executor import Trace
from .ir import Plan, Verb
from .lines import beside as _beside
from .lines import flatten, value_after_label

#: Shapes an API key plausibly takes. Not a security control — a sanity
#: check that stops us from "verifying" a sentence someone wrote about keys.
_KEY_SHAPE = re.compile(r"\b([A-Za-z0-9_\-]{16,128})\b")

#: Responses that mean "this key is not a key". Everything else — 200, 403,
#: 404, 429 — proves the credential was accepted as a credential, which is
#: what the postcondition claims. A 404 on an authenticated endpoint still
#: says the auth layer let us through.
_AUTH_FAILURES = frozenset({401, 403})

#: Statuses that mean "the auth layer let us through". 404 counts: the
#: request was authenticated and then routed nowhere, which is still the key
#: working. Everything else — 5xx, a followed redirect — says something about
#: the service, not about the key.
#:
#: 429 is NOT here, and used to be. Edge rate limiters run BEFORE auth, so a
#: throttled request never reaches the thing that would judge the key —
#: measured: against a server that 401s once and then 429s everything, a
#: garbage key was reported as "used the key … 429". The control request this
#: verifier now sends makes that MORE likely, because it spends the budget.
_ACCEPTED = frozenset({200, 201, 202, 204, 404})

#: Throttled. Not a verdict either way, and worth its own message: the fix is
#: to wait, not to doubt the key.
_THROTTLED = frozenset({429, 503})

#: Sent first, to make the endpoint prove it can reject. Shaped like a key so
#: it reaches the same code path a real one would.
_WRONG_KEY = "rokan-control-not-a-real-key-000000"

#: Text that occupies a value's place without being one. Kept literal and
#: short: a long guess-list would start rejecting real statuses.
_NON_VALUES = frozenset(
    {
        "",
        "-",
        "--",
        "---",
        "—",
        "–",
        "…",
        "...",
        "n/a",
        "na",
        "tbd",
        "loading",
        "loading...",
        "loading…",
        # Added after a pass found these passing: every one leaves the label
        # standing with something beside it that is not a reading.
        "none",
        "null",
        "nil",
        "unknown",
        "pending",
        "error",
        "failed",
        "•",
        "••",
        "•••",
        "?",
        "??",
        "empty",
        "no data",
        "not set",
        "--:--",
    }
)


@dataclass(frozen=True, slots=True)
class Verdict:
    """The verifier's answer. ``proof`` is what we would show a sceptic."""

    passed: bool
    proof: str
    reason: Reason | None = None
    evidence: tuple[str, ...] = field(default_factory=tuple)


def _candidate_key(text: str) -> str | None:
    """The longest key-shaped token on the line we read.

    Longest, not first: a line like "API key: re_9fK..." contains "key" and
    the key itself, and a first-match rule would happily "verify" the word.
    """
    matches = _KEY_SHAPE.findall(text)
    if not matches:
        return None
    best = max(matches, key=len)
    return best if len(best) >= 16 else None


class _NoRedirects(urllib.request.HTTPRedirectHandler):
    """Refuse to follow a redirect while carrying a credential.

    `urlopen` follows redirects by default, and CPython's redirect handler
    copies every header except content-length and content-type onto the new
    request — including Authorization. Measured against two local servers:
    the freshly acquired key reached BOTH the host named in --probe and the
    unnamed host it redirected to.

    That is a credential leaving the machine to an origin the user never
    named, on the one bar with a hard zero. It also broke the verdict twice
    over: the proof said "used the key against <A>" when B had answered, and
    the control request was redirected too, so a third party could satisfy
    the "is this an auth oracle" test on A's behalf.

    `session_fetch` already uses `redirect: 'error'` for exactly this
    reason. This path had forgotten.
    """

    def redirect_request(  # noqa: PLR0913
        self,
        req: urllib.request.Request,
        fp: object,
        code: int,
        msg: str,
        headers: object,
        newurl: str,
    ) -> None:
        return None


_OPENER = urllib.request.build_opener(_NoRedirects)


def _probe(url: str, key: str, timeout: float = 15.0) -> int:
    request = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {key}",
            "User-Agent": "rokan-do/0.0.1 (verification probe)",
            "Accept": "application/json",
        },
        method="GET",
    )
    try:
        with _OPENER.open(request, timeout=timeout) as response:
            return int(response.status)
    except urllib.error.HTTPError as exc:
        # A 3xx arrives here now that redirects are refused. It is not an
        # answer about the key: whatever would have judged it lives at an
        # address we were not given.
        return int(exc.code)
    except Exception:  # noqa: BLE001 — a network failure is not a verdict
        return 0


def verify_key_used(plan: Plan, trace: Trace, *, probe_url: str | None = None) -> Verdict:
    """Prove the key by using it — and prove the probe can tell.

    If we cannot reach an endpoint to spend the key against, the honest
    answer is that the task is UNVERIFIED, which routes to an abstention
    rather than a success.

    **The endpoint must first prove it is an auth oracle.** The original
    check passed on any status that was not 401 or 403, which is a much
    weaker claim than it reads as: a 500 proves the service was broken, a
    302 that `urlopen` follows to a login page proves nothing at all, and a
    probe against a public health endpoint verifies literally any string —
    including "contact-support-for-access", which is key-shaped. So a
    control request is sent first, with a deliberately wrong key. If that is
    NOT rejected, this endpoint cannot distinguish a good key from a bad one
    and no result from it is evidence.
    """
    if not trace.read:
        return Verdict(
            False,
            "nothing was read",
            Reason.ABSTAINED_LOW_CONFIDENCE,
            ("read=none",),
        )
    # Every line, not just the first. A plan that reads two values used to be
    # verified on whichever came out of the dict first, so the other could be
    # anything at all and the task still passed.
    keys = [k for k in (_candidate_key(v) for v in trace.read.values()) if k]
    line = next(iter(trace.read.values()), "")
    key = keys[0] if keys else None
    if len(keys) < len(trace.read):
        return Verdict(
            False,
            "one of the lines read does not contain anything key-shaped",
            Reason.DRIFT_DETECTED,
            (f"read={len(trace.read)}", f"key_shaped={len(keys)}"),
        )
    if key is None:
        return Verdict(
            False,
            "the line read does not contain anything key-shaped",
            Reason.DRIFT_DETECTED,
            (f"line_length={len(line)}",),
        )
    if probe_url is None:
        return Verdict(
            False,
            "no endpoint to spend the key against — unverified is not success",
            Reason.ABSTAINED_LOW_CONFIDENCE,
            ("probe=absent",),
        )

    control = _probe(probe_url, _WRONG_KEY)
    if control == 0:
        # Unreachable is unreachable, and must be reported as that rather
        # than as "this endpoint cannot reject" — the difference is a network
        # to fix versus a probe URL to change.
        return Verdict(
            False,
            "could not reach the service to test the key",
            Reason.NAVIGATION_FAILED,
            ("probe=unreachable",),
        )
    if control in _THROTTLED:
        return Verdict(
            False,
            f"the service throttled the control request ({control}) — a rate "
            "limit is not an answer about anything",
            Reason.QUOTA_EXHAUSTED,
            (f"control_status={control}",),
        )
    if control not in _AUTH_FAILURES:
        return Verdict(
            False,
            f"{probe_url} accepted a key that is not a key ({control}) — it "
            "cannot tell a working key from a broken one, so it cannot prove "
            "this one works",
            Reason.ABSTAINED_LOW_CONFIDENCE,
            (f"control_status={control}", "probe=not_an_auth_oracle"),
        )

    # Every distinct key, not just the first. The verifier already requires
    # all read lines to be key-shaped and then spent only one of them, so a
    # plan reading two keys verified one and reported both.
    statuses = {k: _probe(probe_url, k) for k in dict.fromkeys(keys)}
    # The WORST status wins, not the first interesting one. Surfacing only
    # 0/401/403 let a second key answer 500 or 429 while the verdict quoted
    # the first key's 200 — a pass that named one key and claimed two.
    status = next(
        (s for s in statuses.values() if s not in _ACCEPTED),
        next(iter(statuses.values())),
    )
    if status == 0:
        return Verdict(
            False,
            "could not reach the service to test the key",
            Reason.NAVIGATION_FAILED,
            ("probe=unreachable",),
        )
    if status in _AUTH_FAILURES:
        return Verdict(
            False,
            f"the service rejected the key ({status})",
            Reason.DRIFT_DETECTED,
            (f"probe_status={status}",),
        )
    if status in _THROTTLED:
        return Verdict(
            False,
            f"the service throttled the request ({status}) — a rate limit is "
            "not an answer about the key",
            Reason.QUOTA_EXHAUSTED,
            (f"probe_status={status}",),
        )
    if status not in _ACCEPTED:
        # Not proof either way: the service was reached and something went
        # wrong that is not about our key.
        return Verdict(
            False,
            f"the service answered {status}, which says nothing about the key",
            Reason.NAVIGATION_FAILED,
            (f"probe_status={status}",),
        )
    return Verdict(
        True,
        f"used the key against {probe_url} — {status}",
        None,
        (
            f"probe_status={status}",
            f"control_status={control}",
            # A hash, not a prefix. Six characters of a sixteen-character key
            # is over a third of the secret, and this evidence is rendered,
            # serialised and written to the ledger.
            # Every key probed, not just the first — the verdict covers all
            # of them and its evidence has to say which.
            "keys_sha256="
            + ",".join(hashlib.sha256(k.encode()).hexdigest()[:12] for k in statuses),
        ),
    )


#: Words a line can consist of and BE the reading: a status. NOT digits —
#: a numbered heading ("3. Timeouts") anchored whole would otherwise verify
#: as the answer to a timeout question, and the quantity postcondition
#: would wave it through on the "3". Caught in self-review before this
#: shipped; the measured case (a status headline) needs only the words.
#: SHORT, and every word here is one that cannot be a label. The first
#: vocabulary had `open, closed, active, up, down, yes, no, resolved,
#: maintenance…` — and the Opus round-4 probe verified eleven ordinary
#: lines as answers: "Open positions" (a nav item), "Active users" (a
#: column header), "Maintenance windows" (a heading), "No results found"
#: (an empty state), "Yes, delete this" (a button). A word that is a
#: state only sometimes buys nothing and costs a wrong answer. Badges like
#: "Resolved" can be added later WITH a measurement.
_IS_A_STATUS = re.compile(
    r"(?:operational|degraded|outage|online|offline|healthy|unhealthy|"
    r"enabled|disabled|"
    # An INCIDENT headline is a status too, and not reading one is the
    # dangerous half: githubstatus.com read "Disruption with GitHub
    # Billing" and refused it for holding no state word, which is a
    # refusal to report an outage (measured 2026-08-27, during a real
    # GitHub incident).
    #
    # STATE words only. The incident STAGES — resolved, investigating,
    # monitoring, identified — are badges that repeat down an incident
    # history, and an existing test pins that a bare "Resolved" must not
    # read as the current status (Opus round 4: three identical badges,
    # the topmost served as the answer).
    r"disrupted|down)",
    re.IGNORECASE,
)


#: An incident headline NAMES the thing that broke — "Disruption with
#: GitHub Billing", "Outage affecting API" — so the all-words rule below
#: cannot reach it: "github" and "billing" are not status words and never
#: will be. This matches the SHAPE instead: a service-health noun at the
#: start of the line.
#:
#: The tail stop-list is the other half. "Outage History" and "Incident
#: Log" start the same way and are nav tabs; an existing test pins that
#: they must not read as the current status.
_INCIDENT_HEADLINE = re.compile(
    r"^(?:major|minor|partial|full|service|scheduled|planned)?\s*"
    r"(?:disruption|disrupted|outage|degradation|degraded|maintenance|incident)\s+"
    # Up to two words of the thing's own name may sit between the state
    # and the connective: "Degraded performance on checkout".
    r"(?:\w+\s+){0,2}"
    # A SUBJECT is what separates an event from a section heading. The
    # shape actually measured on githubstatus was "<state> with <thing>";
    # "Maintenance window", "Incident report", "Outage map" and eight more
    # were admitted by the version that only needed the noun (Opus review
    # F5, reproduced 2026-08-27). Naming the connectives is the narrow
    # way: a heading does not say "with", "affecting" or "on".
    r"(?:with|affecting|impacting|on|in|at|for|to)\s+\S",
    re.IGNORECASE,
)
_NAVIGATION_TAIL = re.compile(
    r"\b(?:history|log|logs|archive|archives|updates|timeline|page|status|feed|rss|"
    r"window|windows|map|mode|summary|details|detail|schedule|response|report|"
    r"reports|notice|notices|events|incidents?|outages?|disruptions?)$",
    re.IGNORECASE,
)

#: Words that may accompany a status word in a headline and still leave the
#: line a STATUS rather than a label: "All Systems Operational", "Partial
#: Outage", "Degraded Performance". Nothing else — the round-5 probe built
#: ten false passes from lines that merely CONTAIN a status word ("Enabled
#: by default", a heading; "Offline mode", a toggle; "Outage History", a
#: nav tab), so the rule matches the whole line, not a word inside it.
#: NOT `status`, `service`, `services`: with those, a status word in the
#: ADJECTIVE slot makes a heading — "Operational Status" is the <h2> above
#: the real value on many status pages, and on a degraded day it still
#: reads "Operational" (Opus round 6). None of the measured headlines uses
#: them. Documented residual: "Operational Performance" (a rare report
#: heading) still passes, because `performance` must stay for "Degraded
#: Performance"; accepted rather than contorting the rule further.
_STATUS_CONNECTIVES = frozenset(
    {
        "all",
        "systems",
        "system",
        "partial",
        "major",
        "minor",
        "performance",
    }
)


#: A value token that is not the line's own numbering: a digit that comes
#: AFTER a label separator — a colon, an equals sign, a quote or an opening
#: parenthesis — which itself comes after a word. "3. Timeouts" has its
#: digit first; "Section 4" has no separator at all; `Default:
#: MaxKeepAliveRequests 100`, `max_execution_time "30" INI_ALL` and
#: `uint8 the set of all unsigned 8-bit integers (0 to 255)` carry theirs
#: after one.
_CARRIES_A_VALUE_AFTER_A_LABEL = re.compile(r"""[a-z_].*?[:=("'].*?\d""")

#: `requests 2.34.2` — a label and its value with nothing but a space
#: between them. No separator, so the rule above refuses it, and pypi.org
#: names every version that way: the whole line was read correctly and then
#: refused as "carries no value" (measured 2026-08-27).
#:
#: Narrow deliberately. The trailing token must be SHAPED like a value —
#: dotted (`2.34.2`) or carrying a unit (`75s`, `32 TB`, `20%`) — because a
#: bare small integer after a word is how a heading reads ("Section 4",
#: "Chapter 2"), and admitting those is how a heading becomes an answer.
#: Labels that introduce FURNITURE, whatever shape follows them.
#:
#: NOT exhaustive, and it cannot be: "Bootstrap 5.3" is the same shape as
#: "express 5.2.1", and on a page about Bootstrap it IS the answer. What
#: separates them is the question, which this function never sees — the
#: planner does, and it chose the anchor. Recorded rather than papered
#: over (Opus review F5). "Added
#: in: v0.5.4" and "requests 2.34.2" are both a word and a dotted number;
#: only the label says which is the page's answer and which is its
#: bookkeeping.
_FURNITURE_LABEL = re.compile(
    r"^\s*(?:added|available|introduced|deprecated|removed|changed|updated|"
    r"last\s+updated|published|released|revised|modified|created|"
    r"compatibility|compatible|edition|version\s+history|changelog|"
    # ACTION labels: a button, a badge, a reading-time estimate. "Download
    # 2.4 MB" and "Read 5 min" are the same shape as "requests 2.34.2" and
    # neither is a fact about the page (Opus review F5).
    r"download|read|watch|listen|play|view|open|print|share|copy|install|"
    r"get|try|start|continue|learn|explore|browse|buy|order|subscribe|"
    r"copyright|source|module|see\s+also|cite(?:\s+as)?|since|requires?|"
    r"depends?\s+on|tested\s+(?:on|with)|supported?\s+(?:on|in))\b",
    re.IGNORECASE,
)

_LABEL_THEN_VALUE = re.compile(
    r"^[^\d]*[A-Za-z][\w.@/-]*\s+"
    r"(?:v?\d+(?:\.\d+)+[\w.+-]*|\d[\d,.]*\s?(?:%|[A-Za-z]{1,4}))\s*[.;:]?$"
)

#: The digits a reference page wears as FURNITURE: versions, dates, years,
#: citations. A docs page says "Added in: v0.5.4", "Last updated:
#: 2024-08-25", "See also: RFC 7230", "Compatibility: Available in Apache
#: 2.4 and later" on almost every section, each a whole line with a digit
#: after a separator — and none of them the value anybody asked for. Opus
#: round 12 ran twenty-three such lines through the separator gate alone
#: and every one passed; with these stripped first, 18 of 19 land where
#: intended. Cost: a question whose answer IS a version or a date refuses
#: instead of answering. The safe side, for a rule whose job is stopping a
#: wrong-but-verified.
_FURNITURE_DIGITS = re.compile(
    r"v?\d+(?:\.\d+)+"
    r"|\b(?:19|20)\d{2}(?:-\d{2}(?:-\d{2})?)?\b"
    r"|\b(?:rfc|pep|cve|bug|issue|arxiv|isbn)[\s:#-]*\d+(?:\.\d+)*\b"
    r"|\bsince[\s:]*\d+(?:\.\d+)*\b",
    re.IGNORECASE,
)


def _is_itself_a_value(anchor: str, line: str) -> bool:
    """Is this line, in its entirety, the value — with the anchor being the
    whole of it?

    Two shapes qualify. A STATUS line: every word a status word or a status
    connective, with at least one status word present ("All Systems
    Operational"). And a LABELLED VALUE the planner quoted whole: a line that
    carries a number or a quoted token after at least one word — measured
    twice in the head-to-head (2026-08-25): httpd.apache.org's `Default:
    MaxKeepAliveRequests 100` and php.net's `max_execution_time "30"
    INI_ALL` were both read exactly and refused as "carries no value",
    because the value was inside the anchor. The page holds that line
    verbatim, so the value is the page's, not the plan's; and a plan that
    quotes a value fails closed the day the page changes it. A numbered
    heading ("3. Timeouts") and a bare label ("Usage this month") still
    refuse: the digit must follow a label separator, and a heading has
    none. And the digit must survive `_FURNITURE_DIGITS`: "Added in:
    v0.5.4" and "See also: RFC 7230" are whole lines with a digit after a
    colon on every reference page, and none of them is a value.
    """
    flat_line = flatten(line).lower()
    if flatten(anchor).lower() != flat_line:
        return False
    words = re.findall(r"[a-z]+", flat_line)
    if not words:
        return False
    if any(_IS_A_STATUS.fullmatch(w) for w in words) and all(
        _IS_A_STATUS.fullmatch(w) or w in _STATUS_CONNECTIVES for w in words
    ):
        return True
    if _INCIDENT_HEADLINE.match(flat_line) and not _NAVIGATION_TAIL.search(flat_line.strip()):
        return True
    if _STATUS_PHRASE.search(flat_line):
        # A state spelled as a phrase rather than a word — Cloudflare's
        # "No known service issues". The whole line IS the reading, exactly
        # as "All Systems Operational" is.
        return True
    # A label and its value with only a space between them — `requests
    # 2.34.2` — has no separator for the rule below to find, so it is
    # decided here, before that gate refuses it.
    if _LABEL_THEN_VALUE.match(flat_line):
        return not _FURNITURE_LABEL.match(flat_line)
    if not _CARRIES_A_VALUE_AFTER_A_LABEL.search(flat_line):
        return False
    return bool(re.search(r"\d", _FURNITURE_DIGITS.sub(" ", flat_line)))


def _reads_a_banner(trace: Trace) -> Verdict | None:
    """Refuse a read that came back with the search's own banner.

    Shared by both verifiers that hand a READ back as the answer. It was
    first written into the value verifier alone, and the task that
    produced it — "search for X and extract the headline of a related
    article" — routes to GENERAL mode, so the check never ran on the path
    that needed it (2026-08-27).
    """
    line = next((ln for ln in trace.read.values() if _SEARCH_BANNER.search(ln)), "")
    if not line:
        return None
    return Verdict(
        False,
        "that is the search's own banner, not a result of it — read a line "
        "from the results themselves",
        Reason.DRIFT_DETECTED,
        (f"line={line[:60]}",),
    )


#: A search page's own banner. It restates the query and says how the
#: search went; it is never a result of the search.
#:
#: Measured on hindustantimes.com (2026-08-27): asked to search for
#: "Narendra Modi" and extract the headline of a related article, a run
#: typed the query, reached the results page, and read back "Showing
#: result for Narendra Modi..." — a real line, beside a real anchor,
#: containing the very words the question used, and not an article.
_SEARCH_BANNER = re.compile(
    # "Showing 1-10 of 431 results for…" — the count comes with a range,
    # a total, and any of the words a site uses to join them.
    r"^\s*(?:showing|displaying)\b[^.]{0,40}?\bresults?\b"
    r"|^\s*(?:showing|displaying)\s+result\b"
    r"|^\s*search\s+results?\s+(?:for|:)"
    r"|^\s*results?\s+for\b"
    r"|^\s*(?:about\s+)?\d[\d,]*\s+results?\b"
    r"|^\s*no\s+results?\s+(?:found|for)\b",
    re.IGNORECASE,
)


def verify_value_present(plan: Plan, trace: Trace) -> Verdict:
    """Prove the read: the value is on the page the run actually reached.

    Three ways this refuses — nothing read, the anchor missing from the final
    page text, or a line with no value beside its anchor. The third is the
    subtle one: an anchor can survive on a page whose value has been replaced
    by "—" or "loading", and reporting that as a reading would be a quiet
    lie.
    """
    if not trace.read:
        return Verdict(False, "nothing was read", Reason.ABSTAINED_LOW_CONFIDENCE, ("read=none",))
    for anchor, line in trace.read.items():
        # Case-insensitive, matching the executor: the two must agree about
        # what "on the page" means, or a plan that ran will fail to verify.
        # Flattened on both sides — see `lines.flatten`. A page that holds
        # a non-breaking space where the anchor has an ordinary one is not
        # a page that lacks the anchor.
        flat_anchor = flatten(anchor).lower()
        matching = [ln for ln in trace.page_text.splitlines() if flat_anchor in flatten(ln).lower()]
        if not matching:
            return Verdict(
                False,
                f"{anchor!r} is not on the page that was reached",
                Reason.DRIFT_DETECTED,
                (f"anchor={anchor}",),
            )
        if len(matching) > 1 and len({_beside(anchor, ln) for ln in matching}) > 1:
            # The executor takes the FIRST matching line, so an anchor that
            # matches several DIFFERENT values is not a read — it is a
            # coincidence with a value attached. Measured: the anchor
            # "Usage" matched both "Usage & Billing" (a nav item) and
            # "Usage this month 4812 GB", and the nav item was reported as
            # the verified answer.
            #
            # DISAGREEMENT is the fault, not multiplicity. A first run
            # against real sites refused an RFC because its title appears in
            # every page header — and a value shown twice with the same
            # number beside it, in a summary and again in a table, is not
            # ambiguous at all: every candidate reading agrees, and the
            # first is as good as any. Requiring exactly one line refused
            # those too, and calling that caution is only true in one
            # direction.
            #
            # This check also replaces one that could not fail: the executor
            # populates `trace.read` BY scanning `page_text` for the anchor,
            # so asserting the anchor is in `page_text` was true by
            # construction for every plan v1 can express.
            return Verdict(
                False,
                f"{anchor!r} matches {len(matching)} lines on this page — an "
                "anchor that identifies more than one line identifies none",
                Reason.DRIFT_DETECTED,
                tuple(f"line={ln[:60]}" for ln in matching[:3]),
            )
        remainder = _beside(anchor, line)
        if not remainder:
            # A bare label, with its value on the next line. See
            # `value_after_label` for why only a colon pairs.
            page_lines = trace.page_text.splitlines()
            for position, candidate in enumerate(page_lines):
                if candidate.strip() == line.strip():
                    remainder = value_after_label(page_lines, position)
                    break
        if not remainder and len(matching) == 1 and _is_itself_a_value(anchor, line):
            # `len(matching) == 1`: a whole-line anchor has an EMPTY
            # remainder on every match, so the disagreement check above
            # sees one remainder and waves it through, and the executor
            # takes the first — three identical "Resolved" badges under an
            # incident history returned the topmost one as "the current
            # status" (Opus round 4). A line that is the whole value and
            # appears more than once identifies nothing.
            # The line IS the value. A status headline — "All Systems
            # Operational", "Enabled" — has no label beside it; the whole
            # line is the reading. Measured on githubstatus.com through the
            # real CLI: the correct read was refused as "carries no value",
            # and it took a second rung and a shortened anchor to pass.
            # Narrow on purpose: the anchor must be the ENTIRE line, and
            # the line must be a STATUS — a bare label ("Usage this month")
            # and a numbered heading ("3. Timeouts") still refuse.
            remainder = flatten(line)
        # A dashboard that failed to load still renders its label, often with
        # a placeholder beside it. "Usage this month —" and "Usage this month
        # …" are the same non-answer as "Usage this month", and reporting
        # either as a reading is the quiet lie this whole product avoids.
        if remainder.lower() in _NON_VALUES:
            remainder = ""
        if not remainder:
            return Verdict(
                False,
                f"{anchor!r} is present but carries no value",
                Reason.DRIFT_DETECTED,
                (f"line={line[:80]}",),
            )
    banner = _reads_a_banner(trace)
    if banner is not None:
        return banner
    values = " · ".join(trace.read.values())
    return Verdict(True, values, None, tuple(f"read={v[:80]}" for v in trace.read.values()))


#: Words a site's chrome uses for itself. A block made of these is a menu,
#: whatever the question was: news.ycombinator.com answered "the first 5
#: story titles" with "new · past · comments · ask · show", every one of
#: them a real link in real order (2026-08-27).
#:
#: This heuristic may only REFUSE. It never admits anything — admitting on
#: a guess is how a wrong answer gets a verified label, and refusing on one
#: costs a rung the ladder already budgets for.
_CHROME_WORDS = frozenset(
    {
        "new",
        "past",
        "comments",
        "ask",
        "show",
        "jobs",
        "submit",
        "login",
        "logout",
        "register",
        "home",
        "about",
        "contact",
        "help",
        "docs",
        "support",
        "blog",
        "pricing",
        "careers",
        "privacy",
        "terms",
        "settings",
        "profile",
        "account",
        "search",
        "menu",
        "more",
        "next",
        "previous",
        "back",
        "top",
        "first",
        "last",
        "page",
        "news",
    }
)


def _looks_like_navigation(block: list[str]) -> str:
    """Why this block is a menu rather than a list, or "" if it is not."""
    items = [flatten(ln).strip().lower() for ln in block if ln.strip()]
    if len(items) < 2:
        return ""
    chrome = sum(1 for item in items if item in _CHROME_WORDS)
    if chrome * 2 > len(items):
        return f"{chrome} of {len(items)} are navigation labels"
    # A real list of things has things in it. Five items averaging four
    # characters is a menu bar.
    if sum(len(item) for item in items) / len(items) < 6:
        return "every item is too short to be a title, a name or a row"
    return ""


def _column_rows(
    groups: list[list[list[str]]], wanted: list[str]
) -> tuple[list[list[str]], int, list[int]] | None:
    """Where these lines sit: the group, the column, and WHICH ROWS.

    Returns the rows so a caller can demand that a second field come from
    the same ones. Checking each column on its own was not enough: every
    line of "Blazer — 199.00 USD" is real, on the page, and one column of
    a repeat — and Blazer costs 129.00. The pairing was manufactured by
    `zip` and nothing looked at it (external review, 2026-08-27).

    Rows must be CONSECUTIVE. Allowing a later row let "the first 5" be
    answered with every other row of a ten-row table, which is a real
    reading of the page and not the one that was asked for.
    """
    for units in groups or []:
        flat = [[flatten(c).strip().lower() for c in row] for row in units]
        col = -1
        first_row = -1
        for i, row in enumerate(flat):
            if wanted[0] in row:
                col, first_row = row.index(wanted[0]), i
                break
        if col < 0:
            continue
        rows = [first_row]
        ok = True
        for offset, item in enumerate(wanted[1:], start=1):
            at = first_row + offset
            if at >= len(flat) or col >= len(flat[at]) or flat[at][col] != item:
                ok = False
                break
            rows.append(at)
        if ok:
            return units, col, rows
    return None


def _is_one_column(groups: list[list[list[str]]], wanted: list[str]) -> bool:
    """Are these lines one cell each of CONSECUTIVE rows of ONE group?

    This is the shape claim a list answer actually makes. A block that
    satisfies it cannot be five fields of one row dressed up as five rows,
    and cannot mix a results item with a footer link, whatever the two
    happen to look like.

    All of them or none: a group covering four rows of a five-row answer
    proves nothing about the fifth, which is exactly the line most likely
    to have come from somewhere else.
    """
    return _column_rows(groups, wanted) is not None


def _is_one_row(groups: list[list[list[str]]], wanted: list[str]) -> bool:
    """Are these lines several cells of a SINGLE row of some repeat-group?

    A list of five is five rows. Five cells of one row — a story's title,
    its site, its author, its age — are adjacent lines of the page in the
    page's own order, so the plain run check accepts them; only the
    structure knows they are one item wearing five coats.
    """
    for units in groups or []:
        for row in units:
            cells = [flatten(c).strip().lower() for c in row]
            if len(wanted) > 1 and all(ln in cells for ln in wanted):
                return True
    return False


def verify_block_present(plan: Plan, trace: Trace) -> Verdict:
    """Prove a LIST: these are the page's own lines, contiguous and in order.

    The failure this exists to refuse is the one every list-answering agent
    has: a model reads a page, writes five plausible items, and one of them
    was never there — or all five were there but in a different order, so
    "the top 5 by activity" is really "five of them, in some order". Both
    read as success to a judge skimming the answer.

    So the check is not "each item appears somewhere". It is: the returned
    lines are a RUN of the rendered page, adjacent, in the same order. That
    cannot be satisfied by a summary, a re-ordering, or an invention, and
    it needs no knowledge of what the right answer was.
    """
    if not trace.block:
        return Verdict(False, "nothing was read", Reason.ABSTAINED_LOW_CONFIDENCE, ("block=none",))
    # Against the SAME sequence the block was read from. Checking a run of
    # links against the rendered text would pass on coincidence — a link
    # label usually appears in the text too, just not adjacently.
    source = trace.links if trace.block_kind == "link" else trace.page_text.splitlines()
    page = [flatten(ln).strip().lower() for ln in source]
    if trace.block_kind == "link":
        page = [ln for ln in page if ln]
    else:
        # Blank lines are KEPT as boundaries. Stripping them first made
        # "contiguous" mean "adjacent once the gaps are closed", so a run
        # could start in a results list and end in the footer navigation
        # and still verify (Opus review F6, reproduced 2026-08-27). A
        # rendered page separates its blocks with blank lines; a list that
        # crosses one is two lists.
        page = [ln if ln else "\x00" for ln in page]
    wanted = [flatten(ln).strip().lower() for ln in trace.block]
    if any(not ln for ln in wanted):
        return Verdict(
            False,
            "a blank line is not an item",
            Reason.DRIFT_DETECTED,
            (f"lines={len(wanted)}",),
        )
    # A repeat-group that covers every line is BETTER evidence than
    # adjacency: it says the lines are rows of one structure the page
    # built, not merely lines that sit next to each other. The order and
    # the no-outsider-in-between checks still run — a group is a fence,
    # not a licence to re-order — but the blank-line boundary and the
    # navigation heuristic are both subsumed by it, because a footer link
    # is not a row of the results list whatever it looks like.
    if not (trace.block_kind != "link" and trace.collections) and len(set(wanted)) != len(
        wanted
    ):
        # Five rows that are really one row read five times is not a list.
        # Only asked WITHOUT structure: a column repeats values honestly —
        # quotes.toscrape.com lists two quotes by Albert Einstein, and the
        # authors column is right to say his name twice (2026-08-27). When
        # the fence proves each line came from a different ROW, sameness is
        # the page's, not the reader's.
        return Verdict(
            False,
            "the same line appears more than once — that is not a list",
            Reason.DRIFT_DETECTED,
            (f"lines={len(wanted)}",),
        )
    if trace.block_kind != "link" and _is_one_row(trace.collections, wanted):
        return Verdict(
            False,
            "these are several fields of ONE item, not a list of items",
            Reason.DRIFT_DETECTED,
            tuple(f"cell={ln[:40]}" for ln in trace.block[:5]),
        )
    if trace.block_kind != "link" and _is_one_column(trace.collections, wanted):
        # Every line still has to BE on the page — the group says which
        # lines belong together, never what they say.
        on_page = set(page)
        missing = [ln for ln in wanted if ln not in on_page]
        if missing:
            return Verdict(
                False,
                "a line of this list is not on the page",
                Reason.DRIFT_DETECTED,
                tuple(f"line={ln[:50]}" for ln in missing[:3]),
            )
        if trace.block_extra:
            # A second field of the same rows is a second CLAIM, and it is
            # checked as its own column: same length, on the page, and one
            # column of a repeat-group. Only then are a row's two fields
            # put together, and only in the answer.
            extra = [flatten(ln).strip().lower() for ln in trace.block_extra]
            if len(extra) != len(wanted):
                return Verdict(
                    False,
                    "the second field was not read for every row",
                    Reason.DRIFT_DETECTED,
                    (f"rows={len(wanted)}", f"second={len(extra)}"),
                )
            missing_extra = [ln for ln in extra if ln not in set(page)]
            if missing_extra:
                return Verdict(
                    False,
                    "a second-field line is not on the page",
                    Reason.DRIFT_DETECTED,
                    tuple(f"line={ln[:50]}" for ln in missing_extra[:3]),
                )
            primary = _column_rows(trace.collections, wanted)
            second = _column_rows(trace.collections, extra)
            if (
                primary is None
                or second is None
                # The SAME group, the SAME rows, a DIFFERENT column. Without
                # all three, `zip` invents the pairing: "Blazer — 199.00
                # USD" is two real lines of two real columns and Blazer
                # costs 129.00, and "Blazer — Help" pairs a product with a
                # footer link.
                or primary[0] is not second[0]
                or primary[2] != second[2]
                or primary[1] == second[1]
            ):
                return Verdict(
                    False,
                    "the second field does not belong to the same rows as "
                    "the first",
                    Reason.DRIFT_DETECTED,
                    tuple(f"line={ln[:50]}" for ln in trace.block_extra[:3]),
                )
            paired = " · ".join(
                f"{a} — {b}" for a, b in zip(trace.block, trace.block_extra, strict=True)
            )
            return Verdict(
                True,
                paired,
                None,
                (f"lines={len(wanted)}", "fence=repeat-group", "fields=2"),
            )
        return Verdict(
            True,
            " · ".join(trace.block),
            None,
            (f"lines={len(wanted)}", "fence=repeat-group"),
        )
    if trace.block_kind != "link" and trace.collections:
        # The page told us where it repeats, and these lines are not one
        # column of any of it. Refuse rather than fall back to adjacency:
        # measured on quotes.toscrape.com (2026-08-27), the adjacency rule
        # accepted a "list of the first 5 authors" that was really quote,
        # tags, quote, tags, quote — five real lines of the page, in the
        # page's own order, and not a list of anything.
        return Verdict(
            False,
            "these lines are not one column of any list this page repeats",
            Reason.DRIFT_DETECTED,
            tuple(f"line={ln[:50]}" for ln in trace.block[:3]),
        )
    chrome = _looks_like_navigation(trace.block)
    if chrome:
        return Verdict(
            False,
            f"these look like navigation, not a list: {chrome}",
            Reason.DRIFT_DETECTED,
            tuple(f"item={ln[:40]}" for ln in trace.block[:5]),
        )
    run = next(
        (i for i in range(len(page) - len(wanted) + 1) if page[i : i + len(wanted)] == wanted),
        -1,
    )
    if run < 0:
        return Verdict(
            False,
            "these lines are not a run of the page — a list that the page "
            "does not show in that order was not read, it was written",
            Reason.DRIFT_DETECTED,
            tuple(f"line={ln[:50]}" for ln in trace.block[:3]),
        )
    return Verdict(
        True,
        " · ".join(trace.block),
        None,
        (f"block={len(trace.block)} {trace.block_kind}s", f"at_index={run}"),
    )


#: Registry keyed exactly as `accept.TaskClass.verify` names them. A missing
#: key here is a programming error, not a runtime condition: the gate cannot
#: accept a class whose verifier does not exist.
def verify_quantity_present(plan: Plan, trace: Trace) -> Verdict:
    """`value_present`, and the line must actually carry a number.

    Asked for a timeout, a size, an interval or a count, an answer without
    a digit in it is not an answer. Measured: three of the four
    confidently-wrong real-site results read a line with no number on it —
    nginx's `Syntax:` row, node's paragraph about the pool, prometheus's
    YAML comment — while every correct answer to a quantity question had a
    digit.

    This can only ever turn a wrong answer into a refusal, which is the
    trade this product should always take. It cannot make a refused task
    succeed.
    """
    verdict = verify_value_present(plan, trace)
    if not verdict.passed:
        return verdict
    for anchor, line in trace.read.items():
        if not re.search(r"\d", line):
            return Verdict(
                False,
                f"{anchor!r} was asked for a quantity and the line beside it "
                "has no number in it — it mentions the subject rather than "
                "stating the value",
                Reason.DRIFT_DETECTED,
                (f"line={line[:80]}",),
            )
    return verdict


#: Exactly three digits, standing alone. `\b` keeps "RFC7538" together (no
#: boundary between word characters) and refuses "2014" (four digits) and
#: "Section 4" (one) — which is precisely the digit-bearing note that a
#: plain any-digit rule admitted as the answer to "which status code".
_THREE_DIGITS = re.compile(r"\b\d{3}\b")


def verify_status_code_present(plan: Plan, trace: Trace) -> Verdict:
    """`value_present`, and the line must carry a standalone 3-digit number.

    An HTTP status code is exactly three digits by definition (RFC 9110
    §15), so a question asking WHICH status code constrains its answer's
    shape completely. Measured: the frozen set's one such task was answered,
    three passes out of three, with "Note: This status code is much younger
    (June 2014) than its sibling codes…" — a line about a code with no code
    on it. Its digits are a year, a section number and an RFC number; none
    is a standalone three-digit run, so this refuses it.

    Like the quantity verifier, this can only ever turn a wrong answer into
    a refusal. It cannot make a refused task succeed.
    """
    verdict = verify_value_present(plan, trace)
    if not verdict.passed:
        return verdict
    for anchor, line in trace.read.items():
        if not _THREE_DIGITS.search(line):
            return Verdict(
                False,
                f"{anchor!r} was asked for a status code and the line beside "
                "it has no three-digit number on it — it mentions the "
                "subject rather than stating the code",
                Reason.DRIFT_DETECTED,
                (f"line={line[:80]}",),
            )
    return verdict


#: The Unicode Standard's own notation: U+ then four to six hex digits.
_U_PLUS_HEX = re.compile(r"U\+[0-9A-Fa-f]{4,6}\b")


def verify_code_point_present(plan: Plan, trace: Trace) -> Verdict:
    """`value_present`, and the line must carry a U+hex code point.

    A code point is written U+XXXX by the standard that defines it, so a
    question asking WHICH code point constrains its answer's notation
    completely. Measured: the extended set's one such task was answered,
    three passes out of three, with the surrogates paragraph — whose
    ranges are written D800(subscript 16) and which therefore carries no
    U+ token — while the correct line reads "U+0000..U+10FFFF".

    Like the other typed postconditions this can only ever turn a wrong
    answer into a refusal, never the reverse.
    """
    verdict = verify_value_present(plan, trace)
    if not verdict.passed:
        return verdict
    for anchor, line in trace.read.items():
        if not _U_PLUS_HEX.search(line):
            return Verdict(
                False,
                f"{anchor!r} was asked for a code point and the line beside "
                "it has no U+hex token on it — it mentions the subject "
                "rather than stating the code point",
                Reason.DRIFT_DETECTED,
                (f"line={line[:80]}",),
            )
    return verdict


#: What a system-status line says. Statuspage, Instatus, and hand-rolled
#: pages all draw from this vocabulary; a heading ("System status") or a
#: nav line ("Past Incidents") carries none of these as a STATE word.
#: Bare `on`, `up`, `off`, `down`, `available` are NOT here: "Current
#: Status on Acme", "Sign up", "Log on", "No data available" all matched
#: (Opus round 9). A state must be said as a state.
#: Whole phrases that ARE a state though no single word in them is one.
#: Cloudflare's all-clear is "No known service issues" — read correctly and
#: then refused for holding no state word (measured 2026-08-27).
_STATUS_PHRASE = re.compile(
    r"\bno\s+(?:known\s+)?(?:service\s+)?(?:issues|incidents|problems|outages)\b"
    r"|\bnothing\s+to\s+report\b|\ball\s+clear\b",
    re.IGNORECASE,
)

_STATUS_WORD = re.compile(
    r"\b(?:operational|degraded|outage|maintenance|incidents?|investigating|"
    r"identified|monitoring|resolved|disruption|partial(?:ly)?|major|minor|healthy|"
    r"unhealthy|unavailable|normal|no (?:known |active )?(?:issues|incidents)|all systems|"
    r"running smoothly|enabled|disabled|active|inactive|paused|pending|verified|"
    r"unverified|is (?:up|down|online|offline)|systems? (?:up|down)|not available)\b",
    re.IGNORECASE,
)


def verify_status_word_present(plan: Plan, trace: Trace) -> Verdict:
    """`value_present`, and the line must STATE a status.

    Measured on the pre-warm batch (2026-08-25, 20 status pages): six
    "verified" answers were headings — "System status", "Cloudflare System
    Status", "Powered by Atlassian Statuspage", "Current Status Scheduled
    Maintenance …" — lines that name the subject and state nothing. A line
    that answers "what is the status" carries a state word. Like every
    typed postcondition this only turns a wrong answer into a refusal."""
    verdict = verify_value_present(plan, trace)
    if not verdict.passed:
        return verdict
    for anchor, line in trace.read.items():
        flat = flatten(line).strip()
        headline = _INCIDENT_HEADLINE.match(flat) and not _NAVIGATION_TAIL.search(flat)
        if not (_STATUS_WORD.search(line) or _STATUS_PHRASE.search(line) or headline):
            return Verdict(
                False,
                f"{anchor!r} was asked for a status and the line beside it "
                "states none — it names the subject rather than the state",
                Reason.DRIFT_DETECTED,
                (f"line={line[:80]}",),
            )
    return verdict


# — general mode: declared postconditions, each a deterministic signal ————


def _url_reached(plan: Plan, trace: Trace, argument: str) -> str:
    """The run landed where the plan said it would. Substring on the reached
    URL, fragment ignored; "" when it holds, else why not."""
    reached = (trace.last_url or "").split("#", 1)[0].lower()
    if argument.lower() in reached:
        return ""
    return f"expected to reach {argument!r}, reached {reached or 'nowhere'!r}"


def _confirmation_text(plan: Plan, trace: Trace, argument: str) -> str:
    """Something on the page that would not be there if the run had failed.

    A confirmation that merely repeats what the run TYPED confirms nothing:
    the words are sitting in the box the plan filled, so the postcondition
    holds on the page the search started from as surely as on the results.

    Measured on eventbrite.com (2026-08-27): a plan filled the search box
    with "San Francisco", pressed Enter, declared
    `confirmation_text=San Francisco`, and read the search box's own
    SUGGESTIONS — Cooking, Job fairs, Mothers day — while the page had
    never moved. Every check passed, because the query was on the page: it
    was in the box.
    """
    wanted = flatten(argument).lower()
    for step in plan.steps:
        if step.verb is not Verb.FILL_REF:
            continue
        typed = flatten(str(step.args.get("value") or "")).lower()
        if typed and wanted in typed:
            return (
                f"{argument!r} is what this plan TYPED, so finding it proves "
                "nothing — confirm on something the page would only show if "
                "the action worked"
            )
    if wanted in flatten(trace.page_text).lower():
        return ""
    return f"{argument!r} is not on the page that was reached"


def _state_changed(plan: Plan, trace: Trace, argument: str) -> str:
    """The LAST action reported a change. Unknown (None) is not a change,
    and no action at all is not a change."""
    if not trace.actions:
        return "no action ran, so nothing changed"
    w5 = trace.actions[-1].get("w5") or {}
    if w5.get("url_changed") or w5.get("dom_changed") or w5.get("new_tab"):
        return ""
    return "the last action reported no change"


#: Text that means a form refused what was typed. Conservative: whole
#: phrases a validation message uses, not the bare words "required" or
#: "invalid" (a page's legal footer says "required by law").
_VALIDATION_ERROR = re.compile(
    r"\b(?:this field is required|is required\b|required field|invalid (?:email|address|"
    r"card|number|value|input|format)|please enter a valid|must be at least|"
    r"does not match|cannot be blank|can't be blank|may not be empty)",
    re.IGNORECASE,
)


def _no_validation_error(plan: Plan, trace: Trace, argument: str) -> str:
    hit = _VALIDATION_ERROR.search(flatten(trace.page_text))
    if hit is None:
        return ""
    return f"the page shows a validation error: {hit.group(0)!r}"


_POSTCONDITIONS = {
    "url_reached": _url_reached,
    "confirmation_text": _confirmation_text,
    "state_changed": _state_changed,
    "no_validation_error": _no_validation_error,
}


def verify_general(plan: Plan, trace: Trace) -> Verdict:
    """ALL declared postconditions must hold. None declared → the run is
    `self_reported`: it finished, and nothing could check it. That verdict
    is honest and is never admitted to memory — a replay of a guess is a
    guess replayed (2606.09863: agents' own completion claims are wrong
    45–76% of the time, and no judge beats AUROC 0.65)."""
    if not plan.postconditions:
        return Verdict(
            False,
            "the run finished, and nothing on the page can confirm what it did",
            Reason.ABSTAINED_LOW_CONFIDENCE,
            ("self_reported",),
        )
    evidence: list[str] = []
    for condition in plan.postconditions:
        kind, argument = next(iter(condition.items()))
        check = _POSTCONDITIONS.get(kind)
        if check is None:
            # Fail CLOSED: `ir.validate` refuses unknown kinds, so reaching
            # here means an edited row — and an unchecked condition must not
            # count as a passed one.
            return Verdict(False, f"unknown postcondition {kind!r}", Reason.DRIFT_DETECTED, ())
        problem = check(plan, trace, argument)
        if problem:
            return Verdict(False, problem, Reason.DRIFT_DETECTED, tuple(evidence))
        evidence.append(f"{kind}={argument}")
    # What the run READ, never a scrap of the page. This used to be the
    # page's LAST LINE, which is a footer on every site there is: asked to
    # "find events in San Francisco and list each title with its ticket
    # price range", a run that reached the right page answered "United
    # States" — eventbrite's footer country selector — and the postconditions
    # passed, because they check the ACTION and this string was pretending
    # to be the ANSWER (2026-08-27, browser-use WebBenchREAD task 14).
    #
    # A general run with no read step did something rather than found
    # something out, and "done" is the whole truth about it.
    if trace.block:
        # The postconditions checked what the run DID. They say nothing
        # about what it READ, so the list verifier runs too — and a general
        # answer that is a list carries the same honesty as a read_list
        # one: `block_present` proves an answer has the SHAPE of a list,
        # not that it is the list the question meant. Measured on
        # eventbrite (2026-08-27): asked for events in San Francisco, a run
        # read the search box's SUGGESTIONS — Cooking, Job fairs, Mothers
        # day — a real column of a real repeat, and was labelled verified.
        listed = verify_block_present(plan, trace)
        if not listed.passed:
            return listed
        evidence.extend([*listed.evidence, "self_reported"])
        proof = " · ".join(trace.block)
    elif trace.read:
        banner = _reads_a_banner(trace)
        if banner is not None:
            return banner
        # An ANSWER, so it is held to the answer verifier. General mode was
        # a strictly weaker route to `verified` than `value_present`: this
        # branch ran one check where `verify_value_present` runs six, and
        # it is the route the planner picks for the messy tasks. A read
        # that would not survive as a value read is still reported — the
        # run did happen — but it is reported as self-reported.
        as_a_value = verify_value_present(plan, trace)
        if not as_a_value.passed:
            evidence.append("self_reported")
        proof = str(list(trace.read.values())[-1])
    else:
        # NOTHING WAS READ. The postconditions prove the run ACTED, and
        # "done" is the whole truth about it — but whether the person
        # wanted a fact is not something this can know, and it was
        # answering questions with the literal string "done" under a
        # `verified` label. `_ASKS_FOR_INFORMATION` cannot close that: it
        # enumerates verbs, and `extract`, `retrieve`, `get the price of`
        # and `name the top 5` all walked past it (external review,
        # 2026-08-27). A verb list is the wrong shape of answer to this.
        evidence.append("self_reported")
        proof = "done"
    return Verdict(True, proof, None, tuple(evidence))


VERIFIERS = {
    "general": verify_general,
    "key_used": verify_key_used,
    "value_present": verify_value_present,
    "value_present_quantity": verify_quantity_present,
    "value_present_status_code": verify_status_code_present,
    "value_present_code_point": verify_code_point_present,
    "value_present_status_word": verify_status_word_present,
    "block_present": verify_block_present,
}


#: Words that make a question about THIS ACCOUNT rather than about the
#: world. Deliberately tiny and possessive-only: measured on both corpora
#: before it was written (0 of 34 real-site tasks match, 10 of 18
#: behind-a-login fixture tasks match and all of them authenticate).
_ACCOUNT_SCOPED = re.compile(r"\b(my|our|mine|ours)\b", re.IGNORECASE)


def needs_a_session(said: str) -> bool:
    """Does this question ask about the user's own account?"""
    return bool(_ACCOUNT_SCOPED.search(said or ""))


def http_misread(trace: Trace | None, verdict: Verdict | None) -> bool:
    """Did a failure come from the HTTP-first read rather than the page?

    True when the run read server HTML instead of the browser render and
    the result did not verify. The render is the ground truth this product
    is measured against; the HTTP text is a shortcut, and a shortcut that
    misses must hand back to the browser, not stand as the verdict."""
    if trace is None or trace.transport != "http":
        return False
    return verdict is None or not verdict.passed


#: Tasks that want to be TOLD something, as opposed to tasks that want
#: something done. Kept to verbs that name the telling: a request to
#: "cancel my plan" is complete when the plan is cancelled, and must not be
#: asked for an answer it never promised.
_ASKS_FOR_INFORMATION = re.compile(
    r"\b(?:compile|summar(?:y|ise|ize)|"
    r"tell me|show me|what|which|how many|how much|"
    r"find out|look up|calculate)\b"
)
#: Dropped from the list above, and why. Each was refusing a task that had
#: been DONE, because the word does other work in ordinary English:
#:   list    "add me to the mailing list", "add it to my shopping list"
#:   note    "add a note to the calendar event"
#:   report  "report a bug on the issue tracker"
#:   output  "set the output format to PDF and save"
#:   give me "give me a refund on order 4471"
#:   identify "identify myself with the one-time code and log in"
#: The gate can afford to be narrow now: a task it MISSES no longer earns a
#: false `verified`, because a general run that read nothing is
#: self-reported whatever the phrasing (external review, 2026-08-27).


def verify(plan: Plan, trace: Trace, said: str = "", **kwargs: object) -> Verdict:
    """The postcondition, plus one precondition that belongs to the QUESTION.

    FOUND ON A REAL ACCOUNT (falsifier round 1, 2026-08-24): asked "what is
    MY current plan at supabase.com", the loop never logged in — it read a
    marketing testimonial off the public homepage, and every postcondition
    passed, because each asks "does this line carry the value the anchor
    names" and none asked whether the page was ever behind the login the
    question implies. It was admitted to memory and would have replayed.

    So: an account-scoped question read from an unauthenticated page is
    refused before its postcondition is even consulted. This can only ever
    NARROW, and its collateral was measured at zero on both sets before a
    line of it was written.
    """
    if said and needs_a_session(said) and not trace.authenticated:
        return Verdict(
            False,
            "that question is about your account, and this page was read "
            "without signing in — a public page cannot answer it",
            Reason.ABSTAINED_LOW_CONFIDENCE,
            ("account_scoped=true", "authenticated=false"),
        )
    if (
        plan.verify == "general"
        and said
        and _ASKS_FOR_INFORMATION.search(said.lower())
        and not (trace.block or trace.read)
    ):
        # The postconditions of a general plan check what it DID. A task
        # that asked a question is not answered by having acted: measured
        # on browser-use's WebBenchREAD task 14 (2026-08-27), a run asked
        # to "find events in San Francisco and list each title with its
        # ticket price range" typed the search, pressed Enter, verified
        # `confirmation_text=San Francisco`, and returned an answer of
        # "done" — labelled verified.
        return Verdict(
            False,
            "this asked for something to be found out, and the run acted "
            "without reading an answer — end the plan with read_value or "
            "read_block",
            Reason.ABSTAINED_LOW_CONFIDENCE,
            ("acted=true", "read=none"),
        )
    try:
        verifier = VERIFIERS[plan.verify]
    except KeyError as exc:  # pragma: no cover — accept() prevents this
        raise KeyError(
            f"no verifier named {plan.verify!r}; a plan with no postcondition "
            "should never have been accepted"
        ) from exc
    return verifier(plan, trace, **kwargs)


def as_json(verdict: Verdict) -> str:
    """For the ledger. Proof is kept verbatim; it is the evidence."""
    return json.dumps(
        {
            "passed": verdict.passed,
            "proof": verdict.proof,
            "reason": verdict.reason.value if verdict.reason else None,
            "evidence": list(verdict.evidence),
        },
        separators=(",", ":"),
    )
