"""What Rokan agrees to attempt — and what it refuses, before anything runs.

Every other agent product answers "can you do this?" with a model's guess and
finds out by trying. That is where the 20-33% success rates come from: the
attempt IS the classifier, and a wrong guess costs a real action on a real
account.

Here the answer is a lookup. A task is accepted only if it matches a class in
this file, with every required slot present. Precision is ~1.0 by
construction — not because the matcher is clever, but because it cannot say
yes to something it has no verifier for. The published number is therefore
**coverage** (what share of real requests we accept) and the refusal rate,
which are honest numbers a narrow gate can improve over time.

The inversion that matters: an over-narrow gate ABSTAINS, which is safe and
visible. A confident classifier MIS-ACCEPTS, which is neither. AgentOccam's
result points the same way — pruning the action space beat adding memory.

**No model runs in this file.** A gate that asks an LLM whether it can do
something has re-invented the guess it exists to prevent.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from urllib.parse import urlparse

from rokan_agent.core.reasons import Reason
from rokan_agent.core.result import Result, Status


@dataclass(frozen=True, slots=True)
class TaskRequest:
    """An accepted task: a class, a site, and the slots the class requires."""

    task_class: str
    site: str
    slots: dict[str, str] = field(default_factory=dict)
    #: The user's words, kept for the planner's prompt and the ledger. Never
    #: parsed for meaning after this point — the class is the meaning.
    said: str = ""


@dataclass(frozen=True, slots=True)
class TaskClass:
    """One thing Rokan knows how to do AND knows how to prove it did."""

    name: str
    #: Phrases that must appear for this class to be considered. Deliberately
    #: dumb: a regex cannot hallucinate a capability.
    triggers: tuple[str, ...]
    #: Slots the planner needs. A class whose slots cannot be filled from the
    #: request is refused with the missing slot named — never guessed.
    required_slots: tuple[str, ...]
    #: The verifier registry key. A class without one cannot exist here: if
    #: we cannot prove the task was done, we do not accept the task.
    verify: str
    #: One line for the refusal message's "what I can do" list.
    describes: str


#: Words that refuse a request outright, whatever else it contains.
#:
#: A request can hold a read trigger AND an action nobody should take on
#: someone's behalf: "wire $500 from my checking account, then check it went
#: out" contains "check" and was accepted as a read. The IR's verbs are
#: read-only, so nothing would have been wired — but a gate that says yes to
#: that sentence is not the gate this file claims to be, and the accepted
#: request would be counted in published coverage.
#:
#: Kept deliberately short. Each word here costs coverage on some innocent
#: phrasing, and the rule for adding one is that the action it names is
#: irreversible or spends money.
_NEVER = (
    "wire", "transfer", "withdraw", "deposit", "purchase", "buy", "pay",
    "cancel", "delete", "unsubscribe", "refund", "checkout", "top up",
    "add funds", "place an order", "place the order",
    # Destroying a credential, which this module's own docstring already
    # promised was refused and was not.
    #
    # Measured on a corpus of natural phrasings: "rotate my api key",
    # and equally "regenerate", "revoke", "reset" and "roll", were all
    # ACCEPTED — as `get_api_key`, the READ class. Two things follow, and
    # the second is the serious one. The user is answered with the key they
    # already had, so they believe a rotation happened that did not. And
    # the planner is handed the words "rotate my api key" against a page
    # with a Regenerate button, which it may well press — after which the
    # postcondition, "use the acquired key", PASSES on the new one. A
    # destructive irreversible action, reported as a success, on a class
    # the design excluded precisely because its failure mode locks a person
    # out of their own credential.
    "rotate", "regenerate", "revoke", "reset", "roll", "invalidate",
    "disable", "deactivate", "suspend", "remove", "close",
    # Creating a credential is rotating one, said differently. "get a new
    # api key" was accepted as the READ class, which is the rotate bug
    # wearing a different verb.
    "generate", "create", "issue", "get a new", "get another",
    "request a new", "get rid of",
    # Sending anything to a third party. "copy my api key to my clipboard
    # and email it to me" was accepted: the clause splitter did its job and
    # handed "email it to me" to a list that had no word for it.
    "email", "send", "share", "forward", "post", "upload",
    # Paying. `_MONEY` only sees an AMOUNT, and a checkout carries none —
    # "double check out with my saved card" was accepted, because "checkout"
    # is one word in this list and two in that sentence, and because the
    # positional rule looks at the clause opener, which was "double".
    #
    # Spelled out rather than solved by stripping "double" as filler: that
    # would turn "double my quota at acme.example" into "my quota at
    # acme.example", a read — trading one mis-accept for another.
    "check out", "double check out", "dispute", "switch", "upgrade",
    "downgrade", "book", "order", "press", "click", "add", "confirm",
)

#: A never-word introduced by an INDEFINITE article is the thing itself,
#: not a fact about it — and asking for the thing itself is asking for it
#: to happen.
#:
#: "show me a refund" and "check my refund status" differ by one word, and
#: only one of them is a read. The positional rule cannot separate them:
#: "refund" is mid-clause in both. Measured while widening the trigger list
#: from 52% to 92% coverage — without this, that widening accepted both
#: refund phrasings.
#:
#: Indefinite only. "the refund" is left alone deliberately: "check the
#: refund status" is an ordinary read, and refusing it would buy nothing.
_ASKS_FOR_ONE = re.compile(
    r"\b(?:a|an|another|new)\s+(?:" + "|".join(re.escape(w) for w in _NEVER) + r")\b",
    re.IGNORECASE,
)

#: Filler that can precede an instruction without changing it.
_POLITE = re.compile(
    r"^(?:please|kindly|can you|could you|would you|"
    r"i (?:want|need|would like)(?: you)? to|i'?d like(?: you)? to|"
    r"go(?: and| ahead(?: and| to)?)?|proceed to|make sure to|"
    r"now|just|and|then|also|next|after that|finally)\s+"
)

#: Where a new instruction can begin. A request is one or more of these, and
#: only the FIRST word of one is the thing being asked for.
_CLAUSE = re.compile(r"[,;.]|\bthen\b|\band then\b|\balso\b|\band\b")


def _asks_for(text: str) -> str:
    """The first `_NEVER` action this request actually ASKS for, or "".

    Position is the whole difference between an action and a noun. Matching
    the word anywhere refused "check my refund status", "how much did I pay
    last month", "read my transfer history" and "how many purchase orders
    are open" — all plain reads, all counted against coverage. So a word only
    refuses when it OPENS a clause, which is where an imperative lives:

        wire $500, then check it went out   -> "wire" opens the request
        check my balance then wire it       -> "wire" opens the second clause
        check my refund status              -> "refund" is a noun, mid-clause
    """
    for raw in _CLAUSE.split(text):
        clause = raw.strip()
        while True:
            shortened = _POLITE.sub("", clause)
            if shortened == clause:
                break
            clause = shortened
        for word in _NEVER:
            if clause.startswith(word) and (
                len(clause) == len(word) or not clause[len(word)].isalnum()
            ):
                return word
    return ""

#: An amount of money in the REQUEST. None of v1's classes need one — the
#: numbers they read live on the page, not in the sentence — so a request
#: carrying one is asking for something else.
_MONEY = re.compile(r"[$£€]\s?\d|(?<!\w)\d[\d,]*\s?(dollars|usd|eur|gbp|pounds)(?!\w)")

#: An amount that is a CRITERION rather than a payment: a ceiling, a floor,
#: a range. "Filter property listings with a maximum rent of $3000 and list
#: the addresses" spends nothing — it types a number into a filter — and
#: was refused with "Rokan reads and fetches; it does not spend or undo"
#: (browser-use WebBenchREAD task 12, 2026-08-27).
#:
#: This NARROWS the money guard, so it is deliberately grudging: the
#: constraint word must sit within a few words of the amount, and it is
#: only ever consulted when no write verb was found in the same sentence.
#: An amount with a verb on it — pay, send, buy, transfer — never reaches
#: here.
_MONEY_AS_CRITERION = re.compile(
    r"\b(?:maximum|max|minimum|min|under|below|over|above|at most|at least|"
    r"less than|more than|no more than|up to|between|cheaper than|"
    r"price range|budget|priced?)\b[^.]{0,24}?[$£€]?\s?\d"
    # A RANGE needs a currency on BOTH ends. Without that, "$20 to 3"
    # matched — and "move $20 to 3 of my contacts" is the grammar of a
    # payment, not of a price range (found independently by two reviewers,
    # 2026-08-27).
    r"|[$£€]\s?\d[\d,]*\s?(?:-|to|–|—)\s?[$£€]\s?\d"
)

#: Verbs that SPEND, wherever they sit in the sentence. `_asks_for` only
#: catches a word that opens a clause, so "…under $50 and complete the
#: checkout" walked past it — the money guard was the only thing stopping
#: that request, and narrowing it let the request through.
#:
#: The rule both reviewers arrived at independently: an amount may decide
#: ROUTING and must never decide PERMISSION. So a spend verb anywhere in
#: the sentence beats any criterion grammar, and when the grammar is wrong
#: — and it will be again — the cost is a mis-routed task, not a payment.
_SPENDS = re.compile(
    # Unambiguous: these words only ever spend.
    r"\b(?:pay|paying|purchase|purchasing|buy|buying|checkout|check\s+out|"
    r"subscribe|subscribing|donate|donating|withdraw|deposit|"
    r"transfer|transferring|pre-?order)\b"
    # Ambiguous as nouns — "maximum RENT of $3000" is a filter, "RENT a car"
    # is a spend; "the BOOK under $20" is a filter, "BOOK a table" is a
    # spend. So these count only with a determiner or a quantity on them.
    r"|\b(?:rent|renting|book|booking|order|ordering|reserve|reserving|"
    r"tip|tipping|charge|charging|send|sending|secure|securing|"
    r"complete|finish|confirm)\s+"
    r"(?:a|an|the|it|them|this|that|my|two|three|four|five|\d+)\b"
    # Phrases whose whole meaning is completing a transaction.
    r"|\b(?:complete|finish|go\s+through(?:\s+with)?|put\s+through)\s+"
    r"(?:the\s+|my\s+)?(?:purchase|order|booking|checkout|payment|transaction)\b"
    r"|\bplace\s+(?:the|my|an?)\s+order\b"
)


def money_is_a_criterion(lowered: str) -> bool:
    """Is the amount in this request a filter, and nothing more?

    A spend verb ANYWHERE in the sentence answers no, whatever the grammar
    around the number looks like. That ordering is the whole point: the
    grammar decides how a request is routed, and never whether it is
    allowed.
    """
    if _SPENDS.search(lowered):
        return False
    return bool(_MONEY_AS_CRITERION.search(lowered))

#: A credential in the REQUEST itself. Either a marker word bound to a value,
#: a bare one-time code, or a token with a recognisable vendor prefix.
#: A credential in the REQUEST itself.
#:
#: The separator is OPTIONAL, because "my password hunter2" is how half of
#: people type it and the first version required "is", "=" or ":" — so the
#: one phrasing the registered eval entry used was the one phrasing the
#: regex caught, and the set was scoring the regex against itself.
#: A marker word bound to a value, with the copula optional and the SPACE
#: allowed inside "api key" — the literal phrase this product uses everywhere.
#: The value is judged, not merely measured: see `_pasted_secret`.
_SECRET_INTRO = re.compile(
    r"(?:password|passwd|pwd|secret|token|passphrase|recovery phrase|"
    r"seed phrase|api[\s_-]?key|access[\s_-]?key|credentials?|key)"
    r"\s*(?:is|are|=|:)?\s+(\S+)",
    re.IGNORECASE,
)

#: Shapes that are a credential on sight, wherever they appear.
_SECRET_SHAPE = re.compile(
    r"(?:^|\s)(?:otp|code|2fa|pin)\s*(?:is|=|:)?\s*\d{4,8}(?!\w)"
    r"|(?<![A-Za-z0-9_-])(?:sk|pk|rk|re|ghp|gho|ghs|github_pat|xox[bpasr]|shpat)"
    r"[_-][A-Za-z0-9_-]{12,}"
    r"|(?<![A-Za-z0-9_-])(?:AKIA|ASIA|AIza|ya29)[A-Za-z0-9_-]{8,}"
    r"|(?<![A-Za-z0-9_-])eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_.-]{8,}"
    # A long hex or base64 run is a digest or a token whatever precedes it.
    # Nothing a person types into a request looks like this.
    r"|(?<![A-Za-z0-9])[0-9a-f]{32,}(?![A-Za-z0-9])"
    r"|(?<![A-Za-z0-9+/=])[A-Za-z0-9+/]{28,}={0,2}(?![A-Za-z0-9+/=])",
    re.IGNORECASE,
)

#: Markers whose value is EXPECTED to be ordinary words. A mnemonic is
#: twelve dictionary words on purpose, so every entropy or word-shape test
#: says "prose" about the one thing here that is never prose. What gives it
#: away is the run of them.
#: Refused on MENTION, not on shape — the only topic here treated that way.
#:
#: A mnemonic is twelve dictionary words on purpose, so every entropy test
#: and every word-shape test calls it prose. Trying to tell a pasted one from
#: a question about one produced errors in both directions, and the two
#: errors are not comparable: refusing "check my recovery phrase status"
#: costs a person one retyped sentence, and missing a pasted seed phrase
#: sends the keys to someone's savings to a model provider, irreversibly.
#:
#: There is also no read here worth having. Rokan has no task whose answer is
#: a seed phrase, so nothing is lost by declining the subject entirely.
_PHRASE_MARKER = re.compile(
    r"(?:recovery|seed|backup)\s+phrase|mnemonic|passphrase", re.IGNORECASE
)

#: Words that follow a marker in an ordinary REQUEST rather than a paste:
#: "read my token expiration date", "check the secret scanning results".
#: Without this, any marker followed by a long word refused a plain read and
#: told the user to store a credential they never typed.
_ABOUT_NOT_A_VALUE = frozenset({
    "expiration", "expiry", "rotation", "scanning", "settings", "page",
    "history", "usage", "status", "list", "count", "limit", "policy",
    "policies", "requests", "quota", "permissions", "scopes", "name",
    "names", "id", "ids", "for", "from", "at", "on", "in", "of", "and",
    "the", "my", "a", "an",
})


#: The credential-shaped things that legitimately appear in a URL — and the
#: ones that never do. A path segment is a location; a query parameter named
#: `token` is a credential someone pasted.
_URL_CREDENTIAL = re.compile(
    r"[?&#](?:token|api[_-]?key|key|password|passwd|secret|access[_-]?token)"
    r"=[^&\s]{6,}",
    re.IGNORECASE,
)


def _pasted_secret(text: str, site: str = "") -> bool:
    """Did the user paste a credential into the request itself?

    Two ways to be wrong here and both are real. Missing one sends it to a
    model provider in the prompt, verbatim. Firing on "read my token
    expiration date" refuses a plain read and tells the person to store a
    credential they never typed.

    So a marker word alone decides nothing: what follows it is judged. An
    ordinary English word after "token" is a request ABOUT a token; a run of
    characters with no business being a word is a token.
    """
    # The URL is a LOCATION, and it is judged on its own terms.
    #
    # `_SECRET_SHAPE` looks for long mixed-case runs, and a deep link is one:
    # "US/docs/Web/HTTP/Reference/Status/404" matched the base64 rule and the
    # gate refused a perfectly ordinary MDN link as a pasted credential. The
    # fixture set could never find this — its URLs are `127.0.0.1:PORT/console`
    # — and a real-site run found it on the first try.
    #
    # Removing the URL from the prose scan does NOT stop a credential inside a
    # URL being refused: `_URL_CREDENTIAL` looks for one where it would
    # actually be, in the query or the fragment, and a path segment is not
    # that.
    if site:
        if _URL_CREDENTIAL.search(site):
            return True
        bare = site.split("://", 1)[-1]
        text = text.replace(site, " ").replace(bare, " ")
    if _SECRET_SHAPE.search(text) or _PHRASE_MARKER.search(text):
        return True
    for match in _SECRET_INTRO.finditer(text):
        value = match.group(1).strip(".,;:!?\"'")
        if not value or value.lower() in _ABOUT_NOT_A_VALUE:
            continue
        if value.isalpha() and value.islower() and len(value) < 12:
            # A short all-lowercase word is prose. "hunter2" is not — it has
            # a digit — and neither is "S3cretPass".
            continue
        if len(value) >= 6:
            return True
    return False


def _says(text: str, trigger: str) -> bool:
    """Does the text contain this trigger as WORDS, not as letters?

    A bare substring test made the gate accept "delete the thread",
    "unsubscribe already", and "spread the word" as read_value, because
    "read" hides inside thread, already and spread. It also accepted "wire
    $500 from my checking account, then check it went out" — a money task,
    which this module's own docstring promises is refused.

    That is a mis-accept, the dangerous direction, and it made the claim of
    precision-by-construction false: the construction was a substring search.
    """
    return re.search(rf"(?<!\w){re.escape(trigger)}(?!\w)", text) is not None


#: v1 is TWO classes, deliberately.
#:
#: `get_api_key` is the only class with an end-to-end proof in this repo (the
#: gauntlet acquired a key on a real site and then USED it — an authenticated
#: 200 is a postcondition no story can fake). `read_value` is the highest
#: frequency ask and verifies against anchors already twice-adversarially
#: reviewed.
#:
#: Not here, on purpose: `rotate_api_key` (its failure mode locks the user out
#: of their own credential), anything involving money, orders, third parties,
#: or multi-step chains. Those are not "coming soon" — they are refused until
#: a verifier exists for them.
CLASSES: tuple[TaskClass, ...] = (
    TaskClass(
        name="get_api_key",
        triggers=("api key", "api token", "access key", "secret key"),
        required_slots=("site",),
        verify="key_used",
        describes="get an API key from a service you have an account on",
    ),
    TaskClass(
        name="read_list",
        triggers=(
            "list the", "list all", "list every", "name the", "give me the top",
            "top 5", "top 10", "first 5", "first 10", "the first ",
            "all the", "every ", "each of the",
            # Ways of asking for a list that this vocabulary did not know.
            # Measured on browser-use's WebBenchREAD (2026-08-27): "compile
            # a list of the suggested ingredient substitutions" was refused
            # at the door in under a millisecond, with a message offering
            # to read a list.
            "compile a list", "a list of", "list of the", "output the",
        ),
        required_slots=("site",),
        verify="block_present",
        describes="read a run of rows the page already shows, in the page's own order",
    ),
    TaskClass(
        name="read_value",
        triggers=(
            "read", "how much", "how many", "what is", "what's", "check",
            "balance", "usage", "status", "how far", "when is",
            "which", "when", "where", "who", "why", "how long",
            "show me", "look up", "give me", "tell me", "remind me",
            "do i have", "am i", "has my", "was my", "is my", "is the",
            "find", "get the", "get my",
            # Same measurement: "identify the headline of the top breaking
            # news article and note its publication time" named a page, a
            # value and where it sits, and matched nothing.
            "identify", "note the", "note its",
        ),
        required_slots=("site",),
        verify="value_present",
        describes="read a number or status from a page behind your login",
    ),
)

_BY_NAME = {task_class.name: task_class for task_class in CLASSES}

#: Comma-separated task class names this process may accept — the names in
#: `CLASSES` plus ``general``. Unset or empty: every class, today's
#: behaviour. A deployment that should only READ sets
#: ``ROKAN_TASK_CLASSES=read_value,read_list`` and the gate refuses the
#: rest at the door, in the same words it refuses a write.
_TASK_CLASSES_ENV = "ROKAN_TASK_CLASSES"


def _allowed_classes() -> frozenset[str] | None:
    """The classes this process may accept, or None for "all of them".

    Read on every call, not at import: the MCP gateway and the tests both
    set the environment after this module is loaded. Tolerant of the ways a
    hand-typed list goes wrong — spaces, a trailing comma, mixed case —
    because a value that fails to parse must not silently mean "all".
    """
    raw = os.environ.get(_TASK_CLASSES_ENV, "")
    names = frozenset(part.strip().lower() for part in raw.split(",") if part.strip())
    return names or None


def _class_allowed(name: str) -> bool:
    allowed = _allowed_classes()
    return allowed is None or name in allowed


def _refused_out_of_class(refused_on: str) -> Result:
    """The one refusal for "Rokan does not do that here" — a write, an
    amount of money, or a class this deployment has switched off. One
    shape, so a caller that handles the refusal handles all three."""
    return Result(
        status=Status.ABSTAINED,
        reason=Reason.ABSTAINED_NO_REPAIR_CLASS,
        next_step=(
            "Rokan reads and fetches; it does not spend or undo. Ask for "
            "the part it can prove — for example: "
            'rokan-do "read my balance at <site>"'
        ),
        evidence=[
            f"refused_on={refused_on}",
            *[f"can_do={d}" for d in classes_offered()],
        ],
    )

#: A full URL, a dotted host, or a host:port (which is how a local fixture or
#: a dev server is named — the first real planner run was refused because
#: `127.0.0.1:8477` has no TLD). Anchored so ordinary prose is never mistaken
#: for a site.
_SITE = re.compile(
    r"\b(?:"
    r"https?://[^\s]+"
    r"|(?:[a-z0-9-]+\.)+[a-z]{2,}(?::\d{2,5})?(?:/[^\s]*)?"
    r"|(?:\d{1,3}\.){3}\d{1,3}(?::\d{2,5})?(?:/[^\s]*)?"
    r"|localhost(?::\d{2,5})?(?:/[^\s]*)?"
    r")\b",
    re.IGNORECASE,
)


def _find_site(text: str) -> str | None:
    match = _SITE.search(text)
    if match is None:
        return None
    raw = match.group(0).rstrip(".,;:!?")
    if not raw.lower().startswith(("http://", "https://")):
        # Local hosts do not serve https. Forcing the scheme sent the first
        # real planner run to https://127.0.0.1:8477, which cannot connect —
        # a wrong plan produced by the gate, not the model.
        host = raw.split("/", 1)[0].split(":", 1)[0].lower()
        local = host in {"localhost", "127.0.0.1", "0.0.0.0", "::1"}
        raw = ("http://" if local else "https://") + raw
    parsed = urlparse(raw)
    return raw if parsed.netloc else None


def classes_offered() -> tuple[str, ...]:
    return tuple(
        task_class.describes for task_class in CLASSES if _class_allowed(task_class.name)
    )


def strip_locations(text: str) -> str:
    """The text with every URL-shaped token removed, by PATTERN.

    Byte-exact `said.replace(site, " ")` was the first implementation and
    the Opus review proved it wrong three ways: discovery REWRITES the site
    before planning, so the user's typed URL was no longer the string being
    stripped; a capitalised host never matched the lowercased parse; and
    the same defect lived a second life in memory's question matcher. One
    pattern (`_SITE`, the same regex that parses sites in) strips them all,
    case-insensitively, wherever they appear.
    """
    return _SITE.sub(" ", text)


#: Longest request Rokan will consider. Generous for a sentence and far
#: below a paste: a 108 KB task was accepted in 29ms and carried verbatim
#: into `Task: {said}` on every rung, so one paste accident billed ~27K
#: tokens three times over. The page text has always been truncated; the
#: user's own words were not truncated anywhere.
MAX_TASK_CHARS = 400


#: A NAMED SUB-LOCATION of the site: "the Text Effect section", "the TV
#: shows category", "the APA research database portal", the "Keto Pancakes"
#: recipe page. Reaching one means clicking a link, and a read class may
#: only navigate to the URL it was given — a plan is forbidden from
#: inventing `apa.org/pubs/databases`, and rightly so.
#:
#: Measured on browser-use's WebBenchREAD (2026-08-27): "Access the APA
#: research database portal and list all available databases" navigated to
#: apa.org, looked for "APA PsycInfo" on the homepage, and refused. Seven
#: of the twenty name a section this way.
#:
#: "browse" and "open" are here only WITH such a word. On their own they
#: describe arriving somewhere, which a read class does — and "On the Daily
#: Mail homepage, identify the headline" must stay a plain read.
_NAMES_A_SECTION = re.compile(
    r"\b(?:browse|open|access|visit|navigate\s+to|go\s+to|explore)\b"
    r"[^.]{0,70}?"
    r"\b(?:section|category|categories|portal|tab|sub-?page|"
    r"recipe\s+page|product\s+page|listing\s+page|archive)\b"
)

#: Verbs that name work the page has to be MADE to do before there is
#: anything to read. Deliberately narrow: each one describes changing what
#: the page shows, not merely looking at part of it. "browse", "open",
#: "view" and "go to" are NOT here — they describe arriving somewhere, and
#: a read class can navigate. "log in" is not here either: an existing
#: coverage test holds that "log in to acme.example and wait for me" stays
#: out of class, and it is right to — the out-of-class half of a request
#: must not be smuggled in by the half we can route.
_NEEDS_AN_ACTION_FIRST = re.compile(
    r"\b(?:"
    r"search(?:\s+(?:for|the))?|"
    r"use\s+(?:the\s+)?(?:advanced\s+)?(?:search|filter|sort)|"
    r"filter(?:\s+(?:for|by|the))?|"
    r"sort(?:\s+by)?|"
    r"apply\s+(?:a\s+|the\s+)?filters?"
    r")\b"
)


def accept(said: str) -> TaskRequest | Result:
    """Accept a task, or refuse it with something the user can act on.

    Returns a TaskRequest when the request matches a class with all slots
    filled; otherwise an abstention (exit 0 — declining is a result, not a
    crash) naming what Rokan can do instead.
    """
    text = (said or "").strip()
    if not text:
        return Result(
            status=Status.ABSTAINED,
            reason=Reason.ABSTAINED_LOW_CONFIDENCE,
            next_step='Run: rokan-do "get my api key from <a site you use>"',
            evidence=[f"can_do={d}" for d in classes_offered()],
        )

    if len(text) > MAX_TASK_CHARS:
        return Result(
            status=Status.ABSTAINED,
            reason=Reason.ABSTAINED_LOW_CONFIDENCE,
            next_step=(
                f"That is {len(text)} characters. Ask for one thing in a "
                'sentence — for example: rokan-do "read my usage at <site>"'
            ),
            evidence=[f"length={len(text)}", f"max={MAX_TASK_CHARS}"],
        )

    lowered = text.lower()

    # A credential the USER pasted. The IR refuses literal secrets in plan
    # arguments, but `said` goes into the planner's prompt verbatim and into
    # the stored task record — so "read the usage at acme.com, my password is
    # hunter2" sent that password to a model provider. The planner's claim
    # that it "could not leak what it never held" is only true if this
    # refuses first.
    if _pasted_secret(text, site=_find_site(text) or ""):
        return Result(
            status=Status.ABSTAINED,
            reason=Reason.ABSTAINED_NO_REPAIR_CLASS,
            next_step=(
                "That looks like a credential. Don't paste one into a task — "
                "it would go to your model provider in the prompt. Store it "
                'once with: rokan save-login <site>'
            ),
            evidence=["refused_on=a credential in the request"],
        )

    # Checked BEFORE the triggers, so a sentence that asks for both a read
    # and an irreversible action is refused rather than accepted for the half
    # we happen to have a verifier for.
    asks_for_one = _ASKS_FOR_ONE.search(lowered)
    blocked = _asks_for(lowered) or (asks_for_one.group(0) if asks_for_one else "")
    if blocked or (_MONEY.search(lowered) and not money_is_a_criterion(lowered)):
        return _refused_out_of_class(blocked or "an amount of money")

    # A read that cannot happen until something is DONE first belongs to
    # general mode, which can act. The read classes navigate and read; they
    # cannot search, filter or sort, so a task built on one of those was
    # answered from whatever the landing page happened to show.
    #
    # Measured on browser-use's own WebBenchREAD (2026-08-27): ELEVEN of
    # its twenty tasks open with an instruction to search, filter or sort,
    # and every one of them came here. "Use the advanced search to filter
    # movies released in 2022 and output the first 5 results with their
    # average ratings" matched `read_list` on "the first 5", read the
    # landing page, and answered with themoviedb's keyboard shortcuts.
    if (
        _NEEDS_AN_ACTION_FIRST.search(lowered) or _NAMES_A_SECTION.search(lowered)
    ) and _find_site(text) is not None:
        # Refused, not fallen through: with `general` switched off, letting
        # this reach the read classes would re-open the landing-page bug
        # above — a search task "matched" as a read and answered wrongly.
        if not _class_allowed("general"):
            return _refused_out_of_class("class=general")
        return accept_general(text)

    # First match wins, and CLASSES is ordered most-specific first: "get my
    # api key" contains "get" AND "key", and must not fall into read_value.
    for task_class in CLASSES:
        if not any(_says(lowered, trigger) for trigger in task_class.triggers):
            continue
        if not _class_allowed(task_class.name):
            return _refused_out_of_class(f"class={task_class.name}")
        site = _find_site(text)
        if site is None and "site" in task_class.required_slots:
            return Result(
                status=Status.ABSTAINED,
                reason=Reason.ABSTAINED_LOW_CONFIDENCE,
                # NOT "add --discover". Discovery searches WITHIN a service —
                # it finds which page of vercel.com shows your usage — so it
                # cannot supply the service itself, and advising it here sent
                # people to a flag that would refuse them a second time.
                next_step=(
                    'Name the site: rokan-do "' + text[:40] + ' from <site>"'
                    " — then --discover can find the right page on it."
                ),
                evidence=["missing=site"],
            )
        return TaskRequest(
            task_class=task_class.name,
            site=site or "",
            slots={"site": site or ""},
            said=text,
        )

    # Deliberately built rather than routed through `Result.abstained`: that
    # helper fills guidance from the shared reason table, whose text belongs
    # to the watcher ("run rokan check <id>") and would send a `do` user to a
    # command that has nothing to do with their request. The class is still
    # named, the exit code is still 0, and the guidance is still mandatory —
    # only the words are ours.
    return Result(
        status=Status.ABSTAINED,
        reason=Reason.ABSTAINED_NO_REPAIR_CLASS,
        next_step=(
            "Run: rokan-do can — to see what Rokan accepts. This is refused "
            "not because it is hard, but because Rokan cannot prove it worked."
        ),
        evidence=[f"can_do={d}" for d in classes_offered()],
    )


#: Nouns whose value is a QUANTITY, so the answer has a number in it.
#:
#: The question constrains the answer, and the gate is the only place that
#: sees the question. Measured across nineteen real sites: every task
#: naming one of these has a numeric answer, and every task whose answer is
#: text — "Not Found", "DISTINCT", "Reserved Top Level DNS Names" — names
#: none of them.
#:
#: NOT here, deliberately: "code" and "status". A status code is a number
#: and a status is not, and "read the status code name" answers with "Not
#: Found". A word that is a quantity only sometimes buys nothing and costs
#: a correct answer.
_QUANTITY = (
    "timeout", "interval", "size", "limit", "length", "rate", "count",
    "number", "amount", "digits", "requests", "redirects", "seats",
    "quota", "usage", "price", "capacity", "duration",
)


def _asks_for_a_quantity(said: str) -> bool:
    """Does the question name something measured in numbers?

    Matched at IDENTIFIER boundaries, which is neither a plain substring
    nor a word boundary, and both of the simple answers are wrong here:

    * a substring search reads "account" as "count", and the fixture
      caught it — `read the account email` was held to a quantity and
      refused for having no number in it;
    * a word-boundary search misses `keepalive_timeout` and
      `scrape_interval`, because `_` is a word character, and those are
      exactly the cases this exists for.

    So: preceded by something that is not a letter or digit — which an
    underscore satisfies — or capitalised inside camelCase, which is how
    `poolSize` and `MaxKeepAliveRequests` name their quantity.
    """
    return any(
        re.search(
            rf"(?<![A-Za-z0-9]){re.escape(word)}|(?<=[a-z]){re.escape(word.capitalize())}",
            said,
        )
        for word in _QUANTITY
    )


#: A question about a STATUS CODE names the one type on this product's
#: surface with a fixed, definition-backed shape: an HTTP status code is
#: exactly three digits (RFC 9110 §15). That is not a guess about answers —
#: it is what the words mean — so the verifier can hold the read to it.
#:
#: Measured need: "which status code is unused" was answered, on all three
#: passes of the frozen set, with a note about a code's age — a line whose
#: digits are a year, an RFC number and a section number, none of them a
#: standalone three-digit run. A digit rule admits it; the type refuses it.
#:
#: EXCLUDED: a question about the code's NAME or MEANING, whose answer is
#: text by the same definition that makes the code numeric. "read the
#: status code name" answers "Not Found", and holding that to three digits
#: would refuse a correct answer — the one direction this routing must
#: never take.
#: Hyphenated and closed-up spellings count: people write "status-code"
#: and "codepoint", and a miss returns the question to the generic
#: verifier — that is, to the measured wrong answer (Opus review, F11).
_STATUS_CODE = re.compile(r"\bstatus[-\s]+code\b", re.IGNORECASE)
#: The exclusion is about the question's SUBJECT, not any occurrence of
#: the word: "which status code MEANS gone" asks WHICH code (answer 410)
#: and the first version refused to type it because "means" appeared.
#: Only a question about the name, or a "what does … mean" question, is
#: asking for text.
_ABOUT_THE_CODE_NOT_ITS_VALUE = re.compile(
    r"\b(?:name|named|called|description|reason|meaning)\b"
    r"|\bwhat\s+does\b.*\bmeans?\b",
    re.IGNORECASE,
)


def _asks_for_a_status_code(said: str) -> bool:
    """Does the question ask WHICH status code, rather than about one?"""
    return bool(
        _STATUS_CODE.search(said)
        and not _ABOUT_THE_CODE_NOT_ITS_VALUE.search(said)
    )


#: A question about a CODE POINT names the second type on this surface with
#: a definition-backed shape: the Unicode Standard's own notation for a
#: code point is U+ followed by hex digits (U+0041, U+10FFFF).
#:
#: Measured need: "what is the highest Unicode code point" was answered on
#: all three passes of the extended set with the SURROGATES paragraph — a
#: line that mentions code points and states none. Its ranges are written
#: D800(subscript 16), so it carries no U+ token at all, while the correct
#: line reads "U+0000..U+10FFFF". The type separates them completely.
#:
#: SINGULAR only, deliberately: "how many code points…" asks for a COUNT,
#: whose answer is a number with no U+ in it, and holding it to the code
#: point shape would refuse a correct answer. The name/meaning exclusion is
#: shared with the status-code routing for the same reason it exists there.
#: `[-\s]*` admits "code-point" and "codepoint"; the old `(?!s)` was dead
#: (`point\b` already cannot match inside "points") and is gone.
_CODE_POINT = re.compile(r"\bcode[-\s]*point\b", re.IGNORECASE)


#: "what is the current status", "is X up", "any incidents" — a question
#: whose answer is a SYSTEM STATE, not a number. Measured on the pre-warm
#: batch (2026-08-25): 6 of 20 status pages "verified" a heading — "System
#: status", "Powered by Atlassian Statuspage", a nav line — because
#: `value_present` only asks whether the anchor is on the page.
#:
#: An EXIT status or RETURN status is a number a program hands back, not a
#: state a system is in. Measured on man7.org (head-to-head, 2026-08-25):
#: "what is the exit status for serious trouble" read the right line —
#: `2  if serious trouble (e.g., cannot access command-line argument)` —
#: and was refused for holding no state word. Same family as "status code".
_STATUS_WORD_ASK = re.compile(
    r"(?<!\bexit\s)(?<!\breturn\s)\b(?:current\s+)?status\b(?!\s*code)"
    r"|\bincidents?\b|\boutage\b|\bis\b[^?.]{0,40}?\b(?:up|down)\b",
    re.IGNORECASE,
)


#: "how many incidents" is a COUNT, whatever word follows (Opus round 9).
_A_COUNT = re.compile(r"\bhow many\b", re.IGNORECASE)


def _asks_for_a_status(said: str) -> bool:
    """Does the question ask what STATE a system is in? Not when it asks
    how MANY of something — that is a quantity, routed as before."""
    if _A_COUNT.search(said):
        return False
    return bool(_STATUS_WORD_ASK.search(said)) and not _STATUS_CODE.search(said)


def _asks_for_a_code_point(said: str) -> bool:
    """Does the question ask WHICH code point, rather than about one?"""
    return bool(
        _CODE_POINT.search(said)
        and not _ABOUT_THE_CODE_NOT_ITS_VALUE.search(said)
    )


def accept_general(said: str, *, allow_write: bool = False) -> TaskRequest | Result:
    """The door for `rokan_browse`: any task, on a named site, with a write
    only through the human's grant.

    Free text through `accept()` never reaches this class. Here the same
    refusals run first — empty, too long, a pasted credential — then the
    write rule: a task that asks for a `_NEVER` action (or names an amount
    of money) runs only when the caller said ``allow_write`` AND a grant
    for that action on that site exists (`policy.allow`). The refusal names
    the exact command; an agent cannot grant itself the door.
    """
    from . import policy  # noqa: PLC0415 — policy imports this module

    text = (said or "").strip()
    early = accept(text) if not text or len(text) > MAX_TASK_CHARS else None
    if isinstance(early, Result):
        return early
    if not _class_allowed("general"):
        return _refused_out_of_class("class=general")
    if _pasted_secret(text, site=_find_site(text) or ""):
        return Result(
            status=Status.ABSTAINED,
            reason=Reason.ABSTAINED_NO_REPAIR_CLASS,
            next_step=(
                "That looks like a credential. Don't paste one into a task — "
                "it would go to your model provider in the prompt. Store it "
                "once with: rokan save-login <site>"
            ),
            evidence=["refused_on=a credential in the request"],
        )
    site = _find_site(text)
    if site is None:
        return Result(
            status=Status.ABSTAINED,
            reason=Reason.ABSTAINED_LOW_CONFIDENCE,
            next_step='Name the site: "' + text[:40] + ' at <site>"',
            evidence=["missing=site"],
        )
    lowered = text.lower()
    host = site.split("://", 1)[-1].split("/", 1)[0].lower()
    needed: list[str] = []
    asked = policy.action_asked(lowered)
    if asked:
        needed.append(asked)
    # PARITY WITH `accept()`. This door is the one other agents call over
    # MCP, and it was the weaker of the two: `accept()` refuses "book a
    # table", "add the widget to my cart", "press publish", "roll my api
    # key" on `_asks_for`/`_ASKS_FOR_ONE`, while here `action_asked` mapped
    # none of them to a grant and they arrived with `action=''` — accepted,
    # with nothing asked of the human (two reviewers, independently,
    # 2026-08-27).
    #
    # A word this door cannot map to a named grant still demands one: it is
    # named as the action itself, so the human is asked in its own words
    # rather than not asked at all.
    asks_one = _ASKS_FOR_ONE.search(lowered)
    unmapped = _asks_for(lowered) or (asks_one.group(0) if asks_one else "")
    if unmapped and unmapped not in needed:
        needed.append(unmapped)
    if _MONEY.search(lowered) and "pay" not in needed and not money_is_a_criterion(lowered):
        # An amount of money is a payment however the verb is spelled —
        # unless it is a ceiling, a floor or a range, which is a number
        # typed into a filter and spends nothing.
        needed.append("pay")
    if needed:
        if not allow_write:
            return Result(
                status=Status.ABSTAINED,
                reason=Reason.NEEDS_APPROVAL,
                next_step=(
                    f"This asks to {needed[0]} on {host}. Call again with "
                    "allow_write=true — and only if the human has granted it: "
                    f"rokan-do allow {host} {needed[0]}"
                ),
                evidence=[f"write={a}" for a in needed],
            )
        missing = [a for a in needed if not policy.permits(host, a)]
        if missing:
            return Result(
                status=Status.ABSTAINED,
                reason=Reason.NEEDS_APPROVAL,
                next_step=(
                    f"A person must grant this once, in their own terminal: "
                    f"rokan-do allow {host} {missing[0]}"
                ),
                evidence=[
                    *[f"write={a}" for a in needed],
                    *[f"missing_grant={a}" for a in missing],
                ],
            )
    return TaskRequest(
        task_class="general",
        site=site,
        slots={
            "site": site,
            "action": needed[0] if needed else "",
            # Travels to `cascade.execution_policy`, which builds the
            # dispatch-time check from it. Never inferred downstream.
            "allow_write": "true" if allow_write else "false",
        },
        said=text,
    )


def verifier_for(task_class: str, said: str = "", site: str = "") -> str:
    """The postcondition key a class MUST pass. Raises for unknown classes —
    an accepted task with no verifier would be exactly the thing this module
    exists to make impossible.

    A `read_value` task that asks for a QUANTITY gets the stricter
    postcondition, because the question tells us the answer has a number in
    it and the verifier otherwise cannot tell a line that states the value
    from one that merely mentions the subject. Four of nineteen real-site
    tasks were confidently wrong exactly there — answering "what is the
    default keepalive_timeout" with the directive's `Syntax:` row.

    The QUESTION routes, never the URL. Caught while pre-flighting the
    extended real-site set: "how many subrequests … at
    developers.cloudflare.com/workers/platform/limits" routed to the
    quantity postcondition on the word "limit" — from the PATH. A text
    answer at any /limits or /size URL would be wrongly held to digits.
    Same lesson, third appearance (memory's recall matcher learned it
    twice): the URL is location, and it is stripped as a SUBSTRING before
    any routing word is looked for.
    """
    if task_class == "general":
        # General mode proves itself by the postconditions the plan
        # declares (`verify.verify_general`), not by a value shape.
        return "general"

    try:
        base = _BY_NAME[task_class].verify
    except KeyError as exc:  # pragma: no cover — accept() cannot produce this
        raise KeyError(f"{task_class!r} is not an accepted class") from exc
    # Pattern-based, not byte-exact — the site parameter is kept for call
    # sites that have it, but the strip no longer depends on it matching
    # the URL as typed (discovery rewrites `site`; users capitalise).
    if site:
        said = said.replace(site, " ").replace(site.split("://", 1)[-1], " ")
    said = strip_locations(said)
    if base == "value_present" and said:
        # Most specific first: a named type ("status code", "code point")
        # is a stronger promise than "some number".
        if _asks_for_a_status_code(said):
            return "value_present_status_code"
        if _asks_for_a_code_point(said):
            return "value_present_code_point"
        if _asks_for_a_status(said):
            return "value_present_status_word"
        if _asks_for_a_quantity(said):
            return "value_present_quantity"
    return base
