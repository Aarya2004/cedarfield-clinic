"""The endpoint the site's own code names — a second way to compile.

`compile_op` finds the endpoint by scoring the responses a page load fired
against what the page showed. That needs the data to have arrived as a
response the page fetched. A server-rendered page that ALSO exposes an
endpoint — a Statuspage that renders "All Systems Operational" into the
HTML and ships `/api/v2/status.json` in its bundle — never fires that
response on load, so the identifier has nothing to score and the operation
stays on the render path at ~3 s.

This module reads the bundles the recording already captured (the recorder
keeps every textual body, JavaScript included), lists the GET endpoints the
site's code names on its own host, fetches the few plausible ones INSIDE
the user's session, and compiles the first whose body carries the value
the verifier just read. Measured 2026-08-26 (`source-lever-q1-q3`): where
the endpoint exists it answers in 8–41 ms, exact.

Every guard `compile_op` applies still applies: same host only, GET only,
the value must be locatable in the body, and the operation is re-verified
on its first replay. Nothing here bypasses the quarantine.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
from collections import Counter
from collections.abc import Awaitable, Callable
from dataclasses import replace
from datetime import UTC, datetime
from urllib.parse import urljoin, urlsplit, urlunsplit

from rokan_mcp.identify import RecordedResponse, RecordedSession

from .compile_op import SyntheticOperation, locate_agreeing_paths
from .source_surface import Affordance, extract, script_urls

#: How many source-named endpoints one compile may fetch. Each is an
#: in-session GET on the site the user is already on; three is enough to
#: pick a `status.json` over a `subscribers/count.json`.
MAX_TRIES = 3

#: Paths that name infrastructure, not the page's data. Every one of these
#: appeared on the 2026-08-26 set and none carries an answer.
_NOT_DATA = re.compile(
    r"recaptcha|analytics|prebid|/events?\b|csrf|logged_in_user|session|"
    r"chooseServer|refreshCreds|jserrorlogging|subscribers?\b|track|metrics|"
    r"telemetry|beacon|/auth\b|/me\b|login|logout|\.css$|\.js$|\.png$|\.svg$",
    re.IGNORECASE,
)
#: A path with a parameter cannot be called without a value for it.
_HAS_PARAM = re.compile(r"[:{}$]|\{\w+\}|/:\w+")

#: A path may be probed only on POSITIVE evidence that it reads.
#:
#: The previous rule was a denylist, and a denylist written against one
#: example catches that example: `/api/v2/subscription/cancel` was
#: refused while `/api/v2/cancelSubscription`, `/api/v1/deleteAccount`,
#: `/api/v2/funds/withdraw`, `/api/v2/plan/downgrade` and five more went
#: through with the user's cookies — 9 of 9 (Opus review F4, reproduced
#: 2026-08-27). The verb list can never be finished, so it is no longer
#: the thing that decides.
#:
#: What decides: the LAST segment must read like a document — a `.json`
#: file, or a plural/collection noun, or one of the small set of words
#: that name a reading. Everything else is refused, including every verb
#: nobody has thought of yet.
#: `<collection>/<id>` — the REST shape for reading one thing:
#: `/api/v1/crates/serde`, `/api/v2/packages/express`. The collection
#: segment must itself read like a collection, and the write-verb rule
#: still runs first, so `/api/v2/orders/cancel` never reaches this.
_READS_ONE_OF_A_COLLECTION = re.compile(
    r"/(?:[A-Za-z0-9_-]*(?:s|list|index|all)|items|entries|records)"
    r"/[A-Za-z0-9_.@-]+$",
    re.IGNORECASE,
)

_READS_LIKE_A_DOCUMENT = re.compile(
    r"(?:^|/)(?:"
    r"[A-Za-z0-9_-]+\.json"  # crates.io/api/openapi.json
    r"|[A-Za-z0-9_-]*(?:s|list|index|feed|all)"  # /crates, /packages, /index
    r"|status|summary|health|info|meta|detail|details|overview|stats"
    r"|current|latest|version|config|schema|manifest|catalog"
    r")$",
    re.IGNORECASE,
)

#: Still refused first, because a verb in ANY position is a warning even
#: when the tail reads like a document (`/api/v2/orders/cancel/all`).
#: Matched across camelCase as well as separators — `cancelSubscription`
#: hid from the old separator-anchored pattern.
_NAMES_A_WRITE = re.compile(
    r"(?:^|[/_.\-]|(?<=[a-z]))"
    r"(?:cancel|delete|remove|destroy|unsubscribe|subscribe|create|update|"
    r"edit|leave|join|accept|decline|revoke|reset|close|archive|disable|"
    r"enable|activate|deactivate|purchase|checkout|pay|refund|withdraw|"
    r"transfer|downgrade|upgrade|redeem|send|post|publish|upload|import|"
    r"export|merge|approve|reject|mark|logout|signout|follow|unfollow|"
    r"star|unstar|like|unlike|vote|watch|unwatch|block|mute|unmute|report|"
    r"flag|claim|download|install|invite|share|apply|submit|confirm|verify|"
    r"restore|rollback|revert|clear|empty|purge|drop|kill|stop|start|"
    r"restart|reboot|deploy|release|rotate)"
    r"(?:[/_.\-]|[A-Z]|$)",
    re.IGNORECASE,
)

#: The whole attempt's budget. `session_get` bounds each fetch at 8s; ten
#: of those bolted onto a 200 ms replay is eighty seconds of the user
#: waiting for a shortcut they did not ask for (Opus round 13). The
#: attempt is an optimisation: past this it is abandoned, and the next
#: replay is unaffected because the look is recorded either way.
#:
#: Five, not three: the daemon's FIRST call on a host costs ~1.7 s
#: (measured on crates.io), and a three-second budget spent most of itself
#: there before the contract probes returned. This is paid once per
#: behaviour, after the answer has been computed.
ATTEMPT_BUDGET_S = 5.0

Fetch = Callable[[str], Awaitable[tuple[int, str]]]


def _reads(path: str) -> bool:
    """Does this path READ something? Positive evidence only.

    A document (`…/status.json`, `…/summary`) or one thing out of a named
    collection (`/api/v1/crates/serde`). Everything else is refused,
    including every write verb nobody has thought of yet — which is the
    point: the denylist that decided this before caught the one example
    from the previous review and let nine others through.
    """
    trimmed = path.rstrip("/")
    if not trimmed:
        return False
    return bool(
        _READS_LIKE_A_DOCUMENT.search(trimmed) or _READS_ONE_OF_A_COLLECTION.search(trimmed)
    )


def candidates(recorded: RecordedSession) -> list[str]:
    """Absolute GET URLs the site's own code names, on the page's host, in
    the order worth trying: `.json` first, then shortest path first."""
    page_host = (urlsplit(recorded.page_url or "").hostname or "").lower()
    if not page_host:
        return []
    found: dict[str, Affordance] = {}
    for response in recorded.responses:
        ctype = (response.resp_content_type or "").lower()
        body = response.resp_body or ""
        # CODE only, never the page. A path literal in HTML is written by
        # whoever can put text on the page — a comment, a username, a
        # review — and reading them let page content choose what Rokan
        # GETs with the user's cookies (security review, 2026-08-26). The
        # site's own bundles are the site's own statement about itself.
        if not body or not ("javascript" in ctype or "ecmascript" in ctype):
            continue
        name = response.url.rsplit("/", 1)[-1][:40] or "page"
        for a in extract(body, name, recorded.page_url, named=False)[0]:
            if a.kind != "read" or _HAS_PARAM.search(a.path) or _NOT_DATA.search(a.path):
                continue
            if not _reads(a.path):
                continue
            # A GET-shaped mutation is still a mutation. `extract` defaults
            # to GET whenever no `method:` literal sits beside the call —
            # which is most minified call sites — so "the site said GET" is
            # not evidence. A path that NAMES a write is refused whatever
            # the site says (security review, 2026-08-26:
            # `/api/v2/subscription/cancel` passed every other filter).
            if _NAMES_A_WRITE.search(a.path):
                continue
            url = urljoin(
                recorded.page_url, a.path if a.path.startswith("/") else f"https://{a.path}"
            )
            if (urlsplit(url).hostname or "").lower() != page_host:
                continue
            found.setdefault(url, a)

    def rank(url: str) -> tuple[int, int, str]:
        path = urlsplit(url).path
        return (0 if path.endswith(".json") else 1, len(path), path)

    return sorted(found, key=rank)


def _looks_like_data(body: str) -> bool:
    head = body.lstrip()[:1]
    return head in ("{", "[")


#: Where a site publishes its own contract. Probed only when nothing
#: cheaper answered, all at once, inside the attempt's budget. crates.io
#: serves it at `/api/openapi.json` — NOT at the guessed `/openapi.json`,
#: which 404s — so the list is short and the order is by observed hit rate
#: (research memo, 2026-08-26).
_SPEC_PATHS = (
    "/api/openapi.json",
    "/openapi.json",
    "/.well-known/openapi.json",
    "/swagger.json",
    "/api-docs",
)

#: `{name}`, `:name`, `<name>` — the three spellings a path template uses.
_TEMPLATE_PARAM = re.compile(r"\{[^{}/]+\}|(?<=/):[^/]+|<[^<>/]+>")


def templates_from_spec(spec_text: str) -> list[str]:
    """GET path templates a published spec declares, longest first.

    Longest first because a template with more fixed segments is more
    specific: `/api/v1/crates/{name}` before `/api/v1/{anything}`. Write
    verbs are refused here as everywhere — a spec that declares
    `/crates/{name}/follow` for GET is still naming a change.
    """
    try:
        spec = json.loads(spec_text)
    except ValueError:
        return []
    paths = spec.get("paths")
    if not isinstance(paths, dict):
        return []
    out = []
    for path, methods in paths.items():
        if not isinstance(path, str) or not isinstance(methods, dict):
            continue
        if "get" not in {str(m).lower() for m in methods}:
            continue
        if _NAMES_A_WRITE.search(path) or _NOT_DATA.search(path):
            continue
        if not _reads(_TEMPLATE_PARAM.sub("x", path)):
            continue
        out.append(path)
    return sorted(out, key=lambda p: (-len(p.split("/")), p))


def bind_template(template: str, page_url: str) -> str | None:
    """Fill a template's parameters from the page's own address.

    The page the user asked about names its subject: `crates.io/crates/serde`
    against `/api/v1/crates/{name}` gives `/api/v1/crates/serde`. Bound
    ONLY when the template's fixed segments all appear in the page path in
    the same order — otherwise a one-parameter template would swallow the
    page's last segment and produce a URL about something else.
    """
    page_parts = [p for p in urlsplit(page_url).path.split("/") if p]
    template_parts = [p for p in template.split("/") if p]
    if not page_parts or not template_parts:
        return None
    fixed = [p for p in template_parts if not _TEMPLATE_PARAM.fullmatch(p)]
    if not fixed:
        return None
    tail = [p for p in page_parts if p not in ("index", "")]
    # Every fixed segment the template names after its prefix must be on
    # the page's own path, in order.
    cursor = 0
    for segment in fixed:
        if segment in ("api", "v1", "v2", "v3", "rest"):
            continue
        while cursor < len(tail) and tail[cursor] != segment:
            cursor += 1
        if cursor == len(tail):
            return None
        cursor += 1
    remaining = tail[cursor:]
    bound = []
    for part in template_parts:
        if _TEMPLATE_PARAM.fullmatch(part):
            if not remaining:
                return None
            bound.append(remaining.pop(0))
        else:
            bound.append(part)
    if remaining:
        # The page names more than the template does; a partial bind would
        # answer about a parent resource, not the page.
        return None
    return "/" + "/".join(bound)


async def published_candidates(page_url: str, fetch: Fetch) -> list[str]:
    """URLs a site's OWN published contract names for this page.

    The strongest of the discovery routes and the cheapest: no browser, no
    headers, no auth, and the recovered URL is a versioned public contract
    rather than a build artefact — so it survives deploys that kill a
    bundle-derived one (research memo, 2026-08-26; crates.io went from "no
    literal anywhere in the bundle" to exact JSON through one spec fetch).
    """
    parts = urlsplit(page_url)
    specs = await asyncio.gather(
        *[
            _quiet(fetch, urlunsplit((parts.scheme, parts.netloc, path, "", "")))
            for path in _SPEC_PATHS
        ]
    )
    out: list[str] = []
    for status, body in specs:
        if status != 200 or not body:
            continue
        for template in templates_from_spec(body):
            bound = bind_template(template, page_url)
            if bound and not _HAS_PARAM.search(bound):
                url = urlunsplit((parts.scheme, parts.netloc, bound, "", ""))
                if url not in out:
                    out.append(url)
    return out


#: Where a server-rendered page keeps the data it rendered FROM. Measured
#: over 25 real sites (2026-08-27): the fact a person reads off the page is
#: recoverable from embedded state on 13 of the 21 that rendered at all —
#: and `__NEXT_DATA__` carried it on 5 of the 5 pages that had one. This is
#: the only route for a page with no endpoint to call: npm, IMDb, BBC,
#: Walmart and Target all render on the server and fetch nothing.
_NEXT_DATA = re.compile(
    r'<script[^>]+id="__NEXT_DATA__"[^>]*>(.*?)</script>', re.IGNORECASE | re.DOTALL
)
#: A JSON island: `<script type="application/json" id="…">`. Frameworks park
#: per-component state here (Rotten Tomatoes' scorecard, GitHub's
#: embeddedData, Airbnb's deferred state).
_JSON_ISLAND = re.compile(
    r'<script([^>]*\btype="application/(?:ld\+)?json"[^>]*)>(.*?)</script>',
    re.IGNORECASE | re.DOTALL,
)
#: The tag's own id, wherever it sits among the attributes: `id` before
#: `type` and `id` after `type` are the same tag, and a pattern that only
#: reads one order silently loses half the islands.
_TAG_ID = re.compile(r'\bid="([^"]+)"', re.IGNORECASE)

#: `window.__PRELOADED_STATE__ = {…}` and its cousins. npm's is the cleanest
#: of the whole set (`context.packument.distTags.latest`).
_WINDOW_STATE = re.compile(r"window\.(__[A-Z_]+__|__[a-z_]+__)\s*=\s*(\{.*?\})\s*[;<]", re.DOTALL)


def _shape_name(body: str) -> str:
    """A name for a blob that carries no id: its SHAPE.

    Compile picks the first blob that carries the value; replay re-finds a
    blob BY NAME. When two id-less islands were both called
    `script[json]` those were different blobs — Rotten Tomatoes ships one
    island per scorecard, and a page whose critics score was compiled
    replayed the audience score, on the unchanged page, on the first
    replay, labelled verified (Fable review, reproduced 2026-08-27).

    The top-level key set is stable across re-orderings and value changes
    and differs between components, which is exactly what is needed. Two
    blobs that are still indistinguishable stay indistinguishable, and
    `embedded_state` drops both rather than guess.
    """
    try:
        parsed = json.loads(body)
    except ValueError:
        return "script[json]"
    if isinstance(parsed, dict):
        shape = ",".join(sorted(str(k) for k in parsed)[:12])
    elif isinstance(parsed, list) and parsed and isinstance(parsed[0], dict):
        shape = "[]" + ",".join(sorted(str(k) for k in parsed[0])[:12])
    else:
        shape = type(parsed).__name__
    return "script[" + hashlib.sha1(shape.encode()).hexdigest()[:10] + "]"  # noqa: S324 — a name, not a secret


def embedded_state(html: str) -> list[tuple[str, str]]:
    """(name, json text) for every state blob the page carries, best first.

    Ordered by how reliably each pattern carried the answer when it was
    present: `__NEXT_DATA__` (5/5), then framework islands, then window
    assignments, then schema.org — which is present nearly everywhere and
    carries the answer rarely (4 of 14), so it goes last rather than first.
    """
    out: list[tuple[str, str]] = []
    for m in _NEXT_DATA.finditer(html):
        out.append(("__NEXT_DATA__", m.group(1).strip()))
    islands: list[tuple[str, str]] = []
    linked: list[tuple[str, str]] = []
    for m in _JSON_ISLAND.finditer(html):
        attributes, body = m.group(1), m.group(2).strip()
        if not body:
            continue
        found_id = _TAG_ID.search(attributes)
        name = f"script#{found_id.group(1)}" if found_id else _shape_name(body)
        if found_id and found_id.group(1) == "__NEXT_DATA__":
            # Already captured by name, and captured FIRST because it is the
            # pattern that carried the answer every time it was present.
            continue
        target = linked if "ld+json" in attributes.lower() else islands
        target.append((name, body))
    out.extend(islands)
    for m in _WINDOW_STATE.finditer(html):
        out.append((f"window.{m.group(1)}", m.group(2).strip()))
    out.extend(linked)
    kept = [(name, body) for name, body in out if len(body) > 40]
    # A name that does not identify ONE blob identifies none. Compile takes
    # the first blob that carries the value and replay takes the first with
    # the name; when those can differ, the answer can be a different
    # component's number on an unchanged page.
    seen = Counter(name for name, _ in kept)
    return [(name, body) for name, body in kept if seen[name] == 1]


async def compile_from_source(
    recorded: RecordedSession | None,
    anchor_line: str,
    fetch: Fetch,
    *,
    max_tries: int = MAX_TRIES,
) -> SyntheticOperation | None:
    """Compile from a source-named endpoint, or None — never an error.

    `fetch(url)` is the in-session GET (`fastpath.session_get`), returning
    (status, body). The first body that is JSON and carries the anchor's
    value becomes the operation; a body that is a page shell, a redirect, or
    data without the value is passed over. Nothing is stored here.
    """
    if recorded is None or not anchor_line.strip():
        return None
    for url in candidates(recorded)[:max_tries]:
        try:
            status, body = await fetch(url)
        except Exception:  # noqa: BLE001 — a fetch that fails is a candidate that fails
            continue
        if status != 200:
            continue
        found = _compiled_if_it_carries(url, body, anchor_line, recorded.page_url or "")
        if found is not None:
            return found
    return None


def _compiled_if_it_carries(
    url: str, body: str, anchor_line: str, page_url: str
) -> SyntheticOperation | None:
    """The operation, if this body is JSON holding the value that was read.

    Named by the site's own code (or its own address) and carrying the
    verified value. It is not a ranking: `margin` is 0.0 and `source` is
    `source_hint`, so the two ways of compiling stay countable apart.
    """
    if not _looks_like_data(body):
        return None
    # No second parse here: the locator reads the body through
    # `compile_op._leaves`, which returns nothing at all for a body that is
    # not JSON — so a malformed body cannot locate a value and cannot
    # compile. Verified rather than assumed (the duplicate `json.loads`
    # this replaced had no surviving mutant, which is what redundancy looks
    # like).
    located = locate_agreeing_paths(anchor_line, body)
    if located is None:
        return None
    marker, paths, start, end = located
    return SyntheticOperation(
        url=url,
        method="GET",
        expected_anchor=anchor_line.strip(),
        source="source_hint",
        # Not a ranking, so there is no margin to report — and reporting
        # 1.0 would let a source hint be averaged with the identifier's
        # measured wins. `source` says which population this belongs to.
        confidence=1.0,
        margin=0.0,
        compiled_at=datetime.now(UTC).isoformat(),
        value_path=paths[0],
        # Several slots carrying one fact are compiled together and must
        # keep agreeing; a single slot records nothing extra.
        value_paths=paths if len(paths) > 1 else (),
        value_marker=marker,
        value_start=start,
        value_end=end,
        page_url=page_url,
    )


#: Bundles fetched when compiling from a live page rather than a recording.
#: The endpoint that answers a page's own question is named in the first few
#: first-party scripts; past that the cost is not repaid.
MAX_BUNDLES = 6


async def compile_from_live_page(
    page_url: str,
    anchor_line: str,
    fetch: Fetch,
    *,
    max_bundles: int = MAX_BUNDLES,
    max_tries: int = MAX_TRIES,
    read_the_code: bool = True,
) -> SyntheticOperation | None:
    """Compile from the page's own code, fetched now, with no recording.

    The recording exists only on the run that PLANNED — and an operation
    earns the compiled path by being replayed, which records nothing. So a
    proven operation asks the site directly: fetch the page, read the
    scripts it loads, and probe what they name. Every fetch is the same
    in-session GET the compiled path itself uses; a failure anywhere just
    means this operation stays on the replay path, which already works.

    `read_the_code=False` keeps only the page's own address — one GET to a
    URL the user just visited, no new surface. That is the mode for a host
    the user is SIGNED INTO: probing a logged-in site's endpoints with the
    user's own session, on paths chosen by a filter, is a risk the 9 ms is
    not worth taking unasked (Opus round 13).
    """
    if not page_url or not anchor_line.strip():
        return None

    # 1. The site's own published contract. FIRST, and independent of the
    # page fetch: it is the cheapest route (one concurrent round of small
    # GETs), the only one that works when the URL is built at runtime, and
    # what it recovers is a versioned public contract rather than a build
    # artefact, so it outlives the deploys that kill a bundle-derived URL
    # (research memo, 2026-08-26 — ranked first by coverage per unit of
    # work). Independence matters: crates.io answers 404 to its own page
    # URL under `Accept: application/json`, and when this ran after the
    # page fetch that 404 ended the attempt before the contract — the
    # exact case the route exists for — was ever asked.
    for url in (await published_candidates(page_url, fetch))[:max_tries]:
        status, body = await _quiet(fetch, url)
        if status != 200:
            continue
        published = _compiled_if_it_carries(url, body, anchor_line, page_url)
        if published is not None:
            return published

    # 2. The page's own address, spelled the conventional data ways. Every
    # Statuspage, Discourse and github.com repo page answers one of these
    # (8 of 30 sites measured, 2026-08-26).
    status, html = await _quiet(fetch, page_url)
    for candidate, known in (
        (page_url, html if status == 200 else ""),
        *[(u, None) for u in _same_address_forms(page_url)],
    ):
        text = known if known is not None else (await _quiet(fetch, candidate))[1]
        if not text:
            continue
        negotiated = _compiled_if_it_carries(candidate, text, anchor_line, page_url)
        if negotiated is not None:
            return negotiated

    # 3. The state the page was RENDERED FROM. A server-rendered page has
    # no endpoint to call — npm ships 342 source files and makes zero fetch
    # calls — but it carries the data it rendered, and reading that is one
    # fetch of a page the browser already visits.
    if status == 200 and html:
        for name, blob in embedded_state(html):
            found = _compiled_if_it_carries(page_url, blob, anchor_line, page_url)
            if found is not None:
                return replace(found, extract=name)

    # 4. The endpoints the site's own first-party code names. Needs the
    # page's HTML to find the bundles, so it is last and it is skipped
    # when the page did not answer.
    if not read_the_code or status != 200 or not html:
        return None
    session = RecordedSession(
        host=(urlsplit(page_url).hostname or ""),
        task_label="compile_from_live_page",
        page_url=page_url,
        rendered_text="",
        responses=[_as_response(page_url, "text/html", html)],
    )
    page_host = (urlsplit(page_url).hostname or "").lower()
    first_party = [
        url
        for url in script_urls(page_url, html)
        if (urlsplit(url).hostname or "").lower() == page_host
    ]
    for url in first_party[:max_bundles]:
        js_status, js = await _quiet(fetch, url)
        if js_status == 200 and js:
            session.responses.append(_as_response(url, "application/javascript", js))
    return await compile_from_source(session, anchor_line, fetch, max_tries=max_tries)


def _same_address_forms(page_url: str) -> list[str]:
    """The page's own address, spelled the two conventional data ways."""
    parts = urlsplit(page_url)
    path = parts.path.rstrip("/")
    forms = []
    if path and not path.endswith(".json"):
        forms.append(urlunsplit((parts.scheme, parts.netloc, path + ".json", "", "")))
    if "format=json" not in parts.query:
        query = f"{parts.query}&format=json" if parts.query else "format=json"
        forms.append(urlunsplit((parts.scheme, parts.netloc, parts.path, query, "")))
    return forms


async def _quiet(fetch: Fetch, url: str) -> tuple[int, str]:
    try:
        return await fetch(url)
    except Exception:  # noqa: BLE001 — a probe that cannot run is not an error
        return 0, ""


def _as_response(url: str, ctype: str, body: str) -> RecordedResponse:
    return RecordedResponse(
        url=url,
        method="GET",
        status=200,
        resource_type="script" if "javascript" in ctype else "document",
        resp_content_type=ctype,
        resp_body=body,
    )
