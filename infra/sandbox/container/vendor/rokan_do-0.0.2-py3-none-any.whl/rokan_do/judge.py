"""The refusal-only judge — an EXPERIMENT, not a shipped feature.

Gated by ``ROKAN_JUDGE=1`` and OFF by default. The pre-registered plan
(`docs/measurements/2026-08-24-judge-measurement-plan.md`) decides whether
this ever ships: five thresholds, written before the first run, all of
which must hold.

The shape that makes it admissible at all: this judge can only VETO. It
converts a would-be-verified answer into a refusal and can never pass an
answer itself, so the failure directions are asymmetric — a false veto
costs a retry; a false pass is impossible by construction. That is the
same one-way narrowing as the three typed postconditions, generalised.

Two hard rules:

* **Never on ``key_used``.** The read line there IS the credential, and a
  judge prompt must not be a new egress of a secret. The gate lives at
  the call site in `cascade`, and a test holds it.
* **A judge outage fails OPEN.** The judge erroring (no key, no network,
  no credit) must not convert the product into refusing everything —
  fail-open is exactly the baseline behaviour the experiment compares
  against, so an outage degrades to the control arm, not to a new one.
"""

from __future__ import annotations

import os

from rokan_agent.core.reasons import Reason

from rokan_do.executor import Trace
from rokan_do.redact import redact
from rokan_do.verify import Verdict

#: Pinned, per the pre-registered plan. Changing the model invalidates the
#: experiment's numbers.
MODEL = "claude-haiku-4-5"

#: Fixed BEFORE the run, per the plan. One example each way. The judge
#: sees the question, the line, and nothing else — no page text, so it
#: cannot re-plan; it can only doubt.
PROMPT = (
    "A deterministic reader was asked: {question}\n"
    "It read this line off the page: {line}\n"
    "Does this line STATE the value the question asks for, or merely "
    "MENTION the subject? Reply with one word: ALLOW only if it states "
    "the value, otherwise VETO.\n\n"
    "Example — asked 'what is the default port', line 'The default port "
    "is 5432.' -> ALLOW\n"
    "Example — asked 'what is the current population', line 'The town "
    "grew rapidly after its incorporation in 1834.' -> VETO\n"
    "Answer:"
)

_CALLS = 0


def enabled() -> bool:
    return os.environ.get("ROKAN_JUDGE") == "1"


def calls() -> int:
    """How many judge model calls this process has made — the plan's
    'one per verified read' threshold is checked against this."""
    return _CALLS


def _ask(question: str, line: str) -> str:
    """One model call, one token back. Raises on provider failure."""
    global _CALLS
    from rokan_do.planner import _client  # noqa: PLC0415 — key handling lives there

    client = _client()
    _CALLS += 1
    response = client.messages.create(  # type: ignore[attr-defined]
        model=MODEL,
        max_tokens=5,
        # anthropic 1.0.0: `create` takes no temperature kwarg — it travels
        # in extra_body (same API fact the planner measured 2026-08-23).
        extra_body={"temperature": 0},
        messages=[
            {
                "role": "user",
                # Redacted defensively: the line is page content and must
                # never carry a stored credential into a prompt.
                "content": PROMPT.format(question=question, line=redact(line)),
            }
        ],
    )
    text: str = response.content[0].text
    return text.strip().upper()


def review(question: str, trace: Trace, verdict: Verdict) -> Verdict:
    """Return `verdict` unchanged (allow / judge outage), or a failed one.

    One call per verified read line — never per attempt; the caller only
    reaches here after the deterministic verifier has already PASSED.
    """
    for anchor, line in trace.read.items():
        try:
            answer = _ask(question, line)
        except Exception:  # noqa: BLE001 — fail OPEN, see module docstring
            return verdict
        if answer != "ALLOW":
            # Anything that is not the exact allow token is a veto —
            # including garbage. A judge that cannot say ALLOW clearly
            # has not earned the admission it is guarding.
            return Verdict(
                False,
                f"the judge vetoed the read: {line[:80]!r} mentions the "
                "subject without stating the value the question asks for",
                Reason.ABSTAINED_SCORER_DISAGREEMENT,
                ("judge=veto", f"anchor={anchor}"),
            )
    return verdict
