"""The three speeds of one task, callable by anything — not only the CLI.

This is `cli._do`'s middle, moved out whole. It existed only inside the
command, which had a measured consequence: the eval harness called
`cascade.run` directly, so **no eval had ever exercised memory or the
compiled path** — every published number was a cold-path number, and the
memory-collision defect (the wrong value served at compiled speed to a
second question, `tests/test_memory_answers_the_question.py`) was invisible
to every measurement we had. The product path and the measured path must be
the same function, or the numbers are about something else.

What lives here: compiled → remembered → planned, each earned by the one
below it and each checked by the same postcondition. What stays in the CLI:
the disclosure, discovery, rendering, and exit codes — the parts that talk.
"""

from __future__ import annotations

import asyncio
import re
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from urllib.parse import urlparse

from rokan_agent.core.reasons import Reason
from rokan_agent.core.result import Result, Status

from . import discover
from .accept import TaskRequest, verifier_for
from .cascade import _WORLD_FAILURES, RunReport, execution_policy, run
from .compile_op import SyntheticOperation
from .executor import ExecutionFailed, Trace, execute
from .fastpath import (
    FastPathRefused,
    FastPathUnavailable,
    record_while,
    run_fast,
    session_get,
    try_compile,
)
from .ir import ACTION_VERBS
from .memory import UNAVAILABLE_LIMIT, Memory
from .private_index import PrivateIndex
from .source_hint import (
    ATTEMPT_BUDGET_S,
    MAX_TRIES,
    compile_from_live_page,
    compile_from_source,
)
from .verify import _STATUS_WORD, _THREE_DIGITS, _U_PLUS_HEX, http_misread, verify


@dataclass(frozen=True, slots=True)
class Performed:
    """What happened, plus WHICH SPEED answered — because a harness that
    cannot see the path cannot claim to have measured it. A warm eval whose
    every task quietly re-planned would report green numbers about a memory
    it never touched (the C12 shape, pointed at measurement)."""

    result: Result
    #: The cascade's report when planning ran; None on the fast paths.
    report: RunReport | None
    #: "compiled" | "replayed" | "planned"
    path: str
    #: What the steps said, for the CLI to narrate.
    narration: tuple[str, ...] = field(default_factory=tuple)
    #: The operation key this run used or learned — "" when none was
    #: involved (a cold run that learned nothing). `recheck` reads it.
    key: str = ""
    #: The label every result carries: ``verified`` (a deterministic
    #: postcondition passed), ``self_reported`` (the run finished and
    #: nothing on the page could check it — honest, and never memory), or
    #: ``refused`` (declined, before or after trying).
    verification: str = "refused"


def _same_host(candidate: str, named: str) -> bool:
    """Is a discovered URL on the site the user actually named?"""
    here = urlparse(candidate).netloc.lower().removeprefix("www.")
    there = urlparse(named if "://" in named else f"https://{named}")
    want = there.netloc.lower().removeprefix("www.")
    return bool(want) and (here == want or here.endswith("." + want))


#: Verifier keys whose checks are page-based and carry no value shape.
#: `key_used` is here for completeness only — credential classes never
#: compile — and it must stay listed rather than fall through.
_SHAPELESS = frozenset({"value_present", "key_used"})

_SHAPES: dict[str, Callable[[str], bool]] = {
    # General mode never holds on the compiled path: its proof is a declared
    # postcondition on a PAGE, which an HTTP shortcut cannot re-check, and
    # a general plan carrying an action never compiles at all.
    "general": lambda v: False,
    # A LIST never holds on the compiled path either, and for a sharper
    # reason: `block_present` proves that these lines are a contiguous run
    # of the PAGE, and an HTTP shortcut has no page to check them against.
    # Five cached rows served in four milliseconds is precisely the stale
    # answer this whole ladder exists to refuse.
    "block_present": lambda v: False,
    "value_present_quantity": lambda v: bool(re.search(r"\d", v)),
    "value_present_status_code": lambda v: bool(_THREE_DIGITS.search(v)),
    "value_present_code_point": lambda v: bool(_U_PLUS_HEX.search(v)),
    "value_present_status_word": lambda v: bool(_STATUS_WORD.search(v)),
}


def _typed_shape_holds(verify: str, value: str) -> bool:
    """The typed postconditions' shape rules, applied to a compiled value.

    Mirrors `verify.py` one-to-one: quantity needs a digit, a status code a
    standalone three-digit run, a code point a U+hex token. FAIL-CLOSED: an
    unknown verifier key holds NOTHING, so the next typed postcondition
    cannot arrive unenforced on the compiled path (Opus third round, F4 —
    the same fail-open `_VERIFY_NEEDS` grew a completeness test for). A
    test holds this registry and `verify.VERIFIERS` together."""
    if verify in _SHAPELESS:
        return True
    shape = _SHAPES.get(verify)
    return shape(value) if shape is not None else False


def _host_has_login(host: str) -> bool:
    """Is the user signed in here? A stored credential — exact or a sibling
    under the same apex — means this host's endpoints are not ours to probe
    on the user's session (Opus round 13). Any failure reading the vault
    answers YES: the cautious direction."""
    try:
        from rokan_agent.core.proven import vault  # noqa: PLC0415

        normalized = vault.normalize_host(host)
        return vault.get(normalized) is not None or vault.find_sibling(normalized) is not None
    except Exception:  # noqa: BLE001 — unreadable vault means assume signed in
        return True


def _quiet(_message: str) -> None:
    """The default `warn`: a headless caller has nowhere to put asides."""


_ACTION_VERBS = ACTION_VERBS


#: Classes whose verifier proves the answer is the page's OWN, but cannot
#: prove it is the RIGHT one. `block_present` shows that these items are a
#: contiguous run of the page in the page's own order — no invention, no
#: re-ordering — and nothing more: "the top 5 crates" and "the first 5
#: links under this heading" are different questions and only the page
#: knows whether they have the same answer. Measured 2026-08-27, when a
#: perfectly provable run of links answered a question about crates with a
#: sidebar. So a list is reported as SELF-REPORTED, never verified, and
#: never admitted to memory on that basis.
#:
#: The repeat-group fence (same day) makes this materially stronger — the
#: lines are now provably one COLUMN of one structure the page built, which
#: rules out the sidebar entirely, and the verdict carries
#: `fence=repeat-group` when that is what proved it. It is deliberately NOT
#: promoted to `verified`: the fence proves the shape of the answer, not
#: that this list is the list the question meant, nor that the page's
#: display order is the ordering the word "top" asked for.
_SELF_REPORTED_VERIFIERS = frozenset({"block_present"})


def _label_of(result: Result, report: RunReport | None) -> str:
    """The label a planned run earns. `verified` needs a passed verdict;
    `self_reported` is the general verifier's own word for "ran, nothing to
    check" and travels in the verdict's evidence; everything else refused."""
    if result.status is Status.OK:
        plan = report.attempts[-1].plan if report is not None and report.attempts else None
        if plan is not None and plan.verify in _SELF_REPORTED_VERIFIERS:
            return "self_reported"
        # A verifier may also say so for itself. General mode verifies the
        # ACTION against the postconditions the plan declared, and that is
        # worth `verified` — but when the answer it hands back is a LIST it
        # inherits `block_present`'s honesty, because proving an answer has
        # the shape of a list is not proving it is the list that was asked
        # for.
        verdict = report.attempts[-1].verdict if report is not None and report.attempts else None
        if verdict is not None and "self_reported" in verdict.evidence:
            return "self_reported"
        return "verified"
    if report is not None and report.attempts:
        verdict = report.attempts[-1].verdict
        if verdict is not None and "self_reported" in verdict.evidence:
            return "self_reported"
    return "refused"


def _verdict_word(failure: BaseException | None, verdict: object) -> str:
    """One short word for the ledger — a `Reason` value or an exception's
    TYPE, never its message: messages quote pages and arguments, and the
    ledger is read back by tooling that must not be a second place a
    secret can surface."""
    reason = getattr(verdict, "reason", None)
    if reason is not None:
        return str(getattr(reason, "value", reason))
    if isinstance(failure, ExecutionFailed):
        return failure.reason.value
    if failure is not None:
        return type(failure).__name__
    return "failed"


async def perform(
    task: TaskRequest,
    *,
    probe: str | None = None,
    fresh: bool = False,
    use_discovery: bool = False,
    memory: Memory | None = None,
    index: PrivateIndex | None = None,
    on_before_egress: Callable[[], None] = lambda: None,
    warn: Callable[[str], None] = _quiet,
    replay_only: bool = False,
    params: Mapping[str, str] | None = None,
) -> Performed:
    """Do one accepted task, fastest proven speed first.

    ``replay_only`` forbids planning: the fast paths run exactly as they
    would for a user, and when they decline the answer is an abstention
    rather than a model call. `recheck` — the half-life instrument — is the
    caller, and the property it needs is that nothing leaves the machine.

    The body is `cli._do`'s speeds block, moved — the comments moved with
    it. `memory`/`index` are injectable for tests; a caller that passes
    neither gets the real store under ``ROKAN_MCP_HOME``.

    ``on_before_egress`` fires once, after the fast paths have declined and
    before ANYTHING leaves the machine — discovery calls Exa and planning
    calls Anthropic. The CLI hangs its disclosure on it; the ordering is
    part of the product (a consent notice on a run that phones nobody
    trains people to dismiss consent notices) and is pinned by
    `test_disclosure`.
    """
    memory = memory if memory is not None else Memory()
    index = index if index is not None else PrivateIndex()

    # The three speeds, fastest first. Each is earned by the one below it,
    # and each is checked by the same postcondition — a fast answer is
    # allowed to be fast, never allowed to be trusted.
    #
    # The question travels with the lookup: only a plan whose anchors share
    # a word with what was asked may replay. Without this, the second
    # question about a host was answered with the first question's value —
    # verified, at compiled speed, and wrong (reproduced live in
    # tests/test_memory_answers_the_question.py).
    remembered = memory.recall(task.site, task.task_class, task.said)
    # The postcondition belongs to the QUESTION, and memory stores the one
    # the LEARNING question earned. A code-point question replaying a plan
    # verified under the generic rule would re-admit the exact wrong answer
    # the typed postcondition was built to refuse — and the compiled path
    # below never verifies at all (Opus review, F4, probe-proven). A
    # mismatch skips every fast path: re-planning costs seconds and is
    # always correct.
    if remembered is not None and remembered.plan.verify != verifier_for(
        task.task_class, task.said, task.site
    ):
        remembered = None
    if remembered is not None and not fresh:
        host = remembered.plan.site.split("://", 1)[-1].split("/", 1)[0]

        # compiled: the site's own endpoint, no browser render at all.
        if remembered.compiled:
            try:
                operation = SyntheticOperation.from_json(remembered.compiled)
                fast = await run_fast(operation, host)
                if not _typed_shape_holds(remembered.plan.verify, fast.value):
                    # The typed postconditions never ran on this path (Opus
                    # re-review, F3): an endpoint whose field drifts from
                    # "U+10FFFF" to 1114111, or from 410 to "Gone", was
                    # served as verified in four milliseconds. The same
                    # shape the verifier holds a read line to is held here,
                    # and a value that fails it is drift — the shortcut is
                    # dropped and the slow path answers.
                    raise FastPathRefused("the endpoint's value lost its shape")
                # "passed" here means run_fast's own checks passed (origin,
                # status, agrees_with_page) — the full verifier never runs
                # on this path, so the replays counter is weaker evidence
                # than the word suggests (Opus review, F12). memory.py's
                # own warning applies: these counters are not evidence.
                memory.record_replay(
                    remembered.key,
                    passed=True,
                    path="compiled",
                    latency_ms=fast.elapsed_ms,
                    verdict="ok",
                )
                memory.fast_path_worked(remembered.key)
                return Performed(
                    result=Result.succeeded(
                        fast.value,
                        evidence=["compiled=true", f"endpoint={fast.url}"],
                        transport_used="replay",
                        elapsed_ms=fast.elapsed_ms,
                    ),
                    report=None,
                    path="compiled",
                    key=remembered.key,
                    # NOT "verified". The full verifier never runs on this
                    # rung — `agrees_with_page` asks only whether the field
                    # is still findable, and the typed shape asks only
                    # whether it still looks like a number. This is a cache
                    # with a shape check, and the comment two frames up has
                    # said so since the path was written while this field
                    # said otherwise. Every eval that counts `verified` was
                    # counting these (Opus review F2).
                    verification="compiled",
                )
            except FastPathUnavailable:
                # Our machinery, not the site: no daemon, a wedged socket, a
                # timeout. Fall through for this run and KEEP the shortcut —
                # a restarted daemon must not cost the user the millisecond
                # path forever. It is not counted as a failure of the
                # operation either: this run said nothing about whether the
                # operation still works.
                #
                # But patience is not infinite. After a run of these the
                # attempt itself is the cost — a daemon round trip and the
                # timeout, on every task — so the shortcut is released. That
                # is cheap to undo: the next browser run records its own
                # traffic and compiles again for free.
                #
                # The ledger gets the row with NO verdict: this run said
                # nothing about the operation, and a half-life that counted
                # it would be measuring our uptime.
                memory.record_use(remembered.key, path="compiled", ok=None, verdict="unavailable")
                if memory.fast_path_unavailable(remembered.key) >= UNAVAILABLE_LIMIT:
                    memory.drop_compiled(remembered.key)
            except FastPathRefused:
                # The endpoint stopped agreeing with the page. Drop the
                # shortcut and fall through — seconds lost, truth kept. This
                # IS a failure of the operation and is counted as one.
                memory.record_replay(
                    remembered.key, passed=False, path="compiled", verdict="refused"
                )
                memory.drop_compiled(remembered.key)
            except Exception:  # noqa: BLE001 — an unreadable row is not fatal
                # A stored row that will not parse: written by an older build,
                # or edited on disk. `from_json` raises KeyError and TypeError
                # as readily as ValueError, and letting one escape here killed
                # the command outright instead of falling back to the browser
                # path that would have answered correctly.
                memory.record_use(remembered.key, path="compiled", ok=None, verdict="unreadable")
                memory.drop_compiled(remembered.key)

        # remembered: the proven plan replays, no model involved.
        probe_kw = {"probe_url": probe} if remembered.plan.verify == "key_used" else {}
        trace: Trace | None
        try:
            trace = await execute(remembered.plan, said=task.said, **execution_policy(task, params))
            verdict = verify(remembered.plan, trace, said=task.said, **probe_kw)
            failure: BaseException | None = None
        except ExecutionFailed as exc:
            verdict, trace, failure = None, exc.trace, exc
        except Exception as exc:  # noqa: BLE001 — a failed replay is not fatal
            verdict, trace, failure = None, None, exc
        if http_misread(trace, verdict):
            # The HTTP text missed; the browser decides. Nothing has been
            # recorded yet, so a proven operation is never retired on a
            # shortcut's misreading (the Postgres replay, 2026-08-25).
            try:
                trace = await execute(
                    remembered.plan,
                    said=task.said,
                    force_browser=True,
                    **execution_policy(task, params),
                )
                verdict = verify(remembered.plan, trace, said=task.said, **probe_kw)
                failure = None
            except ExecutionFailed as exc:
                verdict, trace, failure = None, exc.trace, exc
            except Exception as exc:  # noqa: BLE001
                verdict, trace, failure = None, None, exc
        if verdict is not None and verdict.passed:
            memory.record_replay(
                remembered.key,
                passed=True,
                latency_ms=trace.elapsed_ms if trace is not None else 0,
                verdict="ok",
            )
            # An operation earns the compiled path by being REPLAYED three
            # times — and a replay records no traffic, so the compile
            # attempt on the planned path (which ran when the quarantine
            # still forbade it) was the only one that ever happened. The
            # shortcut was therefore unreachable for every operation that
            # behaved: proven often enough to deserve it, never re-planned
            # to attach it. Found 2026-08-26 with the source hint, on
            # githubstatus: five verified passes, cold_proofs=5, compiled
            # empty. Here the proven operation asks the site's own code,
            # once, in the session it just used.
            if (
                not remembered.compiled
                and not memory.compile_searched(remembered.key)
                and memory.compile_allowed(remembered.key)
                and remembered.plan.verify != "key_used"
                and not any(step.verb in ACTION_VERBS for step in remembered.plan.steps)
                and trace is not None
                # Exactly one value was read, so there is no question WHICH
                # one the compiled form must reproduce (Opus round 13).
                and len(trace.read) == 1
            ):
                anchor_now = next(iter(trace.read.values()), "")
                memory.compile_searched_now(remembered.key)
                try:
                    from_source = await asyncio.wait_for(
                        compile_from_live_page(
                            trace.last_url or remembered.plan.site,
                            anchor_now,
                            lambda url: session_get(host, url),
                            # A signed-in host is probed at its own address
                            # only — see `compile_from_live_page`.
                            read_the_code=not _host_has_login(host),
                        ),
                        timeout=ATTEMPT_BUDGET_S,
                    )
                except (TimeoutError, Exception):  # noqa: BLE001 — an optimisation, never a failure
                    from_source = None
                if from_source is not None:
                    memory.compiled_ready(remembered.key, from_source.to_json())
            if trace is not None and trace.page_text:
                index.record(remembered.plan.site, trace.page_text)
            return Performed(
                result=Result.succeeded(
                    verdict.proof,
                    evidence=["replayed=true", *verdict.evidence],
                    transport_used="replay",
                    elapsed_ms=trace.elapsed_ms if trace else 0,
                ),
                report=None,
                path="replayed",
                narration=tuple(trace.said) if trace else (),
                key=remembered.key,
                # A replay is worth exactly what its verifier is worth. This
                # said "verified" for every operation it re-ran, so a LIST —
                # which the cold path is careful to report as self-reported,
                # because `block_present` proves the shape of an answer and
                # not that it answers the question — came back the second
                # time claiming proof it never had. Caught on
                # stackexchange.com (2026-08-27): a replayed list answered
                # "the top 5 Q&A communities" with Stack Overflow, Stack
                # Internal, Stack Data Licensing, Stack Ads, Press — the
                # footer's product links — in 243ms, labelled `verified`.
                verification=(
                    "self_reported"
                    if remembered.plan.verify in _SELF_REPORTED_VERIFIERS
                    else "verified"
                ),
            )
        if isinstance(failure, ExecutionFailed) and failure.reason in _WORLD_FAILURES:
            # A rejected password, a bot check, a missing credential: the
            # WORLD said no, and the cascade below would drive the same
            # login again — twice more, once per rung. Measured risk, not
            # theoretical: Plunk, Supabase and Stripe all lock or
            # hard-rate-limit below the three submissions one `rokan-do`
            # run was making (Opus architecture audit, S3), and the vault
            # may hold a mistyped password right now.
            #
            # This is the ANSWER, not a hiccup: the same abstention the
            # cascade would have produced, minus the extra attempts. The
            # plan is NOT retired — a rejected password says nothing about
            # whether the page still carries the value.
            memory.record_use(
                remembered.key, path="replayed", ok=None, verdict=failure.reason.value
            )
            return Performed(
                result=Result.abstained(failure.reason, evidence=[f"replay: {failure}"[:200]]),
                report=None,
                # NOT "replayed": this run never replayed anything. Counting
                # it as a speed let a warm run where every task was locked
                # out print `replayed N` with no alarm — the round-4
                # outage-scoring defect in another costume (Opus round 2,
                # F-A).
                path="",
                key=remembered.key,
            )
        if Memory.failure_retires_the_plan(failure, verdict):
            # The page moved. Retire the plan and fall through to planning —
            # never report a stale answer, never silently keep replaying.
            # Counted here rather than above, because the durability number
            # this column feeds is meant to answer "how long does a learned
            # operation keep working" — and a run that died because our
            # daemon was down is not an answer to that question.
            memory.record_replay(
                remembered.key, passed=False, verdict=_verdict_word(failure, verdict)
            )
            memory.retire(remembered.key)
        else:
            # Otherwise our side broke, which says nothing about the plan.
            # Fall through and re-plan for this run; the proven plan stays
            # earned — and the ledger records a run with no verdict.
            memory.record_use(
                remembered.key,
                path="replayed",
                ok=None,
                verdict=_verdict_word(failure, verdict),
            )

    if replay_only:
        # Planning is forbidden. Whatever the fast paths recorded (a
        # verified replay, a retirement, a no-verdict outage) is already in
        # the ledger; this run learns nothing new and phones nobody.
        return Performed(
            result=Result.abstained(
                Reason.ABSTAINED_LOW_CONFIDENCE,
                evidence=["replay_only: no remembered speed answered"],
            ),
            report=None,
            path="",
            key=remembered.key if remembered is not None else "",
        )

    # Everything below this line can leave the machine; the caller's notice
    # comes first. The fast paths above returned without reaching it.
    on_before_egress()

    site = task.site
    if use_discovery:
        wanted = task.said
        private = index.find(site, wanted)
        if private:
            # The private index is free, offline, and more likely to hold the
            # exact page — so nothing reaches Exa when this hits.
            site = private[0].url
        elif discover.key_present():
            try:
                found = discover.find(site, wanted)
            except discover.DiscoveryUnavailable as exc:
                warn(f"  (search: {exc})")
            else:
                # Checked HERE, because nothing downstream can. `ir.validate`
                # pins navigation to `plan.site`, and `plan.site` is whatever
                # this line assigns — so a candidate on someone else's host
                # would be validated against itself, read, and rendered as a
                # verified answer to a question about the named site.
                on_site = [c for c in found if _same_host(c.url, site)]
                if on_site:
                    site = on_site[0].url
                else:
                    warn("  (search: nothing on that site)")
    task = TaskRequest(task_class=task.task_class, site=site, slots=task.slots, said=task.said)

    host = task.site.split("://", 1)[-1].split("/", 1)[0]
    began = time.monotonic()
    (result, report), recorded = await record_while(
        host, task.task_class, lambda: run(task, probe_url=probe, params=params)
    )
    planned_ms = int((time.monotonic() - began) * 1000)
    narration: tuple[str, ...] = ()
    key: str | None = None
    if result.status is Status.OK:
        last = report.attempts[-1]
        if last.trace is not None:
            narration = tuple(last.trace.said)
        if last.plan is not None and last.verdict is not None:
            key = memory.remember(last.plan, last.verdict, task.said)
            if last.trace is not None and last.trace.page_text:
                index.record(last.plan.site, last.trace.page_text)
            # compile: the traffic that just proved the answer is the
            # traffic that identifies the endpoint. Costs nothing extra
            # and describes the same instant the verifier read.
            #
            # NOT for a credential class. A compiled operation stores
            # the line it was learned from as its anchor and the value
            # as its marker — for `get_api_key` that is the key itself,
            # written unencrypted into the store. And the compiled path
            # returns its answer without calling `verify` at all, so the
            # one postcondition that makes this class honest (the key is
            # proven by SPENDING it) would never run again after the
            # first time. A millisecond answer is not worth either.
            # QUARANTINE: the compiled path never calls `verify`, so it is
            # earned by repeated full-verifier proof rather than by one cold
            # pass. Attaching on the first success meant a single
            # verified-but-wrong answer bought a permanent 4 ms shortcut to
            # that wrong value (the Toronto-1834 shape; both audits' #1).
            # NOT for a write. A compiled operation replays an HTTP request
            # without the page, the postcondition, or the human's grant in
            # the loop — for a read that is a millisecond answer; for a
            # write it is a cancellation fired blind. Writes replay through
            # the browser, verified every time, and never compile.
            compilable = last.plan.verify != "key_used" and not any(
                step.verb in _ACTION_VERBS for step in last.plan.steps
            )
            if key is not None and not memory.compile_allowed(key):
                compilable = False
            if key is not None and last.trace is not None and compilable:
                anchor = next(iter(last.trace.read.values()), "")
                compiled = try_compile(recorded, anchor) if anchor else None
                if compiled is None and anchor:
                    # The page rendered its answer on the server, so no
                    # response carried it and the identifier had nothing to
                    # score — but the site's own code may still NAME an
                    # endpoint that does. Measured 2026-08-26: a Statuspage
                    # renders "All Systems Operational" into the HTML and
                    # ships `/api/v2/status.json` in its bundle, which
                    # answers the same question in 8 ms. Bounded: at most
                    # three in-session GETs on the site the run just used,
                    # and a candidate compiles only if its body carries the
                    # value the verifier read.
                    try:
                        compiled = await asyncio.wait_for(
                            compile_from_source(
                                recorded,
                                anchor,
                                lambda url: session_get(host, url),
                                # The same gate the replay path has always
                                # had, which this one did not: on a host
                                # the user is SIGNED INTO, endpoints named
                                # by a bundle are not ours to probe with
                                # their session — and reads behind a login
                                # are the core use case, so this is the
                                # path where it matters most (Opus review
                                # F4).
                                max_tries=0 if _host_has_login(host) else MAX_TRIES,
                            ),
                            timeout=ATTEMPT_BUDGET_S,
                        )
                    except (TimeoutError, Exception):  # noqa: BLE001 — an optimisation
                        compiled = None
                if compiled is not None:
                    memory.compiled_ready(key, compiled.to_json())
    # The planned row. A learned operation's FIRST row is this one; a run
    # that learned nothing still writes a row under '' so every perform
    # leaves AT LEAST one row. Rows are per ATTEMPT, not per perform: a
    # compiled outage followed by a verified replay is two rows, and
    # `recheck` reads the last one.
    label = _label_of(result, report)
    if result.status is Status.OK:
        planned_verdict = "ok"
    elif label == "self_reported":
        planned_verdict = "self_reported"
    elif result.reason is not None:
        planned_verdict = result.reason.value
    else:
        planned_verdict = result.status.value
    memory.record_use(
        key or "",
        path="planned",
        ok=result.status is Status.OK,
        latency_ms=planned_ms,
        verdict=planned_verdict,
    )
    return Performed(
        result=result,
        report=report,
        path="planned",
        narration=narration,
        key=key or "",
        verification=label,
    )
