"""``rokan-do`` — the whole loop as one command.

    $ rokan-do "get my api key from resend.com"

What happens, in order, and why each part is where it is:

1. **Accept** — a lookup, not a guess. Out of class means a calm refusal.
2. **Recall** — if this operation was proven before, replay it. No model runs
   on a remembered task; that is the entire point of remembering.
3. **Discover** — when no URL was named: the private index first (pages this
   machine has actually reached), then Exa (the public web) if the user
   allowed it. Private first because it is free, offline, and more likely to
   hold the exact page.
4. **Plan → execute → verify → escalate-or-refuse** — the cascade.
5. **Remember** — a verified plan enters the library; the next run is step 2.

Output follows the same rules as the rest of Rokan: the answer alone in ink,
narration dimmed beneath it, refusals calm and classed with something to run,
and exit 0 when Rokan declines — declining is a result.
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sqlite3
import sys

from rokan_agent.core.result import Result

from . import service
from .accept import accept, classes_offered
from .cli_ops import cmd_allow, cmd_recheck, cmd_seed
from .memory import Memory
from .private_index import PrivateIndex
from .render_do import render

#: Shown once, before the first task ever runs. `do` sends the page's text to
#: a model provider under the user's own key — that is a real disclosure, not
#: a footnote, and it is made before anything is sent rather than after.
DISCLOSURE = """Before Rokan does this, here is exactly what leaves this machine.

  · The text of the page it opens goes to Anthropic, to plan the task,
    using YOUR API key under your account's terms.
  · If you use --discover, the service name and the kind of page you want
    go to Exa, to look up the URL. Never a number, never an account
    detail, never anything from behind a login.

Nothing else. Credentials stay in the local vault, the session stays in a
local browser profile, and no result is uploaded anywhere.

Planning happens once per task. Remembered and compiled tasks replay with
no model and no search at all.
"""


def _out(message: str = "") -> None:
    print(message, file=sys.stdout)


def _err(message: str) -> None:
    print(message, file=sys.stderr)


def _disclosure_shown() -> bool:
    from rokan_agent.core.proven import paths

    return (paths.home() / ".do-disclosed").exists()


def _mark_disclosed() -> None:
    from rokan_agent.core.proven import paths

    (paths.home() / ".do-disclosed").touch()


#: Shown by `rokan-do allow-agents`. The gateway hands RESULTS — for
#: `get_api_key`, the key itself — to whichever agent called, and that agent
#: sends its transcript to its own model provider. The first-run disclosure
#: above promises "no result is uploaded anywhere"; that promise is true of
#: the CLI and false of the gateway, so the gateway needs its own consent,
#: given by the human, once, in their own terminal.
GATEWAY_DISCLOSURE = """Before another agent can call Rokan, here is what changes.

  · Results go back to the agent that asked — a value read from a page,
    or an API key Rokan fetched for you. That agent keeps its own
    transcript and sends it to its own model provider.
  · First runs still send the page's text to Anthropic under YOUR key, as
    shown at your first task. Remembered and compiled tasks send nothing.
  · Agents can also list what Rokan has learned to do on your accounts.

Credentials never leave the local vault. Rokan still refuses anything it
cannot verify, and tells the agent why.
"""


def _gateway_allowed() -> bool:
    from rokan_agent.core.proven import paths

    return (paths.home() / ".do-agents-allowed").exists()


def _mark_gateway_allowed() -> None:
    from rokan_agent.core.proven import paths

    (paths.home() / ".do-agents-allowed").touch()


def cmd_allow_agents(_args: argparse.Namespace) -> int:
    """Consent for the gateway. Prints what changes, records acceptance."""
    _out(GATEWAY_DISCLOSURE)
    if _disclosure_shown():
        _mark_gateway_allowed()
        _out("Agents may now call rokan_do. Start the gateway with: rokan-do mcp")
        _out("Register it in Claude Code: claude mcp add rokan-do -- rokan-do mcp")
        return 0
    _out("Run one task first so the first-run disclosure is shown too:")
    _out('  rokan-do "read the default keepalive_timeout at nginx.org"')
    return 2


def _narrate(lines: tuple[str, ...]) -> None:
    for said in lines:
        _out(f"    \033[2m{said}\033[0m" if sys.stdout.isatty() else f"    {said}")


async def _do(args: argparse.Namespace) -> int:
    """Accept, then hand the task to the service; render what comes back.

    The three speeds, discovery and the egress ordering live in
    `service.perform`, shared with the eval harness so the measured path IS
    the product path. What stays here is everything that talks: the
    disclosure (hung on the service's before-egress hook, so the fast paths
    — which send nothing — never show it), the rendering, the exit code.
    """
    task = accept(args.task)
    if isinstance(task, Result):
        return render(task)

    def disclose() -> None:
        # Everything that leaves this machine is named BEFORE any of it
        # leaves. The service fires this once, after the fast paths have
        # declined and before discovery or planning — a disclosure printed
        # after either would be describing something that had already
        # happened.
        if not _disclosure_shown():
            _out(DISCLOSURE)
            _mark_disclosed()

    performed = await service.perform(
        task,
        probe=args.probe,
        fresh=args.fresh,
        use_discovery=args.discover,
        on_before_egress=disclose,
        warn=_err,
    )
    code = render(performed.result)
    if performed.path == "planned":
        # Replays are silent on purpose: the narration explains a plan the
        # user has already seen work.
        _narrate(performed.narration)
    return code


def cmd_ops(_args: argparse.Namespace) -> int:
    """The library: what Rokan has proven it can do on your accounts."""
    library = Memory().library()
    if not library:
        _out("nothing learned yet")
        _out('  Run: rokan-do "get my api key from <a site you use>"')
        return 0
    _out()
    _out(
        f"  {'OPERATION':<14}{'SITE':<24}{'READS':<26}{'USES':<6}"
        f"{'REPLAYS':<9}{'FAILURES':<10}SPEED"
    )
    for item in library:
        host = item.plan.site.split("://", 1)[-1].split("/", 1)[0]
        # Whether this operation has a synthetic API is the single most
        # visible thing about it — the difference between a second and a
        # millisecond — and it can be lost silently to a moved endpoint. It
        # belongs on screen, not only in the store.
        speed = "instant" if item.compiled else "replayed"
        # One host now holds one operation PER VALUE, so class + host no
        # longer identifies a row — what it READS does. This is the anchor,
        # never the value: a `get_api_key` row's value is the credential.
        reads = " · ".join(
            str(step.args.get("contains", ""))
            for step in item.plan.steps
            if step.verb.value == "read_value"
        )
        _out(
            f"  {item.plan.task_class:<14}{host:<24}{reads[:24]:<26}"
            f"{item.uses:<6}{item.replays:<9}{item.failures:<10}{speed}"
        )
    _out()
    _out(f"  {len(library)} learned")
    return 0


#: Suffixes a person types when they mean a site. Refused rather than
#: obeyed: `forget("com")` would retire every .com operation in the store.
_PUBLIC_SUFFIXES = frozenset({
    "com", "org", "net", "io", "dev", "app", "ai", "co", "me", "sh",
    "uk", "ca", "us", "eu", "de", "fr", "jp", "au", "in", "gov", "edu",
})


def cmd_forget(args: argparse.Namespace) -> int:
    """Make Rokan stop replaying what it learned on a site.

    The command a person needs the moment they catch a wrong answer being
    replayed — reality batch 4 served an 1834 history paragraph as
    Toronto's population, twice, and the only way to stop it was
    hand-written SQL against the store.

    Silence on a miss is the failure mode this command cannot have (the
    `known --forget` lesson: it matched nothing and reported success), so
    a miss names what IS learned instead.
    """
    # A bare public suffix would retire every operation under it, and there
    # is no un-forget: recovery would be the hand-written SQL this command
    # exists to replace (Opus round 7).
    bare = args.site.strip().lower().split("://", 1)[-1].split("/", 1)[0]
    if bare in _PUBLIC_SUFFIXES:
        _out(f'"{bare}" is a public suffix, not a site — that would retire')
        _out("  every operation under it, and there is no un-forget.")
        _out('  Name the site: rokan-do forget en.wikipedia.org')
        return 0

    memory = Memory()
    forgotten = memory.forget(args.site, reads=args.reads or "")
    if not forgotten:
        hosts = memory.live_hosts()
        _out(f"nothing learned on {args.site} — nothing to forget")
        if args.reads:
            _out(f'  (no operation there reads anything matching "{args.reads}")')
        if hosts:
            _out()
            _out("  Rokan has learned operations on:")
            for host in hosts:
                _out(f"    {host}")
        return 0
    _out()
    for _key, reads in forgotten:
        _out(f"  forgot   {reads or '(no read anchors)'}")
    unreadable = sum(1 for _k, r in forgotten if r.startswith("("))
    if unreadable and args.reads:
        _out()
        _out(
            f"  ({unreadable} had an unreadable plan and could not be matched "
            'against --reads, so they were retired rather than skipped.)'
        )
    _out()
    _out(
        f"  {len(forgotten)} operation{'s' if len(forgotten) != 1 else ''} "
        f"retired on {args.site}. The next run re-plans from scratch."
    )
    _out(
        "  The record is kept, not erased — run `rokan-do known --forget "
        f"{args.site}` to erase the page map too."
    )
    # An honest limit: a later run that anchors a DIFFERENT line on the
    # same page earns its own key and its own row, so "retired" is about
    # these operations, not about the site forever.
    _out(
        "  A later run may still learn a different reading on this page — "
        "run forget again if it does."
    )
    return 0


def cmd_known(args: argparse.Namespace) -> int:
    """What the private index has mapped — and how to erase it."""
    index = PrivateIndex()
    if args.forget:
        removed = index.forget(args.forget)
        _out(f"forgot {removed} pages on {args.forget}")
        return 0
    hosts = index.known_hosts()
    if not hosts:
        _out("no pages mapped yet")
        return 0
    for host in hosts:
        _out(f"  {host}")
    _out()
    _out("  Run: rokan-do known --forget <site>    to erase one")
    return 0


def cmd_mcp(_args: argparse.Namespace) -> int:
    """The gateway: `do` as a tool another agent calls. See `rokan_do.mcp`."""
    try:
        from .mcp import main as serve_mcp
    except ImportError:
        _err("the MCP SDK is not installed; run: pip install 'rokan-do[mcp]' or pip install mcp")
        return 2

    return serve_mcp()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rokan-do",
        description="Do a task on the web — verified, or refused.",
    )
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("run", help="do a task (default)")
    p.add_argument("task")
    p.add_argument("--probe", help="endpoint to verify an acquired key against")
    p.add_argument(
        "--discover",
        action="store_true",
        help=(
            "find the right page ON the site you named — your own visited "
            "pages first, then the web. Does not find the site itself."
        ),
    )
    p.add_argument(
        "--fresh", action="store_true", help="ignore any remembered plan and re-plan"
    )
    p.set_defaults(func=lambda a: asyncio.run(_do(a)))

    p = sub.add_parser("ops", help="what Rokan has learned to do")
    p.set_defaults(func=cmd_ops)

    p = sub.add_parser(
        "forget", help="stop replaying what Rokan learned on a site"
    )
    p.add_argument("site", help="the site to forget, e.g. en.wikipedia.org")
    p.add_argument(
        "--reads",
        metavar="TEXT",
        help=(
            "only operations whose read anchors contain TEXT — a host can "
            "hold several, and forgetting one should not cost the others"
        ),
    )
    p.set_defaults(func=cmd_forget)

    p = sub.add_parser(
        "recheck",
        help="try every remembered operation again, no model — the half-life clock",
    )
    p.add_argument("site", nargs="?", default="", help="only operations on this site")
    p.set_defaults(func=cmd_recheck)

    p = sub.add_parser(
        "allow", help="grant one write action on one site (cancel, delete, pay, send…)"
    )
    p.add_argument("site", nargs="?", default="", help="e.g. notion.so")
    p.add_argument("action", nargs="?", default="", help="e.g. cancel")
    p.add_argument("--list", action="store_true", help="show every grant")
    p.add_argument("--revoke", action="store_true", help="remove the grant instead")
    p.set_defaults(func=cmd_allow)

    p = sub.add_parser("seed", help="install operations verified elsewhere, or export yours")
    p.add_argument("what", choices=("install", "export"))
    p.add_argument("file", nargs="?", default="")
    p.set_defaults(func=cmd_seed)

    p = sub.add_parser("known", help="pages Rokan has mapped on your accounts")
    p.add_argument("--forget", metavar="SITE", help="erase everything about a service")
    p.set_defaults(func=cmd_known)

    p = sub.add_parser(
        "mcp",
        help="serve rokan_do as an MCP tool over stdio, for another agent to call",
    )
    p.set_defaults(func=cmd_mcp)

    p = sub.add_parser(
        "allow-agents",
        help="consent, once, to other agents calling rokan_do (shows what changes)",
    )
    p.set_defaults(func=cmd_allow_agents)

    p = sub.add_parser("can", help="what Rokan will accept")
    p.set_defaults(func=lambda _a: _print_classes())
    return parser


def _print_classes() -> int:
    _out("Rokan can:")
    for described in classes_offered():
        _out(f"  · {described}")
    _out()
    _out("Everything else is refused — with the reason and what to do instead.")
    return 0


def main(argv: list[str] | None = None) -> int:
    raw = list(sys.argv[1:] if argv is None else argv)
    # `rokan-do "task"` is the whole product; requiring a subcommand for it
    # would put a word between the user and the thing they came for.
    if raw and raw[0] not in {
        "run", "ops", "known", "can", "forget", "recheck", "allow", "seed", "mcp", "allow-agents",
        "-h", "--help"
    }:
        raw.insert(0, "run")
    parser = build_parser()
    args = parser.parse_args(raw)
    if not getattr(args, "func", None):
        parser.print_help()
        return 2
    if os.environ.get("ROKAN_DO_DISABLED"):
        _err("rokan-do is disabled in this environment")
        return 2
    try:
        result: int = args.func(args)
    except KeyboardInterrupt:
        # Ctrl-C is a decision, not a crash. Re-raising printed a traceback
        # at someone who had just told Rokan to stop.
        _err("")
        _err("  stopped.")
        return 130
    except sqlite3.OperationalError as exc:
        # BEFORE the corrupt-store branch, because OperationalError is a
        # SUBCLASS of DatabaseError and these are not the same event at all.
        # A locked database means another Rokan is mid-write — the scheduler,
        # or a second terminal — and the corrupt-store advice below tells the
        # user to move the file aside. Following it because a neighbour held
        # a write lock for a moment destroys the operation library and the
        # observation ledger.
        detail = str(exc).lower()
        if "locked" in detail or "busy" in detail:
            # A neighbour holding a write lock. Waiting IS the answer.
            _err("")
            _err("  ⏸ waiting — Rokan's store is in use by another run")
            _err("")
            _err(f"    why     {exc}")
            _err("    next    Let the other one finish, then run this again.")
            _err("")
            return 1
        if any(w in detail for w in ("readonly", "full", "i/o", "disk")):
            # NOT the same thing, and they used to share the message above.
            # "Let the other one finish" never comes true for a full disk, a
            # read-only mount or failing hardware — the user retries forever
            # while the real cause stays hidden.
            _err("")
            _err("  ✕ stopped — Rokan could not write to its store")
            _err("")
            _err(f"    why     {exc}")
            _err(
                "    next    Check free disk space and that your home "
                "directory is writable. Nothing was lost."
            )
            _err("")
            return 1
        _err(f"error: {type(exc).__name__}: {exc}")
        return 1
    except sqlite3.DatabaseError as exc:
        if type(exc) is not sqlite3.DatabaseError:
            # Real corruption raises exactly DatabaseError ("file is not a
            # database"). ProgrammingError, IntegrityError and the rest are
            # subclasses and are OUR bugs — telling the user to move their
            # operation library aside for one would be a code defect costing
            # them their data.
            _err(f"error: {type(exc).__name__}: {exc}")
            return 1
        # A corrupt store printed `error: DatabaseError: file is not a
        # database` and exit 1 — no class, no next step, and no hint that
        # the file is a cache the user may simply delete.
        from rokan_agent.core.proven import paths  # noqa: PLC0415

        _err("")
        _err("  ✕ stopped — Rokan's own store could not be read")
        _err("")
        _err(f"    why     {exc}")
        _err(
            "    next    Everything in it can be re-earned. Move it aside "
            f"and run again:\n            mv {paths.home() / 'rokan.db'} "
            f"{paths.home() / 'rokan.db.broken'}"
        )
        _err("")
        return 1
    except Exception as exc:  # noqa: BLE001 — the last line before the user
        _err(f"error: {type(exc).__name__}: {exc}")
        return 1
    return result


if __name__ == "__main__":
    raise SystemExit(main())
