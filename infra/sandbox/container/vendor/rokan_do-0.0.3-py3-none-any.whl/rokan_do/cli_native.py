"""``rokan-do native`` — call a site's OWN WebMCP tool by name. Zero model calls.

    $ rokan-do native list https://shop.example
    $ rokan-do native invoke https://shop.example search_catalog \\
          --set catalog.query='wool runners'

`rokan do` picks the tool for you (one model call, `service._try_native`); this
subcommand is the explicit form: the caller names the tool and fills its input,
so nothing is sent to a model and the trailer reads `⚡ ⚙ native:<site>:<tool>`
with `calls=0`. Same read/write policy as the automatic path (`native.invoke`):
a write-class tool needs `--allow-write`, and `--allow-write` is itself refused
when this process is pinned read-only (`ROKAN_TASK_CLASSES` without `general`).

Exit codes: 0 answered · 1 the tool errored or the site does not declare it ·
2 policy refusal or bad input.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from . import native
from .accept import _allowed_classes, _find_site
from .render_do import render

EXIT_OK = 0
EXIT_TOOL = 1
EXIT_POLICY = 2

#: Where the previous invoke's value is kept, under the same home as the rest
#: of the store (``ROKAN_MCP_HOME`` relocates it). `--set path=@prev` reads it.
LAST_FILE = "native-last.json"
PREV_TOKEN = "@prev"

#: Description column width in `native list` — one line per tool, always.
_DESC_MAX = 80


def _out(message: str = "") -> None:
    print(message, file=sys.stdout)


def _err(message: str) -> None:
    print(message, file=sys.stderr)


def _last_file() -> Path:
    from rokan_agent.core.proven import paths  # noqa: PLC0415 — deferred like cli.py

    return paths.home() / LAST_FILE


def _one_line(text: str, limit: int) -> str:
    """Untrusted site text into one printable line: no control chars, no ANSI,
    collapsed whitespace, hard-capped."""
    cleaned = " ".join("".join(c for c in text if c.isprintable()).split())
    return cleaned[:limit]


def _resolve(raw_url: str) -> tuple[str, str, str] | None:
    """(site, url, host) the way `rokan do` derives them: `task.site` is
    `_find_site`'s normalised URL, `url` is that with a scheme, `host` is the
    bare host that travels in evidence and the trailer."""
    site = _find_site(raw_url.strip())
    if site is None:
        return None
    url = site if "://" in site else f"https://{site}"
    host = site.split("://", 1)[-1].split("/", 1)[0]
    return site, url, host


# --------------------------------------------------------------------------
# list
# --------------------------------------------------------------------------


def cmd_native_list(args: argparse.Namespace) -> int:
    resolved = _resolve(args.url)
    if resolved is None:
        _err(f"not a site: {args.url!r}")
        return EXIT_POLICY
    site, url, host = resolved
    began = time.monotonic()
    tools = asyncio.run(native.list_tools(site, url))
    ms = int((time.monotonic() - began) * 1000)
    if args.as_json:
        _out(
            json.dumps(
                {
                    "site": host,
                    "url": url,
                    "tools": [
                        {
                            "name": t.name,
                            "read": t.auto_invokable,
                            "description": t.description,
                        }
                        for t in tools
                    ],
                    "ms": ms,
                }
            )
        )
        return EXIT_OK
    if not tools:
        _out(f"no WebMCP tools declared at {url}")
        return EXIT_OK
    width = max(len(t.name) for t in tools)
    for t in tools:
        kind = "read" if t.auto_invokable else "write"
        name = _one_line(t.name, 64)
        _out(f"{name:<{width}}  {kind:<5}  {_one_line(t.description, _DESC_MAX)}")
    return EXIT_OK


# --------------------------------------------------------------------------
# invoke
# --------------------------------------------------------------------------


class BadInput(ValueError):
    """The caller's input could not be turned into a tool input object."""


def _previous_value() -> str:
    path = _last_file()
    try:
        record = json.loads(path.read_text())
    except OSError as exc:
        raise BadInput(f"{PREV_TOKEN}: no previous invoke ({path} is missing)") from exc
    except ValueError as exc:
        raise BadInput(f"{PREV_TOKEN}: {path} is not readable JSON") from exc
    value = record.get("value") if isinstance(record, dict) else None
    if not isinstance(value, str):
        raise BadInput(f"{PREV_TOKEN}: {path} holds no value")
    return value


def _apply_set(target: dict[str, Any], spec: str) -> None:
    """`a.b.c=value` into nested dicts; the leaf is always a string."""
    path, sep, value = spec.partition("=")
    if not sep or not path:
        raise BadInput(f"--set wants PATH=VALUE, got {spec!r}")
    keys = path.split(".")
    if any(not k for k in keys):
        raise BadInput(f"--set path has an empty segment: {path!r}")
    if value == PREV_TOKEN:
        value = _previous_value()
    node = target
    for key in keys[:-1]:
        child = node.get(key)
        if not isinstance(child, dict):
            child = {}
            node[key] = child
        node = child
    node[keys[-1]] = value


def build_input(raw_json: str | None, sets: list[str] | None) -> dict[str, Any]:
    """`--input` is the base object; each `--set` overlays one leaf. Neither
    given means an empty object — a no-argument tool (`get_cart`) is real."""
    tool_input: dict[str, Any] = {}
    if raw_json is not None:
        try:
            parsed = json.loads(raw_json)
        except ValueError as exc:
            raise BadInput(f"--input is not valid JSON: {exc}") from exc
        if not isinstance(parsed, dict):
            raise BadInput("--input must be a JSON object")
        tool_input = parsed
    for spec in sets or []:
        _apply_set(tool_input, spec)
    return tool_input


def _write_allowed() -> bool:
    """`--allow-write` is honoured only where `general` (the write class) is
    on offer. A read-only deployment (`ROKAN_TASK_CLASSES=read_value,read_list`)
    stays read-only whatever flag the caller passes."""
    allowed = _allowed_classes()
    return allowed is None or "general" in allowed


def _record_last(host: str, tool: str, result: native.NativeResult) -> None:
    record = {
        "site": host,
        "tool": tool,
        "value": result.value,
        "elapsed_ms": result.elapsed_ms,
        "at": datetime.now(UTC).isoformat(timespec="seconds"),
    }
    try:
        _last_file().write_text(json.dumps(record))
    except OSError as exc:
        _err(f"  (could not record the value for {PREV_TOKEN}: {exc})")


async def _invoke(
    site: str, url: str, tool: str, tool_input: dict[str, Any], *, allow_write: bool
) -> tuple[native.NativeResult | None, int]:
    """(result, wall_ms); result None when the site does not declare `tool`."""
    tools = await native.list_tools(site, url)
    meta = next((t for t in tools if t.name == tool), None)
    if meta is None:
        return None, 0
    began = time.monotonic()
    result = await native.invoke(
        site, url, tool, tool_input, require_read=not allow_write, tool_meta=meta
    )
    elapsed = int((time.monotonic() - began) * 1000) or result.elapsed_ms
    return result, elapsed


def cmd_native_invoke(args: argparse.Namespace) -> int:
    # Every refusal below is decided BEFORE anything is sent to the site.
    resolved = _resolve(args.url)
    if resolved is None:
        _err(f"not a site: {args.url!r}")
        return EXIT_POLICY
    site, url, host = resolved
    tool: str = args.tool
    if args.allow_write and not _write_allowed():
        _err("  ✕ refused — --allow-write is not available here")
        _err("    why     ROKAN_TASK_CLASSES pins this process to reads; writes are off")
        _err("    next    Unset ROKAN_TASK_CLASSES (or include `general`) where writes are meant")
        return EXIT_POLICY
    try:
        tool_input = build_input(args.input, args.set)
    except BadInput as exc:
        _err(f"  ✕ refused — {exc}")
        return EXIT_POLICY

    result, elapsed = asyncio.run(
        _invoke(site, url, tool, tool_input, allow_write=bool(args.allow_write))
    )

    def emit_json(*, ok: bool, value: str, ms: int, is_error: bool) -> None:
        if args.as_json:
            _out(
                json.dumps(
                    {
                        "ok": ok,
                        "site": host,
                        "tool": tool,
                        "value": value,
                        "elapsed_ms": ms,
                        "model_calls": 0,
                        "is_error": is_error,
                    }
                )
            )

    if result is None:
        _err(f"  ✕ stopped — {url} does not declare a tool named {tool!r}")
        _err(f"    next    rokan-do native list {url}")
        emit_json(ok=False, value="", ms=0, is_error=True)
        return EXIT_TOOL
    refused = result.raw.get("refused") if isinstance(result.raw, dict) else None
    if refused:
        # The read/write gate said no; the site was never contacted.
        _err(f"  ✕ refused — {refused}")
        if not args.allow_write:
            _err("    next    Re-run with --allow-write to approve this write yourself")
        emit_json(ok=False, value="", ms=0, is_error=True)
        return EXIT_POLICY
    _record_last(host, tool, result)
    if not result.ok:
        _err(f"  ✕ stopped — {tool} did not answer")
        if result.value:
            _err(f"    detail  {_one_line(result.value, 200)}")
        emit_json(ok=False, value=result.value, ms=elapsed, is_error=result.is_error)
        return EXIT_TOOL
    # The SAME Result + renderer `rokan do` uses, so the trailer line the bridge
    # parses (`<answer>   <ms>ms  ⚡  ⚙ native:<site>:<tool>`) is produced by
    # the one place that knows its grammar — never hand-formatted here.
    from .service import _native_performed  # noqa: PLC0415 — heavy; deferred

    performed = _native_performed(host, result.value, tool, elapsed, calls=0)
    code = render(performed.result)
    emit_json(ok=True, value=result.value, ms=elapsed, is_error=False)
    return code


# --------------------------------------------------------------------------
# parser
# --------------------------------------------------------------------------


def add_native_parser(sub: Any) -> None:
    """Register `native list` / `native invoke` on `rokan-do`'s subparsers."""
    p = sub.add_parser(
        "native",
        help="a site's own WebMCP tools, called by name — no model, no DOM",
    )
    nsub = p.add_subparsers(dest="native_command")

    lp = nsub.add_parser("list", help="the tools a site declares, read or write")
    lp.add_argument("url")
    lp.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="one JSON line {site, url, tools:[{name, read, description}], ms}",
    )
    lp.set_defaults(func=cmd_native_list)

    ip = nsub.add_parser("invoke", help="call one declared tool with an explicit input")
    ip.add_argument("url")
    ip.add_argument("tool")
    ip.add_argument("--input", metavar="JSON", help="the tool's input, as a JSON object")
    ip.add_argument(
        "--set",
        action="append",
        metavar="PATH=VALUE",
        help=(
            "one input field, dotted for nesting (catalog.query=wool runners); "
            f"repeatable; VALUE {PREV_TOKEN} is the previous invoke's answer"
        ),
    )
    ip.add_argument(
        "--allow-write",
        action="store_true",
        help="approve a write-class tool (refused where ROKAN_TASK_CLASSES excludes general)",
    )
    ip.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="after the answer line, one JSON line {ok, site, tool, value, elapsed_ms, …}",
    )
    ip.set_defaults(func=cmd_native_invoke)

    p.set_defaults(func=lambda _a: _native_usage(p))


def _native_usage(parser: argparse.ArgumentParser) -> int:
    parser.print_help(file=sys.stdout)
    return EXIT_POLICY
