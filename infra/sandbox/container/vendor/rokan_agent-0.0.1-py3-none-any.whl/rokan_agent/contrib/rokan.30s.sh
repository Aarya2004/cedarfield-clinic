#!/bin/bash
# Rokan presence dot — a SwiftBar/xbar plugin. One glyph in the menu bar:
#
#   ● saffron        watching, all quiet
#   ●·N saffron      N changes since you last looked (rokan status)
#   ● grey           the background service is not running
#   ● wine           a watch needs you (two consecutive failures)
#
# Install: brew install swiftbar; copy this file into your SwiftBar plugin
# folder (the .30s. in the name IS the refresh cadence). Or xbar.
#
# It is an indicator, not an app: read-only queries against the local
# ledger, no network, no writes, nothing ambient beyond the glyph. It never
# animates and never pops anything up — the dot changing color IS the entire
# vocabulary.
set -euo pipefail

ROKAN_HOME="${ROKAN_MCP_HOME:-$HOME/.rokan}"
DB="$ROKAN_HOME/rokan.db"
SEEN="$ROKAN_HOME/.dot-seen"

SAFFRON="#d97706"
WINE="#991b1b"
GREY="#8e8e93"

color_param() {
  # SwiftBar prefers sfcolor; xbar reads color. Emitting both is harmless.
  printf 'color=%s sfcolor=%s' "$1" "$1"
}

if [ ! -f "$DB" ]; then
  echo "● | $(color_param "$GREY")"
  echo "---"
  echo "Rokan has no watches yet"
  echo "Get started | bash=rokan param1=--help terminal=true"
  exit 0
fi

q() { sqlite3 -readonly "$DB" "$1" 2>/dev/null || echo ""; }

WATCHES=$(q "SELECT COUNT(*) FROM watch WHERE retired_at IS NULL;")
LAST_AT=$(q "SELECT MAX(at) FROM observation;")

# A watch needs you: two consecutive non-ok observations on an active watch.
NEEDS_YOU=$(q "
WITH latest AS (
  SELECT w.id AS wid,
         (SELECT COUNT(*) FROM observation o
           WHERE o.watch_id = w.id
             AND o.id > COALESCE((SELECT MAX(id) FROM observation
                                   WHERE watch_id = w.id AND status = 'ok'), 0)
         ) AS streak
  FROM watch w WHERE w.retired_at IS NULL)
SELECT COUNT(*) FROM latest WHERE streak >= 2;")

# Unread: changed checks newer than the last time `rokan status` was read.
if [ -f "$SEEN" ]; then
  SEEN_AT=$(date -u -r "$SEEN" +"%Y-%m-%dT%H:%M:%S")
else
  SEEN_AT="1970-01-01T00:00:00"
fi
UNREAD=$(q "SELECT COUNT(*) FROM observation WHERE changed = 1 AND at > '$SEEN_AT';")

SERVICE_RUNNING=0
if launchctl print "gui/$(id -u)/computer.rokan.serve" 2>/dev/null \
    | grep -q "state = running"; then
  SERVICE_RUNNING=1
fi

if [ "${NEEDS_YOU:-0}" -gt 0 ]; then
  echo "● | $(color_param "$WINE")"
elif [ "$SERVICE_RUNNING" -eq 0 ]; then
  echo "● | $(color_param "$GREY")"
elif [ "${UNREAD:-0}" -gt 0 ]; then
  echo "●·$UNREAD | $(color_param "$SAFFRON")"
else
  echo "● | $(color_param "$SAFFRON")"
fi

echo "---"
echo "$WATCHES watches · last check ${LAST_AT:-never}"
q "SELECT '  ' || host || '   ' || COALESCE(
     (SELECT MAX(at) FROM observation
       WHERE watch_id = watch.id AND status = 'ok'), 'never')
   FROM watch WHERE retired_at IS NULL ORDER BY host;" | while read -r line; do
  [ -n "$line" ] && echo "$line | font=Menlo size=12"
done
if [ "$SERVICE_RUNNING" -eq 0 ]; then
  echo "service not running — rokan serve --install | $(color_param "$GREY")"
fi
echo "Open status | bash=rokan param1=status terminal=true"
