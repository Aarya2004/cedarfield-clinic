"""Did we actually land on the page we think we did?

Without this, the watcher's worst failure is also its loudest. A session
expires overnight, the site serves a sign-in page, and a naive diff reports the
largest change it has ever seen — at 7am, to someone who then stops trusting
it. The change is real; the *conclusion* is wrong. Nothing changed on the page
being watched, because that page was never reached.

So every observation is checked against anchors — the parts that stayed put
while the volatile parts moved — before any diff is believed. Anchors gone
means "this is not that page", which is a different event with a different
next step, and never a change notification.

Pairs with :mod:`volatility`: the mask says what may move, the anchors say what
must not.
"""

from __future__ import annotations

import json
from collections.abc import Sequence
from dataclasses import dataclass

from .reasons import Reason
from .result import Result
from .volatility import SLOT, Mask, lines, tokens

#: How much of the page's stable skeleton must survive for it to still be the
#: same page.
#:
#: ⚠️ **Not calibrated.** Chosen as a starting point, not measured against real
#: sites. Sites legitimately drop a banner or a row between loads, so
#: all-or-nothing is too brittle; how much slack is right is an empirical
#: question the first real watches have to answer. Do not quote it as tuned.
ANCHOR_TOLERANCE = 0.6

#: Anchors shorter than this match too much to identify a page.
_MIN_ANCHOR_TOKENS = 2

#: Above this share of never-seen lines, the observation is treated as drift
#: even when the anchor fraction passes. Anchors are the lines most likely to
#: be site chrome — nav, footer, cookie banner — and a login wall carries the
#: same chrome. The wall's *body* is what gives it away: line after line this
#: page has never shown.
#:
#: ⚠️ **Not calibrated**, same as ANCHOR_TOLERANCE. The deliberate bias: a
#: big genuine update that trips this reads as drift, whose message names a
#: runnable next step — the reverse mistake (a login wall reported as
#: "changed" at 7am) torches trust. Do not quote it as tuned.
NOVELTY_TOLERANCE = 0.6

#: When anchors are thin, how much novel content it takes to call the page
#: someone else's. Found by the wheel E2E, not by review: on a small page the
#: watched value is itself an anchor, so the value changing dropped the
#: anchor fraction below tolerance and the change was reported as DRIFT —
#: "the page changed shape" — when the page had done exactly what the user
#: was watching for. Missing anchors alone are how small pages change;
#: missing anchors *replaced by lines never seen before* are how sessions
#: expire. ⚠️ Not calibrated either.
REPLACEMENT_TOLERANCE = 0.4


@dataclass(frozen=True, slots=True)
class Anchors:
    """Lines that were present, unchanged, in every sample of the page.

    Stored **raw** (whitespace-normalised, never mask-rendered). The mask
    evolves after learning — a template folded in weeks later must not
    invalidate anchors written before it existed, so masking happens at
    compare time instead. Anchors stored by earlier builds may carry slot
    markers; ``present_fraction`` still matches those against the masked view.
    """

    lines: tuple[str, ...]

    @property
    def is_empty(self) -> bool:
        return not self.lines

    def to_json(self) -> str:
        return json.dumps(list(self.lines), separators=(",", ":"))

    @classmethod
    def from_json(cls, raw: str) -> Anchors:
        return cls(lines=tuple(json.loads(raw)))

    def present_fraction(self, text: str, mask: Mask | None = None) -> float:
        if not self.lines:
            return 0.0
        seen = set(_raw_lines(text)) | set(_masked_lines(text, mask))
        return sum(1 for line in self.lines if line in seen) / len(self.lines)


def _raw_lines(text: str) -> list[str]:
    return [" ".join(tokens(line)) for line in lines(text)]


def _masked_lines(text: str, mask: Mask | None = None) -> list[str]:
    source = mask.apply(text) if mask is not None and not mask.masks_nothing else text
    return [" ".join(tokens(line)) for line in lines(source)]


def learn_anchors(samples: Sequence[str]) -> Anchors:
    """The stable skeleton: lines every sample shares, stored raw.

    Volatile lines drop out of the intersection by themselves — a line that
    ticks between samples is not in every sample. No mask is involved, so the
    anchors stay valid however the mask later evolves.
    """
    if not samples:
        return Anchors(lines=())

    common: set[str] | None = None
    for sample in samples:
        common = (
            set(_raw_lines(sample))
            if common is None
            else (common & set(_raw_lines(sample)))
        )

    kept = [
        line
        for line in sorted(common or set())
        if len(tokens(line)) >= _MIN_ANCHOR_TOKENS
        and not all(token == SLOT for token in tokens(line))
    ]
    return Anchors(lines=tuple(kept))


def _has_lineage(line: str, known: Sequence[str]) -> bool:
    """Whether this line reads as a mutation of a line the page has shown.

    'REVENUE 9,999,000' after 'REVENUE 4,812,000' is the watched value
    changing — the product working — not novel content. A login wall's
    'Please verify your identity' shares nothing with any learned line.
    Token overlap, not sequence match: cheap, order-blind, and enough.
    """
    line_tokens = set(tokens(line))
    if not line_tokens:
        return False
    for candidate in known:
        overlap = line_tokens & set(tokens(candidate))
        # Half the line's tokens AND at least two of them. One shared word
        # is not lineage: it let a login wall's 'Forgot your password?' claim
        # descent from any anchor containing 'your', and single-token chrome
        # ('Support') claim descent from the nav — measured to re-open the
        # login-wall hole with a 0.04 margin. A genuinely mutated value line
        # shares its whole label, which is always ≥ 2 tokens.
        if len(overlap) >= 2 and len(overlap) * 2 >= len(line_tokens):
            return True
    return False


def novelty_fraction(text: str, anchors: Anchors, mask: Mask | None = None) -> float:
    """Share of this observation's lines the learned page cannot explain.

    A line is explained by being an anchor, being masked (learned as
    volatile), or carrying *lineage* — sharing at least half its tokens with
    some anchor, which is what a changed value looks like. Everything else
    is novel, and a page that is mostly novel is not the page that was
    learned, whatever the surviving chrome says.
    """
    raw = _raw_lines(text)
    if not raw:
        return 0.0
    masked = _masked_lines(text, mask)
    known = anchors.lines
    known_set = set(known)
    novel = sum(
        1
        for raw_line, masked_line in zip(raw, masked, strict=True)
        if raw_line not in known_set
        and SLOT not in masked_line
        and not _has_lineage(raw_line, known)
    )
    return novel / len(raw)


def verify(text: str, anchors: Anchors, mask: Mask | None = None) -> Result:
    """Check an observation before any diff of it is trusted.

    Returns an ``ok`` Result carrying the masked, canonical text — the exact
    string a change comparison should use — or a failure naming why the
    observation cannot be compared at all.
    """
    if anchors.is_empty:
        # Never treat "we learned nothing" as "everything is fine". A watch
        # with no anchors cannot tell a dashboard from a login wall.
        return Result.abstained(Reason.ABSTAINED_LOW_CONFIDENCE)

    canonical = "\n".join(_masked_lines(text, mask))
    present = anchors.present_fraction(text, mask)
    novel = novelty_fraction(text, anchors, mask)
    evidence = [f"anchors_present={present:.2f}", f"novel_lines={novel:.2f}"]

    # Three ways to conclude "this is not the page that was learned", each
    # covering the others' blind spot:
    #   1. Nothing recognisable at all — a blank, an error page, a redirect.
    #   2. Mostly-novel content — the chrome-heavy login wall that keeps
    #      enough anchors to pass any fraction test.
    #   3. Thin anchors AND meaningful novel replacement — the classic
    #      session expiry. Thin anchors ALONE are not drift: on a small page
    #      the watched value is itself an anchor, and the value changing is
    #      the product working, not the page vanishing.
    if present == 0.0:
        return Result.failed(Reason.DRIFT_DETECTED, evidence=evidence)
    if novel > NOVELTY_TOLERANCE:
        return Result.failed(Reason.DRIFT_DETECTED, evidence=evidence)
    if present < ANCHOR_TOLERANCE and novel > REPLACEMENT_TOLERANCE:
        return Result.failed(Reason.DRIFT_DETECTED, evidence=evidence)

    if mask is not None and not mask.is_trustworthy(text):
        # A mask covering most of the page does not make a quiet watcher, it
        # makes a blind one. Say so rather than report "no changes" forever.
        return Result.abstained(
            Reason.ABSTAINED_LOW_CONFIDENCE,
            evidence=[f"masked_fraction={mask.masked_fraction(text):.2f}"],
        )

    return Result.succeeded(canonical, evidence=[f"anchors_present={present:.2f}"])
