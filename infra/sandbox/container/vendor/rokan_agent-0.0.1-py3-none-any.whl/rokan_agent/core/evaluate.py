"""Measuring whether the mask is any good, without anyone labelling anything.

The hard part of evaluating a change detector is ground truth: given two
observations of a real page, did it *meaningfully* change? Nobody wants to
label thousands of those, and a labelling pass we do ourselves is a labelling
pass we can talk ourselves into.

Both numbers here avoid the problem instead of solving it.

**False alerts** are measured only within a *burst* — several loads of one page
seconds apart. Nothing on the page can genuinely have changed in that window,
so any reported change is definitionally wrong. No labels required, and no
judgement call available.

**Detection** is measured against deliberate mutations of a recorded sample: a
number moves, a line appears, a line vanishes. Those changes are real by
construction and must be caught.

Two baselines bracket every result, as spec §12 requires — a measurement with
nothing to beat is a number, not evidence:

* **no mask at all** — reports every difference. Its false-alert rate is the
  ceiling we must come in under. If we do not, the mask does nothing.
* **never report** — perfect silence, zero detection. If our detection rate is
  not clearly above it, the quiet is worthless.

**The honest limit:** synthetic mutations are not real edits. A real change may
be subtler than any of these, so the detection figure is an upper bound on a
harder task, and must be reported as one.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass

from .corpus import Sample, bursts
from .metrics import Rate, wilson
from .reinforce import FOLD_CAP, explains_entire_diff, flap_candidates, fold, ripe
from .volatility import Mask, changed, learn, lines, tokens

#: A mutation takes a page and returns a changed page, or None if it does not
#: apply (nothing numeric to move, too few lines to drop).
Mutation = Callable[[str], str | None]


def bump_a_number(text: str) -> str | None:
    """A usage figure, a balance, a count — the common real change."""
    for index, line in enumerate(lines(text)):
        for position, token in enumerate(tokens(line)):
            digits = "".join(c for c in token if c.isdigit())
            if digits:
                replaced = token.replace(digits, str(int(digits) + 7), 1)
                parts = tokens(line)
                parts[position] = replaced
                page = lines(text)
                page[index] = " ".join(parts)
                return "\n".join(page)
    return None


def add_a_line(text: str) -> str | None:
    """An alert or banner appearing — what a watcher exists to catch."""
    return text + "\nYOUR PLAN HAS BEEN CANCELLED"


def drop_a_line(text: str) -> str | None:
    """Something disappearing is a change too, and easier to miss."""
    page = lines(text)
    return "\n".join(page[:-1]) if len(page) > 2 else None


MUTATIONS: tuple[tuple[str, Mutation], ...] = (
    ("number moved", bump_a_number),
    ("line added", add_a_line),
    ("line removed", drop_a_line),
)


@dataclass(frozen=True, slots=True)
class Evaluation:
    name: str
    false_alerts: Rate
    detection: Rate
    baseline_no_mask: Rate
    baseline_never_report: Rate
    templates_learned: int
    samples: int
    #: Auto-folds the flap path committed during replay. Each one is a single
    #: "now ignoring" message to the user — not free, so not hidden.
    folds: int = 0

    @property
    def beats_no_mask(self) -> bool:
        """Fewer false alerts than reporting every difference, established —
        not merely a nicer point estimate."""
        return self.false_alerts.high < self.baseline_no_mask.low

    @property
    def beats_silence(self) -> bool:
        return self.detection.low > self.baseline_never_report.high

    def report(self) -> str:
        verdict = (
            "useful"
            if self.beats_no_mask and self.beats_silence
            else "NOT ESTABLISHED"
        )
        return (
            f"{self.name}\n"
            f"  false alerts   {self.false_alerts}\n"
            f"    vs no mask   {self.baseline_no_mask}\n"
            f"  detection      {self.detection}   (upper bound: synthetic)\n"
            f"    vs silence   {self.baseline_never_report}\n"
            f"  templates      {self.templates_learned}   samples {self.samples}"
            + (f"   folds {self.folds}" if self.folds else "")
            + f"\n  verdict        {verdict}"
        )


def evaluate(
    name: str, samples: Sequence[Sample], mutations: Sequence[tuple[str, Mutation]] = MUTATIONS
) -> Evaluation:
    """Replay a recorded corpus through the detector. Deterministic.

    The mask is learned from the **first burst only** and scored on the
    later ones, mirroring production: the learn run happens once, and every
    scheduled check afterwards is out-of-sample. Scoring the training burst
    would credit the mask with memorising its own noise — with one burst
    recorded there is nothing held out, so every rate reports ``n=0`` rather
    than a flattering number.
    """
    groups = bursts(list(samples))
    training = [s.text for g in groups[:1] for s in g]
    scoring = groups[1:]
    mask = (
        learn(training)
        if len({t.strip() for t in training}) > 1
        else Mask(samples_seen=len(training))
    )

    fp_hits = fp_total = 0
    raw_hits = raw_total = 0
    for group in scoring:
        first = group[0].text
        for later in group[1:]:
            fp_total += 1
            raw_total += 1
            if changed(first, later.text, mask):
                fp_hits += 1
            if changed(first, later.text, None):
                raw_hits += 1

    caught = attempted = 0
    for group in scoring:
        base = group[0].text
        for _, mutate in mutations:
            mutated = mutate(base)
            if mutated is None:
                continue
            attempted += 1
            if changed(base, mutated, mask):
                caught += 1

    return Evaluation(
        name=name,
        false_alerts=wilson(fp_hits, fp_total),
        detection=wilson(caught, attempted),
        baseline_no_mask=wilson(raw_hits, raw_total),
        baseline_never_report=wilson(0, attempted),
        templates_learned=len(mask.active_templates),
        samples=len(samples),
    )


def evaluate_reinforced(
    name: str, samples: Sequence[Sample], mutations: Sequence[tuple[str, Mutation]] = MUTATIONS
) -> Evaluation:
    """Replay a corpus through the *whole* production loop, folds included.

    ``evaluate`` freezes the mask after the learning burst, which is exactly
    the engine the flap path exists to improve: slow volatility — a field
    that ticks between bursts but not inside one — alerts on every check,
    forever. This replays each scored check in time order, letting the flap
    detector fold what keeps flapping, and reports what the user would have
    actually experienced: false alerts, fold notices, and whether real
    changes still get through the final mask.
    """
    groups = bursts(list(samples))
    training = [s.text for g in groups[:1] for s in g]
    scoring = groups[1:]
    mask = (
        learn(training)
        if len({t.strip() for t in training}) > 1
        else Mask(samples_seen=len(training))
    )

    window: list[str] = [mask.apply(training[-1])] if training else []
    fp_hits = fp_total = 0
    raw_hits = raw_total = 0
    folds = 0
    for group in scoring:
        for index, sample in enumerate(group):
            canonical = mask.apply(sample.text)
            did_change = bool(window) and canonical != window[-1]
            within_burst = index > 0
            if within_burst:
                fp_total += 1
                raw_total += 1
                if changed(group[index - 1].text, sample.text, None):
                    raw_hits += 1
            if did_change:
                flaps = ripe(flap_candidates([*window, canonical]))
                committed = (
                    fold(mask, flaps, sample.text)
                    if flaps
                    and folds < FOLD_CAP  # model production's cap, not a laxer engine
                    and explains_entire_diff(flaps, window[-1], canonical)
                    else None
                )
                if committed is not None:
                    # One "now ignoring" notice; the window restarts because
                    # earlier canonicals were rendered under the old mask.
                    # Fold notices are interruptions the user receives — they
                    # are reported in `folds`, and the launch gate counts
                    # them separately from false alerts, never hides them.
                    mask = committed.mask
                    folds += 1
                    window = [mask.apply(sample.text)]
                    continue
                if within_burst:
                    fp_hits += 1
            window.append(canonical)
            window = window[-8:]

    caught = attempted = 0
    for group in scoring:
        base = group[0].text
        for _, mutate in mutations:
            mutated = mutate(base)
            if mutated is None:
                continue
            attempted += 1
            if changed(base, mutated, mask):
                caught += 1

    return Evaluation(
        name=name,
        false_alerts=wilson(fp_hits, fp_total),
        detection=wilson(caught, attempted),
        baseline_no_mask=wilson(raw_hits, raw_total),
        baseline_never_report=wilson(0, attempted),
        templates_learned=len(mask.active_templates),
        samples=len(samples),
        folds=folds,
    )
