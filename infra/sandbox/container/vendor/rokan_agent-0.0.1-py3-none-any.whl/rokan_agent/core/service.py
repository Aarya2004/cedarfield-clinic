"""Rokan as a local service, not a plugin.

The distinction is the whole reason this package exists. An MCP plugin is
request/response: a host asks, we answer, and **nothing invokes us at 7am**.
"Check this every morning" — the thing people actually rely on — is impossible
through that shape.

The browser daemon already owns its own process and already outlives whoever
spawned it (it adopts a running instance and reaps itself after an idle
timeout). This module widens that scope from "the browser" to "the engine": the
service owns the engine, and later the store and the scheduler. Every transport
becomes a client of it.

Skeleton: it holds an :class:`Engine` and nothing else. The socket, the store
and the scheduler arrive in their own steps.
"""

from __future__ import annotations

from .engine import Engine


class Service:
    """The long-lived local process that owns the engine."""

    def __init__(self) -> None:
        self._engine = Engine()

    @property
    def engine(self) -> Engine:
        return self._engine
