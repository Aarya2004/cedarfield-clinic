"""Making `rokan serve` a launchd citizen, so unattended means unattended.

The survival launch-metric counts scheduled checks that completed with no
human. Under `nohup`, a reboot or a logout ends the loop silently and the
metric measures the user's terminal habits instead of Rokan. A LaunchAgent
survives reboot, login, and crashes (KeepAlive restarts on non-zero exit).

Everything here is pure or injected: plist rendering is a function of its
inputs (golden-tested byte for byte), and the `launchctl` runner is a
callable the CLI passes in — tests never touch the real LaunchAgents
directory, and the one real install is verified by hand against
`launchctl print` before Stage 0 runs on it (C9: verify against the running
process, never against the code that built the arguments).
"""

from __future__ import annotations

import os
import plistlib
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from .proven import paths

LABEL = "computer.rokan.serve"

#: A runner takes argv and returns (exit_code, output). Injected so tests
#: can fake launchctl; the default speaks to the real one.
Runner = Callable[[list[str]], tuple[int, str]]


def _real_runner(argv: list[str]) -> tuple[int, str]:
    # 5s, not 30: `rokan status` calls this on every invocation, and a
    # wedged launchctl must not wedge the status line with it.
    proc = subprocess.run(argv, capture_output=True, text=True, timeout=5)
    return proc.returncode, (proc.stdout + proc.stderr)


def supported() -> bool:
    return sys.platform == "darwin"


def _require_macos() -> None:
    if not supported():
        raise RuntimeError(
            "background install uses launchd and is macOS-only today — on "
            "Linux run it under systemd or nohup: nohup rokan serve &"
        )


def plist_path(home: Path | None = None) -> Path:
    base = home if home is not None else Path.home()
    return base / "Library" / "LaunchAgents" / f"{LABEL}.plist"


def log_path() -> Path:
    return paths.home() / "serve.log"


def resolve_program() -> list[str]:
    """The exact command launchd should run — never a bare name.

    A1's lesson applies doubly here: launchd agents get a minimal
    environment, so a bare `rokan` resolves to nothing. `sys.argv[0]` is the
    installed console script when run as one; running from source refuses
    rather than pinning a path that stops existing when the checkout moves.
    """
    script = Path(sys.argv[0]).resolve()
    if script.name != "rokan" or not os.access(script, os.X_OK):
        raise RuntimeError(
            "serve --install needs the installed `rokan` command, not a "
            "source checkout — install the wheel, then run it again"
        )
    # --from-service marks the launchd invocation so it can skip the
    # "a service is already running these watches" guard — which would
    # otherwise see ITSELF, refuse, exit 2, and put KeepAlive into a spawn
    # loop. Found by the real-machine smoke, not by the fakes.
    return [str(script), "serve", "--from-service"]


def render_plist(program: list[str], log: Path) -> bytes:
    """The LaunchAgent, byte-stable for the golden test.

    KeepAlive on unsuccessful exit only: a crash restarts, a deliberate stop
    stays stopped. EnvironmentVariables are the minimum the daemon needs —
    PATH for Chrome discovery, HOME for the vault — because launchd gives
    agents almost nothing.
    """
    env = {
        "PATH": "/usr/bin:/bin:/usr/local/bin:/opt/homebrew/bin",
        "HOME": str(Path.home()),
        # Python block-buffers stdout when it is not a tty, so without this
        # the service's log stays empty until the process EXITS — a healthy
        # service that looks dead, which is the papercut that makes a tester
        # kill it. Found on the real machine, invisible to every fake.
        "PYTHONUNBUFFERED": "1",
    }
    # An override in the installing shell must follow the service, or a dev
    # or test install silently points the background loop at the REAL store
    # (D10's rule, extended to launchd).
    if os.environ.get("ROKAN_MCP_HOME"):
        env["ROKAN_MCP_HOME"] = os.environ["ROKAN_MCP_HOME"]
    payload = {
        "Label": LABEL,
        "ProgramArguments": program,
        "RunAtLoad": True,
        "KeepAlive": {"SuccessfulExit": False},
        "StandardOutPath": str(log),
        "StandardErrorPath": str(log),
        "ProcessType": "Background",
        "EnvironmentVariables": env,
    }
    return plistlib.dumps(payload, sort_keys=True)


@dataclass(frozen=True, slots=True)
class ServiceState:
    installed: bool
    running: bool


def state(run: Runner | None = None, home: Path | None = None) -> ServiceState:
    installed = plist_path(home).exists()
    if not installed:
        return ServiceState(installed=False, running=False)
    runner = run or _real_runner
    code, output = runner(
        ["launchctl", "print", f"gui/{os.getuid()}/{LABEL}"]
    )
    return ServiceState(installed=True, running=code == 0 and "state = running" in output)


def install(
    program: list[str], *, run: Runner | None = None, home: Path | None = None
) -> list[str]:
    """Write the plist, load it, VERIFY it runs. Returns past-tense lines.

    Raises RuntimeError with the check-it-yourself command when verification
    fails — an install that claims success without looking is exactly the
    lie C9 exists to prevent.
    """
    if run is None:
        _require_macos()
    runner = run or _real_runner
    target = plist_path(home)
    target.parent.mkdir(parents=True, exist_ok=True)
    log = log_path()
    # Pre-created 0600 BEFORE launchd touches it: launchd creates the log at
    # umask default (0644) and never re-modes an existing file. §8.2 #7's
    # file-mode family covers this log — it holds watched hostnames.
    if not log.exists():
        os.close(os.open(log, os.O_CREAT | os.O_WRONLY, 0o600))
    target.write_bytes(render_plist(program, log))
    os.chmod(target, 0o600)
    lines = [f"wrote {target}"]

    def _abort(message: str) -> RuntimeError:
        # A failed install must not leave the plist behind: macOS bootstraps
        # ~/Library/LaunchAgents at login, so an orphaned plist silently
        # becomes a running service the next time the user logs in.
        target.unlink(missing_ok=True)
        return RuntimeError(message)

    domain = f"gui/{os.getuid()}"
    code, _ = runner(["launchctl", "bootstrap", domain, str(target)])
    if code != 0:
        # Already bootstrapped (re-install) or an older macOS. bootout+retry
        # covers the first; `load -w` the second (same era as `print`, so if
        # this path ever runs, verification below speaks its dialect too).
        runner(["launchctl", "bootout", f"{domain}/{LABEL}"])
        code, _ = runner(["launchctl", "bootstrap", domain, str(target)])
        if code != 0:
            code, _ = runner(["launchctl", "load", "-w", str(target)])
    if code != 0:
        raise _abort(
            f"could not start the service — check: launchctl print {domain}/{LABEL}"
        )
    lines.append("started the service")

    # launchd reports `spawn scheduled` for a beat before `running` — a
    # single immediate look raises on a healthy install. A few seconds of
    # patience is not the same as not looking.
    for attempt in range(6):
        verify_code, output = runner(["launchctl", "print", f"{domain}/{LABEL}"])
        if verify_code == 0 and "state = running" in output:
            lines.append("verified: running")
            return lines
        if attempt < 5:
            time.sleep(1)
    runner(["launchctl", "bootout", f"{domain}/{LABEL}"])
    raise _abort(
        f"the service loaded but is not running — check: "
        f"launchctl print {domain}/{LABEL} and {log}"
    )


def uninstall(*, run: Runner | None = None, home: Path | None = None) -> list[str]:
    """Bootout + delete. Idempotent: uninstalling nothing reports that."""
    runner = run or _real_runner
    target = plist_path(home)
    if not target.exists():
        return ["nothing installed — nothing removed"]
    was_running = state(run=runner, home=home).running
    code, _ = runner(["launchctl", "bootout", f"gui/{os.getuid()}/{LABEL}"])
    target.unlink()
    if code != 0 and was_running:
        # The plist is gone but the process may still be running — and with
        # the plist removed, status can no longer see it. Say so, or the
        # user starts a second scheduler next to an invisible first one.
        return [
            f"removed {target}",
            "warning: the running service did not confirm stopping — check: "
            f"launchctl print gui/{os.getuid()}/{LABEL}",
        ]
    return ["stopped the service", f"removed {target}"]
