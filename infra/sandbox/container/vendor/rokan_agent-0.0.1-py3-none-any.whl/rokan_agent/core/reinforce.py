"""Learning from the checks themselves — the flap path.

Quiet checks carry no diff, so everything the mask can learn after day one
lives in the *changed* checks. That is dangerous territory: fold a reported
change into the mask carelessly and the watch goes blind to the exact line
the user installed it for. Every rule here is a guard rail:

* Evidence is a **streak** — the same template mined from several recent
  changed pairs. A one-off change produces one sighting and can never fold.
* A fold must **explain the entire current diff**. A flap arriving together
  with a genuine change reports the change and folds nothing.
* A fold is **self-verifying**: each new template has to match the page in
  hand, match it *unambiguously* (a template that fits two lines would mask
  the twin the user is watching), and actually silence something.
* A fold must leave the mask **trustworthy** — masking most of the page is
  blindness, not quiet.

Everything is pure: canonicals in, verdicts out. The engine owns the store,
the window boundaries and the notification; the evaluation harness can drive
this directly on a recorded corpus.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

from .volatility import (
    ACTIVATION_SUPPORT,
    MAX_MASKED_FRACTION,
    Mask,
    Template,
    matching_lines,
    templates_from_pair,
)

#: Sightings before a line is considered flapping rather than changing.
FLAP_THRESHOLD = 3

#: Trailing pairs that may vouch for a streak. A window, not a reset: a pair
#: where the flap line shifted position (a banner appeared above it) simply
#: contributes nothing, instead of zeroing the count and restarting the
#: user's alerts from scratch.
WINDOW_PAIRS = 6

#: Auto-folds per watch, ever. A page that needs more than this is not noisy,
#: it is dynamic, and the honest end state is telling the user rather than
#: quietly masking it into blindness.
FOLD_CAP = 5


@dataclass(frozen=True, slots=True)
class Flap:
    """One template seen varying across recent changed checks."""

    template: Template
    streak: int


def flap_candidates(canonicals: Sequence[str]) -> tuple[Flap, ...]:
    """Per-template count of recent pairs showing it, strongest first.

    ``canonicals`` are oldest→newest and must all be rendered under the same
    mask — mixing masks manufactures templates out of the mask change itself,
    so the caller windows the input at the last fold.
    """
    counts: dict[Template, int] = {}
    # Consecutive identical canonicals are quiet checks — they carry no
    # evidence and must not occupy window slots, or a ticker slower than the
    # check interval (changes every third check, say) dilutes its own streak
    # below the threshold and never folds. The streak counts *transitions*.
    distinct: list[str] = []
    for canonical in canonicals:
        if not distinct or canonical != distinct[-1]:
            distinct.append(canonical)
    pairs = list(zip(distinct, distinct[1:], strict=False))[-WINDOW_PAIRS:]
    for before, after in pairs:
        # Deduplicated per pair for the same reason learn() does it: twice on
        # one page is one sighting.
        for template in set(templates_from_pair(before, after)):
            counts[template] = counts.get(template, 0) + 1
    ordered = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0].render()))
    return tuple(Flap(template=t, streak=c) for t, c in ordered)


def ripe(flaps: Sequence[Flap], threshold: int = FLAP_THRESHOLD) -> tuple[Flap, ...]:
    return tuple(f for f in flaps if f.streak >= threshold)


def explains_entire_diff(
    flaps: Sequence[Flap], previous: str, current: str
) -> bool:
    """Whether masking just these templates makes the two observations equal.

    If a residual remains, something genuinely changed alongside the flap —
    that check must report normally and fold nothing, or the fold message
    would bury the very change the user installed the watch for.
    """
    trial = Mask(
        templates=tuple(f.template for f in flaps),
        support=tuple(max(f.streak, ACTIVATION_SUPPORT) for f in flaps),
    )
    return trial.apply(previous) == trial.apply(current)


@dataclass(frozen=True, slots=True)
class Fold:
    """A committed fold: the new mask, and exactly which templates made it.

    ``folded`` is what any user-facing notice must be built from — a ripe
    flap the guards refused is NOT ignored, and telling the user it is would
    be false and would break the one-notice promise when it re-ripens.
    """

    mask: Mask
    folded: tuple[Template, ...]


def fold(
    mask: Mask, flaps: Sequence[Flap], raw_sample: str, *, support_cap: int | None = None
) -> Fold | None:
    """The folded mask, or None when no fold passes the guards.

    ``support_cap`` exists for the human-initiated path: an explicit ignore
    enters at exactly the activation bar, never higher — the human witnessed
    the *alert*, not the volatility, and that is the weakest possible
    evidence a fold can rest on.
    """
    accepted: dict[Template, int] = {}
    for flap in flaps:
        matches = len(matching_lines(flap.template, raw_sample))
        if matches != 1:
            # Zero matches: the line moved on; folding is a no-op that would
            # re-fire the "now ignoring" notice forever. Two or more: the
            # template also fits a twin line — masking it would blind the
            # watch to the one the user is actually watching. Context-bearing
            # templates get NO exemption here: they are all-slot, so under a
            # repeated panel header ("Last updated" twice on one dashboard)
            # one would match both panels' value lines and silently kill the
            # second. On the single-header page they were built for, the
            # match count is 1 and this guard passes anyway.
            continue
        entering = max(flap.streak, ACTIVATION_SUPPORT)
        if support_cap is not None:
            entering = min(entering, support_cap)
        accepted[flap.template] = entering

    if not accepted:
        return None

    merged: dict[Template, int] = {}
    for template, prior in zip(mask.templates, mask.support, strict=True):
        merged[template] = prior
    for template, entering in accepted.items():
        # Never demote: the support statistic is what activation rests on
        # and what the benchmark reports.
        merged[template] = max(merged.get(template, 0), entering)

    ordered = sorted(merged.items(), key=lambda kv: (-kv[1], kv[0].render()))
    proposal = Mask(
        templates=tuple(t for t, _ in ordered),
        support=tuple(c for _, c in ordered),
        samples_seen=mask.samples_seen,
    )

    if proposal.masked_fraction(raw_sample) > MAX_MASKED_FRACTION:
        # The fold would cross from quiet into blind. verify() would start
        # abstaining on the very next check, which reads as a failure the
        # user cannot act on.
        return None
    if proposal.apply(raw_sample) == mask.apply(raw_sample):
        # Self-verification: a fold that silences nothing would detect the
        # same flap and re-send the same notice on every later check.
        return None
    return Fold(mask=proposal, folded=tuple(accepted))
