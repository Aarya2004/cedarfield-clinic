"""Drop consent-bar boilerplate from fetched page text.

A cookie bar is the likeliest false alert on a real page. Its lines are
*inserts*, and inserts are never masked by rule (``volatility``); the fold
only learns in-place replacements (``reinforce``). So without this step the
watcher alerts when the bar appears, alerts again when it goes, and never
learns either. Filtering at the text step keeps the learning engine — and
Arav's false-alert benchmark — untouched.

This is the text-level MVP. The bar is recognised by what it says, not where
it sits, because ``document.body.innerText`` carries no layout. The
DOM-level strip (``position: fixed``/``sticky``, ``<dialog>``) — which also
tells a sticky header from a popup — belongs in the daemon, which is frozen
pending Arav's OK.

Two rules keep content safe: only short lines are candidates (a paragraph
that *discusses* cookies is content), and a line must carry both a consent
verb and a cookie/consent noun, or be one of a small list of bare consent
buttons.
"""

from __future__ import annotations

import re

#: A line longer than this is prose, never a bar. Bars are terse by design.
MAX_BAR_LINE = 160

#: Whole-line button labels (case-insensitive, trailing punctuation ignored).
_BUTTONS = frozenset(
    {
        "accept",
        "accept all",
        "accept all cookies",
        "accept cookies",
        "allow all",
        "allow all cookies",
        "allow cookies",
        "reject all",
        "reject all cookies",
        "decline",
        "decline all",
        "i agree",
        "i accept",
        "agree",
        "got it",
        "ok",
        "okay",
        "customise",
        "customize",
        "manage preferences",
        "manage cookies",
        "cookie settings",
        "cookie preferences",
        "privacy settings",
        "necessary only",
        "necessary cookies only",
        "only necessary",
        "essential only",
    }
)

_NOUN = re.compile(r"\bcookies?\b", re.IGNORECASE)
_VERB = re.compile(
    r"\b(use|uses|using|accept|agree|consent|allow|reject|decline|manage"
    r"|preferences|settings|policy|notice)\b",
    re.IGNORECASE,
)
_TRAILING = re.compile(r"[\s.!?…:]+$")


def is_consent_line(line: str) -> bool:
    """True for a line a consent bar would render and content would not."""
    stripped = line.strip()
    if not stripped or len(stripped) > MAX_BAR_LINE:
        return False
    label = _TRAILING.sub("", stripped).lower()
    if label in _BUTTONS:
        return True
    return bool(_NOUN.search(stripped) and _VERB.search(stripped))


def strip_consent_lines(text: str) -> str:
    """``text`` with consent-bar lines removed, other lines untouched."""
    return "\n".join(line for line in text.split("\n") if not is_consent_line(line))
