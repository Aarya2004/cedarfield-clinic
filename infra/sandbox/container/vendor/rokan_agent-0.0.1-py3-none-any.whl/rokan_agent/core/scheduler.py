"""Running checks when nobody is watching, and deciding when to speak.

This is the step that makes Rokan a product rather than a command. "Check this
every morning" cannot work through a request/response tool — nothing invokes it
at 7am. So there is a loop.

Two rules govern the loop, and both exist to stop it becoming something the
user mutes:

**A single blip is silent.** Networks fail. A watch that fails once and
recovers has told the user nothing worth an interruption, so a failure is only
announced after ``FAILING_THRESHOLD`` consecutive failures — and then exactly
once, on the check that crosses it, never again while it stays broken.

**Recovery is announced only if the failure was.** Otherwise a watch that
flaps hourly sends two messages an hour, which is worse than sending none.

Both decisions are derived from the append-only ledger rather than stored, so
there is no separate "have we notified?" state to drift out of sync with what
actually happened.
"""

from __future__ import annotations

import asyncio
import contextlib
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from .engine import NOW_IGNORING, Engine
from .notify import Notifier, changed_message, failing_message, now_ignoring_message
from .reasons import Reason, next_step_for
from .result import Result, Status
from .store import Watch

#: Consecutive failures before the user hears about it. One is a blip.
FAILING_THRESHOLD = 2

#: How often the loop wakes to look for work when nothing is due sooner.
POLL_SECONDS = 30.0


@dataclass(frozen=True, slots=True)
class Tick:
    """What one check did, and whether it was worth saying out loud."""

    watch: Watch
    result: Result
    notified: str | None = None


def _parse(iso: str) -> datetime:
    parsed = datetime.fromisoformat(iso)
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)


def due_at(engine: Engine, watch: Watch) -> datetime | None:
    """When this watch next wants running. ``None`` means "right now".

    Computed from the last observation rather than from a stored deadline, so
    a missed window (laptop asleep, process restarted) simply runs late
    instead of silently never running again.
    """
    history = engine.store.history(watch.id, limit=1)
    if not history:
        return None
    return _parse(history[0].at) + timedelta(seconds=watch.interval_seconds)


def is_due(engine: Engine, watch: Watch, now: datetime | None = None) -> bool:
    when = due_at(engine, watch)
    return when is None or when <= (now or datetime.now(UTC))


def seconds_until_next(engine: Engine, now: datetime | None = None) -> float:
    """How long the loop may sleep. Never negative, never unbounded."""
    moment = now or datetime.now(UTC)
    soonest: float | None = None
    for watch in engine.list_watches():
        when = due_at(engine, watch)
        if when is None:
            return 0.0
        wait = (when - moment).total_seconds()
        soonest = wait if soonest is None else min(soonest, wait)
    if soonest is None:
        return POLL_SECONDS
    return max(0.0, min(soonest, POLL_SECONDS))


def _decide(engine: Engine, watch: Watch, result: Result) -> str | None:
    """The message to send, or None to stay quiet."""
    before = engine.store.failure_streak_before_latest(watch.id)

    if result.status is Status.OK:
        if str(result.data) == "changed":
            ignored = [
                e.split("=", 1)[1]
                for e in result.evidence
                if e.startswith(f"{NOW_IGNORING}=")
            ]
            if ignored:
                # The fold's one-time notice replaces the change alert: this
                # "change" was the flap itself, and reporting it as news
                # would be the third alert for the same ticking line.
                return now_ignoring_message(watch.host, "\n".join(ignored), watch.id)
            return changed_message(watch.host, watch.url, watch.id)
        if before >= FAILING_THRESHOLD:
            # Recovery, and only because the failure was announced.
            return f"{watch.host} is working again\n\nrokan status"
        return None

    now_streak = before + 1
    if now_streak == FAILING_THRESHOLD:
        # Exactly once, on the check that crosses the line.
        reason = result.reason or Reason.ABSTAINED_LOW_CONFIDENCE
        return failing_message(
            watch.host, watch.id, reason.value, result.next_step or next_step_for(reason)
        )
    return None


async def run_due(
    engine: Engine, notifier: Notifier, now: datetime | None = None
) -> list[Tick]:
    """Run every watch that is due. Never raises for one bad watch."""
    ticks: list[Tick] = []
    for watch in engine.list_watches():
        if not is_due(engine, watch, now):
            continue
        try:
            result = await engine.check_now(watch.id)
        except Exception as exc:  # noqa: BLE001 — one bad watch must not stop the rest
            result = Result.failed(Reason.ABSTAINED_LOW_CONFIDENCE, evidence=[type(exc).__name__])
        message = _decide(engine, watch, result)
        sent = None
        if message and notifier.send(message):
            sent = message
        ticks.append(Tick(watch=watch, result=result, notified=sent))
    return ticks


async def serve(
    engine: Engine,
    notifier: Notifier,
    *,
    stop: asyncio.Event | None = None,
    max_rounds: int | None = None,
) -> list[Tick]:
    """The loop. Runs until stopped.

    ``max_rounds`` exists so tests can drive it deterministically instead of
    racing a sleep.
    """
    stopper = stop or asyncio.Event()
    done: list[Tick] = []
    rounds = 0
    while not stopper.is_set():
        done.extend(await run_due(engine, notifier))
        rounds += 1
        if max_rounds is not None and rounds >= max_rounds:
            break
        with contextlib.suppress(TimeoutError):
            await asyncio.wait_for(
                stopper.wait(), timeout=max(1.0, seconds_until_next(engine))
            )
    return done
