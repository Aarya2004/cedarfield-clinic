"""What Rokan does, independent of who asked.

The loop, in one paragraph: fetch the page (signing in if the site asks),
check it is still the page we learned, mask what is allowed to move, and
compare what is left against last time. Anything that cannot be done safely
returns an abstention rather than a guess.

The first check of a new watch **learns** instead of comparing. It has nothing
to compare against, and reporting "changed" on the first run would be both
true and useless.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from . import overlay, reinforce, volatility
from .postcondition import Anchors, learn_anchors, verify
from .reasons import Reason
from .result import Result, Status
from .store import Store, Watch
from .volatility import Mask

#: Observation.reason for the append-only row a fold writes. Deliberately
#: NOT a member of the Reason enum — Reason is the failure taxonomy, every
#: member renders as a failure headline with a next step, and a fold is a
#: success event. The ledger's reason column is free text.
MASK_EXTENDED = "mask_extended"

#: Observation.reason for the row a HUMAN-initiated `watch ignore` writes.
#: Distinct from MASK_EXTENDED for two reasons: the row is not a check (it
#: must not inflate the survival-rate denominator, which is a launch gate),
#: and the fold cap deliberately governs only the automatic path — an
#: explicit human ignore is exempt by decision, bounded instead by
#: MAX_MASKED_FRACTION.
MASK_EXTENDED_MANUAL = "mask_extended_manual"

#: Observation.reason on a learning run's row. A mask boundary just like a
#: fold: blobs written before it were rendered under a different (or no)
#: mask, and diffing across it manufactures templates out of the mask change
#: itself — which is how a relearn (the documented undo for a bad fold)
#: could silently re-fold the very line it rescued.
LEARNED = "learned"

#: Everything that ends a flap window: blobs on the far side were rendered
#: under a different mask.
_WINDOW_BOUNDARIES = (MASK_EXTENDED, MASK_EXTENDED_MANUAL, LEARNED)

#: Evidence label carried by a fold's result AND matched by the scheduler to
#: replace the change alert with the one-time notice. One constant on both
#: sides — as control flow, a repeated string literal here would let a
#: rename silently revert the notice to a plain change alert with every
#: test still green.
NOW_IGNORING = "now_ignoring"

#: Samples taken on the learning run. Four samples give three pairs, so a
#: template needs 2 of 3 pairs — a majority — to activate. With three samples
#: there are only two pairs and ACTIVATION_SUPPORT=2 silently means
#: unanimity: anything that ticks slower than the sample gap becomes a held
#: candidate that masks nothing, a fresh false-alert class.
LEARN_SAMPLES = 4

#: Gap between learning samples, so a second-resolution clock actually ticks.
#: Back-to-back loads landed inside the same second and learned nothing.
LEARN_GAP_SECONDS = 1.5


@dataclass(frozen=True, slots=True)
class EngineInfo:
    version: str
    proven_version: str


def _interval_seconds(every: str) -> int:
    """Parse `30m`, `2h`, `1d`. Rejects anything else rather than guessing."""
    raw = (every or "").strip().lower()
    if len(raw) < 2 or not raw[:-1].isdigit():
        raise ValueError(f"could not read an interval from {every!r} — try 30m, 1h or 1d")
    amount, unit = int(raw[:-1]), raw[-1]
    factor = {"m": 60, "h": 3600, "d": 86400}.get(unit)
    if factor is None or amount <= 0:
        raise ValueError(f"could not read an interval from {every!r} — try 30m, 1h or 1d")
    return amount * factor


#: `login.fetch` predates the Reason enum and reports its own strings. They
#: were chosen from the same taxonomy, so most map straight across; anything
#: unrecognised becomes a low-confidence abstention rather than a crash.
def _reason_for(raw: str | None) -> Reason:
    try:
        return Reason(raw or "")
    except ValueError:
        return Reason.ABSTAINED_LOW_CONFIDENCE


class Engine:
    """The watch engine."""

    def __init__(self, store: Store | None = None) -> None:
        self._store = store or Store()

    @property
    def store(self) -> Store:
        return self._store

    def info(self) -> EngineInfo:
        from .. import __version__
        from . import proven

        return EngineInfo(version=__version__, proven_version=proven.PROVEN_VERSION)

    # — credentials ————————————————————————————————————

    def save_login(
        self, site: str, username: str, password: str, totp_secret: str | None = None
    ) -> tuple[str, bool]:
        from . import proven

        return proven.vault.save(site, username, password, totp_secret)

    def list_logins(self) -> list[dict[str, Any]]:
        from . import notify, proven

        # The notification channel is stored in the vault too (one identifier,
        # one secret, same shape) but it is not a website the user signs in
        # to, so listing it here would only confuse.
        return [
            row for row in proven.vault.list_sites() if row.get("host") != notify.NOTIFY_HOST
        ]

    def forget_login(self, site: str) -> bool:
        from . import proven

        return proven.vault.delete(site)

    # — watches ————————————————————————————————————————

    def add_watch(self, url: str, every: str) -> Watch:
        from . import proven

        if not url.lower().startswith(("http://", "https://")):
            url = "https://" + url.lstrip("/")
        host = proven.vault.normalize_host(url)
        return self._store.add_watch(url, host, _interval_seconds(every))

    def list_watches(self, *, include_retired: bool = False) -> list[Watch]:
        return self._store.list_watches(include_retired=include_retired)

    def remove_watch(self, watch_id: str) -> bool:
        return self._store.retire_watch(watch_id)

    def relearn_watch(self, watch_id: str) -> bool:
        """Forget the mask and anchors; the next check learns fresh.

        This is the drift exit: after a redesign the old anchors describe a
        page that no longer exists, and every check drifts forever. The
        observations stay — relearning is not an eraser for the ledger.
        """
        return self._store.clear_learning(watch_id)

    def status(self) -> list[Any]:
        return [
            health
            for watch in self._store.list_watches(include_retired=True)
            if (health := self._store.health(watch.id)) is not None
        ]

    # — the loop ————————————————————————————————————————

    async def check_now(self, watch_id: str) -> Result:
        watch = self._store.get_watch(watch_id)
        if watch is None:
            raise ValueError(f"no watch with id {watch_id!r}")
        started = time.monotonic()

        text = await self._observe(watch)
        if isinstance(text, Result):
            self._record_failure(watch, text, started)
            return text

        if not watch.mask_json or not watch.anchors_json:
            return await self._learn(watch, text, started)

        mask = Mask.from_json(watch.mask_json)
        anchors = Anchors.from_json(watch.anchors_json)
        checked = verify(text, anchors, mask)
        if checked.status is not Status.OK:
            self._record_failure(watch, checked, started)
            return checked

        canonical = str(checked.data)
        digest = self._store.put_blob(canonical)
        previous = self._store.last_ok_content_hash(watch.id)
        changed = previous is not None and previous != digest

        evidence = [f"content={digest[:12]}", *checked.evidence]
        reason: str | None = None
        if changed:
            folded, evidence_extra = self._consider_fold(watch, mask, text, canonical)
            evidence.extend(evidence_extra)
            if folded is not None:
                # Re-render the in-hand page under the new mask in the same
                # step, so the stored baseline and the stored mask can never
                # disagree — the next check is quiet because both moved.
                canonical = folded.apply(text)
                digest = self._store.put_blob(canonical)
                reason = MASK_EXTENDED
        if reason is None:
            # A concurrent `watch ignore` may have moved the mask while this
            # check was mid-fetch. Storing a baseline rendered under the
            # stale mask would fire a spurious "changed" on the next check,
            # straight into the false-alert rate — re-render under whatever
            # is current before it becomes the baseline.
            fresh = self._store.get_watch(watch.id)
            if fresh is not None and fresh.mask_json != watch.mask_json:
                current_mask = (
                    Mask.from_json(fresh.mask_json) if fresh.mask_json else Mask()
                )
                canonical = current_mask.apply(text)
                digest = self._store.put_blob(canonical)

        elapsed = int((time.monotonic() - started) * 1000)
        self._store.record(
            watch.id,
            status="ok",
            reason=reason,
            content_hash=digest,
            changed=changed,
            elapsed_ms=elapsed,
        )
        return Result.succeeded(
            "changed" if changed else "no change",
            evidence=evidence,
            transport_used="browser",
            elapsed_ms=elapsed,
        )

    def _consider_fold(
        self, watch: Watch, mask: Mask, text: str, canonical: str
    ) -> tuple[Mask | None, list[str]]:
        """Decide whether this changed check is a flap, and maybe fold it.

        Returns the committed new mask (None if nothing folded) and evidence
        lines for the result. Every guard lives in :mod:`reinforce`; this
        method owns the window, the policy, the cap and the store write.
        """
        window = self._canonicals_since_fold(watch.id)
        if not window:
            return None, []
        flaps = reinforce.flap_candidates([*window, canonical])
        ready = reinforce.ripe(flaps)
        if not ready:
            return None, []

        renders = [f.template.render() for f in ready]
        if watch.flap_policy != "auto":
            return None, [
                *(f"flap_line={r}" for r in renders),
                f"hint=rokan watch ignore {watch.id}",
            ]
        if self._fold_count(watch.id) >= reinforce.FOLD_CAP:
            # The cap is the honest end state for a genuinely dynamic page:
            # stop masking, keep reporting, and point at the full reset.
            return None, [
                *(f"flap_line={r}" for r in renders),
                f"hint=rokan watch relearn {watch.id}",
            ]
        if not reinforce.explains_entire_diff(ready, window[-1], canonical):
            # A genuine change is riding along with the flap. Report it
            # untouched; folding now would bury it under "now ignoring".
            return None, []
        committed = reinforce.fold(mask, ready, text)
        if committed is None:
            # Every ripe flap was refused (twin lines, trust ceiling). The
            # refusal is right, but an unexplained alert every check is the
            # mute-the-product path — name the line and the manual way out.
            return None, [
                *(f"flap_line={r}" for r in renders),
                f"hint=rokan watch relearn {watch.id}",
            ]
        if not self._store.update_mask_if_unchanged(
            watch.id, expected_json=watch.mask_json, new_json=committed.mask.to_json()
        ):
            # Another writer folded first. Their fold stands; this check
            # reports normally and the next one sees the merged state.
            return None, []
        # The notice is built from what the fold ACCEPTED, never from what
        # ripened — a refused flap is not ignored, and claiming it is would
        # be false now and re-noticed later.
        return committed.mask, [
            f"{NOW_IGNORING}={t.render()}" for t in committed.folded
        ]

    def _canonicals_since_fold(self, watch_id: str, limit: int = 8) -> list[str]:
        """Recent ok canonicals, oldest→newest, stopping at the last fold.

        Blobs written before a fold were rendered under the previous mask;
        diffing across that boundary manufactures templates out of the mask
        change itself.
        """
        texts: list[str] = []
        for observation in self._store.history(watch_id, limit=50):
            if observation.status == "ok" and observation.content_hash:
                blob = self._store.get_blob(observation.content_hash)
                if blob is not None:
                    texts.append(blob)
            # The boundary check is independent of whether this row carried a
            # blob — a fold or a (re)learn always ends the window, or blobs
            # rendered under the previous mask leak in. Without the LEARNED
            # boundary, a relearn (the undo for a bad fold) diffs new blobs
            # against pre-relearn ones and can re-fold the rescued line.
            if observation.reason in _WINDOW_BOUNDARIES or len(texts) >= limit:
                break
        return list(reversed(texts))

    def _fold_count(self, watch_id: str) -> int:
        # Counted over the WHOLE ledger, one SQL query. A capped history scan
        # quietly turns "5 folds per watch, ever" into "5 per few days" and
        # the cap never binds.
        return self._store.count_reason(watch_id, MASK_EXTENDED)

    def ignore_flapping_line(self, watch_id: str, *, apply: bool) -> Result:
        """The human path: fold the line that keeps alerting, on request.

        The human witnessed the *alert*, not the volatility, so this is the
        weakest evidence a fold can rest on. Hence: a streak of at least two
        is still required (a one-off change is refused — muting it would
        blind the watch to the very line the user reacted to), the fold
        enters at exactly the activation bar, and without ``apply`` this only
        reports what it would do.

        Deliberately exempt from FOLD_CAP: the cap exists to stop the
        *automatic* path from masking a page into blindness unattended. An
        explicit human ignore is attended by definition, and
        MAX_MASKED_FRACTION still bounds how blind a mask can get.
        """
        watch = self._store.get_watch(watch_id)
        if watch is None or watch.mask_json is None:
            raise ValueError(f"no learned watch with id {watch_id!r}")
        window = self._canonicals_since_fold(watch_id)
        if len(window) < 2:
            return Result.abstained(Reason.ABSTAINED_LOW_CONFIDENCE)
        flaps = reinforce.ripe(reinforce.flap_candidates(window), threshold=2)
        if not flaps:
            return Result.abstained(Reason.ABSTAINED_LOW_CONFIDENCE)
        mask = Mask.from_json(watch.mask_json)
        committed = reinforce.fold(
            mask,
            flaps,
            window[-1],
            support_cap=volatility.ACTIVATION_SUPPORT,
        )
        if committed is None:
            return Result.abstained(Reason.ABSTAINED_LOW_CONFIDENCE)
        # Both the preview and the applied message name what the fold would
        # actually accept — never the full ripe list, part of which the
        # guards may have refused.
        renders = "; ".join(t.render() for t in committed.folded)
        if not apply:
            return Result.succeeded(
                f"would ignore: {renders}",
                evidence=[f"undo=rokan watch relearn {watch_id}"],
            )
        if not self._store.update_mask_if_unchanged(
            watch_id, expected_json=watch.mask_json, new_json=committed.mask.to_json()
        ):
            raise RuntimeError("the mask changed underneath — re-run to retry")
        digest = self._store.put_blob(committed.mask.apply(window[-1]))
        self._store.record(
            watch_id, status="ok", reason=MASK_EXTENDED_MANUAL, content_hash=digest
        )
        return Result.succeeded(
            f"now ignoring: {renders}",
            evidence=[f"undo=rokan watch relearn {watch_id}"],
        )

    async def _observe(self, watch: Watch) -> str | Result:
        """``_read`` with consent-bar boilerplate removed.

        Sits above ``_read`` rather than inside it so every reader — the
        browser or a scripted test page — sees the same filter, and so a
        cookie bar is never in the text the engine learns or compares.
        """
        text = await self._read(watch)
        if isinstance(text, Result):
            return text
        return overlay.strip_consent_lines(text)

    async def _read(self, watch: Watch) -> str | Result:
        from . import proven

        fetched = await proven.login.fetch(watch.url, reload=True)
        if not fetched.ok:
            return Result.failed(_reason_for(fetched.reason))
        return str(fetched.text or "")

    async def _learn(self, watch: Watch, first: str, started: float) -> Result:
        """The first check has nothing to compare against, so it learns.

        Reporting "changed" on run one would be true and useless.
        """
        import asyncio

        samples = [first]
        for _ in range(LEARN_SAMPLES - 1):
            await asyncio.sleep(LEARN_GAP_SECONDS)
            more = await self._observe(watch)
            if isinstance(more, Result):
                self._record_failure(watch, more, started)
                return more
            samples.append(more)

        learned = (
            volatility.learn_explained(samples)
            if len({s.strip() for s in samples}) > 1
            else volatility.Learning(Mask(samples_seen=len(samples)), ())
        )
        mask = learned.mask
        anchors = learn_anchors(samples)
        if anchors.is_empty:
            # Nothing stable to recognise the page by. A watch with no anchors
            # cannot tell a dashboard from a login wall, so it must not start.
            outcome = Result.abstained(Reason.ABSTAINED_LOW_CONFIDENCE)
            self._record_failure(watch, outcome, started)
            return outcome

        self._store.learned(
            watch.id, mask_json=mask.to_json(), anchors_json=anchors.to_json()
        )
        canonical = mask.apply(samples[-1])
        digest = self._store.put_blob(canonical)
        elapsed = int((time.monotonic() - started) * 1000)
        self._store.record(
            watch.id,
            status="ok",
            reason=LEARNED,
            content_hash=digest,
            changed=False,
            elapsed_ms=elapsed,
        )
        # The count and the list are the user's only window into what got
        # masked. If the thing they care about ticked during learning, this
        # is where they find out — counting held candidates here would
        # overstate, and hiding the renders would hide the problem.
        active = mask.active_templates
        return Result.succeeded(
            f"learned {watch.host} — {len(active)} moving parts, "
            f"{len(anchors.lines)} anchors",
            evidence=[
                f"content={digest[:12]}",
                *(f"ignoring={t.render()}" for t in active),
                *(
                    f"not_ignoring={t.render()} — appears twice, one copy held still"
                    for t in learned.refused
                ),
            ],
            transport_used="browser",
            elapsed_ms=elapsed,
        )

    def _record_failure(self, watch: Watch, outcome: Result, started: float) -> None:
        self._store.record(
            watch.id,
            status=str(outcome.status),
            reason=outcome.reason.value if outcome.reason else None,
            elapsed_ms=int((time.monotonic() - started) * 1000),
        )

    # — notifications ————————————————————————————————

    def notify_set(self, chat_id: str, token: str) -> None:
        from . import notify

        notify.save(chat_id, token)

    def notify_is_configured(self) -> bool:
        from . import notify

        return notify.is_configured()

    def notify_test(self) -> bool:
        from . import notify

        return notify.load().send(
            "Rokan is connected. You will hear from me when a watched page changes."
        )
