"""The single place this package reaches into ``rokan-mcp``.

**Import, do not fork.** Those modules are the only parts of Rokan that have
been proven against live websites — the encrypted vault, TOTP, the login flow
and the browser daemon that closed 6/6 real sites on 2026-08-20. Copying them
here would fork a proven thing into an unproven one and double every future
fix.

Routing every such import through this one module means the coupling is
greppable: one file to read to know exactly what we depend on, and one file to
change if ``rokan-mcp`` is ever vendored, renamed or merged (see the packaging
note in ``pyproject.toml``).
"""

from __future__ import annotations

from rokan_mcp import __version__ as PROVEN_VERSION
from rokan_mcp import browser, login, paths, totp, vault

#: ``browser`` is the daemon *client*: it spawns the browser daemon, adopts an
#: already-running one, and reaps it after an idle timeout. The daemon is a
#: separate process that deliberately outlives whoever started it.
__all__ = ["PROVEN_VERSION", "browser", "login", "paths", "totp", "vault"]
