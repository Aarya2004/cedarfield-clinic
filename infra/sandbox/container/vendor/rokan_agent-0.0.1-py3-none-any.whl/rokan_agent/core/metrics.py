"""Rates, with honest error bars.

Every number this project publishes will be a proportion measured on a small
sample — false alerts per hundred checks, checks survived per hundred
scheduled. Small-sample proportions are exactly where the obvious method
fails, so the method is fixed here rather than at each call site.

**Wilson, not Wald.** The textbook `p ± z·sqrt(p(1-p)/n)` interval has
measured **25% coverage at three observations** where it claims 95%, and it
collapses to a width of zero at `p = 0` or `p = 1` — so twenty clean checks in
a row would report a false-alert rate of "0%, ± 0%", which is a lie with a
decimal point on it. Wilson holds its coverage and stays wide when the sample
is thin.

Nothing here rounds, formats or interprets. A number that looks like a result
should have come through this module.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

#: Two-sided 95%. Hard-coded because a configurable confidence level invites
#: quoting whichever one looks best.
Z_95 = 1.959963984540054


@dataclass(frozen=True, slots=True)
class Rate:
    """A proportion and the interval it is actually known to within."""

    successes: int
    total: int
    low: float
    high: float

    @property
    def point(self) -> float:
        return self.successes / self.total if self.total else 0.0

    @property
    def width(self) -> float:
        return self.high - self.low

    def __str__(self) -> str:
        if not self.total:
            return "no data"
        return f"{self.point:.1%} (95% CI {self.low:.1%}–{self.high:.1%}, n={self.total})"

    def beats(self, other: Rate) -> bool:
        """True only when the intervals do not overlap.

        Overlapping intervals mean the difference is not established, however
        pleasing the point estimates look. Spec §12: sub-5pp deltas are ties.
        """
        return self.low > other.high


def wilson(successes: int, total: int, z: float = Z_95) -> Rate:
    """Wilson score interval for a proportion."""
    if total < 0 or successes < 0 or successes > total:
        raise ValueError(f"{successes} of {total} is not a proportion")
    if total == 0:
        return Rate(successes=0, total=0, low=0.0, high=1.0)

    p = successes / total
    denominator = 1 + z * z / total
    centre = (p + z * z / (2 * total)) / denominator
    spread = (
        z
        / denominator
        * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total))
    )
    return Rate(
        successes=successes,
        total=total,
        low=max(0.0, centre - spread),
        high=min(1.0, centre + spread),
    )


@dataclass(frozen=True, slots=True)
class Spread:
    """Mean and standard deviation of a repeated measurement."""

    values: tuple[float, ...]

    @property
    def n(self) -> int:
        return len(self.values)

    @property
    def mean(self) -> float:
        return sum(self.values) / self.n if self.n else 0.0

    @property
    def sigma(self) -> float:
        """**Sample** standard deviation, n-1.

        Spec §12 records a "9.4pp" figure that was a *range*, not a sigma, and
        the run budget was sized from it. A range grows with the number of
        runs; a sigma does not. Do not conflate them again.
        """
        if self.n < 2:
            return 0.0
        mean = self.mean
        return math.sqrt(sum((v - mean) ** 2 for v in self.values) / (self.n - 1))

    def runs_needed(self, detectable_difference: float) -> int:
        """Runs per arm to detect a difference of this size, 95%/80%.

        The standard two-sample formula, `16·σ²/Δ²`. Reported so a comparison
        is either affordable or is not attempted — spec §12 measured a naive
        estimate at 11 runs per arm and roughly **290 hours of wall clock**.
        """
        if detectable_difference <= 0:
            raise ValueError("a detectable difference must be positive")
        if self.sigma == 0:
            return 1
        return max(1, math.ceil(16 * self.sigma**2 / detectable_difference**2))
