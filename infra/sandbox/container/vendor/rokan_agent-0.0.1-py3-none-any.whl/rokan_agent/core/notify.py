"""Telling the user, without becoming something they mute.

A watcher earns its place by being silent. Every message it sends that did not
need sending is a withdrawal from the same account, and the balance only goes
one way: people do not un-mute things.

So there are exactly two reasons to speak:

* the watched content **changed**;
* a watch **started failing** — once, when it enters that state, never again
  while it stays there. "Could not sign in" repeated hourly for three days is
  how a useful alert becomes a filter rule.

Transport is Telegram over `urllib`. No dependency, no SDK, no `apps/api`
import — that stack is quarantined and dragging it in would undo the boundary
`test_boundary.py` exists to protect.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Protocol

#: Telegram's own cap is 4096 characters. Leave room for the framing.
MAX_MESSAGE = 3500

_TIMEOUT_SECONDS = 15
_API = "https://api.telegram.org"

#: The vault is keyed by host and holds `username` + `password`. The bot token
#: is exactly that shape — an identifier and a secret for one service — so it
#: is stored there rather than duplicating the Fernet/HKDF machinery for one
#: field. `chat_id` goes in `username`, the token in `password`.
#:
#: `rokan logins` filters this host out: it is not a website the user signs
#: in to, and listing it there would be confusing.
NOTIFY_HOST = "api.telegram.org"


class Notifier(Protocol):
    def send(self, text: str) -> bool: ...


@dataclass(frozen=True, slots=True)
class NullNotifier:
    """No channel configured. Says so rather than pretending to deliver."""

    def send(self, text: str) -> bool:
        return False


@dataclass(frozen=True, slots=True)
class TelegramNotifier:
    chat_id: str
    token: str
    #: Injectable so the transport can be tested against a local server. The
    #: token must never be sent anywhere else, so this is not user-settable.
    api_base: str = _API

    def send(self, text: str) -> bool:
        payload = urllib.parse.urlencode(
            {
                "chat_id": self.chat_id,
                "text": text[:MAX_MESSAGE],
                "disable_web_page_preview": "true",
            }
        ).encode()
        # Building the Request is INSIDE the try, not above it. A malformed
        # base raises ValueError from the constructor, and that exception's
        # message is the full URL — token included. Measured: the first
        # version of this method leaked the token through exactly that path,
        # because only `urlopen` was guarded.
        try:
            request = urllib.request.Request(  # noqa: S310 — host is not user-supplied
                f"{self.api_base}/bot{self.token}/sendMessage",
                data=payload,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            with urllib.request.urlopen(request, timeout=_TIMEOUT_SECONDS) as response:
                body = json.loads(response.read().decode("utf-8"))
            return bool(body.get("ok"))
        except Exception:  # noqa: BLE001
            # Deliberately swallowing the exception OBJECT, not just handling
            # it: a Telegram error body echoes the request URL, and the URL
            # contains the bot token. Nothing derived from it may reach a log,
            # a traceback or a return value. A broad catch is the point —
            # every escape route has to be closed, not the ones anticipated.
            return False


def load() -> Notifier:
    """The configured channel, or one that admits it cannot deliver."""
    from . import proven

    try:
        credential = proven.vault.get(NOTIFY_HOST)
    except Exception:  # noqa: BLE001 — an unreadable vault must not stop a check
        return NullNotifier()
    if credential is None:
        return NullNotifier()
    return TelegramNotifier(chat_id=credential.username, token=credential.password)


def save(chat_id: str, token: str) -> None:
    from . import proven

    proven.vault.save(NOTIFY_HOST, chat_id, token)


def is_configured() -> bool:
    return not isinstance(load(), NullNotifier)


def changed_message(host: str, url: str, watch_id: str) -> str:
    return (
        f"{host} changed\n\n"
        f"{url}\n\n"
        f"rokan check {watch_id}   to see it again"
    )


def now_ignoring_message(host: str, ignored: str, watch_id: str) -> str:
    """Sent exactly once, on the check whose fold silenced a flapping line.

    Names the line so the user can catch a wrong fold immediately, and names
    the undo in the same breath — an automatic mask change the user cannot
    see or reverse is how a watcher goes quietly blind.
    """
    return (
        f"{host} — one line keeps changing, so Rokan now ignores it:\n\n"
        f"{ignored}\n\n"
        f"rokan watch relearn {watch_id}   to undo"
    )


def failing_message(host: str, watch_id: str, reason: str, next_step: str) -> str:
    """Sent once, when a watch enters a failing state.

    Carries the next step, because an alert that tells you something broke and
    not what to do about it is a notification you learn to ignore.
    """
    return (
        f"{host} needs you\n\n"
        f"{reason}\n"
        f"{next_step}\n\n"
        f"rokan check {watch_id}"
    )
