"""Recorded observations of real pages, so measurements can be repeated.

A false-alert rate measured against the live web is not a measurement — it is
an anecdote with a percentage attached. Two runs an hour apart see different
pages, so a change to the mask cannot be told apart from the sites having
moved. Measured earlier in this project: identical code timed 4.3s, 14.1s and
19.2s on the same page.

So observations are recorded once and replayed forever. This is the "common
random numbers" idea from spec §12, applied at the layer that actually
matters here: the decision function reads **extracted text**, not network
traffic, so recording at that boundary is smaller, exactly reproducible, and
free of the cassette-rot that makes HTTP-level fixtures expire.

**These files hold pages fetched from behind the user's logins.** They are
0600 inside a 0700 directory, and recording is opt-in per run — nothing is
captured unless a benchmark asks for it.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from .proven import paths


@dataclass(frozen=True, slots=True)
class Sample:
    """One observation of one page."""

    at: str
    text: str
    #: Samples taken back-to-back, when nothing can have changed. These are
    #: the only pairs that yield a *sound* false-positive measurement: any
    #: reported change between them is definitionally wrong.
    burst: int = 0


def corpus_dir() -> Path:
    directory = paths.home() / "corpus"
    directory.mkdir(parents=True, exist_ok=True)
    directory.chmod(0o700)
    return directory


def _file(name: str) -> Path:
    safe = "".join(c if c.isalnum() or c in "-._" else "_" for c in name)
    return corpus_dir() / f"{safe}.jsonl"


def record(name: str, text: str, *, burst: int = 0) -> Sample:
    """Append one observation. Never rewrites — the corpus is a record."""
    sample = Sample(at=datetime.now(UTC).isoformat(), text=text, burst=burst)
    path = _file(name)
    existed = path.exists()
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"at": sample.at, "burst": burst, "text": text}) + "\n")
    if not existed:
        path.chmod(0o600)
    return sample


def load(name: str) -> list[Sample]:
    path = _file(name)
    if not path.exists():
        return []
    out: list[Sample] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        out.append(
            Sample(at=row["at"], text=row["text"], burst=int(row.get("burst", 0)))
        )
    return out


def names() -> list[str]:
    return sorted(p.stem for p in corpus_dir().glob("*.jsonl"))


def bursts(samples: list[Sample]) -> list[list[Sample]]:
    """Group samples into the bursts they were captured in.

    A burst is several loads seconds apart. Within one, nothing on the page
    can genuinely have changed, so every reported change is a false alert —
    ground truth without a human labelling anything.
    """
    grouped: dict[int, list[Sample]] = {}
    for sample in samples:
        grouped.setdefault(sample.burst, []).append(sample)
    return [grouped[key] for key in sorted(grouped) if len(grouped[key]) > 1]
