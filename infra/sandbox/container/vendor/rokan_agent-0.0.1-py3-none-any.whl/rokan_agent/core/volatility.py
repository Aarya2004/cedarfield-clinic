"""Telling "the page changed" apart from "the page is alive".

This is the highest-risk component in the MVP. A watcher that fires because a
clock ticked or a session id rotated gets muted within a day, and a muted
watcher is indistinguishable from one that was never installed. Everything
here exists to make one decision correctly: **is this difference worth waking
someone for?**

The method is empirical, not clever. Load the same page several times when
nothing can have changed, see which parts differ anyway, and remember those
parts as noise. No heuristics about what "looks like" a timestamp — a regex
guessing at dates would mask a genuine price that happened to look like one.

**The limitation, stated plainly because it decides what this can promise:**
back-to-back samples only expose *per-request* volatility — session tokens,
nonces, second-resolution clocks, rotating adverts. A field that changes once a
minute will look perfectly stable across three samples taken two seconds apart
and will produce a false alert later. Slow volatility can only be learned from
observations spread over time — that is :mod:`reinforce`, the flap path,
which folds a line that keeps alerting back into the mask under guard rails.
(`Mask.reinforced_with` is the bare primitive it rests on: `learn` with this
mask as the seed.)
"""

from __future__ import annotations

import json
import re
from collections.abc import Sequence
from dataclasses import dataclass
from difflib import SequenceMatcher

#: What a masked slot renders as. Chosen to be visible in a diff and absent
#: from real page text.
SLOT = "§"

#: Above this, the mask is hiding so much of the page that a real change would
#: almost certainly land inside it. See `Mask.is_trustworthy`.
MAX_MASKED_FRACTION = 0.5

#: Fewer than this many samples cannot distinguish "varies every load" from
#: "happened to differ once".
MIN_SAMPLES = 3

#: A template masks nothing until this many sample pairs have shown it
#: varying. One pair is a coincidence — a real change that happened to land
#: inside a learning window would otherwise become a permanent blind spot,
#: which is the C12 failure shape wearing a different hat. Templates below
#: the bar are *held* (so later evidence can promote them) but never applied.
ACTIVATION_SUPPORT = 2

_TOKEN = re.compile(r"\S+")


def lines(text: str) -> list[str]:
    return [ln.strip() for ln in text.splitlines() if ln.strip()]


def tokens(line: str) -> list[str]:
    return _TOKEN.findall(line)


@dataclass(frozen=True, slots=True)
class Template:
    """One line, with the positions that were seen to vary marked.

    ``tokens`` holds the words that stayed put; ``slots`` are the indices that
    moved. Two lines match the same template when every non-slot token is
    identical and the token count agrees.
    """

    tokens: tuple[str, ...]
    slots: frozenset[int]
    #: The unchanged line immediately above, when this line has no anchor of
    #: its own. A bare clock or a lone number is entirely volatile, so a
    #: template of `§` would match every one-word line on the page. Requiring
    #: the neighbour above lets such a value be masked without the template
    #: becoming a wildcard. Measured on time.is, whose clock is a single token
    #: and which produced a false alert while this was unsupported.
    context: str | None = None

    def matches(self, line_tokens: Sequence[str], previous: str | None = None) -> bool:
        if len(line_tokens) != len(self.tokens):
            return False
        if self.context is not None and previous != self.context:
            return False
        return all(
            line_tokens[i] == token
            for i, token in enumerate(self.tokens)
            if i not in self.slots
        )

    def render(self) -> str:
        return " ".join(
            SLOT if i in self.slots else token for i, token in enumerate(self.tokens)
        )


@dataclass(frozen=True, slots=True)
class Mask:
    """What to ignore on this page, and how much support that has."""

    templates: tuple[Template, ...] = ()
    samples_seen: int = 0
    #: Per template, how many sample pairs showed it varying. One pair is a
    #: coincidence; several is a pattern.
    support: tuple[int, ...] = ()

    def __post_init__(self) -> None:
        # templates and support are parallel by contract, but Mask is built
        # in enough places (learn, fold, from_json, tests) that the pairing
        # must hold structurally, not by discipline. Short support is padded
        # to the activation bar — the missing entries come from data stored
        # before support existed, when every template was applied. Longer
        # support is a construction bug and says so.
        if len(self.support) > len(self.templates):
            raise ValueError(
                f"{len(self.support)} support entries for "
                f"{len(self.templates)} templates"
            )
        if len(self.support) < len(self.templates):
            padded = self.support + (ACTIVATION_SUPPORT,) * (
                len(self.templates) - len(self.support)
            )
            object.__setattr__(self, "support", padded)

    @property
    def is_empty(self) -> bool:
        """No templates at all — nothing was ever learned or held."""
        return not self.templates

    @property
    def masks_nothing(self) -> bool:
        """No *active* templates. Distinct from ``is_empty``: a mask of held
        candidates is not empty, but applying it changes nothing."""
        return not self.active_templates

    @property
    def active_templates(self) -> tuple[Template, ...]:
        """Templates with enough support to be applied.

        Below ``ACTIVATION_SUPPORT`` a template is a held candidate: it stays
        in the mask so later evidence can promote it, but it masks nothing.
        """
        return tuple(
            t
            for t, s in zip(self.templates, self.support, strict=True)
            if s >= ACTIVATION_SUPPORT
        )

    def masked_fraction(self, text: str) -> float:
        """Share of this page's tokens the mask would hide."""
        page_lines = lines(text)
        total = sum(len(tokens(ln)) for ln in page_lines) or 1
        hidden = 0
        previous: str | None = None
        active = self.active_templates
        for line in page_lines:
            toks = tokens(line)
            for template in active:
                if template.matches(toks, previous):
                    hidden += len(template.slots)
                    break
            previous = " ".join(toks)
        return hidden / total

    def is_trustworthy(self, text: str) -> bool:
        """False when the mask hides so much that a real change would vanish.

        A mask covering most of the page does not make a quiet watcher; it
        makes a blind one. Better to say so than to report "no changes"
        forever.
        """
        return self.masked_fraction(text) <= MAX_MASKED_FRACTION

    def apply(self, text: str) -> str:
        """Canonical form: volatile slots replaced, everything else intact."""
        out: list[str] = []
        previous: str | None = None
        active = self.active_templates
        for line in lines(text):
            toks = tokens(line)
            for template in active:
                if template.matches(toks, previous):
                    out.append(template.render())
                    break
            else:
                out.append(" ".join(toks))
            # Context is the line as it appeared, not as it was rendered, so a
            # masked line above never becomes an anchor for the line below.
            previous = " ".join(toks)
        return "\n".join(out)

    def to_json(self) -> str:
        return json.dumps(
            {
                "samples_seen": self.samples_seen,
                "templates": [
                    {
                        "tokens": list(t.tokens),
                        "slots": sorted(t.slots),
                        "context": t.context,
                    }
                    for t in self.templates
                ],
                "support": list(self.support),
            },
            separators=(",", ":"),
        )

    @classmethod
    def from_json(cls, raw: str) -> Mask:
        data = json.loads(raw)
        templates = tuple(
            Template(
                tokens=tuple(t["tokens"]),
                slots=frozenset(t["slots"]),
                context=t.get("context"),
            )
            for t in data.get("templates", [])
        )
        # Stored data is clamped, never crashed on: short support is padded
        # by __post_init__ (masks stored before support existed were applied
        # in full, and silently deactivating them would fire a false alert),
        # and over-long support is truncated — a mangled mask_json must
        # degrade the mask, not take down check_now.
        support = tuple(data.get("support", []))[: len(templates)]
        return cls(
            templates=templates,
            support=support,
            samples_seen=int(data.get("samples_seen", 0)),
        )

    def reinforced_with(self, sample: str, previous: str) -> Mask:
        """Fold one more observation in, learned over real elapsed time.

        Back-to-back sampling cannot see slow volatility (a "3 minutes ago"
        that ticks once a minute). Every scheduled check that finds a
        difference the user was never told about is evidence, and this is how
        it gets folded back in.
        """
        return learn([previous, sample], seed=self)


def templates_from_pair(before: str, after: str) -> list[Template]:
    """Lines that stayed aligned but changed tokens, as templates."""
    left, right = lines(before), lines(after)
    found: list[Template] = []
    matcher = SequenceMatcher(a=left, b=right, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag != "replace" or (i2 - i1) != (j2 - j1):
            # Inserted or deleted lines are structural change, not noise.
            # Masking them would hide exactly the events worth reporting.
            continue
        for offset in range(i2 - i1):
            a_tokens, b_tokens = tokens(left[i1 + offset]), tokens(right[j1 + offset])
            if len(a_tokens) != len(b_tokens) or not a_tokens:
                continue
            slots = frozenset(
                i for i, (x, y) in enumerate(zip(a_tokens, b_tokens, strict=True)) if x != y
            )
            if slots and len(slots) == len(a_tokens):
                # Every token moved, so the line carries no anchor. It can
                # still be masked safely if the line above it held still.
                prev_a = left[i1 + offset - 1] if (i1 + offset) > 0 else None
                prev_b = right[j1 + offset - 1] if (j1 + offset) > 0 else None
                anchor_above = " ".join(tokens(prev_a)) if prev_a is not None else None
                if (
                    anchor_above
                    and prev_b is not None
                    and anchor_above == " ".join(tokens(prev_b))
                    # A context containing a slot marker means the "raw" text
                    # was actually a rendered canonical (the reinforcement
                    # path diffs stored blobs). A masked line must never
                    # anchor its neighbour.
                    and SLOT not in anchor_above
                ):
                    found.append(
                        Template(
                            tokens=tuple(SLOT for _ in a_tokens),
                            slots=slots,
                            context=anchor_above,
                        )
                    )
                continue
            if slots and len(slots) < len(a_tokens):
                # A line where EVERY token moved carries no anchor, so the
                # template would match unrelated lines of the same length.
                #
                # Slot positions are stored as SLOT rather than as whichever
                # value this sample happened to hold. Keeping the raw value
                # makes two identical templates unequal, so support never
                # accumulates past 1 and the mask grows forever. Measured:
                # three samples of one volatile line produced two templates
                # that rendered identically.
                canonical = tuple(
                    SLOT if i in slots else token for i, token in enumerate(a_tokens)
                )
                found.append(Template(tokens=canonical, slots=slots))
    return found


def matching_lines(template: Template, text: str) -> list[int]:
    """Indices of the lines in ``text`` the template fits, context included."""
    hits: list[int] = []
    previous: str | None = None
    for index, line in enumerate(lines(text)):
        toks = tokens(line)
        if template.matches(toks, previous):
            hits.append(index)
        previous = " ".join(toks)
    return hits


def has_stable_twin(template: Template, before: str, after: str) -> bool:
    """True when the template also fits a line that held still between the
    two loads. Masking it would blind the watch to that line."""
    left = lines(before)
    matcher = SequenceMatcher(a=left, b=lines(after), autojunk=False)
    held = {
        index
        for tag, i1, i2, _j1, _j2 in matcher.get_opcodes()
        if tag == "equal"
        for index in range(i1, i2)
    }
    return any(index in held for index in matching_lines(template, before))


@dataclass(frozen=True, slots=True)
class Learning:
    mask: Mask
    #: Templates that also fit a line that never moved. Left live on purpose,
    #: and named so the user knows what is NOT being ignored.
    refused: tuple[Template, ...]


def learn(samples: Sequence[str], *, seed: Mask | None = None) -> Mask:
    """Build a mask from samples of a page taken when nothing changed.

    Raises on too few samples rather than returning a weak mask: a mask
    learned from two loads looks identical to a good one and silently produces
    false alerts weeks later.
    """
    return learn_explained(samples, seed=seed).mask


def learn_explained(samples: Sequence[str], *, seed: Mask | None = None) -> Learning:
    if seed is None and len(samples) < MIN_SAMPLES:
        raise ValueError(
            f"need at least {MIN_SAMPLES} samples to tell volatile from "
            f"coincidence, got {len(samples)}"
        )

    counts: dict[Template, int] = {}
    if seed is not None:
        # Support carries forward. Resetting it to 1 on every re-learn (the
        # old behaviour) meant a template's support could never accumulate
        # past what one call happened to see, so nothing held as a candidate
        # could ever be promoted by later evidence.
        for template, prior in zip(seed.templates, seed.support, strict=True):
            counts[template] = prior
    refused: set[Template] = set()
    for index in range(len(samples) - 1):
        before, after = samples[index], samples[index + 1]
        # Deduplicated per pair: a value rendered twice on the page (header
        # card + table total) yields the identical template twice from ONE
        # pair, which would count as two independent sightings and promote a
        # coincidence straight past the activation bar. Support counts pairs,
        # not occurrences.
        for template in set(templates_from_pair(before, after)):
            if has_stable_twin(template, before, after):
                refused.add(template)
                continue
            counts[template] = counts.get(template, 0) + 1
    # A twin refused in any pair is dropped, not held: one clean pair later
    # would otherwise promote it. Seeded templates keep their support — a
    # re-learn must never silently deactivate a mask already in force.
    seeded = set(seed.templates) if seed is not None else set()
    for template in refused - seeded:
        counts.pop(template, None)

    ordered = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0].render()))
    mask = Mask(
        templates=tuple(t for t, _ in ordered),
        support=tuple(c for _, c in ordered),
        samples_seen=(seed.samples_seen if seed else 0) + len(samples),
    )
    return Learning(mask, tuple(sorted(refused - seeded, key=Template.render)))


def changed(before: str, after: str, mask: Mask | None = None) -> bool:
    """Whether the difference between two observations is worth reporting."""
    if mask is None or mask.masks_nothing:
        return _canonical(before) != _canonical(after)
    return mask.apply(before) != mask.apply(after)


def _canonical(text: str) -> str:
    return "\n".join(" ".join(tokens(ln)) for ln in lines(text))
