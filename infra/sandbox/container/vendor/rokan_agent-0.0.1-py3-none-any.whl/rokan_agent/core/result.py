"""What every operation returns. Built before anything that can fail.

The load-bearing decision is that **abstention is a result, not an error**.
When Rokan cannot safely answer, it says which class of thing stopped it and
exits **0**. A watcher that exits non-zero because it honestly declined would
be indistinguishable, to cron and to any wrapping script, from one that
crashed — and the whole product rests on being trusted while unattended.

High abstention with high accuracy is a **good** outcome and is rendered that
way: "I couldn't safely do this, and here's why."
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from .reasons import Reason, is_no_repair, next_step_for


class Status(StrEnum):
    OK = "ok"
    ABSTAINED = "abstained"
    ERROR = "error"


@dataclass(frozen=True, slots=True)
class Result:
    """The single return shape.

    ``data`` is deliberately ``Any``: it carries whatever the watched page
    yielded, which is arbitrary JSON. Every other field is typed.
    """

    status: Status
    data: Any = None
    reason: Reason | None = None
    next_step: str | None = None
    evidence: list[str] = field(default_factory=list)
    transport_used: str | None = None
    fallback_chain: list[str] = field(default_factory=list)
    elapsed_ms: int = 0

    @property
    def ok(self) -> bool:
        """True only for a real success. **Abstention is not ok** — it did not
        do the thing — but it is also not an error. See ``exit_code``."""
        return self.status is Status.OK

    @property
    def exit_code(self) -> int:
        """0 for success **and for abstention**; 1 for an error.

        Abstaining is Rokan working correctly. Anything that treats a non-zero
        exit as breakage — cron, a shell script, a CI step — must not be told
        that a careful decline is a failure.
        """
        return 1 if self.status is Status.ERROR else 0

    # — constructors ————————————————————————————————————————

    @classmethod
    def succeeded(
        cls,
        data: Any,
        *,
        evidence: list[str] | None = None,
        transport_used: str | None = None,
        fallback_chain: list[str] | None = None,
        elapsed_ms: int = 0,
    ) -> Result:
        return cls(
            status=Status.OK,
            data=data,
            evidence=evidence or [],
            transport_used=transport_used,
            fallback_chain=fallback_chain or [],
            elapsed_ms=elapsed_ms,
        )

    @classmethod
    def abstained(
        cls,
        reason: Reason,
        *,
        evidence: list[str] | None = None,
        elapsed_ms: int = 0,
    ) -> Result:
        """Decline, naming the class. ``next_step`` is filled from the reason,
        so guidance cannot be forgotten at a call site."""
        return cls(
            status=Status.ABSTAINED,
            reason=reason,
            next_step=next_step_for(reason),
            evidence=evidence or [],
            elapsed_ms=elapsed_ms,
        )

    @classmethod
    def failed(
        cls,
        reason: Reason,
        *,
        evidence: list[str] | None = None,
        elapsed_ms: int = 0,
    ) -> Result:
        """An error — but a no-repair reason is **routed to abstention**.

        A 0%-ceiling failure reported as an error invites a retry loop against
        something no retry can fix, and for ``LOGIN_REJECTED`` that loop locks
        the user's account. Making the routing structural means no call site
        can get it wrong.
        """
        if is_no_repair(reason):
            return cls.abstained(reason, evidence=evidence, elapsed_ms=elapsed_ms)
        return cls(
            status=Status.ERROR,
            reason=reason,
            next_step=next_step_for(reason),
            evidence=evidence or [],
            elapsed_ms=elapsed_ms,
        )

    # — serialisation ——————————————————————————————————————

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": str(self.status),
            "ok": self.ok,
            "data": self.data,
            "reason": str(self.reason) if self.reason else None,
            "next_step": self.next_step,
            "evidence": list(self.evidence),
            "transport_used": self.transport_used,
            "fallback_chain": list(self.fallback_chain),
            "elapsed_ms": self.elapsed_ms,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> Result:
        reason_raw = raw.get("reason")
        return cls(
            status=Status(raw["status"]),
            data=raw.get("data"),
            reason=Reason(reason_raw) if reason_raw else None,
            next_step=raw.get("next_step"),
            evidence=list(raw.get("evidence") or []),
            transport_used=raw.get("transport_used"),
            fallback_chain=list(raw.get("fallback_chain") or []),
            elapsed_ms=int(raw.get("elapsed_ms") or 0),
        )

    @classmethod
    def from_json(cls, raw: str) -> Result:
        parsed: dict[str, Any] = json.loads(raw)
        return cls.from_dict(parsed)


def abstain(reason: Reason, *, evidence: list[str] | None = None) -> Result:
    """Shorthand for :meth:`Result.abstained`."""
    return Result.abstained(reason, evidence=evidence)
