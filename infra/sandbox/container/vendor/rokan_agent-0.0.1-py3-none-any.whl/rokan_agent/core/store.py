"""Where watches and their history live.

Two ideas, and the second is the whole product:

1. **A watch is small.** A URL, an interval, and what was learned about the
   page — the mask and the anchors. Cheap to store, cheap to rebuild.
2. **Observations are append-only.** Every check writes one row and no row is
   ever edited or removed. That table *is* the durability ledger: how long a
   watch has kept working, when it last succeeded, how often it declines. The
   spec calls the `LAST OK` column "the entire company" because nobody in the
   field publishes it — and a ledger that can be quietly rewritten is not
   evidence of anything.

Append-only is enforced by SQLite triggers rather than by convention, so a
future bug fixing "stale" rows fails loudly instead of erasing the record.

**Everything here is private.** The database holds pages fetched from behind
the user's logins — usage figures, order histories, account pages. The file is
0600 inside a 0700 directory, and only the *masked canonical* form of a page is
stored: enough to detect and describe a change, without keeping a verbatim copy
of every dashboard the user watches.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import time
import uuid
from collections.abc import Iterator
from contextlib import closing, contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from .proven import paths

SCHEMA_VERSION = 2

_SCHEMA = """
CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS watch (
    id               TEXT PRIMARY KEY,
    url              TEXT NOT NULL,
    host             TEXT NOT NULL,
    interval_seconds INTEGER NOT NULL,
    created_at       TEXT NOT NULL,
    mask_json        TEXT,
    anchors_json     TEXT,
    paused           INTEGER NOT NULL DEFAULT 0,
    -- What happens when one line keeps changing on every check: 'auto'
    -- folds it into the mask after FLAP_THRESHOLD consecutive alerts and
    -- says so once; 'manual' keeps alerting and names the line.
    flap_policy      TEXT NOT NULL DEFAULT 'auto',
    -- Soft delete. A watch is retired, never deleted: its observations are
    -- the record of how well this worked, and the foreign key makes that
    -- structural rather than a promise. The spec's ledger already shows
    -- `retired` as a status for exactly this reason.
    retired_at       TEXT
);

-- Append-only. One row per check, forever.
CREATE TABLE IF NOT EXISTS observation (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    watch_id     TEXT NOT NULL REFERENCES watch(id),
    at           TEXT NOT NULL,
    status       TEXT NOT NULL,
    reason       TEXT,
    content_hash TEXT,
    changed      INTEGER NOT NULL DEFAULT 0,
    elapsed_ms   INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS observation_by_watch ON observation(watch_id, at);

-- The ledger is evidence. A later bug "tidying up" stale rows must fail
-- loudly rather than quietly rewrite the only record of how well this worked.
CREATE TRIGGER IF NOT EXISTS observation_is_append_only_update
BEFORE UPDATE ON observation
BEGIN SELECT RAISE(ABORT, 'observation is append-only'); END;

CREATE TRIGGER IF NOT EXISTS observation_is_append_only_delete
BEFORE DELETE ON observation
BEGIN SELECT RAISE(ABORT, 'observation is append-only'); END;
"""


def _now() -> str:
    return datetime.now(UTC).isoformat()


@dataclass(frozen=True, slots=True)
class Watch:
    id: str
    url: str
    host: str
    interval_seconds: int
    created_at: str
    mask_json: str | None = None
    anchors_json: str | None = None
    paused: bool = False
    flap_policy: str = "auto"
    retired_at: str | None = None

    @property
    def is_retired(self) -> bool:
        return self.retired_at is not None


@dataclass(frozen=True, slots=True)
class Observation:
    watch_id: str
    at: str
    status: str
    reason: str | None
    content_hash: str | None
    changed: bool
    elapsed_ms: int


@dataclass(frozen=True, slots=True)
class Health:
    """One row of the ledger, for `rokan status`."""

    watch: Watch
    runs: int
    last_ok: str | None
    last_change: str | None
    failure_streak: int


def db_file() -> Path:
    return paths.home() / "rokan.db"


def blobs_dir() -> Path:
    d = paths.home() / "blobs"
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o700)
    return d


#: Any TEXT column named *_hash, in any table of this database, holds a blob
#: digest or NULL. rokan-do keeps its proven plans under this contract in its
#: own table; its module may not be imported when GC runs, so the schema — not
#: a Python registry — is what says a blob is live.
BLOB_REF_SUFFIX = "_hash"
#: A blob younger than this is never collected: it may be a put whose
#: observation row has not landed yet.
GC_GRACE_SECONDS = 3600
#: Observation content kept per watch. The engine reads at most the newest 50
#: rows' content (the fold window); the ledger rows themselves are never
#: deleted, only their page text beyond this depth.
GC_KEEP_PER_WATCH = 200
_DIGEST = re.compile(r"^[0-9a-f]{64}$")


@dataclass(frozen=True, slots=True)
class GcReport:
    scanned: int
    live: int
    reclaimable: int
    deleted: int
    bytes: int


class Store:
    """The local database. One instance per process is plenty."""

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or db_file()
        self._migrate()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        if not self.path.exists():
            # Create it 0600 *before* SQLite does, so there is no window in
            # which the file exists world-readable. Same reason
            # `paths.write_private` opens with a mode instead of chmod-ing
            # afterwards.
            os.close(os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600))
        conn = sqlite3.connect(self.path)
        try:
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON")
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _migrate(self) -> None:
        paths.home()  # ensures the 0700 directory exists first
        with self._connect() as conn:
            conn.executescript(_SCHEMA)
            row = conn.execute("SELECT version FROM schema_version").fetchone()
            if row is None:
                conn.execute("INSERT INTO schema_version (version) VALUES (?)", (SCHEMA_VERSION,))
            elif int(row["version"]) == 1:
                # v1 predates flap_policy. Existing watches get 'auto', the
                # same default a fresh table gives new ones.
                conn.execute(
                    "ALTER TABLE watch ADD COLUMN flap_policy TEXT NOT NULL DEFAULT 'auto'"
                )
                conn.execute("UPDATE schema_version SET version = ?", (SCHEMA_VERSION,))
            elif int(row["version"]) != SCHEMA_VERSION:
                raise RuntimeError(
                    f"{self.path} is schema version {row['version']}, "
                    f"this build understands {SCHEMA_VERSION}"
                )
        os.chmod(self.path, 0o600)

    # — watches ————————————————————————————————————————————

    def add_watch(self, url: str, host: str, interval_seconds: int) -> Watch:
        watch = Watch(
            id=uuid.uuid4().hex[:12],
            url=url,
            host=host,
            interval_seconds=interval_seconds,
            created_at=_now(),
        )
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO watch (id, url, host, interval_seconds, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (watch.id, watch.url, watch.host, watch.interval_seconds, watch.created_at),
            )
        return watch

    def learned(self, watch_id: str, *, mask_json: str, anchors_json: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "UPDATE watch SET mask_json = ?, anchors_json = ? WHERE id = ?",
                (mask_json, anchors_json, watch_id),
            )

    def update_mask(self, watch_id: str, *, mask_json: str) -> None:
        """The mask alone. Anchors are stored raw and never need rewriting
        when the mask evolves — that asymmetry is deliberate (see
        :mod:`postcondition`)."""
        with self._connect() as conn:
            conn.execute(
                "UPDATE watch SET mask_json = ? WHERE id = ?", (mask_json, watch_id)
            )

    def update_mask_if_unchanged(
        self, watch_id: str, *, expected_json: str | None, new_json: str
    ) -> bool:
        """Compare-and-swap on mask_json.

        `serve` and a CLI `watch ignore` can both fold at once — the
        documented workflow is "the user reacts right after an alert", i.e.
        while the loop is running. Last-writer-wins would silently drop one
        fold; a failed swap tells the caller to re-read and retry.
        """
        with self._connect() as conn:
            cur = conn.execute(
                "UPDATE watch SET mask_json = ? WHERE id = ? AND mask_json IS ?",
                (new_json, watch_id, expected_json),
            )
            return cur.rowcount > 0

    def set_flap_policy(self, watch_id: str, policy: str) -> None:
        if policy not in ("auto", "manual"):
            raise ValueError(f"flap policy is 'auto' or 'manual', not {policy!r}")
        with self._connect() as conn:
            conn.execute(
                "UPDATE watch SET flap_policy = ? WHERE id = ?", (policy, watch_id)
            )

    def clear_learning(self, watch_id: str) -> bool:
        """Forget the mask and anchors so the next check learns fresh.

        The observations stay — relearning is a new start for detection, not
        an eraser for the ledger.
        """
        with self._connect() as conn:
            cur = conn.execute(
                "UPDATE watch SET mask_json = NULL, anchors_json = NULL "
                "WHERE id = ? AND retired_at IS NULL",
                (watch_id,),
            )
            return cur.rowcount > 0

    def get_watch(self, watch_id: str) -> Watch | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM watch WHERE id = ?", (watch_id,)).fetchone()
        return _watch_from(row) if row else None

    def list_watches(self, *, include_retired: bool = False) -> list[Watch]:
        sql = "SELECT * FROM watch"
        if not include_retired:
            sql += " WHERE retired_at IS NULL"
        sql += " ORDER BY created_at"
        with self._connect() as conn:
            rows = conn.execute(sql).fetchall()
        return [_watch_from(r) for r in rows]

    def retire_watch(self, watch_id: str) -> bool:
        """Stop checking it, keep everything.

        Not a DELETE. The observations are the record of how well this worked,
        and removing a watch must not double as a way to erase a bad week —
        the foreign key makes that structural rather than a promise. A retired
        watch keeps its final durability number in the ledger, which is what
        the spec's `retired` status is for.
        """
        with self._connect() as conn:
            cur = conn.execute(
                "UPDATE watch SET retired_at = ? WHERE id = ? AND retired_at IS NULL",
                (_now(), watch_id),
            )
            return cur.rowcount > 0

    # — observations ————————————————————————————————————

    def record(
        self,
        watch_id: str,
        *,
        status: str,
        reason: str | None = None,
        content_hash: str | None = None,
        changed: bool = False,
        elapsed_ms: int = 0,
    ) -> Observation:
        obs = Observation(
            watch_id=watch_id,
            at=_now(),
            status=status,
            reason=reason,
            content_hash=content_hash,
            changed=changed,
            elapsed_ms=elapsed_ms,
        )
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO observation "
                "(watch_id, at, status, reason, content_hash, changed, elapsed_ms) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    obs.watch_id,
                    obs.at,
                    obs.status,
                    obs.reason,
                    obs.content_hash,
                    int(obs.changed),
                    obs.elapsed_ms,
                ),
            )
        return obs

    def last_ok_content_hash(self, watch_id: str) -> str | None:
        """The newest successful observation's content hash, however far back.

        One indexed query rather than a capped Python scan — a change that
        lands after a long outage must still be compared against the last
        thing actually seen, not silently become the new baseline.
        """
        with self._connect() as conn:
            row = conn.execute(
                "SELECT content_hash FROM observation "
                "WHERE watch_id = ? AND status = 'ok' AND content_hash IS NOT NULL "
                "ORDER BY id DESC LIMIT 1",
                (watch_id,),
            ).fetchone()
        return row["content_hash"] if row else None

    def failure_streak_before_latest(self, watch_id: str) -> int:
        """Consecutive non-ok observations immediately before the newest row.

        The scheduler's "speak on the second consecutive failure" rule needs
        the streak *excluding* the observation just written, and it must not
        stop counting at an arbitrary history cap.
        """
        with self._connect() as conn:
            latest = conn.execute(
                "SELECT MAX(id) AS id FROM observation WHERE watch_id = ?",
                (watch_id,),
            ).fetchone()["id"]
            if latest is None:
                return 0
            last_ok = conn.execute(
                "SELECT MAX(id) AS id FROM observation "
                "WHERE watch_id = ? AND status = 'ok' AND id < ?",
                (watch_id, latest),
            ).fetchone()["id"]
            row = conn.execute(
                "SELECT COUNT(*) AS n FROM observation "
                "WHERE watch_id = ? AND id > ? AND id < ?",
                (watch_id, last_ok or 0, latest),
            ).fetchone()
        return int(row["n"])

    def history(self, watch_id: str, limit: int = 50) -> list[Observation]:
        # Ordered by id — insertion order — like every other ledger query
        # here. Ordering by timestamp text invites an NTP step backwards (or
        # two rows in one microsecond) to reorder the fold window and
        # manufacture templates out of sequence.
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM observation WHERE watch_id = ? ORDER BY id DESC LIMIT ?",
                (watch_id, limit),
            ).fetchall()
        return [_observation_from(r) for r in rows]

    def count_reason(self, watch_id: str, reason: str) -> int:
        """How many observations carry this reason — whole ledger, no cap."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS n FROM observation "
                "WHERE watch_id = ? AND reason = ?",
                (watch_id, reason),
            ).fetchone()
        return int(row["n"])

    def health(self, watch_id: str) -> Health | None:
        """The ledger row. `last_ok` is the number nobody else publishes."""
        watch = self.get_watch(watch_id)
        if watch is None:
            return None
        with self._connect() as conn:
            runs = conn.execute(
                "SELECT COUNT(*) AS n FROM observation WHERE watch_id = ?", (watch_id,)
            ).fetchone()["n"]
            last_ok = conn.execute(
                "SELECT MAX(at) AS at FROM observation WHERE watch_id = ? AND status = 'ok'",
                (watch_id,),
            ).fetchone()["at"]
            last_change = conn.execute(
                "SELECT MAX(at) AS at FROM observation WHERE watch_id = ? AND changed = 1",
                (watch_id,),
            ).fetchone()["at"]
            recent = conn.execute(
                "SELECT status FROM observation WHERE watch_id = ? ORDER BY id DESC",
                (watch_id,),
            ).fetchall()
        streak = 0
        for row in recent:
            if row["status"] == "ok":
                break
            streak += 1
        return Health(
            watch=watch,
            runs=int(runs),
            last_ok=last_ok,
            last_change=last_change,
            failure_streak=streak,
        )

    def totals(self) -> tuple[dict[str, int], dict[str, int]]:
        """Aggregate counts across every watch — and nothing else.

        This feeds `rokan report`, which exists to be pasted into a bug
        report or a tweet: numbers only. No hosts, no URLs, no content, no
        identifiers — a count cannot leak what someone watches. The second
        dict is failures by reason code (a fixed enum, equally shareable):
        without it, self-selection biases every shared number upward and the
        bias is invisible.

        A human `watch ignore` writes a ledger row that is not a check; it
        is excluded from the `checks` count because the unattended survival
        rate — checks completing with no human — is a launch gate, and an
        inflated denominator flatters it.
        """
        with self._connect() as conn:
            watches = conn.execute(
                "SELECT COUNT(*) AS n, "
                "SUM(CASE WHEN retired_at IS NULL THEN 1 ELSE 0 END) AS active "
                "FROM watch"
            ).fetchone()
            observations = conn.execute(
                "SELECT COUNT(*) AS n, "
                "SUM(CASE WHEN status = 'ok' THEN 1 ELSE 0 END) AS ok, "
                "SUM(CASE WHEN changed = 1 THEN 1 ELSE 0 END) AS changed, "
                "SUM(CASE WHEN status = 'abstained' THEN 1 ELSE 0 END) AS abstained "
                "FROM observation "
                "WHERE reason IS NULL OR reason != 'mask_extended_manual'"
            ).fetchone()
            # Folds count BOTH kinds — each one was a mask change the user
            # was told about — while only the automatic kind is also a check.
            folds = conn.execute(
                "SELECT COUNT(*) AS n FROM observation "
                "WHERE reason IN ('mask_extended', 'mask_extended_manual')"
            ).fetchone()
            failure_rows = conn.execute(
                "SELECT reason, COUNT(*) AS n FROM observation "
                "WHERE status NOT IN ('ok') AND reason IS NOT NULL "
                "GROUP BY reason ORDER BY n DESC, reason"
            ).fetchall()
        totals = {
            "watches": int(watches["n"] or 0),
            "active": int(watches["active"] or 0),
            "checks": int(observations["n"] or 0),
            "ok": int(observations["ok"] or 0),
            "changes": int(observations["changed"] or 0),
            "abstained": int(observations["abstained"] or 0),
            "folds": int(folds["n"] or 0),
        }
        failures = {str(r["reason"]): int(r["n"]) for r in failure_rows}
        return totals, failures

    # — content ————————————————————————————————————————

    def put_blob(self, text: str) -> str:
        """Store one observation's canonical text, addressed by its hash.

        Identical content lands on the same path, so a watch that reports "no
        change" for a month costs one copy rather than thirty.
        """
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        target = blobs_dir() / digest[:2] / digest
        target.parent.mkdir(parents=True, exist_ok=True)
        os.chmod(target.parent, 0o700)
        if target.exists():
            os.utime(target, None)
        else:
            paths.write_private(target, text)
        return digest

    # — garbage collection ————————————————————————————————

    def blob_referrers(self) -> list[tuple[str, str]]:
        found: list[tuple[str, str]] = []
        with self._connect() as conn:
            tables = [
                str(r["name"])
                for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type = 'table'"
                ).fetchall()
            ]
            for table in tables:
                for col in conn.execute(f'PRAGMA table_info("{table}")').fetchall():
                    if str(col["name"]).endswith(BLOB_REF_SUFFIX):
                        found.append((table, str(col["name"])))
        return found

    def live_digests(self, *, keep: int | None = GC_KEEP_PER_WATCH) -> set[str]:
        live: set[str] = set()
        with self._connect() as conn:
            for table, column in self.blob_referrers():
                if (table, column) == ("observation", "content_hash") and keep is not None:
                    rows = conn.execute(
                        "SELECT content_hash FROM observation o WHERE content_hash IS NOT NULL "
                        "AND id IN (SELECT id FROM observation WHERE watch_id = o.watch_id "
                        "ORDER BY id DESC LIMIT ?)",
                        (keep,),
                    ).fetchall()
                    rows += conn.execute(
                        "SELECT content_hash FROM observation o WHERE status = 'ok' "
                        "AND content_hash IS NOT NULL AND id = (SELECT MAX(id) FROM observation "
                        "WHERE watch_id = o.watch_id AND status = 'ok' "
                        "AND content_hash IS NOT NULL)"
                    ).fetchall()
                else:
                    rows = conn.execute(
                        f'SELECT "{column}" FROM "{table}" WHERE "{column}" IS NOT NULL'
                    ).fetchall()
                live.update(str(r[0]) for r in rows)
        return live

    def gc(
        self,
        *,
        dry_run: bool = False,
        keep: int | None = GC_KEEP_PER_WATCH,
        grace_seconds: float = GC_GRACE_SECONDS,
        now: float | None = None,
    ) -> GcReport:
        """Delete blob files nothing points at any more. Ledger rows are
        never touched; a watch's history keeps its digests, and the engine
        already tolerates content that is gone.

        A put that dedupes against an old file and a gc that unlinks it can
        still cross in the same instant; the next check compares digests,
        not content, so the cost is one thinner fold window, never a wrong
        alert.
        """
        if self.path != db_file():
            raise RuntimeError("gc runs only against the home database")
        root = blobs_dir()
        candidates = [
            f for f in root.glob("??/*") if f.is_file() and _DIGEST.match(f.name)
        ]
        live = self.live_digests(keep=keep)
        cutoff = (now if now is not None else time.time()) - grace_seconds
        reclaimable = 0
        deleted = 0
        size = 0
        for file in candidates:
            if file.name in live:
                continue
            try:
                st = file.stat()
            except FileNotFoundError:
                continue
            if st.st_mtime > cutoff:
                continue
            reclaimable += 1
            size += st.st_size
            if dry_run:
                continue
            try:
                file.unlink()
            except FileNotFoundError:
                continue
            deleted += 1
        return GcReport(len(candidates), len(live), reclaimable, deleted, size)

    def get_blob(self, digest: str) -> str | None:
        target = blobs_dir() / digest[:2] / digest
        if not target.exists():
            return None
        with closing(target.open(encoding="utf-8")) as fh:
            return fh.read()


def _watch_from(row: sqlite3.Row) -> Watch:
    return Watch(
        id=row["id"],
        url=row["url"],
        host=row["host"],
        interval_seconds=int(row["interval_seconds"]),
        created_at=row["created_at"],
        mask_json=row["mask_json"],
        anchors_json=row["anchors_json"],
        paused=bool(row["paused"]),
        flap_policy=row["flap_policy"],
        retired_at=row["retired_at"],
    )


def _observation_from(row: sqlite3.Row) -> Observation:
    return Observation(
        watch_id=row["watch_id"],
        at=row["at"],
        status=row["status"],
        reason=row["reason"],
        content_hash=row["content_hash"],
        changed=bool(row["changed"]),
        elapsed_ms=int(row["elapsed_ms"]),
    )


def dumps(obj: object) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))
