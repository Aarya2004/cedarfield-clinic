"""Why something did not happen, and what the person should do about it.

The failure path is the surface most likely to be exercised on a machine that
is not ours. An agent handed a ``reason`` with no ``next_step`` is stuck, and a
human who hits a code we never documented concludes the tool is broken. So the
two are welded together here and the weld is tested: a reason without guidance,
or without a README row, fails the build.

Taxonomy is spec §11.
"""

from __future__ import annotations

from enum import StrEnum


class Reason(StrEnum):
    """Every way a run can end other than plainly working."""

    # — credentials and login ————————————————————————————————
    NO_CREDENTIAL = "no_credential"
    LOGIN_REJECTED = "login_rejected"
    #: The page offered is a REGISTRATION form, not a sign-in one. `login`
    #: has emitted this string since it was written; the enum had no member,
    #: so `executor` bucketed it as ABSTAINED_LOW_CONFIDENCE — which is not
    #: a world failure, so the ladder was walked against a signup form and
    #: the user was told to rephrase (Opus architecture audit, S8).
    SIGNUP_PAGE = "signup_page"
    TOTP_REQUIRED_NO_SEED = "totp_required_no_seed"
    EMAIL_CODE_REQUIRED = "email_code_required"
    CAPTCHA_BLOCKED = "captcha_blocked"
    LOGIN_FORM_NOT_FOUND = "login_form_not_found"
    SUBMIT_NOT_FOUND = "submit_not_found"
    SESSION_UNRECOVERABLE = "session_unrecoverable"
    #: The sign-in form is not on the site the credential belongs to.
    #:
    #: Its own class because it is the one refusal that is about safety
    #: rather than capability. Everything else here means Rokan could not do
    #: the thing; this means Rokan would not, and the user needs to know a
    #: redirect took them somewhere their password does not belong.
    CREDENTIAL_ORIGIN_REFUSED = "credential_origin_refused"
    #: The page moved to another origin WHILE a credential was being typed.
    #:
    #: Distinct from a refusal because nothing was prevented: the keystrokes
    #: are already sent and cannot be recalled. A pre-check cannot be made
    #: atomic with a keystroke, so the honest design is to detect the window
    #: being hit and tell the person to rotate — silence is what would make
    #: this unacceptable.
    CREDENTIAL_MAY_BE_EXPOSED = "credential_may_be_exposed"

    # — environment and input ——————————————————————————————
    BROWSER_UNAVAILABLE = "browser_unavailable"
    NAVIGATION_FAILED = "navigation_failed"
    INVALID_URL = "invalid_url"
    TOO_MANY_STEPS = "too_many_steps"
    QUOTA_EXHAUSTED = "quota_exhausted"

    # — safety ————————————————————————————————————————————
    DRIFT_DETECTED = "drift_detected"
    NEGATIVE_POSTCONDITION_VIOLATED = "negative_postcondition_violated"
    NEEDS_APPROVAL = "needs_approval"

    # — deliberate abstention ————————————————————————————
    ABSTAINED_NO_REPAIR_CLASS = "abstained_no_repair_class"
    #: The model provider is unreachable or refuses us. Named separately
    #: because it is neither a bad request nor a page problem, and the two it
    #: used to share a class with sent the user advice about rephrasing a
    #: request that was fine. Abstained, because no retry and no bigger model
    #: fixes a key that is missing or rejected.
    ABSTAINED_PLANNER_UNAVAILABLE = "abstained_planner_unavailable"
    ABSTAINED_LOW_CONFIDENCE = "abstained_low_confidence"
    ABSTAINED_SCORER_DISAGREEMENT = "abstained_scorer_disagreement"


#: Guidance a person or an agent can actually act on. Never blank — blank
#: guidance is worse than none, because it looks answered.
NEXT_STEPS: dict[Reason, str] = {
    Reason.NO_CREDENTIAL: "Run: rokan save-login <site>",
    Reason.LOGIN_REJECTED: (
        "Check the password, then run: rokan save-login <site>. Rokan tried "
        "once and stopped — repeated attempts lock accounts."
    ),
    Reason.TOTP_REQUIRED_NO_SEED: (
        "Run: rokan save-login <site> and paste the 'setup key' shown beside "
        "the QR code."
    ),
    Reason.EMAIL_CODE_REQUIRED: (
        "Switch the account to an authenticator app, or watch a page that does "
        "not ask for a code."
    ),
    Reason.CAPTCHA_BLOCKED: (
        "Run: ROKAN_BROWSER_WATCH=1 rokan check <id> — solve it in the window "
        "that opens and the session is reused afterwards. Rokan never solves "
        "these itself."
    ),
    Reason.LOGIN_FORM_NOT_FOUND: (
        "Run: rokan watch add <url> for a page reachable with a password login."
    ),
    Reason.SUBMIT_NOT_FOUND: "Report the site: https://rokan.computer",
    Reason.SIGNUP_PAGE: (
        "That link opens a sign-UP form. Sign in yourself once in a browser, "
        "then run: rokan save-login <site>."
    ),
    Reason.CREDENTIAL_MAY_BE_EXPOSED: (
        "Run: change this password on the site now, then update it with "
        "rokan save-login."
    ),
    Reason.CREDENTIAL_ORIGIN_REFUSED: (
        "Check where that link leads: open it yourself and confirm the "
        "sign-in page is on the site you expected."
    ),
    Reason.SESSION_UNRECOVERABLE: (
        "Confirm the login works in a normal browser, then run: rokan check <id>."
    ),
    Reason.BROWSER_UNAVAILABLE: (
        "Run: {python} -m playwright install chromium — this exact "
        "interpreter; a different one installs into the wrong place."
    ),
    Reason.NAVIGATION_FAILED: (
        "Nothing to do unless it keeps happening — then check the URL."
    ),
    Reason.INVALID_URL: "Give a full URL including the scheme, e.g. https://example.com/usage",
    Reason.TOO_MANY_STEPS: "Run: rokan check <id> to see where it stopped.",
    Reason.QUOTA_EXHAUSTED: (
        "Wait for the next period, or reduce how often this watch runs."
    ),
    Reason.DRIFT_DETECTED: "Run: rokan watch relearn <id>, then rokan check <id>.",
    Reason.NEGATIVE_POSTCONDITION_VIOLATED: (
        "Inspect the site before running this watch again. Rokan will not "
        "retry on its own."
    ),
    Reason.NEEDS_APPROVAL: "Run: rokan check <id> and confirm.",
    Reason.ABSTAINED_NO_REPAIR_CLASS: "Run: rokan check <id> to see the page yourself.",
    Reason.ABSTAINED_PLANNER_UNAVAILABLE: (
        "Run: export ANTHROPIC_API_KEY=... and try the same command again."
    ),
    Reason.ABSTAINED_LOW_CONFIDENCE: "Run: rokan check <id> to see the page yourself.",
    Reason.ABSTAINED_SCORER_DISAGREEMENT: "Run: rokan check <id> to see the page yourself.",
}


#: Reasons where automated repair has a **0% ceiling**: no retry, no
#: self-healing and no amount of cleverness resolves them, because the missing
#: thing is a human action. These must abstain rather than burn attempts.
#:
#: Two entries earn their place for safety rather than futility:
#:
#: * ``LOGIN_REJECTED`` — a retry is not merely useless, it locks the account.
#: * ``NEGATIVE_POSTCONDITION_VIOLATED`` — something changed that should not
#:   have. Retrying could apply that change a second time. **Stopping is the
#:   entire value of having detected it.**
NO_REPAIR: frozenset[Reason] = frozenset(
    {
        Reason.NO_CREDENTIAL,
        Reason.LOGIN_REJECTED,
        Reason.SIGNUP_PAGE,
        Reason.TOTP_REQUIRED_NO_SEED,
        Reason.EMAIL_CODE_REQUIRED,
        Reason.CAPTCHA_BLOCKED,
        Reason.LOGIN_FORM_NOT_FOUND,
        Reason.SESSION_UNRECOVERABLE,
        Reason.CREDENTIAL_ORIGIN_REFUSED,
        Reason.CREDENTIAL_MAY_BE_EXPOSED,
        Reason.BROWSER_UNAVAILABLE,
        Reason.INVALID_URL,
        Reason.QUOTA_EXHAUSTED,
        Reason.NEEDS_APPROVAL,
        Reason.NEGATIVE_POSTCONDITION_VIOLATED,
        Reason.ABSTAINED_NO_REPAIR_CLASS,
        Reason.ABSTAINED_PLANNER_UNAVAILABLE,
        Reason.ABSTAINED_LOW_CONFIDENCE,
        Reason.ABSTAINED_SCORER_DISAGREEMENT,
    }
)


def next_step_for(reason: Reason) -> str:
    """Guidance for a reason. Raises rather than return a placeholder.

    ``{python}`` in a template becomes the running interpreter. A bare
    ``python -m playwright`` hint fails exactly the user it is for: under a
    venv or uvx their shell python has no playwright, so the generic command
    installs into the wrong place and the error comes straight back
    (BUILD-PLAN A1; the sister package pins this and this table had drifted).
    """
    import sys

    try:
        return NEXT_STEPS[reason].format(python=sys.executable)
    except KeyError as exc:  # pragma: no cover — the contract test prevents this
        raise KeyError(f"{reason} has no next_step; add one to NEXT_STEPS") from exc


def is_no_repair(reason: Reason) -> bool:
    """True when retrying or self-repair cannot help, so Rokan must abstain."""
    return reason in NO_REPAIR
