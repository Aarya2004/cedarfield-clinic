"""Rokan — cron for the logged-in web.

Layout, and the rule that governs it:

* ``core/`` is the engine. It may import the standard library and the proven
  pieces of ``rokan-mcp``. **It may never import a transport** — not ``mcp``,
  not ``click``, not ``fastapi``. A transport is how someone talks to Rokan;
  it is not what Rokan is.
* ``adapters/`` holds the transports. Each one is a *client* of the engine.

Enforced by ``tests/test_boundary.py``, which also proves the harder claim:
delete the whole MCP adapter and the engine still builds and still passes its
tests. That is the difference between a product and a plugin.
"""

from __future__ import annotations

__version__ = "0.0.1"
__all__ = ["__version__"]
