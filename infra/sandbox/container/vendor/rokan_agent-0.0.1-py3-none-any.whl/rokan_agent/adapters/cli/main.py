"""The ``rokan`` command. Shapes come from BUILD-PLAN Part A.

argparse rather than click, matching ``rokan-mcp``: the CLI is the surface a
stranger meets first and should not drag a dependency in to print help.

**Credentials are entered here and nowhere else.** A password typed at a
terminal never reaches a model, a transcript or a log — which is why
``save-login`` prompts rather than accepting an argument. No command may take
one on the command line, where it would land in shell history and in ``ps``.
"""

from __future__ import annotations

import argparse
import asyncio
import getpass
import sys
from datetime import UTC, datetime
from pathlib import Path

from ...core.engine import Engine
from ...core.result import Status
from ...core.store import GC_KEEP_PER_WATCH, Health
from .render import render


def _out(msg: str = "") -> None:
    print(msg, file=sys.stdout)


def _err(msg: str) -> None:
    print(msg, file=sys.stderr)


def _ago(iso: str | None) -> str:
    """`2h ago`. A6 wants a bank statement, not a timestamp to decode."""
    if not iso:
        return "never"
    try:
        then = datetime.fromisoformat(iso)
    except ValueError:
        return "?"
    seconds = int((datetime.now(UTC) - then).total_seconds())
    if seconds < 60:
        return "just now"
    for unit, size in (("d", 86400), ("h", 3600), ("m", 60)):
        if seconds >= size:
            return f"{seconds // size}{unit} ago"
    return "just now"


def cmd_save_login(args: argparse.Namespace, engine: Engine) -> int:
    _out(f"Storing a login for {args.site}.")
    _out("Nothing typed here is sent anywhere — it is encrypted on this machine.")
    _out()
    try:
        username = input("Username or email: ").strip()
        password = getpass.getpass("Password (hidden): ")
        totp = getpass.getpass("TOTP setup key (hidden, blank to skip): ").strip()
    except (EOFError, KeyboardInterrupt):
        _err("\ncancelled — nothing was stored")
        return 2
    try:
        host, has_totp = engine.save_login(args.site, username, password, totp or None)
    except ValueError as exc:
        _err(f"error: {exc}")
        return 2
    _out()
    _out(f"Saved {username} for {host}{' with two-factor' if has_totp else ''}.")
    _out(f'Try it:  rokan watch add "https://{host}/"')
    return 0


def cmd_logins(_args: argparse.Namespace, engine: Engine) -> int:
    rows = engine.list_logins()
    if not rows:
        _out("no logins stored yet")
        _out("  Run: rokan save-login <site>")
        return 0
    for row in rows:
        mark = " · two-factor" if row.get("has_totp") else ""
        _out(f"  {row['host']:28s}{row['username']}{mark}")
    return 0


def cmd_forget(args: argparse.Namespace, engine: Engine) -> int:
    if engine.forget_login(args.site):
        _out(f"forgot {args.site}")
        return 0
    _err(f"no stored login for {args.site}")
    return 2


def cmd_watch(args: argparse.Namespace, engine: Engine) -> int:
    if args.watch_cmd == "add":
        try:
            watch = engine.add_watch(args.url, args.every)
        except ValueError as exc:
            _err(f"error: {exc}")
            return 2
        _out(f"watching {watch.host} every {args.every}   id {watch.id}")
        _out(f"  Run: rokan check {watch.id}    to learn the page now")
        return 0
    if args.watch_cmd == "rm":
        if engine.remove_watch(args.id):
            _out(f"retired {args.id} — its history is kept")
            return 0
        _err(f"no active watch with id {args.id}")
        return 2
    if args.watch_cmd == "ignore":
        try:
            result = engine.ignore_flapping_line(args.id, apply=args.yes)
        except ValueError as exc:
            _err(f"error: {exc}")
            return 2
        code = render(result)
        if not args.yes and result.status.value == "ok":
            _out(f"  Run: rokan watch ignore {args.id} --yes    to apply")
        return code
    if args.watch_cmd == "relearn":
        if engine.relearn_watch(args.id):
            _out(f"forgot what {args.id} learned — its history is kept")
            _out(f"  Run: rokan check {args.id}    to learn the page again")
            return 0
        _err(f"no active watch with id {args.id}")
        return 2
    watches = engine.list_watches()
    if not watches:
        _out("no watches yet")
        _out('  Run: rokan watch add "https://example.com/usage"')
        return 0
    for watch in watches:
        every = watch.interval_seconds // 60
        _out(f"  {watch.id}  {watch.host:28s}every {every}m   {watch.url}")
    return 0


def cmd_check(args: argparse.Namespace, engine: Engine) -> int:
    try:
        result = asyncio.run(engine.check_now(args.id))
    except ValueError as exc:
        _err(f"error: {exc}")
        return 2
    return render(result)


def cmd_status(args: argparse.Namespace, engine: Engine) -> int:
    """A6's ledger. `LAST OK` is the number nobody else publishes."""
    if getattr(args, "dot", False):
        import rokan_agent

        script = Path(rokan_agent.__file__).parent / "contrib" / "rokan.30s.sh"
        _out("The presence dot is a SwiftBar plugin (brew install swiftbar), then:")
        _out(f"  cp {script} ~/Documents/SwiftBar/")
        return 0
    from ...core.proven import paths as proven_paths

    # The dot's "changes since you last looked" clock: looking = running
    # status. A touch-file, not schema — the dot only ever reads.
    (proven_paths.home() / ".dot-seen").touch()
    rows: list[Health] = engine.status()
    if not rows:
        _out("no watches yet")
        return 0
    _out()
    _out(f"  {'SITE':<26}{'WATCH':<14}{'LEARNED':<12}{'LAST OK':<12}{'RUNS':<7}STATUS")
    healthy = 0
    for health in rows:
        if health.watch.is_retired:
            state = "retired"
        elif health.failure_streak == 0 and health.last_ok:
            state = "ok"
            healthy += 1
        elif health.last_ok is None:
            state = "unlearned"
        else:
            state = f"failing x{health.failure_streak}"
        _out(
            f"  {health.watch.host:<26}{health.watch.id:<14}"
            f"{_ago(health.watch.created_at):<12}{_ago(health.last_ok):<12}"
            f"{health.runs:<7}{state}"
        )
    _out()
    plural = "watch" if len(rows) == 1 else "watches"
    _out(f"  {len(rows)} {plural} · {healthy} healthy")
    from ...core import service_install

    service = service_install.state()
    if service.installed:
        # "Is it alive?" answered here, not in Activity Monitor. The
        # installed-but-not-running state is exactly what a tester needs to
        # see the morning something went wrong.
        _out(
            "  service: running in the background"
            if service.running
            else "  service: installed but NOT running — check ~/.rokan/serve.log"
        )
    return 0


def cmd_notify(args: argparse.Namespace, engine: Engine) -> int:
    action = getattr(args, "notify_cmd", None) or "status"

    if action == "set":
        _out("Connecting a Telegram bot so Rokan can reach you.")
        _out("Message @BotFather to create one; it gives you a token.")
        _out("Then message your bot once and open:")
        _out("  https://api.telegram.org/bot<token>/getUpdates   to find your chat id.")
        _out()
        try:
            chat_id = input("Chat id: ").strip()
            token = getpass.getpass("Bot token (hidden): ").strip()
        except (EOFError, KeyboardInterrupt):
            _err("\ncancelled — nothing was stored")
            return 2
        if not chat_id or not token:
            _err("error: both a chat id and a token are needed")
            return 2
        engine.notify_set(chat_id, token)
        _out()
        _out("Saved, encrypted on this machine.")
        _out("  Run: rokan notify test")
        return 0

    if action == "test":
        if not engine.notify_is_configured():
            _err("no notification channel configured")
            _err("  Run: rokan notify set")
            return 2
        if engine.notify_test():
            _out("sent — check your phone")
            return 0
        _err("could not deliver")
        _err("  Check the chat id and token, then run: rokan notify set")
        return 1

    if engine.notify_is_configured():
        _out("telegram configured")
        _out("  Run: rokan notify test")
    else:
        _out("no notification channel yet")
        _out("  Run: rokan notify set")
    return 0


def cmd_serve(args: argparse.Namespace, engine: Engine) -> int:
    """The loop. Silence is the default — it speaks when something happens."""
    from ...core import notify as notify_module
    from ...core import scheduler, service_install

    if getattr(args, "uninstall", False):
        for line in service_install.uninstall():
            _out(f"  {line}")
        return 0

    watches = engine.list_watches()
    if not watches and not getattr(args, "from_service", False):
        _err("no watches to run")
        _err('  Run: rokan watch add "https://example.com/usage"')
        return 2
    # Under launchd, zero watches must IDLE, never exit: exit 2 puts
    # KeepAlive into a ~10s spawn loop, and exit 0 kills the service
    # permanently and silently. The scheduler already sleeps POLL_SECONDS on
    # an empty list and picks up a watch added later, no reinstall needed.
    # Reachable by the most ordinary action there is: rm the last watch.

    if getattr(args, "install", False):
        if service_install.state().running:
            _err("the service is already running — nothing to do")
            _err("  Run: rokan status")
            return 2
        try:
            for line in service_install.install(service_install.resolve_program()):
                _out(f"  {line}")
        except RuntimeError as exc:
            _err(f"error: {exc}")
            return 1
        _out("  Run: rokan status")
        return 0

    if not getattr(args, "from_service", False) and service_install.state().running:
        # Two schedulers double-check every watch and double-send every
        # message. The ledger would show it, but the CLI should prevent it.
        # The launchd invocation itself carries --from-service, or this
        # guard would see itself and spin KeepAlive.
        _err("the installed service is already running these watches")
        _err("  Run: rokan serve --uninstall    to take them back to the foreground")
        return 2

    notifier = notify_module.load()
    if not engine.notify_is_configured():
        _out("warning: no notification channel — changes will print here only")
        _out("  Run: rokan notify set")
    _out(f"watching {len(watches)} {'page' if len(watches) == 1 else 'pages'} · ctrl-c to stop")

    async def _loop() -> int:
        ticks = await scheduler.serve(engine, notifier, max_rounds=args.rounds)
        for tick in ticks:
            if tick.notified:
                _out(f"  {tick.watch.host}: {str(tick.result.data)} · notified")
            elif tick.result.status is not Status.OK:
                why = tick.result.reason.value if tick.result.reason else "?"
                _out(f"  {tick.watch.host}: {why}")
            elif str(tick.result.data) == "changed":
                _out(f"  {tick.watch.host}: changed")
        return 0

    try:
        return asyncio.run(_loop())
    except KeyboardInterrupt:
        _out("stopped")
        return 0


def cmd_report(_args: argparse.Namespace, engine: Engine) -> int:
    """Numbers safe to paste anywhere: counts only, never a host, a URL or a
    byte of page content. Never sent anywhere by Rokan — printing is the
    whole feature; sharing is the user's move."""
    totals, failures = engine.store.totals()
    _out(
        f"{totals['active']} watches · {totals['checks']} checks · "
        f"{totals['changes']} changes reported"
    )
    _out(f"  ok {totals['ok']}   abstained {totals['abstained']}   "
         f"folds {totals['folds']}   retired {totals['watches'] - totals['active']}")
    if failures:
        # Reason codes are a fixed enum — as shareable as the counts, and
        # without them every shared number is biased upward by the failures
        # nobody can see.
        _out("  failures: " + " · ".join(f"{r} {n}" for r, n in failures.items()))
    return 0


def cmd_gc(args: argparse.Namespace, engine: Engine) -> int:
    """Counts only, like `report`: never a digest, a path or a byte of content."""
    report = engine.store.gc(dry_run=args.dry_run, keep=args.keep)
    verb = "would delete" if args.dry_run else "deleted"
    _out(
        f"{report.scanned} blobs · {report.live} live · "
        f"{verb} {report.reclaimable} ({report.bytes // 1024} KB)"
    )
    return 0


def cmd_version(_args: argparse.Namespace, engine: Engine) -> int:
    info = engine.info()
    _out(f"rokan {info.version} (engine core {info.proven_version})")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rokan",
        description="Cron for the logged-in web — watch pages behind your logins.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("save-login", help="store a login for one site (prompts; never an argument)")
    p.add_argument("site")
    p.set_defaults(func=cmd_save_login)

    p = sub.add_parser("logins", help="list stored logins, without decrypting them")
    p.set_defaults(func=cmd_logins)

    p = sub.add_parser("forget", help="delete a stored login")
    p.add_argument("site")
    p.set_defaults(func=cmd_forget)

    p = sub.add_parser(
        "watch",
        # Names all five. The summary said "add, list or remove" while the
        # subcommand also has `relearn` and `ignore` — and `relearn` is
        # what a drift refusal tells people to run, so the one command the
        # product hands them in a failure was missing from the list they
        # would look at first.
        help="add, list, remove, relearn or ignore a watch",
    )
    wsub = p.add_subparsers(dest="watch_cmd", required=True)
    w = wsub.add_parser("add", help="watch a page and report when it changes")
    w.add_argument("url")
    w.add_argument("--every", default="1h", help="check interval, e.g. 30m, 1h, 1d")
    wsub.add_parser("list", help="list watches")
    w = wsub.add_parser("rm", help="retire a watch, keeping its history")
    w.add_argument("id")
    w = wsub.add_parser(
        "relearn", help="forget the learned page shape; the next check learns fresh"
    )
    w.add_argument("id")
    w = wsub.add_parser(
        "ignore", help="stop reporting the one line that keeps changing"
    )
    w.add_argument("id")
    w.add_argument(
        "--yes", action="store_true", help="apply it (without this, only shows the line)"
    )
    p.set_defaults(func=cmd_watch)

    p = sub.add_parser("check", help="run one watch now, in the foreground")
    p.add_argument("id")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("status", help="the ledger — last ok, runs, failure streak")
    p.add_argument(
        "--dot",
        action="store_true",
        help="how to install the menu-bar presence dot",
    )
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("notify", help="connect or test the notification channel")
    nsub = p.add_subparsers(dest="notify_cmd")
    nsub.add_parser("set", help="connect a Telegram bot (prompts; never an argument)")
    nsub.add_parser("test", help="send yourself a test message")
    p.set_defaults(func=cmd_notify)

    p = sub.add_parser("serve", help="run the watches on their schedule")
    p.add_argument(
        "--rounds",
        type=int,
        default=None,
        help="stop after this many passes (default: run until stopped)",
    )
    mode = p.add_mutually_exclusive_group()
    mode.add_argument(
        "--install",
        action="store_true",
        help="run in the background from now on (survives reboot; macOS)",
    )
    mode.add_argument(
        "--uninstall",
        action="store_true",
        help="stop and remove the background service",
    )
    mode.add_argument(
        "--from-service", action="store_true", help=argparse.SUPPRESS
    )
    p.set_defaults(func=cmd_serve)

    p = sub.add_parser(
        "report", help="counts only — no hosts, no content; safe to share"
    )
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("gc", help="delete page content nothing points at; the ledger stays")
    p.add_argument("--dry-run", action="store_true", help="count, delete nothing")
    p.add_argument(
        "--keep", type=int, default=GC_KEEP_PER_WATCH, help="content kept per watch"
    )
    p.set_defaults(func=cmd_gc)

    p = sub.add_parser("version", help="print versions")
    p.set_defaults(func=cmd_version)

    return parser


#: Every top-level verb. Pinned by a test so the surface cannot drift silently.
COMMANDS = (
    "save-login",
    "logins",
    "forget",
    "watch",
    "check",
    "status",
    "notify",
    "serve",
    "report",
    "gc",
    "version",
)


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    engine = Engine()
    try:
        result: int = args.func(args, engine)
    except KeyboardInterrupt:
        raise
    except Exception as exc:  # noqa: BLE001 — the last line before the user
        # Under launchd an unhandled traceback exits 1, KeepAlive restarts
        # every ~10s, and the traceback repeats into ~/.rokan/serve.log until
        # the disk minds. One line, one exit — the log stays readable and a
        # crash loop writes sentences, not stack dumps.
        _err(f"error: {type(exc).__name__}: {exc}")
        return 1
    return result


if __name__ == "__main__":
    raise SystemExit(main())
