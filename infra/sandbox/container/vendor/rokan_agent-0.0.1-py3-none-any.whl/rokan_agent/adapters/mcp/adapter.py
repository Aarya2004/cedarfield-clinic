"""Exposes Rokan over MCP.

Imports the client and nothing else from inside this package — pinned by
``tests/test_boundary.py``. See ``client.py`` for why.
"""

from __future__ import annotations

from .client import ServiceClient

#: Kept small on purpose. **No tool may accept a password**: credentials are
#: typed at a terminal, never passed through a model's context.
TOOL_NAMES = ("rokan_watch_list", "rokan_check", "rokan_status")


def build_tools(client: ServiceClient | None = None) -> tuple[str, ...]:
    """Return the tool names this adapter would register."""
    _ = client or ServiceClient()
    return TOOL_NAMES
