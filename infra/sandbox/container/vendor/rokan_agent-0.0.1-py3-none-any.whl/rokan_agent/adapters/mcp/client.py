"""Talks to the running service. The MCP adapter's only door into Rokan.

The adapter deliberately does **not** import the engine. If it did, the engine
would live and die inside whichever host loaded the plugin, and Rokan would be
"a Claude Code plugin" rather than a program the user installed. Going through
a client instead means the service keeps running when the host restarts, and a
second transport is a new adapter rather than a rewrite.

Skeleton: the socket arrives with the service step.
"""

from __future__ import annotations


class ServiceUnavailable(RuntimeError):
    """The local service is not running and could not be started."""


class ServiceClient:
    """A connection to the local Rokan service."""

    def __init__(self, socket_path: str | None = None) -> None:
        self.socket_path = socket_path

    def call(self, command: str, args: dict[str, object] | None = None) -> dict[str, object]:
        raise NotImplementedError("the service socket arrives with the service step")
